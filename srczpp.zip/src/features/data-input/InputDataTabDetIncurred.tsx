"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as XLSX from "xlsx";
import { useEffect, useState } from "react";
import { useIncurredTableStore } from "@/stores/useIncurredTableStore";
import { useTrainDevideStoreDetIncurred } from "@/stores/trainDevideStoreDeterministycznyIncurred";
import { useTrainDevideStoreSummary } from "@/stores/trainDevideStoreSummary";
import { useLabelsStore } from "@/stores/useLabelsStore";
import { z } from "zod";
import { SheetSelectIncurred } from "@/components/SheetSelectIncurred";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardFooter,
} from "@/components/ui/card";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Loader2 } from "lucide-react";
import { VisuallyHidden } from "@/components/ui/visually-hidden";
import { DataTypeSelector } from "@/components/DataTypeSelector";
import type { DataType } from "@/components/DataTypeSelector";
import { HeadersSelector } from "@/components/HeadersSelector";
import { convertIncrementalToCumulative } from "@/utils/dataConversion";
import { validateDataValues, ValidationPresets } from "@/utils/dataValidation";
import Modal from "@/components/Modal";
import { resetAllStores } from "@/lib/resetAllStores";

/* ------------------------------------------------------------------ */
/* Zod – formularz (zakres + plik)                                     */
/* ------------------------------------------------------------------ */
const schema = z.object({
  rowStart: z.coerce.number().min(1),
  rowEnd: z.coerce.number().min(1),
  colStart: z.coerce.number().min(1),
  colEnd: z.coerce.number().min(1),
  file: z.any(),
});
type FormField = z.infer<typeof schema>;

/* ------------------------------------------------------------------ */
/* Dodatkowa walidacja zawartości Incurred (dziury, teksty, NaN)       */
/* Dostosuj warunki do rzeczywistego formatu arkusza Incurred.         */
/* ------------------------------------------------------------------ */
function localValidateDataValues(data: any[][]): boolean {
  // Ta funkcja została przeniesiona do @/utils/dataValidation
  // Używamy teraz importowanej wersji z ValidationPresets
  const result = validateDataValues(data, ValidationPresets.incurred());
  return result.isValid;
}

/* ------------------------------------------------------------------ */
/* GŁÓWNY KOMPONENT                                                    */
/* ------------------------------------------------------------------ */
export function InputDataTabIncurred() {
  /* ---------- Lokalny UI‑owy stan ---------- */
  const [showDialog, setShowDialog] = useState(false);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [showNoChangesDialog, setShowNoChangesDialog] = useState(false);
  const [showWarningDialog, setShowWarningDialog] = useState(false);
  const [showWarningModal, setShowWarningModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [pendingFormData, setPendingFormData] = useState<FormField | null>(null);
const setIncurredTriangle = useTrainDevideStoreDetIncurred(s => s.setIncurredTriangle);

  /* ---------- Zustand – store Incurred ---------- */
  const {
    workbook,
    isValid,
    selectedSheetJSON,
    // jeśli w store nie masz previousSheetJSON – usuń kolejną linijkę i kawałek logiki niżej
    previousSheetJSON,
    validationErrorReason,
    setWorkbook,
    getDefaultRange,
    setRangeAndUpdate,
    uploadedFileName,
    setUploadedFileName,
    selectedSheetName,
    lastApprovedSettings,
    setLastApprovedSettings,
  } = useIncurredTableStore();

  const { 
    incurredRowLabels: rowLabels, 
    incurredColumnLabels: columnLabels, 
    setIncurredRowLabels: setRowLabels, 
    setIncurredColumnLabels: setColumnLabels,
    globalRowLabels,
    globalColumnLabels,
    lastLoadedFile
  } = useLabelsStore();

  // Store Incurred dla funkcji czyszczących
  const incurredStore = useTrainDevideStoreDetIncurred();
  const summaryStore = useTrainDevideStoreSummary();

  // Store dla ustawień input'a
  // Store dla ustawień input'a - używamy indywidualnych ustawień z incurredTableStore
  const {
    dataType,
    setDataType,
    hasHeaders,
    setHasHeaders,
  } = useIncurredTableStore();

  /* ---------- React‑hook‑form ---------- */
  const { register, handleSubmit, watch, setValue } = useForm<FormField>({
    resolver: zodResolver(schema),
    defaultValues: {
      rowStart: 1,
      rowEnd: 1,
      colStart: 1,
      colEnd: 1,
    },
  });

  const file = watch("file");

  /* ---------- Synchronizacja zakresu z store’em ---------- */
  useEffect(() => {
    const { startRow, endRow, startCol, endCol } =
      useIncurredTableStore.getState();
    setValue("rowStart", startRow);
    setValue("rowEnd", endRow);
    setValue("colStart", startCol);
    setValue("colEnd", endCol);
  }, [setValue]);

  useEffect(() => {
    const unsub = useIncurredTableStore.subscribe((state) => {
      setValue("rowStart", state.startRow);
      setValue("rowEnd", state.endRow);
      setValue("colStart", state.startCol);
      setValue("colEnd", state.endCol);
    });
    return unsub;
  }, [setValue]);

  /* ---------- Ładowanie pliku ---------- */
  const handleFileLoad = () => {
    const f = file?.[0];
    if (!f) {
      alert("Najpierw wybierz plik.");
      return;
    }

    const reader = new FileReader();

    reader.onloadstart = () => {
      setIsLoading(true);
      setProgress(0);
    };

    reader.onprogress = (e) => {
      if (e.lengthComputable) {
        setProgress(Math.round((e.loaded / e.total) * 100));
      }
    };

    reader.onload = (evt) => {
      const binaryStr = evt.target?.result;
      if (typeof binaryStr === "string") {
        try {
          const wb = XLSX.read(binaryStr, { type: "binary" });

          // Reset tylko store'a dla zakładki Incurred (nie wszystkich store'ów)
          useIncurredTableStore.getState().resetData();
          setWorkbook(wb);
          useIncurredTableStore
            .getState()
            .setSelectedSheetName(wb.SheetNames[0]);

          setUploadedFileName(f.name);
        } catch (err) {
          alert("Błąd podczas wczytywania pliku: " + (err as Error).message);
        }
      } else {
        alert("Niepoprawny typ danych z FileReadera.");
      }

      setIsLoading(false);
      setProgress(0);
    };

    reader.onerror = () => {
      alert("Błąd podczas wczytywania pliku.");
      setIsLoading(false);
    };

    reader.readAsBinaryString(f);
  };

  /* ---------- Wykryj zakres automatycznie ---------- */
  const handleAutoRange = () => {
    const range = getDefaultRange();
    if (!range) return;
    setValue("rowStart", range.startRow);
    setValue("rowEnd", range.endRow);
    setValue("colStart", range.startCol);
    setValue("colEnd", range.endCol);
  };

  /* ---------- Sprawdzanie czy ustawienia się zmieniły ---------- */
  const hasSettingsChanged = (newData: FormField) => {
    console.log('🔍 Sprawdzanie zmian ustawień (Incurred):', {
      selectedSheetJSON: selectedSheetJSON?.length || 0,
      lastApprovedSettings,
      currentSheetName: selectedSheetName,
      newData,
      currentHasHeaders: hasHeaders,
      currentDataType: dataType
    });

    // Sprawdź czy nie ma zapisanych ostatnich ustawień - to oznacza pierwsze użycie
    if (!lastApprovedSettings) {
      console.log('❌ Brak ostatnich ustawień - pierwsze użycie (Incurred)');
      return false;
    }
    
    // Sprawdź czy arkusz się zmienił
    if (selectedSheetName !== lastApprovedSettings.sheetName) {
      console.log('✅ Arkusz się zmienił (Incurred):', selectedSheetName, '!=', lastApprovedSettings.sheetName);
      return true;
    }

    // Sprawdź czy zakres się zmienił
    if (newData.rowStart !== lastApprovedSettings.rowStart ||
        newData.rowEnd !== lastApprovedSettings.rowEnd ||
        newData.colStart !== lastApprovedSettings.colStart ||
        newData.colEnd !== lastApprovedSettings.colEnd) {
      console.log('✅ Zakres się zmienił (Incurred)');
      return true;
    }

    // 🆕 Sprawdź czy ustawienia nagłówków się zmieniły
    if (hasHeaders !== lastApprovedSettings.hasHeaders) {
      console.log('✅ Ustawienie nagłówków się zmieniło (Incurred):', hasHeaders, '!=', lastApprovedSettings.hasHeaders);
      return true;
    }

    // 🆕 Sprawdź czy typ danych się zmienił
    if (dataType !== lastApprovedSettings.dataType) {
      console.log('✅ Typ danych się zmienił (Incurred):', dataType, '!=', lastApprovedSettings.dataType);
      return true;
    }

    console.log('❌ Brak zmian (Incurred)');
    return false;
  };

  /* ---------- Submit formularza ---------- */
  const onSubmit = (data: FormField) => {
    console.log('📝 Submit formularza (Incurred):', data);
    
    // Sprawdź czy ustawienia się zmieniły względem już wczytanych danych
    const settingsChanged = hasSettingsChanged(data);
    console.log('🔄 Ustawienia się zmieniły (Incurred):', settingsChanged);
    
    if (settingsChanged) {
      // Zapisz dane formularza i pokaż modal ostrzeżenia
      console.log('⚠️ Pokazuję modal ostrzeżenia (Incurred)');
      setPendingFormData(data);
      setShowWarningModal(true);
      return;
    }

    // Jeśli nie ma zmian lub nie ma danych, wykonaj normalnie
    console.log('✅ Przetwarzam dane bez modala (Incurred)');
    processFormData(data);
  };

  // DODAJ
function toNumericTriangle(json: any[][], hasHeaders: boolean): (number|null)[][] {
  // Usuń pierwszy wiersz i pierwszą kolumnę niezależnie od nagłówków
  let body = Array.isArray(json) && json.length > 1 ? json.slice(1).map(row => row.slice(1)) : [];
  return body.map(row =>
    row.map(cell => (
      typeof cell === 'number'
        ? cell
        : (cell == null || cell === '' ? null : (Number.isFinite(Number(cell)) ? Number(cell) : null))
    ))
  );
}

  // Funkcja do przetwarzania danych formularza
  const processFormData = (data: FormField) => {
    // reset dialogów
    setShowDialog(false);
    setShowSuccessDialog(false);
    setShowNoChangesDialog(false);
    setShowWarningDialog(false);

    setRangeAndUpdate({
      startRow: data.rowStart,
      endRow: data.rowEnd,
      startCol: data.colStart,
      endCol: data.colEnd,
    });

    // analiza wyniku po aktualizacji zustanda
    setTimeout(() => {
      let {
        isValid: v,
        selectedSheetJSON: json,
        previousSheetJSON: prev, // usuń jeśli nie masz prev
      } = useIncurredTableStore.getState();

      // Zapisz nazwy kolumn i wierszy w zależności od ustawienia hasHeaders
      if (json && json.length > 0) {
        let rowNames: string[];
        let colNames: string[];
        
        if (hasHeaders) {
          // ZAWIERA podpisy - zczytujemy nazwy z pierwszej kolumny/wiersza
          rowNames = json.map((row, index) => 
            row[0] ? String(row[0]) : `Wiersz ${index + 1}`
          );
          
          colNames = json[0]?.map((cell, index) => 
            cell ? String(cell) : `Kolumna ${index + 1}`
          ) || [];
        } else {
          // NIE ZAWIERA podpisów - indeksujemy numerycznie od 0 
          rowNames = json.map((_, index) => `${index}`);
          colNames = json[0]?.map((_, index) => `${index}`) || [];
        }
        
        setRowLabels(rowNames);
        setColumnLabels(colNames);
        
        console.log('📝 Zapisano nazwy (Incurred, hasHeaders:', hasHeaders, '):', { rowNames, colNames });
      }

      // Jeśli wybrano dane inkrementalne, konwertuj je na skumulowane
      if (dataType === "incremental" && json) {
        console.log('🔄 Konwertuję dane inkrementalne na skumulowane (Incurred)...');
        const convertedData = convertIncrementalToCumulative(json);
        
        // Aktualizuj store z przekonwertowanymi danymi
        useIncurredTableStore.setState({ selectedSheetJSON: convertedData });
        json = convertedData;
        
        console.log('✅ Dane przekonwertowane (Incurred):', convertedData);
      }
      // DODAJ po ewentualnej konwersji i ustawieniu etykiet:
    if (json) {
      const numericTriangle = toNumericTriangle(json, hasHeaders);

      // to wystarczy, żeby ChooseDataStoch od razu widział trójkąt
      setIncurredTriangle(numericTriangle);

      console.log('✅ Zapisano incurredTriangle:', {
        rows: numericTriangle.length,
        colsFirstRow: numericTriangle[0]?.length ?? 0,
      });
    }


      const same =
        prev !== undefined && JSON.stringify(json) === JSON.stringify(prev);

      if (!v) {
        setShowDialog(true);
      } else if (same) {
        setShowNoChangesDialog(true);
      } else if (!localValidateDataValues(json || [])) {
        setShowWarningDialog(true);
      } else {
        setShowSuccessDialog(true);
        
        // Zapisz ostatnie zatwierdzone ustawienia po pomyślnym wczytaniu
        setLastApprovedSettings({
          sheetName: selectedSheetName || null,
          rowStart: data.rowStart,
          rowEnd: data.rowEnd,
          colStart: data.colStart,
          colEnd: data.colEnd,
          hasHeaders: hasHeaders,
          dataType: dataType,
        });
      }
    }, 0);
  };

  // Obsługa potwierdzenia w modalu
  const handleConfirmDataReplace = () => {
    resetAllStores(); 
    setShowWarningModal(false);
    
    // Wyczyść wszystkie obliczenia z zakładek Incurred (tak jak Reset współczynników)
    incurredStore.clearDevJResults();
    incurredStore.setFinalDevJ(undefined);
    incurredStore.clearAllDevFinalValues();
    incurredStore.clearFitCurveData();
    incurredStore.clearDevSummaryData();
    
    // 🆕 Wyczyść dane trójkąta żeby wymusiło przeliczenie
    incurredStore.setIncurredTriangle([]);
    
    // 🆕 Wyczyść trainDevideDetIncurred żeby wymusiło przeliczenie CL coefficients
    incurredStore.setTrainDevideDetIncurred(undefined);
    
    // Wyczyść tabele ResultSummary - gdy kasujemy dane Incurred
    summaryStore.clearSummaryData();
    
    if (pendingFormData) {
      processFormData(pendingFormData);
      setPendingFormData(null);
    }
  };

  // Obsługa anulowania w modalu
  const handleCancelDataReplace = () => {
    setShowWarningModal(false);
    setPendingFormData(null);
  };

  /* ------------------------------- JSX ------------------------------- */
  return (
    <div>
      {/* ---------- FORMULARZ ---------- */}
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="p-4 border rounded flex flex-col gap-4"
      >
        <Card>
          <CardHeader>
            <CardTitle>Wprowadź trójkąt danych incurred, który wykorzystasz w zakładce ,,Metody deterministyczne"</CardTitle>
          </CardHeader>

          <CardContent className="space-y-4">
            {/* --- Plik --- */}
            <div className="flex items-center gap-4">
              <input
                type="file"
                accept=".xlsx,.xls"
                className="border p-2 rounded-lg"
                {...register("file")}
              />
              <Button
                type="button"
                onClick={handleFileLoad}
                disabled={!file || file.length === 0}
                className="bg-blue-500 text-white"
              >
                Załaduj plik
              </Button>
              {uploadedFileName && (
                <span className="text-sm text-green-400 ml-2">
                  Wczytano: <strong>{uploadedFileName}</strong>
                </span>
              )}
            </div>

            {/* --- Arkusz --- */}
            <div>
              <Label>Wybór arkusza</Label>
              <SheetSelectIncurred />
            </div>

          <CardHeader>
            <CardTitle> Podaj zakres danych, które chcesz wczytać.</CardTitle>
          </CardHeader>
            {/* --- Zakres --- */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Wiersz początkowy</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register("rowStart")}
                />
              </div>
              <div>
                <Label>Wiersz końcowy</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register("rowEnd")}
                />
              </div>
              <div>
                <Label>Kolumna początkowa</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register("colStart")}
                />
              </div>
              <div>
                <Label>Kolumna końcowa</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register("colEnd")}
                />
              </div>
            </div>

            <Button
              type="button"
              onClick={handleAutoRange}
              variant="outline"
              disabled={!workbook}
              className="bg-blue-500 text-white"
            >
              Wykryj zakres automatycznie
            </Button>

            {/* --- Czy dane zawierają podpisy --- */}
            <HeadersSelector 
              hasHeaders={hasHeaders} 
              onHeadersChange={setHasHeaders} 
            />

            {/* --- Typ danych --- */}
            <DataTypeSelector
              dataType={dataType}
              onDataTypeChange={setDataType}
            />
          </CardContent>

          <CardFooter>
            <Button
              type="submit"
              className="bg-blue-500 text-white"
              disabled={!workbook}
            >
              Wybierz
            </Button>
          </CardFooter>
        </Card>
      </form>

      {/* ---------- ALERTY ---------- */}
      {/* Błąd formatu */}
      <AlertDialog open={showDialog} onOpenChange={setShowDialog}>
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center">
            <VisuallyHidden>
              <AlertDialogTitle>Błąd danych</AlertDialogTitle>
            </VisuallyHidden>
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-red-100 mb-4">
              <svg
                className="w-6 h-6 text-red-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </div>
            <AlertDialogDescription className="text-center text-red-600 font-medium">
              {validationErrorReason ||
                "Dane wejściowe nie spełniają określonego formatu. Sprawdź dane!"}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Zamknij</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Ostrzeżenie */}
      <AlertDialog
        open={showWarningDialog}
        onOpenChange={setShowWarningDialog}
      >
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center">
            <VisuallyHidden>
              <AlertDialogTitle>Ostrzeżenie</AlertDialogTitle>
            </VisuallyHidden>
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-yellow-100 mb-4">
              <svg
                className="w-6 h-6 text-yellow-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M13 16h-1v-4h-1m0-4h.01M12 20c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8z"
                />
              </svg>
            </div>
            <AlertDialogDescription className="text-center text-yellow-600 font-medium">
              Dane są w poprawnym formacie, ale zawierają braki lub niedozwolone
              wartości.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>OK</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Sukces */}
      <AlertDialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center">
            <VisuallyHidden>
              <AlertDialogTitle>Powiadomienie</AlertDialogTitle>
            </VisuallyHidden>
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-green-100 mb-4">
              <svg
                className="w-6 h-6 text-green-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M5 13l4 4L19 7"
                />
              </svg>
            </div>
            <AlertDialogDescription className="text-center text-green-600 font-medium">
              {dataType === "incremental" 
                ? "Dane inkrementalne zostały przekonwertowane na skumulowane i poprawnie wczytane (Incurred)."
                : "Dane skumulowane zostały poprawnie wczytane (Incurred)."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>OK</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Brak zmian */}
      <AlertDialog
        open={showNoChangesDialog}
        onOpenChange={setShowNoChangesDialog}
      >
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center">
            <VisuallyHidden>
              <AlertDialogTitle>Informacja</AlertDialogTitle>
            </VisuallyHidden>
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 mb-4">
              <svg
                className="w-6 h-6 text-blue-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M13 16h-1v-4h-1m0-4h.01M12 20c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8z"
                />
              </svg>
            </div>
            <AlertDialogDescription className="text-center text-blue-600 font-medium">
              Nie dokonano żadnych zmian w danych.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>OK</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Spinner podczas ładowania */}
      {isLoading && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-[#1e1e2f] rounded-lg p-8 flex flex-col items-center w-80">
            <Loader2 className="animate-spin h-10 w-10 text-white mb-6" />
            <div className="w-full bg-gray-700 rounded-full h-4 mb-4 overflow-hidden">
              <div
                className="bg-gray-300 h-full transition-all duration-300 ease-in-out"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="text-white text-sm font-medium">
              Ładowanie… {progress}%
            </div>
          </div>
        </div>
      )}

      {/* MODAL OSTRZEŻENIA O UTRACIE DANYCH */}
      <Modal
        title="Ostrzeżenie"
        message="Czy napewno chcesz wczytać dane? Wszystkie obliczenia w zakładce Metody deterministyczne, Incurred zostaną utracone."
        isOpen={showWarningModal}
        onConfirm={handleConfirmDataReplace}
        onCancel={handleCancelDataReplace}
      />
    </div>
  );
}
