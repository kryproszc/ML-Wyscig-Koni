'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as XLSX from 'xlsx';
import { useEffect, useState } from 'react';
import { useDetailTableStore } from '@/stores/useDetailTableStore';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useTrainDevideStoreSummary } from '@/stores/trainDevideStoreSummary';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { z } from 'zod';
import { SheetSelectDet } from '@/components/SheetSelectDet';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardFooter,
} from '@/components/ui/card';
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Loader2 } from 'lucide-react';
import { VisuallyHidden } from '@/components/ui/visually-hidden';
import { DataTypeSelector } from '@/components/DataTypeSelector';
import type { DataType } from '@/components/DataTypeSelector';
import { HeadersSelector } from '@/components/HeadersSelector';
import { convertIncrementalToCumulative } from '@/utils/dataConversion';
import { validateDataValues, ValidationPresets } from '@/utils/dataValidation';
import { FileUploadSection, RangeInputSection } from '@/components/InputFormSections';
import Modal from '@/components/Modal';
import { resetAllStores } from "@/lib/resetAllStores";

const schema = z.object({
  rowStart: z.coerce.number().min(1),
  rowEnd: z.coerce.number().min(1),
  colStart: z.coerce.number().min(1),
  colEnd: z.coerce.number().min(1),
  file: z.any(),
});
type FormField = z.infer<typeof schema>;

/* ---------- DODATKOWA WALIDACJA (dziury, nienumeryczne itd.) ---------- */
function localValidateDataValues(data: any[][]): boolean {
  // Ta funkcja została przeniesiona do @/utils/dataValidation
  // Używamy teraz importowanej wersji z ValidationPresets dla Paid
  const result = validateDataValues(data, ValidationPresets.paid());
  return result.isValid;
}



// --- AUTO-DETEKCJA NAGŁÓWKÓW ---
function isMostlyNonNumeric(arr: any[], threshold = 0.7) {
  const vals = arr.filter(v => v !== null && v !== undefined && v !== '');
  if (vals.length === 0) return false;
  let nonNum = 0;
  for (const v of vals) {
    if (typeof v !== 'number' && !Number.isFinite(Number(v))) nonNum++;
  }
  return nonNum / vals.length >= threshold;
}

function looksLikeYears(arr: any[], threshold = 0.7) {
  const vals = arr.filter(v => v !== null && v !== undefined && v !== '');
  if (vals.length === 0) return false;
  const years = vals.filter(v => {
    const n = Number(v);
    return Number.isFinite(n) && n >= 1900 && n <= 2100;
  }).length;
  return years / vals.length >= threshold;
}

function looksLikeDevPeriods(arr: any[], threshold = 0.7) {
  const nums = arr
    .map(v => Number(v))
    .filter(n => Number.isFinite(n) && n >= 0 && n <= 500);
  if (nums.length === 0) return false;

  let nonDecreasing = 0;
  for (let i = 1; i < nums.length; i++) {
    const curr = nums[i]!;     // <- wiemy, że istnieje
    const prev = nums[i - 1]!; // <- też istnieje
    if (curr >= prev) nonDecreasing++;
  }
  return (nonDecreasing / Math.max(1, nums.length - 1)) >= threshold;
}


/* --------------------------------------------------------------------- */
export function InputDataTabDet() {
  /* ---------- Lokalny UI‑owy stan ---------- */
  const [showDialog, setShowDialog] = useState(false);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [showNoChangesDialog, setShowNoChangesDialog] = useState(false);
  const [showWarningDialog, setShowWarningDialog] = useState(false);
  const [showWarningModal, setShowWarningModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [pendingFormData, setPendingFormData] = useState<FormField | null>(null);

  /* ---------- Zustanda – store „detaliczny” ---------- */
  const {
    workbook,
    isValid,
    selectedSheetJSON,
    previousSheetJSON,
    validationErrorReason,
    setWorkbook,
    getDefaultRange,
    setRangeAndUpdate,
    uploadedFileName,
    setUploadedFileName,
    selectedSheetName,
    lastApprovedSettings,
    setLastApprovedSettings,
  } = useDetailTableStore();

  const { 
    detRowLabels: rowLabels, 
    detColumnLabels: columnLabels, 
    setDetRowLabels: setRowLabels, 
    setDetColumnLabels: setColumnLabels,
    globalRowLabels,
    globalColumnLabels,
    lastLoadedFile
  } = useLabelsStore();

  // Store Paid dla funkcji czyszczących
  const paidStore = useTrainDevideStoreDet();
  const summaryStore = useTrainDevideStoreSummary();

const setPaidTriangle = useTrainDevideStoreDet((s) => s.setPaidTriangle);

  // Store dla ustawień input'a - używamy indywidualnych ustawień z detailTableStore
  const {
    dataType,
    setDataType,
    incrementDataGeneration,
    hasHeaders,
    setHasHeaders,
  } = useDetailTableStore();

  /* ---------- React‑hook‑form ---------- */
  const {
    register,
    handleSubmit,
    watch,
    setValue,
  } = useForm<FormField>({
    resolver: zodResolver(schema),
    defaultValues: {
      rowStart: 1,
      rowEnd: 1,
      colStart: 1,
      colEnd: 1,
    },
  });

  const file = watch('file');

  /* ---------- Synchronizacja zakresu z store’em ---------- */
  useEffect(() => {
    const { startRow, endRow, startCol, endCol } =
      useDetailTableStore.getState();
    setValue('rowStart', startRow);
    setValue('rowEnd', endRow);
    setValue('colStart', startCol);
    setValue('colEnd', endCol);
  }, [setValue]);

  useEffect(() => {
    const unsub = useDetailTableStore.subscribe((state) => {
      setValue('rowStart', state.startRow);
      setValue('rowEnd', state.endRow);
      setValue('colStart', state.startCol);
      setValue('colEnd', state.endCol);
    });
    return unsub;
  }, [setValue]);

  /* ---------- Ładowanie pliku ---------- */
  const handleFileLoad = () => {
    const f = file?.[0];
    if (!f) {
      alert('Najpierw wybierz plik.');
      return;
    }

    const reader = new FileReader();

    reader.onloadstart = () => {
      setIsLoading(true);
      setProgress(0);
    };

    reader.onprogress = (e) => {
      if (e.lengthComputable) {
        setProgress(Math.round((e.loaded / e.total) * 100));
      }
    };

    reader.onload = (evt) => {
      const binaryStr = evt.target?.result;
      if (typeof binaryStr === 'string') {
        try {
          const wb = XLSX.read(binaryStr, { type: 'binary' });

          // 🆕 Wyczyść paidTriangle PRZED resetowaniem DetailTableStore
          console.log('🧹 [handleFileLoad] Czyszczę paidTriangle przed wczytaniem nowego pliku...');
          paidStore.setPaidTriangle([]);
          
          // 🆕 Wyczyść trainDevideDet żeby wymusić przeliczenie w zakładce CL
          console.log('🧹 [handleFileLoad] Czyszczę trainDevideDet...');
          paidStore.setTrainDevideDet(undefined);
          
          // Reset tylko store'a dla zakładki Det (nie wszystkich store'ów)
          useDetailTableStore.getState().resetData();
          setWorkbook(wb);
          useDetailTableStore
            .getState()
            .setSelectedSheetName(wb.SheetNames[0]);

          setUploadedFileName(f.name);
        } catch (err) {
          alert('Błąd podczas wczytywania pliku: ' + (err as Error).message);
        }
      } else {
        alert('Niepoprawny typ danych z FileReadera.');
      }

      setIsLoading(false);
      setProgress(0);
    };

    reader.onerror = () => {
      alert('Błąd podczas wczytywania pliku.');
      setIsLoading(false);
    };

    reader.readAsBinaryString(f);
  };

  /* ---------- Wykryj zakres automatycznie ---------- */
  const handleAutoRange = () => {
    const range = getDefaultRange();
    if (!range) return;
    setValue('rowStart', range.startRow);
    setValue('rowEnd', range.endRow);
    setValue('colStart', range.startCol);
    setValue('colEnd', range.endCol);
  };

  /* ---------- Sprawdzanie czy ustawienia się zmieniły ---------- */
  const hasSettingsChanged = (newData: FormField) => {
    console.log('🔍 Sprawdzanie zmian ustawień:', {
      selectedSheetJSON: selectedSheetJSON?.length || 0,
      lastApprovedSettings,
      currentSheetName: selectedSheetName,
      newData,
      currentHasHeaders: hasHeaders,
      currentDataType: dataType
    });

    // Sprawdź czy nie ma zapisanych ostatnich ustawień - to oznacza pierwsze użycie
    if (!lastApprovedSettings) {
      console.log('❌ Brak ostatnich ustawień - pierwsze użycie');
      return false;
    }
    
    // Sprawdź czy arkusz się zmienił
    if (selectedSheetName !== lastApprovedSettings.sheetName) {
      console.log('✅ Arkusz się zmienił:', selectedSheetName, '!=', lastApprovedSettings.sheetName);
      return true;
    }

    // Sprawdź czy zakres się zmienił
    if (newData.rowStart !== lastApprovedSettings.rowStart ||
        newData.rowEnd !== lastApprovedSettings.rowEnd ||
        newData.colStart !== lastApprovedSettings.colStart ||
        newData.colEnd !== lastApprovedSettings.colEnd) {
      console.log('✅ Zakres się zmienił');
      return true;
    }

    // 🆕 Sprawdź czy ustawienia nagłówków się zmieniły
    if (hasHeaders !== lastApprovedSettings.hasHeaders) {
      console.log('✅ Ustawienie nagłówków się zmieniło:', hasHeaders, '!=', lastApprovedSettings.hasHeaders);
      return true;
    }

    // 🆕 Sprawdź czy typ danych się zmienił
    if (dataType !== lastApprovedSettings.dataType) {
      console.log('✅ Typ danych się zmienił:', dataType, '!=', lastApprovedSettings.dataType);
      return true;
    }

    console.log('❌ Brak zmian');
    return false;
  };

  /* ---------- Submit formularza ---------- */
  const onSubmit = (data: FormField) => {
    console.log('📝 Submit formularza:', data);
    
    // Sprawdź czy ustawienia się zmieniły względem już wczytanych danych
    const settingsChanged = hasSettingsChanged(data);
    console.log('🔄 Ustawienia się zmieniły:', settingsChanged);
    
    if (settingsChanged) {
      // Zapisz dane formularza i pokaż modal ostrzeżenia
      console.log('⚠️ Pokazuję modal ostrzeżenia');
      setPendingFormData(data);
      setShowWarningModal(true);
      return;
    }

    // Jeśli nie ma zmian lub nie ma danych, wykonaj normalnie
    console.log('✅ Przetwarzam dane bez modala');
    processFormData(data);
  };

  // Funkcja do przetwarzania danych formularza
const processFormData = (data: FormField) => {
  console.log('🔄 [processFormData] Rozpoczynam przetwarzanie danych...', data);

  // reset dialogów
  setShowDialog(false);
  setShowSuccessDialog(false);
  setShowNoChangesDialog(false);
  setShowWarningDialog(false);

  setRangeAndUpdate({
    startRow: data.rowStart,
    endRow: data.rowEnd,
    startCol: data.colStart,
    endCol: data.colEnd,
  });

  setTimeout(() => {
    let { isValid: v, selectedSheetJSON: json, previousSheetJSON: prev } =
      useDetailTableStore.getState();

    // (1) ewentualna konwersja inkrementalnych -> skumulowane
    if (dataType === 'incremental' && json) {
      const converted = convertIncrementalToCumulative(json);
      useDetailTableStore.setState({ selectedSheetJSON: converted });
      json = converted;
    }

// (2) budowa body + etykiet zgodnie z hasHeaders
let body: any[][] = [];
let rowNames: string[] = [];
let colNames: string[] = [];

if (json && json.length > 1) {
  if (hasHeaders) {
    // ✅ Mamy podpisy – wyciągamy je z pierwszego wiersza/kolumny
    colNames = (json[0] ?? []).slice(1).map(c => String(c ?? ''));
    rowNames = json.slice(1).map(r => String((r && r[0]) ?? ''));
    body = json.slice(1).map(r => r.slice(1)); // samo „ciało”
  } else {
    // ❌ Brak podpisów – generujemy 1..N po wycięciu pierwszego wiersza/kolumny
    body = json.slice(1).map(r => r.slice(1));
    rowNames = Array.from({ length: body.length }, (_, i) => String(i + 1));
    colNames = Array.from({ length: body[0]?.length || 0 }, (_, i) => String(i + 1));
  }

  // zapis etykiet do store'a
  setRowLabels(rowNames);
  setColumnLabels(colNames);

  // numericTriangle (number|null) na bazie body
  const numericTriangle: (number | null)[][] = body.map(row =>
    row.map(cell =>
      typeof cell === 'number'
        ? cell
        : cell == null || cell === ''
        ? null
        : Number.isFinite(Number(cell))
        ? Number(cell)
        : null
    )
  );
  setPaidTriangle(numericTriangle);

  // widok tabeli do podglądu (string|number)
  const sheetForStore: (string | number)[][] = body.map(row =>
    row.map(cell => (cell == null ? '' : typeof cell === 'number' ? cell : String(cell)))
  );
  useTrainDevideStoreDet.setState({ selectedSheetDet: sheetForStore });
}



    // (3) walidacje i komunikaty
    const same = JSON.stringify(json) === JSON.stringify(prev);

    if (!v) {
      setShowDialog(true);
    } else if (same) {
      setShowNoChangesDialog(true);
    } else if (!localValidateDataValues(body || [])) {
      setShowWarningDialog(true);
    } else {
      setShowSuccessDialog(true);
      setLastApprovedSettings({
        sheetName: selectedSheetName || null,
        rowStart: data.rowStart,
        rowEnd: data.rowEnd,
        colStart: data.colStart,
        colEnd: data.colEnd,
        hasHeaders,
        dataType,
      });
    }
  }, 0);
};



  



  // Obsługa potwierdzenia w modalu
  const handleConfirmDataReplace = () => {
    resetAllStores(); 
    console.log('🚨 [handleConfirmDataReplace] Rozpoczynam czyszczenie danych...');
    setShowWarningModal(false);
    
    // Wyczyść wszystkie obliczenia z zakładek Paid (tak jak Reset współczynników)
    paidStore.clearDevJResults();
    paidStore.setFinalDevJ(undefined);
    paidStore.clearAllDevFinalValues();
    paidStore.clearFitCurveData();
    paidStore.clearDevSummaryData();
    
    // 🆕 Wyczyść trainDevideDet żeby wymusić przeliczenie w zakładce CL
    console.log('🧹 [handleConfirmDataReplace] Czyszczę trainDevideDet...');
    paidStore.setTrainDevideDet(undefined);
    
    // 🆕 Wyczyść dane trójkąta żeby wymusiło przeliczenie
    console.log('🧹 [handleConfirmDataReplace] Czyszczę paidTriangle...', {
      currentTriangleLength: paidStore.paidTriangle?.length || 0,
      currentTriangleType: Array.isArray(paidStore.paidTriangle) ? 'array' : typeof paidStore.paidTriangle
    });
    paidStore.setPaidTriangle([]);
    console.log('🧹 [handleConfirmDataReplace] paidTriangle po wyczyszczeniu:', {
      newTriangleLength: paidStore.paidTriangle?.length || 0
    });
    
    // Wyczyść tabele ResultSummary - gdy kasujemy dane Paid
    summaryStore.clearSummaryData();
    
    if (pendingFormData) {
      console.log('📝 [handleConfirmDataReplace] Przetwarzam odłożone dane formularza...');
      
      // 🆕 Wymusimy odświeżenie komponentów przez incrementDataGeneration - PRZED processFormData
      console.log('🔄 [handleConfirmDataReplace] Incrementing dataGenerationId...');
      incrementDataGeneration();
      
      // Małe opóźnienie żeby React zdążył przetworzyć zmianę dataGenerationId
      setTimeout(() => {
        console.log('⏰ [handleConfirmDataReplace] Wywołuję processFormData po timeout...');
        processFormData(pendingFormData);
      }, 0);
      
      setPendingFormData(null);
    } else {
      console.log('⚠️ [handleConfirmDataReplace] Brak pendingFormData!');
    }
    console.log('✅ [handleConfirmDataReplace] Zakończono');
  };

  // Obsługa anulowania w modalu
  const handleCancelDataReplace = () => {
    setShowWarningModal(false);
    setPendingFormData(null);
  };

  /* ------------------------------- JSX ------------------------------- */
  return (
    <div>
      {/* ---------- FORMULARZ ---------- */}
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="p-4 border rounded flex flex-col gap-4"
      >
        <Card>
          <CardHeader>
            <CardTitle>Wprowadź trójkąt danych paid, który wykorzystasz w zakładce ,,Metody deterministyczne"</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* --- Plik --- */}
            <div className="flex items-center gap-4">
              <input
                type="file"
                accept=".xlsx,.xls"
                className="border p-2 rounded-lg"
                {...register('file')}
              />
              <Button
                type="button"
                onClick={handleFileLoad}
                disabled={!file || file.length === 0}
                className="bg-blue-500 text-white"
              >
                Załaduj plik
              </Button>
              {uploadedFileName && (
                <span className="text-sm text-green-400 ml-2">
                  Wczytano: <strong>{uploadedFileName}</strong>
                </span>
              )}
            </div>

            {/* --- Arkusz --- */}
            <div>
              <Label>Wybór arkusza</Label>
              {/* Jeśli Twój SheetSelect nie przyjmuje „store”, usuń ten prop */}
              <SheetSelectDet />
            </div>

            
          <CardHeader>
            <CardTitle> Podaj zakres danych, które chcesz wczytać.</CardTitle>
          </CardHeader>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Wiersz początkowy</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('rowStart')}
                />
              </div>
              <div>
                <Label>Wiersz końcowy</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('rowEnd')}
                />
              </div>
              <div>
                <Label>Kolumna początkowa</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('colStart')}
                />
              </div>
              <div>
                <Label>Kolumna końcowa</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('colEnd')}
                />
              </div>
            </div>

            <Button
              type="button"
              onClick={handleAutoRange}
              variant="outline"
              disabled={!workbook}
              className="bg-blue-500 text-white"
            >
              Wykryj zakres automatycznie
            </Button>

            {/* --- Czy dane zawierają podpisy --- */}
            <HeadersSelector 
              hasHeaders={hasHeaders} 
              onHeadersChange={setHasHeaders} 
            />

            {/* --- Typ danych --- */}
            <DataTypeSelector
              dataType={dataType}
              onDataTypeChange={setDataType}
            />
          </CardContent>
          <CardFooter>
            <Button
              type="submit"
              className="bg-blue-500 text-white"
              disabled={!workbook}
            >
              Wybierz
            </Button>
          </CardFooter>
        </Card>
      </form>

      {/* ---------- ALERTY ---------- */}
      {/* Błąd formatu (czerwony) */}
      <AlertDialog open={showDialog} onOpenChange={setShowDialog}>
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center">
            <VisuallyHidden>
              <AlertDialogTitle>Błąd danych</AlertDialogTitle>
            </VisuallyHidden>
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-red-100 mb-4">
              <svg
                className="w-6 h-6 text-red-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </div>
            <AlertDialogDescription className="text-center text-red-600 font-medium">
              {validationErrorReason ||
                'Dane wejściowe nie spełniają określonego formatu. Sprawdź dane!'}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Zamknij</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Ostrzeżenie (żółty) */}
      <AlertDialog open={showWarningDialog} onOpenChange={setShowWarningDialog}>
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center">
            <VisuallyHidden>
              <AlertDialogTitle>Ostrzeżenie</AlertDialogTitle>
            </VisuallyHidden>
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-yellow-100 mb-4">
              <svg
                className="w-6 h-6 text-yellow-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M13 16h-1v-4h-1m0-4h.01M12 20c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8z"
                />
              </svg>
            </div>
            <AlertDialogDescription className="text-center text-yellow-600 font-medium">
              Dane są w poprawnym formacie, ale występują w nich braki lub
              niedozwolone wartości.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>OK</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Sukces (zielony) */}
      <AlertDialog
        open={showSuccessDialog}
        onOpenChange={setShowSuccessDialog}
      >
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center">
            <VisuallyHidden>
              <AlertDialogTitle>Powiadomienie</AlertDialogTitle>
            </VisuallyHidden>
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-green-100 mb-4">
              <svg
                className="w-6 h-6 text-green-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M5 13l4 4L19 7"
                />
              </svg>
            </div>
            <AlertDialogDescription className="text-center text-green-600 font-medium">
              {dataType === 'incremental' 
                ? "Dane inkrementalne zostały przekonwertowane na skumulowane i poprawnie wczytane (Det)."
                : "Dane skumulowane zostały poprawnie wczytane (Det)."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>OK</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Brak zmian (niebieski) */}
      <AlertDialog
        open={showNoChangesDialog}
        onOpenChange={setShowNoChangesDialog}
      >
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center">
            <VisuallyHidden>
              <AlertDialogTitle>Informacja</AlertDialogTitle>
            </VisuallyHidden>
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-100 mb-4">
              <svg
                className="w-6 h-6 text-blue-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M13 16h-1v-4h-1m0-4h.01M12 20c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8z"
                />
              </svg>
            </div>
            <AlertDialogDescription className="text-center text-blue-600 font-medium">
              Nie dokonano żadnych zmian w danych.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>OK</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ---------- Spinner podczas ładowania ---------- */}
      {isLoading && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-[#1e1e2f] rounded-lg p-8 flex flex-col items-center w-80">
            <Loader2 className="animate-spin h-10 w-10 text-white mb-6" />
            <div className="w-full bg-gray-700 rounded-full h-4 mb-4 overflow-hidden">
              <div
                className="bg-gray-300 h-full transition-all duration-300 ease-in-out"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="text-white text-sm font-medium">
              Ładowanie… {progress}%
            </div>
          </div>
        </div>
      )}

      {/* MODAL OSTRZEŻENIA O UTRACIE DANYCH */}
      <Modal
        title="Ostrzeżenie"
        message="Czy napewno chcesz wczytać dane? Wszystkie obliczenia w zakładce Metody deterministyczne zostaną utracone."
        isOpen={showWarningModal}
        onConfirm={handleConfirmDataReplace}
        onCancel={handleCancelDataReplace}
      />
    </div>
  );
}
