'use client';

import { useEffect } from 'react';
import { useIncurredTableStore } from '@/stores/useIncurredTableStore';
import { useTrainDevideStoreDetIncurred } from '@/stores/trainDevideStoreDeterministycznyIncurred';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { TriangleTableView } from '@/shared';
import dynamic from 'next/dynamic';

const IncurredTriangleDet = dynamic(() => import('../../../app/_components/IncurredTriangleDet'), { ssr: false });

export default function IncurredTriangleView() {
  /* ── 1. dane ze stanu loadera XLSX ─────────────────────────── */
  const isValid = useIncurredTableStore((s) => s.isValid);
  const json = useIncurredTableStore((s) => s.selectedSheetJSON);

  /* ── 2. trójkąt Incurred w głównym store ────── */
  const incurredTriangle = useTrainDevideStoreDetIncurred((s) => s.incurredTriangle);

  /* ── 3. labels dla Incurred ──── */
  const incurredRowLabels = useLabelsStore((s) => s.incurredRowLabels);
  const incurredColumnLabels = useLabelsStore((s) => s.incurredColumnLabels);
  
  // Dodatkowe logi dla wszystkich labels ze store
  const globalRowLabels = useLabelsStore((s) => s.globalRowLabels);
  const globalColumnLabels = useLabelsStore((s) => s.globalColumnLabels);
  const lastLoadedFile = useLabelsStore((s) => s.lastLoadedFile);

  /* ── 4.1. logi dla debugowania ──── */
  useEffect(() => {
    console.log('[IncurredTriangleView] isValid:', isValid);
    console.log('[IncurredTriangleView] json:', json);
    console.log('[IncurredTriangleView] incurredTriangle:', incurredTriangle);
    console.log('[IncurredTriangleView] incurredRowLabels:', incurredRowLabels);
    console.log('[IncurredTriangleView] incurredColumnLabels:', incurredColumnLabels);
    console.log('[IncurredTriangleView] globalRowLabels:', globalRowLabels);
    console.log('[IncurredTriangleView] globalColumnLabels:', globalColumnLabels);
    console.log('[IncurredTriangleView] lastLoadedFile:', lastLoadedFile);
  }, [isValid, json, incurredTriangle, incurredRowLabels, incurredColumnLabels, globalRowLabels, globalColumnLabels, lastLoadedFile]);

  // Skip first element from labels as it's typically 'AY' header
  const actualRowLabels = incurredRowLabels.length > 1 ? incurredRowLabels.slice(1) : [];
  const actualColumnLabels = incurredColumnLabels.length > 1 ? incurredColumnLabels.slice(1) : [];

  return (
    <TriangleTableView
      title="Wczytany trójkąt danych"
      triangle={incurredTriangle}
      noDataMessage="Brak danych – wczytaj plik i kliknij Wybierz w zakładce Incurred."
      fallbackComponent={IncurredTriangleDet}
      withNumericHeaders={false}
      className="p-6 text-white"
      rowLabels={actualRowLabels}
      columnLabels={actualColumnLabels}
    />
  );
}
