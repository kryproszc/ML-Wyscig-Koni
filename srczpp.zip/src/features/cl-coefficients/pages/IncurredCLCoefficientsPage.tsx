'use client';

import React from 'react';
import { useIncurredCL }     from '../hooks/useIncurredCL';
import SidebarPanelCLIncurred    from '../components/SidebarPanelCLIncurred';
import DevJTableCLIncurred from '../components/DevJTableCLIncurred';
import { TableDataDetIncurred }  from '@/components/TableDataDetIncurred';
import { useLabelsStore } from '@/stores/useLabelsStore';

export default function IncurredCLCoefficientsPage() {
  // Labels from store for Incurred
  const incurredRowLabels = useLabelsStore((s) => s.incurredRowLabels);
  const incurredColumnLabels = useLabelsStore((s) => s.incurredColumnLabels);

  const {
    triangle,
    trainDevide,
    weights,
    selectedCells,
    devJResults,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,

    selectedVolume,
    selectedSubIndex,
    setSelectedVolume,

    runCL,
    isLoading,
  } = useIncurredCL();

  // Calculate max length for column labels
  const maxLen = React.useMemo(
    () => Math.max(...devJResults.map((r) => r.values.length), 0),
    [devJResults]
  );

  if (!triangle?.length) {
    return (
      <div className="p-6 text-yellow-300">
        ⏳ Oczekiwanie na dane wejściowe <code>incurredTriangle</code>…
      </div>
    );
  }
return (
  <div className="flex gap-6 p-6 text-white">
    {/* PANEL */}
    <div className="w-64 shrink-0">
      <SidebarPanelCLIncurred onCalculate={runCL} devJResults={devJResults} />
    </div>

    {/* CONTENT */}
    <div className="flex-1 min-w-0">
      <h2 className="text-xl font-bold mb-4">Tabela współczynników rok do roku</h2>

      {trainDevide?.length ? (
        <>
          <TableDataDetIncurred
            data={[
              [''].concat(
                incurredColumnLabels.length > 2
                  ? incurredColumnLabels.slice(2, (trainDevide[0]?.length || 0) + 2)
                  : trainDevide[0]?.map((_, i) => i.toString()) ?? []
              ),
              ...trainDevide.map((row, i) => [
                incurredRowLabels.length > i + 1 && incurredRowLabels[i + 1]
                  ? incurredRowLabels[i + 1] || i.toString()
                  : i.toString(),
                ...row.map((c) => c?.toString() ?? ''),
              ]),
            ]}
            weights={weights}
            selectedCells={selectedCells}
            minMaxCells={minMaxHighlighting ? minMaxCells : []}
            minCells={minMaxHighlighting ? minCells : []}
            maxCells={minMaxHighlighting ? maxCells : []}
          />

          {devJResults.length > 0 && (
            <div className="mt-10">
              <h3 className="font-bold text-white mb-2">
                Tabela ważonych uśrednionych współczynników
              </h3>

              <DevJTableCLIncurred
                devJResults={devJResults}
                selectedVolume={selectedVolume}
                selectedSubIndex={selectedSubIndex}
                onSelectVolume={setSelectedVolume}
                columnLabels={
                  incurredColumnLabels.length > 2
                    ? incurredColumnLabels.slice(2, maxLen + 2)
                    : undefined
                }
              />
            </div>
          )}
        </>
      ) : (
        <p className="text-yellow-400">
          {isLoading ? 'Obliczanie...' : 'Brak wyników obliczeń współczynników'}
        </p>
      )}
    </div>
  </div>
);
}