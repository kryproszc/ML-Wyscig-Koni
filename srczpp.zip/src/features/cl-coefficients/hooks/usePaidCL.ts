'use client';

import { useEffect } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useUserStore } from '@/app/_components/useUserStore';
import {
  useTrainDevideStoreDet,
} from '@/stores/trainDevideStoreDeterministyczny';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export function usePaidCL() {
  const userId = useUserStore((s) => s.userId);
  const store  = useTrainDevideStoreDet();

  const {
    paidTriangle,
    trainDevideDet,
    selectedWeightsDet,
    selectedCellsDet,
    volume,
    devJResults,
    setTrainDevideDet,
    setDevJ,
    addDevJResult,
    resetSelectionDet,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    setMinMaxHighlighting,
    selectedDevJVolume   : selectedVolume,
    selectedDevJSubIndex : selectedSubIndex,
    setSelectedDevJVolume: setSelectedVolume,
  } = store;

  /* -------- mutation 1 -------- */
  const mTrainDivide = useMutation({
    mutationKey: ['trainDividePaid', volume],
    mutationFn : async () => {
      const triangle = (paidTriangle ?? []);
      const res = await fetch(`${API_URL}/calc/paid/train_devide_paid`, {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ user_id: userId, paid_data_det: triangle }),
      });
      return res.json() as Promise<{ train_devide?: number[][] }>;
    },
    onSuccess: (d) => {
      if (d.train_devide) {
        setTrainDevideDet(d.train_devide);
        // Ustaw wszystkie komórki jako zaznaczone domyślnie
        resetSelectionDet();
      }
    },
  });

  /* -------- mutation 2 -------- */
  const mCL = useMutation({
    mutationKey: ['clPaid', volume],
    mutationFn : async () => {
      const safeWeights =
        selectedWeightsDet?.map((r) => r.map((c) => (c === 1 ? 1 : 0))) ?? [];
      const res = await fetch(`${API_URL}/calc/paid/cl`, {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({
          user_id      : userId,
          paid_data_det: paidTriangle,
          weights      : safeWeights,
        }),
      });
      return res.json() as Promise<{ train_devide?: number[][]; dev_j?: number[] }>;
    },
    onSuccess: (d) => {
      if (d.train_devide) setTrainDevideDet(d.train_devide);
      if (d.dev_j) {
        setDevJ(d.dev_j);
        addDevJResult(volume, d.dev_j);
        setSelectedVolume(volume, undefined);
      }
    },
  });

  /* auto-start train_divide */
  useEffect(() => {
    console.log('[usePaidCL] 🔍 useEffect triggered:', {
      paidTriangleLength: paidTriangle?.length || 0,
      trainDevideDetLength: trainDevideDet?.length || 0,
      hasPaidTriangle: !!paidTriangle?.length,
      hasTrainDevide: !!trainDevideDet?.length,
      shouldTrigger: !!(paidTriangle?.length && !trainDevideDet?.length)
    });
    
    if (paidTriangle?.length && !trainDevideDet?.length) {
      console.log('[usePaidCL] 🚀 Triggering mTrainDivide.mutate()');
      mTrainDivide.mutate();
    } else {
      console.log('[usePaidCL] ❌ Warunki nie spełnione - nie triggeru ję train_divide');
    }
  }, [paidTriangle, trainDevideDet]);

  return {
    triangle      : paidTriangle,
    trainDevide   : trainDevideDet,
    weights       : selectedWeightsDet,
    selectedCells : selectedCellsDet,
    devJResults,
    selectedVolume,
    selectedSubIndex,
    setSelectedVolume,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,

    runCL      : () => mCL.mutate(),
    isLoading  : mTrainDivide.isPending || mCL.isPending,
  };
}
