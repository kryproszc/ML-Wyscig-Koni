import React, { useMemo } from 'react';
import { TableDataCor } from '@/components/TableDataCor';
import { DensityChart } from './DensityChart';
import type { Dep2Resp } from '../types';
import type { CorRowData } from '@/components/TableDataCor';

interface SummaryTabProps {
  data: Dep2Resp | null;
  isLoading: boolean;
  error: string | null;
  ci: number;
  onCiChange: (value: number) => void;
}

export const SummaryTab: React.FC<SummaryTabProps> = ({
  data,
  isLoading,
  error,
  ci,
  onCiChange,
}) => {
  const summaryTable: CorRowData[] = useMemo(() => {
    if (!data) return [];
    return [
      ['Z', data.totals['Z']],
      ['E[Z]', data.totals['E[Z]']],
      ['Var[Z]', data.totals['Var[Z]']],
      ['Lower', data.range.Lower],
      ['Upper', data.range.Upper],
    ];
  }, [data]);

  const densityChartProps = useMemo(() => {
    if (!data?.density_plot) return null;

    const dens = data.density_plot;
    const curve = dens.curve;
    const Z = dens.Z_stat;
    const EZ = data.totals['E[Z]']; // średnia

    const domain: [number, number] = [
      Math.min(curve[0]![0], Z),
      Math.max(curve[curve.length - 1]![0], Z),
    ];

    return {
      title: 'Gęstość rozkładu testu',
      curve: dens.curve,
      ciArea: dens.ci_area,
      referenceValue: Z, // używamy wartości Z jako wartości referencyjnej
      domain,
    };
  }, [data]);

  return (
    <div className="flex flex-col items-center gap-6 text-white px-4">
      {/* Error display */}
      {error && <p className="text-destructive">{error}</p>}

      {/* Loading state */}
      {isLoading && <p className="italic">Ładowanie…</p>}

      {/* Content */}
      {data && (
        <>
          <h3 className="text-lg font-semibold">
            Test niezależności – kalendarzowe lata wypadkowe
          </h3>
          
          {/* CI slider */}
          <div className="w-full max-w-xl flex flex-col items-center gap-2 mb-6">
            <label htmlFor="ci-range-summary" className="text-sm font-medium">
              Przedział ufności (ci):
            </label>
            <input
              id="ci-range-summary"
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={ci}
              onChange={(e) => onCiChange(parseFloat(e.target.value))}
              className="w-full"
            />
            <span className="text-xs">{Math.round(ci * 100)}%</span>
          </div>
          
          <TableDataCor data={summaryTable} />

          {densityChartProps && (
            <DensityChart
              title={densityChartProps.title}
              curve={densityChartProps.curve}
              ciArea={densityChartProps.ciArea}
              referenceValue={densityChartProps.referenceValue}
              domain={densityChartProps.domain}
            />
          )}
        </>
      )}
    </div>
  );
};
