import type { ChartConfig, ObsRow } from './types';

export const CHART_CONFIGS: ChartConfig[] = [
  {
    key: 'fitted_value',
    title: 'Reszty vs. Dopasowane',
    xLabel: 'Fitted',
    xAccessor: (d: ObsRow) => d.fitted_value,
  },
  {
    key: 'origin_period',
    title: 'Reszty vs. Origin period',
    xLabel: 'Origin period',
    xAccessor: (d: ObsRow) => d.origin_period,
  },
  {
    key: 'cal_period',
    title: 'Reszty vs. Calendar period',
    xLabel: 'Calendar period',
    xAccessor: (d: ObsRow) => d.cal_period,
  },
  {
    key: 'dev_period',
    title: 'Reszty vs. Development period',
    xLabel: 'Development period',
    xAccessor: (d: ObsRow) => d.dev_period,
  },
] as const;

export const TAB_CONFIGS = [
  { key: 'model', label: 'Model' },
  { key: 'assumptions', label: 'Analiza reszt' },
  { key: 'analysis', label: 'Analiza korelacji czynników rozwoju' },
  { key: 'summary', label: 'Analiza niezależności lat wypadkowych' },
] as const;
