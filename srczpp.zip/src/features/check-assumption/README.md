# Check Assumption Feature

Ten feature zawiera komponenty do sprawdzania założeń modelu ubezpieczeniowego.

## Struktura

```
src/features/check-assumption/
├── components/           # Komponenty UI
│   ├── CheckAssumption.tsx    # Główny komponent z zakładkami
│   ├── ModelTab.tsx           # Zakładka modelu
│   ├── AssumptionsTab.tsx     # Analiza reszt
│   ├── AnalysisTab.tsx        # Analiza korelacji
│   ├── SummaryTab.tsx         # Analiza niezależności
│   ├── ResidualChart.tsx      # Wykres reszt
│   ├── DensityChart.tsx       # Wykres gęstości
│   └── index.ts               # Eksporty komponentów
├── hooks/                # Hooki do zarządzania stanem
│   ├── useCheckAssumptionData.ts
│   └── index.ts
├── services/             # Serwisy API
│   ├── api.ts
│   └── index.ts
├── types/                # Definicje typów
│   └── index.ts
├── constants.ts          # Stałe i konfiguracja
└── index.ts             # Główny eksport feature'a
```

## Użycie

```tsx
import { CheckAssumption } from "@/features/check-assumption";

function MyComponent() {
  return <CheckAssumption />;
}
```

## Funkcjonalności

- **Model Tab**: Informacje o modelu
- **Assumptions Tab**: Analiza reszt z interaktywnymi wykresami
- **Analysis Tab**: Analiza korelacji czynników rozwoju
- **Summary Tab**: Analiza niezależności lat wypadkowych

## API Endpoints

- `POST /analyze-residuals` - Analiza reszt
- `POST /analyze-dependence` - Analiza zależności
- `POST /analyze-dep2` - Analiza niezależności
