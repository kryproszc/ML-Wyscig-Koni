/* ------------------------------------------------------------------ */
/*                     IncurredDevSummaryTab.tsx                     */
/* ------------------------------------------------------------------ */
"use client"

import React from 'react'
import { useTrainDevideStoreDetIncurred } from '@/stores/trainDevideStoreDeterministycznyIncurred'
import { useLabelsStore } from '@/stores/useLabelsStore'
import { DevSummaryLayout } from '@/shared/components/DevelopmentEnd'

export default function IncurredDevSummaryTab() {
  // Store selectors
  const leftCount = useTrainDevideStoreDetIncurred(s => s.leftCountSummary)
  const setLeftCount = useTrainDevideStoreDetIncurred(s => s.setLeftCountSummary)
  const selectedCurve = useTrainDevideStoreDetIncurred(s => s.selectedCurveSummary)
  const setSelectedCurve = useTrainDevideStoreDetIncurred(s => s.setSelectedCurveSummary)
  const manualOverrides = useTrainDevideStoreDetIncurred(s => s.manualOverridesSummary)
  const setManualOverrides = useTrainDevideStoreDetIncurred(s => s.setManualOverridesSummary)
  const sourceSwitches = useTrainDevideStoreDetIncurred(s => s.sourceSwitchesSummary)
  const setSourceSwitches = useTrainDevideStoreDetIncurred(s => s.setSourceSwitchesSummary)
  const devJPreview = useTrainDevideStoreDetIncurred(s => s.devJPreview)
  const simResults = useTrainDevideStoreDetIncurred(s => s.simResults)
  const setCombinedDevJSummary = useTrainDevideStoreDetIncurred(s => s.setCombinedDevJSummary)

  // Labels from store
  const incurredColumnLabels = useLabelsStore(s => s.incurredColumnLabels)
  
  // Callback to save remaining dev_j headers
  const setRemainingDevJHeaders = useTrainDevideStoreDetIncurred(s => s.setRemainingDevJHeaders)

  return (
    <DevSummaryLayout
      leftCount={leftCount}
      setLeftCount={setLeftCount}
      selectedCurve={selectedCurve}
      setSelectedCurve={setSelectedCurve}
      manualOverrides={manualOverrides}
      setManualOverrides={setManualOverrides}
      sourceSwitches={sourceSwitches}
      setSourceSwitches={setSourceSwitches}
      devJPreview={devJPreview}
      simResults={simResults}
      setCombinedDevJ={setCombinedDevJSummary}
      columnLabels={incurredColumnLabels}
      onRemainingDevJHeaders={setRemainingDevJHeaders}
    />
  )
}
