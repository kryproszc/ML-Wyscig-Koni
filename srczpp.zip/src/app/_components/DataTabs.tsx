'use client';

import { useState } from "react";
import { InputDataTabDet, InputDataTabIncurred } from '@/features/data-input';
import { cn } from "@/lib/utils";

const tabs = [
  { key: "paid", label: "Trójkąt paid" },
  { key: "incurred", label: "Trójkąt incurred" },
];

export function DataTabs() {
  const [activeTab, setActiveTab] = useState("paid");

  // Obsługa przełączania zakładek
  const handleTabChange = (tabKey: string) => {
    setActiveTab(tabKey);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Zakładki */}
      <div className="flex border-b border-gray-700 space-x-8 text-white text-base font-medium">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => handleTabChange(tab.key)}
            className={cn(
              "pb-2 transition-colors duration-200",
              activeTab === tab.key
                ? "text-blue-400 border-b-2 border-blue-400"
                : "hover:text-blue-300"
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div>
        {activeTab === "paid" && <InputDataTabDet />}
        {activeTab === "incurred" && <InputDataTabIncurred />}
      </div>
    </div>
  );
}
