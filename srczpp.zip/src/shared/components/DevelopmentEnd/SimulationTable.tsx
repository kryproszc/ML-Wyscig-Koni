/* ------------------------------------------------------------------ */
/*                         SimulationTable                           */
/* ------------------------------------------------------------------ */

import React from 'react'
import type { SimulationTableProps, OverrideMap } from '@/shared/types/developmentEnd'
import { formatDpHeader } from '@/shared/utils/developmentEndUtils'

export function SimulationTable({
  simResults,
  dpHeaders,
  leftCount,
  selectedCurve,
  setSelectedCurve,
  manualOverrides,
  setManualOverrides,
  sourceSwitches,
  setSourceSwitches
}: SimulationTableProps) {
  
  const handleCurveChange = (curve: string) => {
    // 1) ustaw nową krzywą
    setSelectedCurve(curve)

    // 2) usuń kliknięcia tej starej krzywej (ale zostaw manual + lewą część)
    const cleaned: OverrideMap = {}
    Object.entries(manualOverrides).forEach(([k, cell]) => {
      const idxNum = Number(k)
      if (idxNum < leftCount || cell.curve === 'manual') {
        cleaned[idxNum] = cell
      }
    })
    if (Object.keys(cleaned).length !== Object.keys(manualOverrides).length) {
      setManualOverrides(cleaned)
    }
  }

  const handleCellClick = (idx: number, curve: string, val: number | undefined) => {
    if (!Number.isFinite(val)) return
    
    // Jeśli to zablokowana komórka (idx < leftCount)
    if (idx < leftCount) {
      // Przełącz sourceSwitches dla tej pozycji z dowolnej krzywej
      const newSwitches = { ...sourceSwitches }
      const currentSwitch = sourceSwitches[idx]
      
      if (currentSwitch && currentSwitch.curve === curve) {
        delete newSwitches[idx] // Usuń przełączenie - wróć do dev podstawowego
      } else {
        newSwitches[idx] = { curve, value: val! } // Przełącz na tę krzywą
      }
      setSourceSwitches(newSwitches)
    } else {
      // Standardowa logika dla prawej części (manual overrides)
      const copy: OverrideMap = { ...manualOverrides }
      if (manualOverrides[idx]?.curve === curve) {
        delete copy[idx]
      } else {
        copy[idx] = { curve, value: val! }
      }
      setManualOverrides(copy)
    }
  }

  return (
    <section>
      <h2 className="text-xl font-bold mb-4 text-center">Tabela współczynników z dopasowanych krzywych</h2>
      <div className="relative w-full max-w-full overflow-x-auto rounded-xl">
        <table className="min-w-max table-fixed border-collapse bg-gray-900 shadow-md text-sm">
          <thead>
            <tr>
              <th className="border border-gray-700 px-3 py-2 bg-gray-800 font-semibold sticky left-0 z-20">
                Źródło
              </th>
              <th className="border border-gray-700 px-3 py-2 bg-gray-800 font-semibold sticky left-[62px] z-20">
                Krzywa
              </th>
              {dpHeaders.map((dpKey) => (
                <th key={dpKey} className="border border-gray-700 px-3 py-2 bg-gray-800 w-[80px] text-center">
                  {formatDpHeader(dpKey)}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Object.entries(simResults).map(([curve, values]) => (
              <tr key={curve} className="hover:bg-gray-800/40">
                {/* Wybór */}
                <td className="border border-gray-700 px-3 py-2 text-center sticky left-0 bg-gray-900 z-10">
                  <input
                    type="radio"
                    name="curve-select"
                    checked={selectedCurve === curve}
                    onChange={() => handleCurveChange(curve)}
                    className="form-radio text-blue-600 bg-gray-700 border-gray-600"
                  />
                </td>

                {/* Nazwa krzywej */}
                <td className="border border-gray-700 px-3 py-2 bg-gray-800 font-semibold sticky left-[62px] z-10">
                  {curve}
                </td>

                {/* wartości dp */}
                {dpHeaders.map((dpKey, idx) => {
                  const val = (values as Record<string, number | undefined>)[dpKey]
                  const blocked = idx < leftCount
                  const isManual = manualOverrides[idx]?.curve === curve
                  const selectedRow = selectedCurve === curve
                  const switchedSource = sourceSwitches[idx]
                  const isSourceSwitched = switchedSource && switchedSource.curve === curve

                  // wyliczamy klasę tła
                  let bg = ""
                  let cursorClass = "cursor-pointer"
                  
                  if (blocked) {
                    if (isSourceSwitched) {
                      bg = "bg-purple-600/70" // Przełączone na tę krzywą
                    } else {
                      bg = "bg-gray-700/20" // Dostępne do przełączenia
                    }
                  } else {
                    if (isManual) bg = "bg-green-500/70"
                    else if (selectedRow && !manualOverrides[idx]) bg = "bg-green-700/70"
                  }

                  return (
                    <td
                      key={dpKey}
                      onClick={() => handleCellClick(idx, curve, val)}
                      className={`border border-gray-700 px-3 py-2 w-[80px] text-center transition-colors ${cursorClass} ${bg}`}
                      title={
                        blocked
                          ? isSourceSwitched
                            ? "Przełączone na tę krzywą - kliknij aby wrócić do dev_j"
                            : `Kliknij aby przełączyć na krzywą "${curve}"`
                          : isManual
                          ? "Ręcznie wybrana wartość – kliknij ponownie, by usunąć"
                          : "Kliknij, aby ustawić ręcznie"
                      }
                    >
                      {Number.isFinite(val) ? Number(val).toFixed(6) : "-"}
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
        {!selectedCurve && (
          <p className="text-yellow-400 mt-4 text-center">
            Wybierz krzywą, aby uzupełnić współczynniki po pozycji {leftCount}.
          </p>
        )}
      </div>
    </section>
  )
}
