/* ------------------------------------------------------------------ */
/*                           FinalTable                              */
/* ------------------------------------------------------------------ */

import React, { useEffect, useMemo } from 'react'
import type { FinalTableProps } from '@/shared/types/developmentEnd'
import { useDevSummaryEditing } from '@/shared/hooks/useDevSummaryEditing'

export function FinalTable({
  combinedDevJ,
  maxLen,
  leftCount,
  columnLabels,
  manualOverrides,
  setManualOverrides,
  sourceSwitches,
  selectedCurve,
  onHeadersGenerated
}: FinalTableProps) {
  const {
    editingIndex,
    editValue,
    setEditValue,
    startEditing,
    stopEditing,
    saveEdit
  } = useDevSummaryEditing()

  // Generate headers and notify parent when they change
  const generatedHeaders = useMemo(() => {
    const headers: string[] = []
    
    for (let idx = 0; idx < maxLen; idx++) {
      let label
      if (idx < leftCount) {
        // Sprawdzamy czy dla tego indeksu jest przełączenie źródła
        const switchedSource = sourceSwitches[idx]
        if (switchedSource) {
          // Mapujemy nazwy krzywych na skróty i używamy spójnego formatu
          let curveShort = switchedSource.curve
          switch(switchedSource.curve) {
            case 'Exponential': curveShort = 'E'; break
            case 'Weibull': curveShort = 'W'; break
            case 'Power': curveShort = 'P'; break
            case 'Inverse Power': curveShort = 'IP'; break
            default: curveShort = switchedSource.curve.charAt(0); break
          }
          
          label = `${curveShort}:${idx + 2}` // +2 bo kolumny zaczynają się od 2
        } else {
          // Standardowa etykieta z dev_j (tylko numer)
          label = `${idx + 2}`
        }
      } else {
        // Dla części z krzywej - używamy skrótu krzywej
        if (selectedCurve) {
          let curveShort = selectedCurve
          switch(selectedCurve) {
            case 'Exponential': curveShort = 'E'; break
            case 'Weibull': curveShort = 'W'; break
            case 'Power': curveShort = 'P'; break
            case 'Inverse Power': curveShort = 'IP'; break
            default: curveShort = selectedCurve.charAt(0); break
          }
          label = `${curveShort}:${idx + 2}` // +2 bo kolumny zaczynają się od 2
        } else {
          label = `k:${idx + 2}`
        }
      }
      headers.push(label)
    }
    
    return headers
  }, [maxLen, leftCount, sourceSwitches, selectedCurve])

  // Notify parent when headers change
  useEffect(() => {
    if (onHeadersGenerated) {
      onHeadersGenerated(generatedHeaders)
    }
  }, [generatedHeaders, onHeadersGenerated])

  const handleCellClick = (idx: number, val: number | string) => {
    if (typeof val === 'string') return
    startEditing(idx, val.toString())
  }

  const handleBlur = () => {
    if (editingIndex !== null) {
      saveEdit(editingIndex, manualOverrides, setManualOverrides)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" || e.key === "Escape") {
      (e.target as HTMLInputElement).blur()
    }
  }

  return (
    <section>
      <h2 className="text-xl font-bold mb-4 text-center">Tabela współczynników Selected Value</h2>
      <div className="relative w-full max-w-full overflow-x-auto rounded-xl">
        <table className="min-w-max border-collapse bg-gray-900 rounded-xl shadow-md text-sm">
          <thead>
            <tr>
              <th className="border border-gray-700 px-3 py-2 bg-gray-800">-</th>
              {generatedHeaders.map((label, idx) => (
                <th key={idx} className="border border-gray-700 px-3 py-2 bg-gray-800">
                  {label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border border-gray-700 px-3 py-2 bg-gray-800">Selected Value</td>
              {combinedDevJ.map((val, idx) => {
                const isEditing = editingIndex === idx

                return (
                  <td
                    key={idx}
                    className={`border border-gray-700 text-center px-3 py-2 ${
                      isEditing ? 'bg-blue-900/50' : 'hover:bg-gray-700/40 cursor-pointer'
                    }`}
                    onClick={() => handleCellClick(idx, val)}
                    title="Kliknij, aby edytować wartość ręcznie"
                  >
                    {isEditing ? (
                      <input
                        type="number"
                        step="any"
                        autoFocus
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        onBlur={handleBlur}
                        onKeyDown={handleKeyDown}
                        className="w-full px-2 py-1 rounded bg-white text-black border border-blue-400 text-sm text-center shadow"
                      />
                    ) : (
                      val
                    )}
                  </td>
                )
              })}
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  )
}
