/* ------------------------------------------------------------------ */
/*                  Development End Utilities                        */
/* ------------------------------------------------------------------ */

/**
 * Tworzy nagłówki dp z wyników symulacji i sortuje je numerycznie
 */
export function createDpHeaders(simResults: Record<string, Record<string, number>> | null | undefined): string[] {
  if (!simResults) return []
  
  const set = new Set<string>()
  Object.values(simResults).forEach((curve) =>
    Object.keys(curve).forEach((k) => set.add(k)),
  )
  
  return Array.from(set).sort((a, b) => {
    const num = (s: string) => parseInt((s.split(':')[1] ?? '0').trim(), 10)
    return num(a) - num(b)
  })
}

/**
 * Formatuje nagłówek dp: na k:
 */
export function formatDpHeader(dpHeader: string): string {
  return dpHeader.replace('dp:', 'k:')
}

/**
 * Tworzy kombinowany devJ z devJPreview, wybranej krzywej i override'ów
 */
export function createCombinedDevJ(
  devJPreview: number[] | undefined,
  dpHeaders: string[],
  leftCount: number,
  selectedCurve: string | null,
  simResults: Record<string, Record<string, number>> | null | undefined,
  manualOverrides: Record<number, { curve: string; value: number }>,
  sourceSwitches?: Record<number, { curve: string; value: number }>
): (number | string)[] {
  if (!devJPreview) return []

  const maxLen = Math.max(devJPreview.length, dpHeaders.length)
  const arr: (number | string)[] = Array(maxLen).fill('-')

  // 1. lewa „pozostawiona" część z devJPreview (ale sprawdzaj sourceSwitches)
  for (let i = 0; i < Math.min(leftCount, maxLen); i++) {
    const switchedSource = sourceSwitches?.[i]
    
    if (switchedSource) {
      // Użyj wartości z wybranej krzywej
      arr[i] = switchedSource.value.toFixed(6)
    } else {
      // Użyj wartości z devJPreview (standardowa logika)
      const v = devJPreview[i]
      arr[i] = v !== undefined ? v.toFixed(6) : '-'
    }
  }

  // 2. prawa część z wybranej krzywej
  if (selectedCurve && simResults?.[selectedCurve]) {
    for (let i = leftCount; i < maxLen; i++) {
      const dpKey = `dp: ${i + 1}`
      const v = simResults[selectedCurve]?.[dpKey]
      if (Number.isFinite(v)) arr[i] = (v as number).toFixed(6)
    }
  }

  // 3. overrides – najwyższy priorytet
  Object.entries(manualOverrides).forEach(([idxStr, cell]) => {
    const idx = Number(idxStr)
    if (idx < maxLen && Number.isFinite(cell.value)) {
      arr[idx] = cell.value.toFixed(6)
    }
  })

  return arr
}

/**
 * Czyści override'y które wpadają pod blokadę leftCount
 */
export function cleanBlockedOverrides(
  manualOverrides: Record<number, { curve: string; value: number }>,
  leftCount: number
): Record<number, { curve: string; value: number }> {
  return Object.fromEntries(
    Object.entries(manualOverrides).filter(
      ([idx, cell]) => Number(idx) >= leftCount || cell.curve === 'manual',
    ),
  )
}
