export type TriangleData = (number | null)[][];

export interface TriangleViewProps {
  title: string;
  noDataMessage: string;
  fallbackComponent?: React.ComponentType;
  rowLabels?: string[];
  columnLabels?: string[];
}

export interface TriangleDisplayData {
  hasData: boolean;
  formattedData: string[][];
}
