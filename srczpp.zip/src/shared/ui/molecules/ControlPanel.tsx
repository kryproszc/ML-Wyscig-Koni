import { Button } from "../atoms/Button";
import { InputNumber } from "../atoms/InputNumber";
import { Card } from "../atoms/Card";

type Props = {
  currentVectorLength: number;
  tailCount: number | "";
  onTailChange: (v: number | "") => void;
  onUpdateVector: () => void;
  onSend: () => void;
  disableSend: boolean;
};

export const ControlPanel = ({
  currentVectorLength,
  tailCount,
  onTailChange,
  onUpdateVector,
  onSend,
  disableSend,
}: Props) => (
  <Card className="w-full lg:w-64 h-fit shrink-0">
    <h3 className="text-lg font-semibold mb-4">Panel sterowania</h3>

    <Button
      full
      onClick={onUpdateVector}
      disabled={!currentVectorLength}
      className="mb-3"
    >
      Zaktualizuj wektor
    </Button>

    <label className="block text-sm mb-1">Ile obserwacji w&nbsp;ogonie:</label>
    <InputNumber
      full
      min={0}
      value={tailCount}
      placeholder="np. 2"
      onChange={(e) =>
        onTailChange(e.target.value === "" ? "" : parseInt(e.target.value, 10))
      }
    />

    <Button
      full
      variant="success"
      onClick={onSend}
      disabled={disableSend}
      className="mt-3"
    >
      Wyślij wybrane
    </Button>
  </Card>
);
