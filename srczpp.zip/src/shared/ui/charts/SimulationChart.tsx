import React, { useMemo } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

type SimResults = Record<string, Record<string, number>>;

type Props = {
  simResults: SimResults | null;
  devJ?: number[];
  dpRange: [number, number];
  selectedCurves: string[];
};

export const SimulationChart = ({
  simResults,
  devJ,
  dpRange,
  selectedCurves,
}: Props) => {
  const data = useMemo(() => {
    if (!simResults) return [];
    const allDpKeys = Object.keys(simResults?.["Exponential"] ?? {});
    return allDpKeys
      .filter((dpKey) => {
        const n = parseInt(dpKey.replace("dp: ", ""), 10);
        return n >= dpRange[0] && n <= dpRange[1];
      })
      .map((dpKey) => {
        const point: Record<string, number | string> = { dp: dpKey };
        for (const curve in simResults) {
          point[curve] = simResults[curve]?.[dpKey] ?? 0;
        }
        const idx = parseInt(dpKey.replace("dp: ", ""), 10) - 1;
        const devVal = devJ?.[idx];
        if (typeof devVal === "number") point["Initial Selection"] = devVal;
        return point;
      });
  }, [simResults, devJ, dpRange]);

  if (!simResults) return null;

  return (
    <div className="w-full h-[400px]">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{ top: 20, right: 30, left: 20, bottom: 80 }}
          style={{ background: "#1a1a2e", borderRadius: 12, padding: 10 }}
        >
          <CartesianGrid stroke="#444" strokeDasharray="3 3" />
          <XAxis dataKey="dp" stroke="#ccc" interval={0} tick={{ fill: "#ccc", fontSize: 12 }} />
          <YAxis stroke="#ccc" domain={["dataMin - 0.5", "dataMax + 0.5"]} />
          <Tooltip
            contentStyle={{ background: "#2c2c3e", borderColor: "#666", color: "#fff" }}
            labelStyle={{ color: "#aaa" }}
          />
          <Legend verticalAlign="bottom" height={50} wrapperStyle={{ paddingTop: 20 }} />

          {selectedCurves.includes("Exponential") && (
            <Line type="monotone" dataKey="Exponential" stroke="#4f8bff" strokeWidth={2} />
          )}
          {selectedCurves.includes("Weibull") && (
            <Line type="monotone" dataKey="Weibull" stroke="#2dd4bf" strokeWidth={2} />
          )}
          {selectedCurves.includes("Power") && (
            <Line type="monotone" dataKey="Power" stroke="#facc15" strokeWidth={2} />
          )}
          {selectedCurves.includes("Inverse Power") && (
            <Line type="monotone" dataKey="Inverse Power" stroke="#f87171" strokeWidth={2} />
          )}
          {selectedCurves.includes("Initial Selection") && (
            <Line type="monotone" dataKey="Initial Selection" stroke="#ef4444" strokeWidth={2} name="Initial Selection" />
          )}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};
