import React from 'react';
import { Label } from '@/components/ui/label';

export type DataType = 'cumulative' | 'incremental';

interface DataTypeSelectorProps {
  dataType: DataType;
  onDataTypeChange: (type: DataType) => void;
}

export const DataTypeSelector: React.FC<DataTypeSelectorProps> = ({
  dataType,
  onDataTypeChange,
}) => {
  return (
    <div className="space-y-3 p-4 border border-gray-600 rounded-lg bg-gray-800">
      <Label className="text-sm font-medium text-white">Typ danych</Label>
      <div className="flex flex-col space-y-3">
        <label className="flex items-start space-x-3 cursor-pointer p-2 rounded hover:bg-gray-700 transition-colors">
          <input
            type="radio"
            name="dataType"
            value="cumulative"
            checked={dataType === 'cumulative'}
            onChange={(e) => onDataTypeChange(e.target.value as DataType)}
            className="w-4 h-4 text-blue-500 bg-gray-700 border-gray-500 focus:ring-blue-400 focus:ring-2 mt-1"
          />
          <div className="flex flex-col">
            <span className="text-sm font-medium text-white">
              📊 Skumulowane
            </span>
          </div>
        </label>
        <label className="flex items-start space-x-3 cursor-pointer p-2 rounded hover:bg-gray-700 transition-colors">
          <input
            type="radio"
            name="dataType"
            value="incremental"
            checked={dataType === 'incremental'}
            onChange={(e) => onDataTypeChange(e.target.value as DataType)}
            className="w-4 h-4 text-blue-500 bg-gray-700 border-gray-500 focus:ring-blue-400 focus:ring-2 mt-1"
          />
          <div className="flex flex-col">
            <span className="text-sm font-medium text-white">
              📈 Inkrementalne
            </span>
          </div>
        </label>
      </div>
    </div>
  );
};
