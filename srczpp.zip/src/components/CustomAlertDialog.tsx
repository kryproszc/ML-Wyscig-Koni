import React from 'react';
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { VisuallyHidden } from '@/components/ui/visually-hidden';

type AlertVariant = 'error' | 'warning' | 'success' | 'info';

interface AlertIconProps {
  variant: AlertVariant;
}

const AlertIcon: React.FC<AlertIconProps> = ({ variant }) => {
  const getIconStyles = () => {
    switch (variant) {
      case 'error': return { bgColor: 'bg-red-100', iconColor: 'text-red-600' };
      case 'warning': return { bgColor: 'bg-yellow-100', iconColor: 'text-yellow-600' };
      case 'success': return { bgColor: 'bg-green-100', iconColor: 'text-green-600' };
      case 'info': return { bgColor: 'bg-blue-100', iconColor: 'text-blue-600' };
    }
  };

  const getIconPath = () => {
    switch (variant) {
      case 'error': return "M6 18L18 6M6 6l12 12";
      case 'warning': return "M13 16h-1v-4h-1m0-4h.01M12 20c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8z";
      case 'success': return "M5 13l4 4L19 7";
      case 'info': return "M13 16h-1v-4h-1m0-4h.01M12 20c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8z";
    }
  };

  const styles = getIconStyles();

  return (
    <div className={`flex items-center justify-center w-12 h-12 rounded-full ${styles.bgColor} mb-4`}>
      <svg className={`w-6 h-6 ${styles.iconColor}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={getIconPath()} />
      </svg>
    </div>
  );
};

interface CustomAlertDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  variant: AlertVariant;
  title: string;
  message: string;
  buttonText?: string;
}

export const CustomAlertDialog: React.FC<CustomAlertDialogProps> = ({
  open,
  onOpenChange,
  variant,
  title,
  message,
  buttonText = 'OK',
}) => {
  const getTextColor = () => {
    switch (variant) {
      case 'error': return 'text-red-600';
      case 'warning': return 'text-yellow-600';
      case 'success': return 'text-green-600';
      case 'info': return 'text-blue-600';
    }
  };

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader className="flex flex-col items-center">
          <VisuallyHidden>
            <AlertDialogTitle>{title}</AlertDialogTitle>
          </VisuallyHidden>
          <AlertIcon variant={variant} />
          <AlertDialogDescription className={`text-center ${getTextColor()} font-medium`}>
            {message}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>{buttonText}</AlertDialogCancel>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};
