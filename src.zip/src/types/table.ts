
export type RowData = (string | number | null)[];
//export type RowData = Record<string, any>;
