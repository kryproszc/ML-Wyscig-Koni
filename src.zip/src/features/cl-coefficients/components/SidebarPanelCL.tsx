'use client';

import { useState } from 'react';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useDisplaySettingsPaidStore } from '@/stores/useDisplaySettingsPaidStore';
import { exportDevJToExcel } from '@/untils/exportToExcel';
import { Button } from '@/components/ui/button';
import { Maximize2, Plus, Minus } from 'lucide-react';
import Modal from '@/components/Modal';
import type { DevJResult } from '@/shared/ui/organisms/DevJTable/DevJTableBase';

type Props = {
  onCalculate: () => void;
  devJResults: DevJResult[];
  className?: string;
  showChart?: boolean;
  onToggleChart?: () => void;
  columnLabels?: string[]; // etykiety kolumn dla eksportu
};

export default function SidebarPanelCL({ 
  onCalculate, 
  devJResults, 
  className,
  showChart = false,
  onToggleChart,
  columnLabels
}: Props) {
  const store = useTrainDevideStoreDet();
  const [resetOpen, setResetOpen] = useState(false);

  // Display settings for fullscreen and scale
  const fullscreenMode = useDisplaySettingsPaidStore((s) => s.fullscreenMode);
  const tableScale = useDisplaySettingsPaidStore((s) => s.tableScale);
  const setFullscreenMode = useDisplaySettingsPaidStore((s) => s.setFullscreenMode);
  const increaseScale = useDisplaySettingsPaidStore((s) => s.increaseScale);
  const decreaseScale = useDisplaySettingsPaidStore((s) => s.decreaseScale);

  const {
    getCurrentVolume,
    getMaxVolume,
    setVolume,
    clearDevJResults,
    setFinalDevJ,
    clearAllDevFinalValues,
    clearFitCurveData,
    clearDevSummaryData,
    openMissingFinalModal,
    isMissingFinalModalOpen,
    closeMissingFinalModal,
    finalDevJ,
    finalDevVector,
    devFinalCustom,
    minMaxHighlighting,
    setMinMaxHighlighting,
    decimalPlaces,
    setDecimalPlaces,
    weightSource,
    setWeightSource,
    cl_initial,
    resetWeightsToInitial,
  } = store;

  const volume = getCurrentVolume();
  const maxVolume = getMaxVolume();

  const overrides = Object.entries(devFinalCustom).map(([idx, c]) => ({
    index: +idx,
    curve: c.curve,
    value: c.value,
  }));

  // Funkcja do pobierania odchyleń standardowych dla wybranych współczynników (Initial Selection)
  const getFinalSdValues = () => {
    if (!finalDevJ?.values) return undefined;
    
    const maxLen = finalDevJ.values.length;
    const sdValues: number[] = [];
    
    for (let j = 0; j < maxLen; j++) {
      const customCell = devFinalCustom[j];
      let sdValue: number | undefined;
      
      if (customCell && customCell.sourceVolume !== undefined) {
        // Dla custom selection - znajdź odchylenie z odpowiedniego volume
        const sourceResult = devJResults.find(
          (result) => 
            result.volume === customCell.sourceVolume && 
            (result.subIndex ?? 0) === (customCell.sourceSubIndex ?? 0)
        );
        sdValue = sourceResult?.sdValues?.[j];
      } else {
        // Dla wartości z finalDevJ
        sdValue = finalDevJ?.sdValues?.[j];
      }
      
      sdValues.push(sdValue ?? NaN);
    }
    
    return sdValues.some(v => !isNaN(v)) ? sdValues : undefined;
  };

  const handleExport = () => {
    if (!finalDevJ?.values?.length) {
      openMissingFinalModal();
      return;
    }
    const finalSdValues = getFinalSdValues();
    exportDevJToExcel(devJResults, finalDevJ, finalDevVector, overrides, columnLabels, finalSdValues, 'wspolczynniki_paid.xlsx');
  };

  const handleReset = () => {
    clearDevJResults();
    setFinalDevJ(undefined);
    clearAllDevFinalValues();
    clearFitCurveData();
    clearDevSummaryData();
  };

  const toggleMinMax = () => {
    setMinMaxHighlighting(!minMaxHighlighting);
  };

  // Komponent kontrolek rozmiaru - używany w panelu bocznym
  const ScaleControls = () => (
    <div className="flex items-center gap-2">
      <Button
        onClick={decreaseScale}
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
        disabled={tableScale <= 0.5}
      >
        <Minus className="w-4 h-4" />
      </Button>
      
      <span className="text-white text-sm min-w-[3rem] text-center">
        {Math.round(tableScale * 100)}%
      </span>
      
      <Button
        onClick={increaseScale}
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
        disabled={tableScale >= 2.0}
      >
        <Plus className="w-4 h-4" />
      </Button>
    </div>
  );

  return (
    <div className={`w-64 shrink-0 space-y-4 ${className ?? ''}`}>
      {/* Kontrolki miejsca po przecinku i volume - razem */}
      <div className="bg-gray-800 rounded-lg p-4 space-y-4">
        <div>
          <label className="text-white text-sm font-medium mb-2 block">
            Miejsca po przecinku
          </label>
          <input
            type="number"
            min="0"
            max="10"
            value={decimalPlaces}
            onChange={(e) => setDecimalPlaces(Number(e.target.value))}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <div className="text-xs text-gray-400 mt-1">
            Współczynniki będą zaokrąglone do {decimalPlaces} miejsc
          </div>
        </div>

        <div>
          <label className="text-white text-sm font-medium mb-2 block">
            Wybierz volume
          </label>
          <input
            type="number"
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            value={volume}
            min={1}
            max={maxVolume}
            onChange={(e) => setVolume(Number(e.target.value))}
          />
        </div>

        {/* Wybór źródła wag */}
        <div>
          <label className="text-white text-sm font-medium mb-2 block">
            Wagi współczynników
          </label>
          <div className="space-y-2">
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="weightSource"
                value="default"
                checked={weightSource === 'default'}
                onChange={(e) => setWeightSource(e.target.value as 'default' | 'cl_initial')}
                className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 focus:ring-blue-500 focus:ring-2"
              />
              <span className="ml-2 text-white text-sm">Domyślne</span>
            </label>
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="weightSource"
                value="cl_initial"
                checked={weightSource === 'cl_initial'}
                onChange={(e) => setWeightSource(e.target.value as 'default' | 'cl_initial')}
                className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 focus:ring-blue-500 focus:ring-2"
                disabled={!cl_initial}
              />
              <span className={`ml-2 text-sm ${!cl_initial ? 'text-gray-500' : 'text-white'}`}>
                Zadane
                {!cl_initial && ' (brak danych)'}
              </span>
            </label>
          </div>
        </div>
      </div>

      {/* 1. Min/Max Button */}
      <button
        onClick={toggleMinMax}
        className="w-full py-4 px-5 bg-gradient-to-r from-gray-600 to-gray-500 text-white rounded-xl font-bold hover:from-gray-700 hover:to-gray-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
      >
        {minMaxHighlighting ? '🔍 Ukryj Min/Max' : '🔍 Pokaż Min/Max'}
      </button>

      {/* 2. Reset wykluczeń */}
      <button
        onClick={resetWeightsToInitial}
        className="w-full py-4 px-5 bg-gradient-to-r from-orange-600 to-orange-500 text-white rounded-xl font-bold hover:from-orange-700 hover:to-orange-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
      >
        Reset wykluczeń
      </button>

      {/* 3. Oblicz */}
      <button
        onClick={onCalculate}
        className="w-full py-4 px-5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl font-bold hover:from-emerald-700 hover:to-emerald-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
      >
        Oblicz
      </button>

      {/* 4. Reset współczynników */}
      <button
        onClick={() => setResetOpen(true)}
        className="w-full py-4 px-5 bg-gradient-to-r from-orange-600 to-orange-500 text-white rounded-xl font-bold hover:from-orange-700 hover:to-orange-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
      >
        Reset współczynników
      </button>

      {/* 5. Eksportuj */}
      <button
        onClick={handleExport}
        className="w-full py-4 px-5 bg-gradient-to-r from-amber-600 to-amber-500 text-white rounded-xl font-bold hover:from-amber-700 hover:to-amber-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
      >
        Eksportuj do Excela
      </button>

      {/* Modals */}
      <Modal
        isOpen={resetOpen}
        title="Usunięcie współczynników"
        message="Czy na pewno chcesz usunąć współczynniki CL i wektory dev_j? Ta operacja jest nieodwracalna."
        onCancel={() => setResetOpen(false)}
        onConfirm={() => {
          handleReset();
          setResetOpen(false);
        }}
      />

      <Modal
        isOpen={isMissingFinalModalOpen}
        title="Brak finalnego wektora"
        message="Najpierw wybierz finalny wektor dev_j."
        onConfirm={closeMissingFinalModal}
        onlyOk
      />

      {/* Ustawienia wyświetlania */}
      <div className="bg-gray-800 rounded-lg p-4">
        <div className="text-white text-lg font-medium mb-4">
          Ustawienia wyświetlania
        </div>
        
        <div className="space-y-4">
          <div>
            <label className="text-white text-sm font-medium mb-2 block">
              Rozmiar tabeli
            </label>
            <ScaleControls />
          </div>
          
          <button
            onClick={() => setFullscreenMode(true)}
            className="w-full py-4 px-5 bg-gradient-to-r from-blue-600 to-blue-500 text-white rounded-xl font-bold hover:from-blue-700 hover:to-blue-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform flex items-center justify-center gap-2"
          >
            <Maximize2 className="w-4 h-4" />
            Pełny ekran
          </button>
          
          {onToggleChart && (
            <button
              onClick={onToggleChart}
              className="w-full py-4 px-5 bg-gradient-to-r from-gray-600 to-gray-500 text-white rounded-xl font-bold hover:from-gray-700 hover:to-gray-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
            >
              {showChart ? 'Ukryj wykres' : 'Pokaż wykres'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
