'use client';

import React, { useState } from 'react';
import { useIncurredCL }     from '../hooks/useIncurredCL';
import SidebarPanelCLIncurred    from '../components/SidebarPanelCLIncurred';
import DevJTableCLIncurred from '../components/DevJTableCLIncurred';
import { TableDataDetIncurred }  from '@/components/TableDataDetIncurred';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { useDisplaySettingsIncurredStore } from '@/stores/useDisplaySettingsIncurredStore';
import { useDisplaySettingsStore } from '@/stores/useDisplaySettingsStore';
import { useTrainDevideStoreDetIncurred } from '@/stores/trainDevideStoreDeterministycznyIncurred';
import { Button } from '@/components/ui/button';
import { Maximize2, Minimize2, Plus, Minus } from 'lucide-react';

export default function IncurredCLCoefficientsPage() {
  // Labels from store for Incurred
  const incurredRowLabels = useLabelsStore((s) => s.incurredRowLabels);
  const incurredColumnLabels = useLabelsStore((s) => s.incurredColumnLabels);

  // Display settings for fullscreen
  const fullscreenMode = useDisplaySettingsIncurredStore((s) => s.fullscreenMode);
  const tableScale = useDisplaySettingsIncurredStore((s) => s.tableScale);
  const setFullscreenMode = useDisplaySettingsIncurredStore((s) => s.setFullscreenMode);
  const increaseScale = useDisplaySettingsIncurredStore((s) => s.increaseScale);
  const decreaseScale = useDisplaySettingsIncurredStore((s) => s.decreaseScale);

  // Globalny stan wykresu (wspólny dla Paid i Incurred)
  const showMainChart = useDisplaySettingsStore((s) => s.showChart);
  const toggleChart = useDisplaySettingsStore((s) => s.toggleChart);

  // Stan dla animacji zamykania
  const [isClosing, setIsClosing] = useState(false);

  const {
    triangle,
    trainDevide,
    weights,
    selectedCells,
    devJResults,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    toggleRowDetIncurred,

    selectedVolume,
    selectedSubIndex,
    setSelectedVolume,

    runCL,
    isLoading,
  } = useIncurredCL();

  // Dostęp do volume i setVolume ze store
  const store = useTrainDevideStoreDetIncurred();
  const { getCurrentVolume, getMaxVolume, setVolume, weightSource } = store;
  const volume = getCurrentVolume();
  const maxVolume = getMaxVolume();

  // Calculate max length for column labels
  const maxLen = React.useMemo(
    () => Math.max(...devJResults.map((r) => r.values.length), 0),
    [devJResults]
  );

  // Funkcja do zamykania z animacją
  const handleCloseFullscreen = () => {
    setIsClosing(true);
    // Opóźnienie zamknięcia o czas trwania animacji
    setTimeout(() => {
      setFullscreenMode(false);
      setIsClosing(false);
    }, 300); // 300ms - szybsze zamykanie
  };

  // Komponent kontrolek rozmiaru - używany w obu miejscach
  const ScaleControls = () => (
    <div className="flex items-center gap-2">
      <Button
        onClick={decreaseScale}
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
        disabled={tableScale <= 0.5}
      >
        <Minus className="w-4 h-4" />
      </Button>
      
      <span className="text-white text-sm min-w-[3rem] text-center">
        {Math.round(tableScale * 100)}%
      </span>
      
      <Button
        onClick={increaseScale}
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
        disabled={tableScale >= 2.0}
      >
        <Plus className="w-4 h-4" />
      </Button>
    </div>
  );

  if (!triangle?.length) {
    return (
      <div className="p-6 text-yellow-300">
        ⏳ Oczekiwanie na dane wejściowe <code>incurredTriangle</code>…
      </div>
    );
  }
return (
  <>
    {/* Normalny widok z panelem bocznym */}
    <div className="flex gap-8 p-8 text-white">
      {/* PANEL */}
      <SidebarPanelCLIncurred 
        onCalculate={runCL} 
        devJResults={devJResults} 
        className="w-64 shrink-0"
        showChart={showMainChart}
        onToggleChart={toggleChart}
        columnLabels={
          incurredColumnLabels.length > 1
            ? incurredColumnLabels.slice(1, (trainDevide?.[0]?.length || 0) + 1)
            : undefined
        }
      />

      {/* CONTENT */}
      <div className="flex-1 min-w-0">
        {trainDevide?.length ? (
          <>
            {/* Debug - sprawdźmy dane */}
            {console.log('🔍 Debug trainDevide:', {
              trainDevide,
              trainDevideLength: trainDevide?.length,
              firstRow: trainDevide?.[0],
              firstRowLength: trainDevide?.[0]?.length,
              incurredColumnLabels,
              incurredRowLabels
            })}
            
            {/* Tabela współczynników rok do roku - styled container */}
            <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white mb-8">
              {/* Header */}
              <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
                <h3 className="font-bold text-gray-800 text-lg tracking-tight">
                  Tabela współczynników rok do roku
                </h3>
              </div>
              
              {/* Zawartość */}
              <div className="overflow-auto p-4">
                <TableDataDetIncurred 
                  data={(() => {
                    const headerRow = [''].concat(
                      incurredColumnLabels.length > 1
                        ? incurredColumnLabels.slice(1, (trainDevide[0]?.length || 0) + 1)
                        : trainDevide[0]?.map((_, i) => i.toString()) ?? []
                    );
                    
                    const dataRows = trainDevide.map((row, i) => [
                      incurredRowLabels.length > i && incurredRowLabels[i]
                        ? incurredRowLabels[i] || (i + 1).toString()
                        : (i + 1).toString(),
                      ...row.map((c) => c?.toString() ?? ''),
                    ]);
                    
                    const finalData = [headerRow, ...dataRows];
                    
                    console.log('🎯 Final data structure for TableDataDetIncurred (główna):', {
                      headerRow,
                      firstDataRow: dataRows[0],
                      finalData: finalData.slice(0, 3),
                      totalRows: finalData.length,
                      totalCols: finalData[0]?.length
                    });
                    
                    return finalData;
                  })()}
                  weights={weights}
                  selectedCells={selectedCells}
                  minMaxCells={minMaxHighlighting ? minMaxCells : []}
                  minCells={minMaxHighlighting ? minCells : []}
                  maxCells={minMaxHighlighting ? maxCells : []}
                  showRowToggle={true}
                  onToggleRow={toggleRowDetIncurred}
                />
              </div>
            </div>

            {devJResults.length > 0 && (
              <div className="mt-10">
                <DevJTableCLIncurred
                  devJResults={devJResults}
                  selectedVolume={selectedVolume}
                  selectedSubIndex={selectedSubIndex}
                  onSelectVolume={setSelectedVolume}
                  columnLabels={
                    incurredColumnLabels.length > 1
                      ? incurredColumnLabels.slice(1, 1 + maxLen)
                      : undefined
                  }
                  externalShowChart={showMainChart}
                />
              </div>
            )}
          </>
        ) : (
          <p className="text-yellow-400">
            {isLoading ? 'Obliczanie...' : 'Brak wyników obliczeń współczynników'}
          </p>
        )}
      </div>
    </div>

    {/* Overlay pełnoekranowy - wyświetla się NAD wszystkim */}
    {fullscreenMode && (
      <div 
        className="fixed inset-0 bg-gray-900 z-50 flex flex-col transition-all duration-300 ease-out"
        style={{
          animation: isClosing ? 'fadeOut 0.2s ease-in forwards' : 'fadeIn 0.3s ease-out'
        }}
      >
        {/* Górny pasek z przyciskiem zamknięcia */}
        <div 
          className="bg-gray-800 p-4 flex justify-between items-center border-b border-gray-700 transition-all duration-300 ease-out"
          style={{
            animation: isClosing 
              ? 'slideOutToTop 0.25s ease-in forwards' 
              : 'slideInFromTop 0.4s ease-out 0.1s both'
          }}
        >
          <h2 className="text-white text-lg font-medium">Tabela współczynników rok do roku - Widok pełnoekranowy</h2>
          
          <div className="flex items-center gap-4">
            {/* Kontrolki volume i oblicz */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <label className="text-white text-sm font-medium">Volume:</label>
                <input
                  type="number"
                  min="1"
                  max={maxVolume}
                  value={volume}
                  onChange={(e) => setVolume(Number(e.target.value))}
                  className="w-16 px-2 py-1 bg-gray-700 border border-gray-600 rounded text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              
              <button
                onClick={runCL}
                disabled={isLoading}
                className="py-3 px-4 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-700 hover:to-emerald-600 text-white rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? 'Obliczanie...' : 'Oblicz'}
              </button>
            </div>

            {/* Kontrolki rozmiaru tabeli */}
            <div className="flex items-center gap-2">
              <Button
                onClick={decreaseScale}
                variant="outline"
                size="sm"
                className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
                disabled={tableScale <= 0.5}
              >
                <Minus className="w-4 h-4" />
              </Button>
              
              <span className="text-white text-sm min-w-[3rem] text-center">
                {Math.round(tableScale * 100)}%
              </span>
              
              <Button
                onClick={increaseScale}
                variant="outline"
                size="sm"
                className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
                disabled={tableScale >= 2.0}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            
            <Button
              onClick={handleCloseFullscreen}
              variant="outline"
              size="sm"
              className="text-white border-gray-600 hover:bg-gray-700"
            >
              <Minimize2 className="w-4 h-4 mr-2" />
              Zamknij pełny ekran
            </Button>
          </div>
        </div>
        
        {/* Zawartość zajmująca całą dostępną przestrzeń */}
        <div 
          className="flex-1 p-6 overflow-auto bg-gray-900 transition-all duration-500 ease-out"
          style={{
            animation: isClosing 
              ? 'zoomOut 0.3s ease-in forwards'
              : 'zoomIn 0.5s ease-out 0.2s both'
          }}
        >
          {trainDevide?.length ? (
            <div 
              style={{ 
                transform: `scale(${tableScale})`, 
                transformOrigin: 'top left',
                width: `${100 / tableScale}%`,
                height: `${100 / tableScale}%`
              }}
            >
              <TableDataDetIncurred
                data={[
                  [''].concat(
                    incurredColumnLabels.length > 1
                      ? incurredColumnLabels.slice(1, (trainDevide[0]?.length || 0) + 1)
                      : trainDevide[0]?.map((_, i) => i.toString()) ?? []
                  ),
                  ...trainDevide.map((row, i) => [
                    incurredRowLabels.length > i + 1 && incurredRowLabels[i + 1]
                      ? incurredRowLabels[i + 1] || i.toString()
                      : i.toString(),
                    ...row.map((c) => c?.toString() ?? ''),
                  ]),
                ]}
                weights={weights}
                selectedCells={selectedCells}
                minMaxCells={minMaxHighlighting ? minMaxCells : []}
                minCells={minMaxHighlighting ? minCells : []}
                maxCells={minMaxHighlighting ? maxCells : []}
                showRowToggle={true}
                onToggleRow={toggleRowDetIncurred}
              />

              {devJResults.length > 0 && (
                <section className="mt-10">
                  <h3 className="font-bold mb-2 text-white">
                    Tabela ważonych uśrednionych współczynników
                  </h3>

                  <DevJTableCLIncurred
                    devJResults={devJResults}
                    selectedVolume={selectedVolume}
                    selectedSubIndex={selectedSubIndex}
                    onSelectVolume={setSelectedVolume}
                    columnLabels={
                      incurredColumnLabels.length > 1
                        ? incurredColumnLabels.slice(1, 1 + maxLen)
                        : undefined
                    }
                  />
                </section>
              )}
            </div>
          ) : (
            <p className="text-yellow-400">
              {isLoading ? 'Obliczanie...' : 'Brak wyników obliczeń współczynników'}
            </p>
          )}
        </div>
        
        {/* Style animacji - otwieranie i zamykanie */}
        <style jsx>{`
          /* Animacje otwierania */
          @keyframes fadeIn {
            from {
              opacity: 0;
            }
            to {
              opacity: 1;
            }
          }
          
          @keyframes slideInFromTop {
            from {
              transform: translateY(-20px);
              opacity: 0;
            }
            to {
              transform: translateY(0);
              opacity: 1;
            }
          }
          
          @keyframes zoomIn {
            from {
              transform: scale(0.95);
              opacity: 0;
            }
            to {
              transform: scale(1);
              opacity: 1;
            }
          }
          
          /* Animacje zamykania */
          @keyframes fadeOut {
            from {
              opacity: 1;
            }
            to {
              opacity: 0;
            }
          }
          
          @keyframes slideOutToTop {
            from {
              transform: translateY(0);
              opacity: 1;
            }
            to {
              transform: translateY(-20px);
              opacity: 0;
            }
          }
          
          @keyframes zoomOut {
            from {
              transform: scale(1);
              opacity: 1;
            }
            to {
              transform: scale(0.95);
              opacity: 0;
            }
          }
        `}</style>
      </div>
    )}
  </>
);
}