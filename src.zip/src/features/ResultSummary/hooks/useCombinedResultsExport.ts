/* ------------------------------------------------------------------ */
/*                    Combined Results Export Hook                     */
/* ------------------------------------------------------------------ */

import { useState, useCallback } from 'react';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useTrainDevideStoreDetIncurred } from '@/stores/trainDevideStoreDeterministycznyIncurred';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { useDataOptions } from '@/shared/hooks/useDataOptions';
import { usePayloadBuilder } from '@/shared/hooks/usePayloadBuilder';

export interface CombinedExportItem {
  key: string;
  label: string;
  selected: boolean;
  type: 'paid' | 'incurred' | 'comparison' | 'weighted-summary';
  category: 'calculations' | 'comparisons' | 'summary';
}

export interface WeightedSummaryData {
  enrichedRows: Array<{
    paid: number;
    wPaid: number;
    incurred: number;
    wInc: number;
    sum: number;
  }>;
  grandTotal: number;
}

export const useCombinedResultsExport = (weightedSummaryData?: WeightedSummaryData) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [exportItems, setExportItems] = useState<CombinedExportItem[]>([]);

  /* ========== PAID DATA ========== */
  const paidSimResults = useTrainDevideStoreDet((s) => s.simResults) ?? {};
  const paidDevJResults = useTrainDevideStoreDet((s) => s.devJResults) ?? [];
  const paidFinalDevVector = useTrainDevideStoreDet((s) => s.finalDevVector) ?? [];
  const paidCombinedDevJSummary = useTrainDevideStoreDet((s) => s.combinedDevJSummary) ?? [];
  const paidComparisonTables = useTrainDevideStoreDet((s) => s.comparisonTables);
  const paidTriangle = useTrainDevideStoreDet((s) => s.paidTriangle) ?? [];
  const paidTrainDevideDet = useTrainDevideStoreDet((s) => s.trainDevideDet) ?? [];

  /* ========== INCURRED DATA ========== */
  const incurredSimResults = useTrainDevideStoreDetIncurred((s) => s.simResults) ?? {};
  const incurredDevJResults = useTrainDevideStoreDetIncurred((s) => s.devJResults) ?? [];
  const incurredFinalDevVector = useTrainDevideStoreDetIncurred((s) => s.finalDevVector) ?? [];
  const incurredCombinedDevJSummary = useTrainDevideStoreDetIncurred((s) => s.combinedDevJSummary) ?? [];
  const incurredComparisonTables = useTrainDevideStoreDetIncurred((s) => s.comparisonTables);
  const incurredTriangle = useTrainDevideStoreDetIncurred((s) => s.incurredTriangle) ?? [];
  const incurredTrainDevideDet = useTrainDevideStoreDetIncurred((s) => s.trainDevideDetIncurred) ?? [];

  /* ========== LABELS ========== */
  const detColumnLabels = useLabelsStore((s) => s.detColumnLabels);
  const detRowLabels = useLabelsStore((s) => s.detRowLabels);
  const incurredColumnLabels = useLabelsStore((s) => s.incurredColumnLabels);
  const incurredRowLabels = useLabelsStore((s) => s.incurredRowLabels);

  /* ========== REMAINING DEV_J HEADERS ========== */
  const paidRemainingDevJHeaders = useTrainDevideStoreDet(s => s.remainingDevJHeaders);
  const incurredRemainingDevJHeaders = useTrainDevideStoreDetIncurred(s => s.remainingDevJHeaders);

  /* ========== PAID HOOKS ========== */
  const { allOptions: paidAllOptions } = useDataOptions({
    simResults: paidSimResults,
    devJResults: paidDevJResults,
    combinedDevJSummary: paidCombinedDevJSummary,
    finalDevVector: paidFinalDevVector,
  });

  const { buildPayload: paidBuildPayload } = usePayloadBuilder({
    simResults: paidSimResults,
    devJResults: paidDevJResults,
    combinedDevJSummary: paidCombinedDevJSummary,
    finalDevVector: paidFinalDevVector,
  });

  /* ========== INCURRED HOOKS ========== */
  const { allOptions: incurredAllOptions } = useDataOptions({
    simResults: incurredSimResults,
    devJResults: incurredDevJResults,
    combinedDevJSummary: incurredCombinedDevJSummary,
    finalDevVector: incurredFinalDevVector,
  });

  const { buildPayload: incurredBuildPayload } = usePayloadBuilder({
    simResults: incurredSimResults,
    devJResults: incurredDevJResults,
    combinedDevJSummary: incurredCombinedDevJSummary,
    finalDevVector: incurredFinalDevVector,
  });

  const initializeExportItems = useCallback(() => {
    const items: CombinedExportItem[] = [];

    // PAID CALCULATIONS FIRST
    // 1. Paid Triangle data (Input Data) - FIRST in Paid calculations
    if (paidTriangle && paidTriangle.length > 0) {
      items.push({
        key: 'triangle-data-paid',
        label: 'Trójkąt danych (Paid)',
        selected: true,
        type: 'paid', // Change from 'triangle' to 'paid'
        category: 'calculations',
      });
    }

    // 2. Paid CL Coefficients
    items.push({
      key: 'paid-cl-coefficients',
      label: 'Współczynniki CL (Paid)',
      selected: true,
      type: 'paid',
      category: 'calculations',
    });

    // 3. Paid calculations (selected curves/coefficients by user)
    paidAllOptions.forEach((option) => {
      items.push({
        key: `paid-calc-${option.key}`,
        label: `Paid: ${option.label}`,
        selected: true,
        type: 'paid',
        category: 'calculations',
      });
    });

    // INCURRED CALCULATIONS SECOND
    // 1. Incurred Triangle data (Input Data) - FIRST in Incurred calculations
    if (incurredTriangle && incurredTriangle.length > 0) {
      items.push({
        key: 'triangle-data-incurred',
        label: 'Trójkąt danych (Incurred)',
        selected: true,
        type: 'incurred', // Change from 'triangle' to 'incurred'
        category: 'calculations',
      });
    }

    // 2. Incurred CL Coefficients
    items.push({
      key: 'incurred-cl-coefficients',
      label: 'Współczynniki CL (Incurred)',
      selected: true,
      type: 'incurred',
      category: 'calculations',
    });

    // 3. Incurred calculations (selected curves/coefficients by user)
    incurredAllOptions.forEach((option) => {
      items.push({
        key: `incurred-calc-${option.key}`,
        label: `Incurred: ${option.label}`,
        selected: true,
        type: 'incurred',
        category: 'calculations',
      });
    });

    // Paid comparisons
    paidComparisonTables.forEach((table, index) => {
      items.push({
        key: `paid-comp-${index}`,
        label: `Paid porównanie: ${table.labelA} vs ${table.labelB}`,
        selected: true,
        type: 'paid',
        category: 'comparisons',
      });
    });

    // Incurred comparisons
    incurredComparisonTables.forEach((table, index) => {
      items.push({
        key: `incurred-comp-${index}`,
        label: `Incurred porównanie: ${table.labelA} vs ${table.labelB}`,
        selected: true,
        type: 'incurred',
        category: 'comparisons',
      });
    });

    // Weighted Summary
    if (weightedSummaryData && weightedSummaryData.enrichedRows.length > 0) {
      items.push({
        key: 'weighted-summary',
        label: 'Tabela końcowa - podsumowanie ważone',
        selected: true,
        type: 'weighted-summary',
        category: 'summary',
      });
    }

    setExportItems(items);
    setIsDialogOpen(true);
  }, [
    paidAllOptions,
    incurredAllOptions,
    paidComparisonTables,
    incurredComparisonTables,
    weightedSummaryData,
    paidTriangle,
    incurredTriangle,
  ]);

  const toggleItemSelection = useCallback((key: string) => {
    setExportItems((prev) =>
      prev.map((item) =>
        item.key === key ? { ...item, selected: !item.selected } : item
      )
    );
  }, []);

  const toggleAllSelection = useCallback(() => {
    const allSelected = exportItems.every((item) => item.selected);
    setExportItems((prev) =>
      prev.map((item) => ({ ...item, selected: !allSelected }))
    );
  }, [exportItems]);

  const closeDialog = useCallback(() => {
    setIsDialogOpen(false);
  }, []);

  // Helper function to create calculation sheet data
  const createCalculationSheetData = useCallback((
    type: 'paid' | 'incurred',
    calculations: CombinedExportItem[],
    buildPayload: Function,
    trainDevideDet: any[][],
    columnLabels: string[] | undefined,
    devJResults: any[],
    triangle: any[][],
    remainingDevJHeaders: string[],
    includeTriangle: boolean = false
  ) => {
    const sheetData: any[][] = [];
    let currentRow = 0;
    let hasVolumes = false;
    let hasCurves = false;
    let hasFinalDev = false;
    
    // Collect data for each section
    const volumes: any[] = [];
    const curves: any[] = [];
    let finalDevData: any = null;

    calculations.forEach((item) => {
      // Skip special items that are not actual calculations
      if (item.key === 'triangle-data-paid' || 
          item.key === 'triangle-data-incurred' ||
          item.key === 'paid-cl-coefficients' || 
          item.key === 'incurred-cl-coefficients') {
        return;
      }
      
      const originalKey = item.key.replace(/^(paid|incurred)-calc-/, '');
      const payload = buildPayload(originalKey);
      
      if (payload) {
        if (payload.curve_name && payload.coeffs) {
          curves.push({ name: payload.curve_name, coeffs: payload.coeffs });
          hasCurves = true;
        } else if (payload.volume && payload.values) {
          volumes.push({ name: `Volume ${payload.volume}`, values: payload.values });
          hasVolumes = true;
        } else if (payload.final_dev_vector) {
          finalDevData = { name: 'Pozostawione dev_j', values: payload.final_dev_vector };
          hasFinalDev = true;
        }
      }
    });

    // 0. Trójkąt danych (Input Data) - only include if specified
    if (includeTriangle && triangle && triangle.length > 0) {
      sheetData.push([`=== Trójkąt danych (${type === 'paid' ? 'Paid' : 'Incurred'}) ===`]);
      currentRow++;
      sheetData.push([]);
      currentRow++;

      sheetData.push(['Trójkąt:']);
      currentRow++;
      
      // Create headers for triangle using proper labels
      const maxCols = Math.max(...triangle.map((row: any[]) => row.length));
      const activeColumnLabels = type === 'paid' ? detColumnLabels : incurredColumnLabels;
      const activeRowLabels = type === 'paid' ? detRowLabels : incurredRowLabels;
      
      const triangleHeaders = ['Rok', ...activeColumnLabels.slice(0, maxCols)];
      sheetData.push(triangleHeaders);
      currentRow++;
      
      // Add triangle data rows with proper row labels
      triangle.forEach((row: any[], idx: number) => {
        const rowLabel = activeRowLabels[idx] ?? (1981 + idx).toString();
        const dataRow = [rowLabel, ...row.map((val: any) => val ?? '')];
        // Fill missing values with empty strings
        while (dataRow.length < triangleHeaders.length) {
          dataRow.push('');
        }
        sheetData.push(dataRow);
        currentRow++;
      });

      sheetData.push([]);
      currentRow++;

      // Współczynniki CL section
      if (trainDevideDet && trainDevideDet.length > 0) {
        sheetData.push(['Współczynniki CL:']);
        currentRow++;
        
        // Create headers for CL coefficients using proper labels (start from index 1)
        const maxClCols = Math.max(...trainDevideDet.map((row: any[]) => row.length));
        const activeColumnLabels = type === 'paid' ? detColumnLabels : incurredColumnLabels;
        const activeRowLabels = type === 'paid' ? detRowLabels : incurredRowLabels;
        
        const clHeaders = ['Rok', ...activeColumnLabels.slice(1, 1 + maxClCols)];
        sheetData.push(clHeaders);
        currentRow++;
        
        // Add CL coefficients data rows with proper row labels
        trainDevideDet.forEach((row: any[], idx: number) => {
          const rowLabel = activeRowLabels[idx] ?? (1981 + idx).toString();
          const dataRow: any[] = [rowLabel, ...row.map((val: any) => val ?? '')];
          // Fill missing values with empty strings
          while (dataRow.length < clHeaders.length) {
            dataRow.push('');
          }
          sheetData.push(dataRow);
          currentRow++;
        });
      }

      // Add separator
      sheetData.push([]);
      sheetData.push([]);
      currentRow += 2;
    }

    // 1. Pełna tabela współczynników CL
    if (trainDevideDet.length > 0 && (!includeTriangle || !triangle || triangle.length === 0)) {
      sheetData.push([`=== 1. Pełna tabela współczynników CL (${type === 'paid' ? 'Paid' : 'Incurred'}) ===`]);
      currentRow++;
      sheetData.push([]);
      currentRow++;
      // Nagłówki kolumn - match format used in other sections (start from column index 1)
      const colLabels = columnLabels && columnLabels.length > 1
        ? columnLabels.slice(1, (trainDevideDet[0]?.length || 0) + 1)
        : trainDevideDet[0]?.map((_, i) => (i + 1).toString()) ?? [];
      sheetData.push([''].concat(colLabels));
      currentRow++;
      // Wiersze
      trainDevideDet.forEach((row, i) => {
        sheetData.push([
          columnLabels && columnLabels.length > i + 1 && columnLabels[i + 1]
            ? columnLabels[i + 1]
            : (i + 1).toString(),
          ...row
        ]);
        currentRow++;
      });
      sheetData.push([]);
      sheetData.push([]);
      currentRow += 2;
    }

    // 2. Dev podstawowe section (or 1. if no triangle data)
    if (hasVolumes) {
      const sectionNumber = includeTriangle && triangle && triangle.length > 0 ? '1' : '2';
      sheetData.push([`=== ${sectionNumber}. Dev podstawowe ===`]);
      currentRow++;
      sheetData.push([]);
      currentRow++;

      // Find max values for headers
      const maxValues = Math.max(...volumes.map(vol => vol.values.length));
      
      // Create headers - match CL coefficients headers (start from column index 1)
      const headers = ['Nazwa'];
      for (let i = 0; i < maxValues; i++) {
        if (columnLabels && columnLabels.length > i + 1 && columnLabels[i + 1]) {
          headers.push(columnLabels[i + 1]!);
        } else {
          headers.push(`${i + 2}`);
        }
      }
      sheetData.push(headers);
      currentRow++;
      
      // Add volume rows (not final dev)
      volumes.forEach((vol) => {
        const row = [vol.name, ...vol.values];
        while (row.length < headers.length) row.push('');
        sheetData.push(row);
        currentRow++;
      });

      // Add Initial Selection row
      // Get finalDevJ and devFinalCustom from appropriate store
      const storeFinalDevJ = type === 'paid' 
        ? useTrainDevideStoreDet.getState().finalDevJ
        : useTrainDevideStoreDetIncurred.getState().finalDevJ;
      
      const storeDevFinalCustom = type === 'paid'
        ? useTrainDevideStoreDet.getState().devFinalCustom
        : useTrainDevideStoreDetIncurred.getState().devFinalCustom;

      if (storeFinalDevJ) {
        // Build Initial Selection row using same logic as displayed() in DevJTableCL
        const initialSelectionValues: (number | string)[] = [];
        for (let j = 0; j < maxValues; j++) {
          const customCell = storeDevFinalCustom?.[j];
          const value = customCell ? customCell.value : storeFinalDevJ.values[j];
          initialSelectionValues.push(value ?? '');
        }
        
        const initialSelectionRow = ['Initial Selection', ...initialSelectionValues];
        while (initialSelectionRow.length < headers.length) initialSelectionRow.push('');
        sheetData.push(initialSelectionRow);
        currentRow++;

        // Add Odchyl. Standardowe row
        const sdValues: (number | string)[] = [];
        for (let j = 0; j < maxValues; j++) {
          const customCell = storeDevFinalCustom?.[j];
          let sdValue: number | undefined;

          if (customCell && customCell.sourceVolume !== undefined) {
            // Find the source volume in devJResults
            const sourceResult = devJResults.find(
              (result: any) => 
                result.volume === customCell.sourceVolume && 
                (result.subIndex ?? 0) === (customCell.sourceSubIndex ?? 0)
            );
            sdValue = sourceResult?.sdValues?.[j];
          } else if (storeFinalDevJ.values[j] !== undefined) {
            // Use SD from finalDevJ
            sdValue = storeFinalDevJ.sdValues?.[j];
          }

          sdValues.push(sdValue ?? '–');
        }

        const sdRow = ['Odchyl. Standardowe', ...sdValues];
        while (sdRow.length < headers.length) sdRow.push('');
        sheetData.push(sdRow);
        currentRow++;
      }

      sheetData.push([]);
      sheetData.push([]);
      currentRow += 2;
    }

    // 3. Tabela współczynników z dopasowanych krzywych (or 2. if no triangle data)
    if (hasCurves) {
      const sectionNumber = includeTriangle && triangle && triangle.length > 0 ? '2' : '3';
      sheetData.push([`=== ${sectionNumber}. Tabela współczynników z dopasowanych krzywych ===`]);
      currentRow++;
      sheetData.push([]);
      currentRow++;

      const maxCoeffs = Math.max(...curves.map(curve => curve.coeffs.length));
      const headers = ['Krzywa', ...Array.from({ length: maxCoeffs }, (_, i) => `k-${i + 1}`)];
      sheetData.push(headers);
      currentRow++;
      
      curves.forEach((curve) => {
        const row = [curve.name, ...curve.coeffs];
        while (row.length < headers.length) row.push('');
        sheetData.push(row);
        currentRow++;
      });

      sheetData.push([]);
      sheetData.push([]);
      currentRow += 2;
    }

    // 4. Tabela współczynników Selected Value (or 3. if no triangle data)
    if (hasFinalDev && finalDevData) {
      const sectionNumber = includeTriangle && triangle && triangle.length > 0 ? '3' : '4';
      sheetData.push([`=== ${sectionNumber}. Tabela współczynników Selected Value ===`]);
      currentRow++;
      sheetData.push([]);
      currentRow++;

      console.log('🏷️ Debug stored headers from stores:', {
        type,
        remainingDevJHeaders,
        finalDevDataLength: finalDevData.values.length
      });

      const headers = ['Nazwa'];
      
      if (remainingDevJHeaders.length > 0 && remainingDevJHeaders.length >= finalDevData.values.length) {
        // Use stored headers from FinalTable
        headers.push(...remainingDevJHeaders.slice(0, finalDevData.values.length));
        console.log('✅ Using stored headers from FinalTable:', remainingDevJHeaders);
      } else {
        // Fallback to columnLabels logic with offset if no stored headers
        console.log('⚠️ No stored headers found, falling back to columnLabels with offset');
        
        for (let i = 0; i < finalDevData.values.length; i++) {
          console.log(`🔍 Processing column ${i}, checking columnLabels[${i + 1}]:`, columnLabels?.[i + 1]);
          
          if (columnLabels && columnLabels.length > i + 1 && columnLabels[i + 1]) {
            const label = columnLabels[i + 1];
            if (label) {
              headers.push(label);
              console.log(`✅ Using columnLabel: ${label}`);
              continue;
            }
          }
          
          // Final fallback to original hardcoded logic
          let fallbackHeader = '';
          if (i === 0) {
            fallbackHeader = 'P-2';
          } else if (i >= 1 && i <= 2) {
            fallbackHeader = `${i + 2}`; // 3, 4
          } else {
            fallbackHeader = `W-${i + 2}`; // W-5, W-6, W-7, W-8, W-9, W-10, etc.
          }
          headers.push(fallbackHeader);
          console.log(`⚠️ Using final fallback header: ${fallbackHeader}`);
        }
      }
      
      sheetData.push(headers);
      currentRow++;
      
      // Add the final dev row with "Selected Value" name
      const finalRow = ['Selected Value', ...finalDevData.values];
      while (finalRow.length < headers.length) finalRow.push('');
      sheetData.push(finalRow);
      currentRow++;
    }

    return { sheetData, volumes, curves, finalDevData };
  }, []);

  const exportSelectedCalculations = useCallback(() => {
    const selectedItems = exportItems.filter((item) => item.selected);
    if (selectedItems.length === 0) {
      alert('Wybierz przynajmniej jeden element do eksportu');
      return;
    }

    try {
      console.log('🚀 Starting fresh export with current data...');

      const workbook = XLSX.utils.book_new();
      const usedSheetNames = new Set<string>(); // Track used sheet names

      // Group calculations by type (paid/incurred) - triangle data now has proper type
      const paidCalculations = selectedItems.filter(item => 
        item.category === 'calculations' && item.type === 'paid'
      );
      const incurredCalculations = selectedItems.filter(item => 
        item.category === 'calculations' && item.type === 'incurred'
      );
      const comparisons = selectedItems.filter(item => item.category === 'comparisons');
      
      // Check if triangle data is selected for each type
      const paidTriangleSelected = selectedItems.some(item => item.key === 'triangle-data-paid');
      const incurredTriangleSelected = selectedItems.some(item => item.key === 'triangle-data-incurred');

      // Create combined Paid calculations sheet
      if (paidCalculations.length > 0) {
        const { sheetData, volumes } = createCalculationSheetData(
          'paid',
          paidCalculations,
          paidBuildPayload,
          paidTrainDevideDet,
          detColumnLabels,
          paidDevJResults,
          paidTriangle,
          paidRemainingDevJHeaders,
          paidTriangleSelected // Include paid triangle data based on user selection
        );

        // Create the worksheet
        if (sheetData.length > 0) {
          const worksheet = XLSX.utils.aoa_to_sheet(sheetData);
          
          // Add highlighting for selected volume (same logic as useCalculationsExport)
          if (volumes.length > 0) {
            // Find the row that contains volume data and apply green background
            let volumeRowStart = -1;
            
            // Find where Dev podstawowe section starts (can be section 1 or 2 depending on triangle data)
            for (let i = 0; i < sheetData.length; i++) {
              const row = sheetData[i];
              if (row && row.length > 0 && (row[0] === '=== 1. Dev podstawowe ===' || row[0] === '=== 2. Dev podstawowe ===')) {
                volumeRowStart = i + 4; // Data starts after section header + empty line + headers
                break;
              }
            }
            
            if (volumeRowStart > 0) {
              // Find the specific volume row and apply highlighting
              volumes.forEach((vol, volIndex) => {
                const rowIndex = volumeRowStart + volIndex;
                
                // Get finalDevJ data to determine selected values
                const finalDevJData = useTrainDevideStoreDet.getState().finalDevJ;
                const devFinalCustom = useTrainDevideStoreDet.getState().devFinalCustom;
                
                // Function to get displayed value (same logic as in UI)
                const getDisplayed = (j: number) => {
                  const cell = devFinalCustom?.[j];
                  return cell ? cell.value : finalDevJData?.values[j];
                };
                
                // Apply green background to selected cells
                vol.values.forEach((value: number, valueIndex: number) => {
                  const colIndex = valueIndex + 1; // +1 because first column is name
                  const cellAddress = XLSX.utils.encode_cell({ r: rowIndex, c: colIndex });
                  
                  // Check if this value is selected (matches finalDevJ logic)
                  const displayed = getDisplayed(valueIndex);
                  const isSelected = displayed === value;
                  
                  if (isSelected) {
                    // Apply green background color to match UI (bg-green-200)
                    if (!worksheet['!cols']) worksheet['!cols'] = [];
                    if (!worksheet[cellAddress]) worksheet[cellAddress] = { t: 'n', v: value };
                    
                    worksheet[cellAddress].s = {
                      fill: {
                        fgColor: { rgb: "C6F6D5" }, // Light green color to match bg-green-200
                      },
                      font: {
                        color: { rgb: "000000" }, // Black text color
                      }
                    };
                    
                    console.log(`🎨 Applied green highlighting to cell ${cellAddress} (Paid, value: ${value})`);
                  }
                });
              });
            }
          }
          
          XLSX.utils.book_append_sheet(workbook, worksheet, 'Obliczenia Paid');
          usedSheetNames.add('Obliczenia Paid');
        }
      }

      // Create combined Incurred calculations sheet
      if (incurredCalculations.length > 0) {
        const { sheetData, volumes } = createCalculationSheetData(
          'incurred',
          incurredCalculations,
          incurredBuildPayload,
          incurredTrainDevideDet,
          incurredColumnLabels,
          incurredDevJResults,
          incurredTriangle,
          incurredRemainingDevJHeaders,
          incurredTriangleSelected // Include incurred triangle data based on user selection
        );

        // Create the worksheet
        if (sheetData.length > 0) {
          const worksheet = XLSX.utils.aoa_to_sheet(sheetData);
          
          // Add highlighting for selected volume (same logic as useCalculationsExport)
          if (volumes.length > 0) {
            // Find the row that contains volume data and apply green background
            let volumeRowStart = -1;
            
            // Find where Dev podstawowe section starts (can be section 1 or 2 depending on triangle data)
            for (let i = 0; i < sheetData.length; i++) {
              const row = sheetData[i];
              if (row && row.length > 0 && (row[0] === '=== 1. Dev podstawowe ===' || row[0] === '=== 2. Dev podstawowe ===')) {
                volumeRowStart = i + 4; // Data starts after section header + empty line + headers
                break;
              }
            }
            
            if (volumeRowStart > 0) {
              // Find the specific volume row and apply highlighting
              volumes.forEach((vol, volIndex) => {
                const rowIndex = volumeRowStart + volIndex;
                
                // Get finalDevJ data to determine selected values
                const finalDevJData = useTrainDevideStoreDetIncurred.getState().finalDevJ;
                const devFinalCustom = useTrainDevideStoreDetIncurred.getState().devFinalCustom;
                
                // Function to get displayed value (same logic as in UI)
                const getDisplayed = (j: number) => {
                  const cell = devFinalCustom?.[j];
                  return cell ? cell.value : finalDevJData?.values[j];
                };
                
                // Apply green background to selected cells
                vol.values.forEach((value: number, valueIndex: number) => {
                  const colIndex = valueIndex + 1; // +1 because first column is name
                  const cellAddress = XLSX.utils.encode_cell({ r: rowIndex, c: colIndex });
                  
                  // Check if this value is selected (matches finalDevJ logic)
                  const displayed = getDisplayed(valueIndex);
                  const isSelected = displayed === value;
                  
                  if (isSelected) {
                    // Apply green background color to match UI (bg-green-200)
                    if (!worksheet['!cols']) worksheet['!cols'] = [];
                    if (!worksheet[cellAddress]) worksheet[cellAddress] = { t: 'n', v: value };
                    
                    worksheet[cellAddress].s = {
                      fill: {
                        fgColor: { rgb: "C6F6D5" }, // Light green color to match bg-green-200
                      },
                      font: {
                        color: { rgb: "000000" }, // Black text color
                      }
                    };
                    
                    console.log(`🎨 Applied green highlighting to cell ${cellAddress} (Incurred, value: ${value})`);
                  }
                });
              });
            }
          }
          
          XLSX.utils.book_append_sheet(workbook, worksheet, 'Obliczenia Incurred');
          usedSheetNames.add('Obliczenia Incurred');
        }
      }

      // Process comparison tables (each as separate sheet)
      comparisons.forEach((item) => {
        const index = parseInt(item.key.replace(/^(paid|incurred)-comp-/, ''));
        let worksheetData: any[] = [];
        let sheetName = '';

        if (item.type === 'paid' && paidComparisonTables[index]) {
          const table = paidComparisonTables[index];
          // Use the same approach as useCalculationsExport
          worksheetData = table.data.map((row: any) => {
            const obj: Record<string, any> = {};
            for (const [k, v] of Object.entries(row)) {
              let newKey = k;
              if (k === 'Projection A') newKey = table.labelA;
              if (k === 'Projection B') newKey = table.labelB;
              
              // Przekonwertuj stringi liczbowe na liczby
              const parsed =
                typeof v === 'string' && v.match(/^-?\d+([,\.]\d+)?$/)
                  ? parseFloat(v.replace(',', '.'))
                  : v;
              obj[newKey] = parsed;
            }
            return obj;
          });
          sheetName = `Paid Porównania ${index + 1}`;
        } else if (item.type === 'incurred' && incurredComparisonTables[index]) {
          const table = incurredComparisonTables[index];
          // Use the same approach as useCalculationsExport
          worksheetData = table.data.map((row: any) => {
            const obj: Record<string, any> = {};
            for (const [k, v] of Object.entries(row)) {
              let newKey = k;
              if (k === 'Projection A') newKey = table.labelA;
              if (k === 'Projection B') newKey = table.labelB;
              
              // Przekonwertuj stringi liczbowe na liczby
              const parsed =
                typeof v === 'string' && v.match(/^-?\d+([,\.]\d+)?$/)
                  ? parseFloat(v.replace(',', '.'))
                  : v;
              obj[newKey] = parsed;
            }
            return obj;
          });
          sheetName = `Incurred Porównania ${index + 1}`;
        }

        // Add comparison worksheet
        if (worksheetData.length > 0 && sheetName) {
          // Generate safe sheet name (same logic as useCalculationsExport)
          const baseName = sheetName
            .replace(/[:\/\\\?\*\[\]]/g, '-')
            .substring(0, 25);

          let finalSheetName = baseName;
          let sheetIndex = 1;
          while (usedSheetNames.has(finalSheetName)) {
            finalSheetName = `${baseName}-${sheetIndex}`;
            sheetIndex++;
          }
          usedSheetNames.add(finalSheetName);
          
          const worksheet = XLSX.utils.json_to_sheet(worksheetData);
          XLSX.utils.book_append_sheet(workbook, worksheet, finalSheetName);
        }
      });

      // Add Weighted Summary if selected
      const weightedSummaryItem = selectedItems.find(item => item.type === 'weighted-summary');
      if (weightedSummaryItem && weightedSummaryData) {
        // Generate row labels based on the number of rows
        const rowLabels: string[] = [];
        const numRows = weightedSummaryData.enrichedRows.length;
        
        // First 3 rows: j, k, l
        if (numRows > 0) rowLabels.push('j');
        if (numRows > 1) rowLabels.push('k');
        if (numRows > 2) rowLabels.push('l');
        
        // Remaining rows: years starting from 1984
        for (let i = 3; i < numRows; i++) {
          rowLabels.push((1981 + i).toString()); // 1984, 1985, 1986, etc.
        }
        
        const summaryData: any[] = weightedSummaryData.enrichedRows.map((row, idx) => ({
          Wiersz: rowLabels[idx] || '',
          Paid: row.paid,
          'Waga Paid': row.wPaid,
          Incurred: row.incurred,
          'Waga Incurred': row.wInc,
          Sum: row.sum,
        }));

        // Add total row
        summaryData.push({
          Wiersz: 'Suma',
          Paid: '',
          'Waga Paid': '',
          Incurred: '',
          'Waga Incurred': '',
          Sum: weightedSummaryData.grandTotal,
        });

        const sheetName = 'Tabela końcowa';
        let finalSheetName = sheetName;
        let counter = 1;
        while (usedSheetNames.has(finalSheetName)) {
          finalSheetName = `${sheetName}_${counter}`;
          counter++;
        }
        usedSheetNames.add(finalSheetName);

        const worksheet = XLSX.utils.json_to_sheet(summaryData);
        XLSX.utils.book_append_sheet(workbook, worksheet, finalSheetName);
      }

      if (workbook.SheetNames.length === 0) {
        alert('Nie znaleziono żadnych danych do eksportu');
        return;
      }

      // Save file with new name
      const buffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const fileName = 'obliczenia_paid_incurred.xlsx';
      saveAs(blob, fileName);
      
     // setIsDialogOpen(false);
    //  alert('Eksport zakończony pomyślnie!');
    } catch (error) {
      console.error('Błąd podczas eksportu:', error);
      alert(`Wystąpił błąd podczas eksportu pliku: ${error}`);
    }
  }, [
    exportItems,
    createCalculationSheetData,
    paidBuildPayload,
    incurredBuildPayload,
    paidComparisonTables,
    incurredComparisonTables,
    detColumnLabels,
    incurredColumnLabels,
    weightedSummaryData,
    paidTrainDevideDet,
    incurredTrainDevideDet,
    paidDevJResults,
    incurredDevJResults,
    paidTriangle,
    incurredTriangle,
    paidRemainingDevJHeaders,
    incurredRemainingDevJHeaders,
  ]);

  const selectedCount = exportItems.filter((item) => item.selected).length;

  return {
    isDialogOpen,
    exportItems,
    selectedCount,
    initializeExportItems,
    toggleItemSelection,
    toggleAllSelection,
    exportSelectedCalculations,
    closeDialog,
  };
};
