// Main export for check-assumption feature
export { CheckAssumption } from './components/CheckAssumption';

// Export individual components if needed elsewhere
export { ModelTab, AssumptionsTab, AnalysisTab, SummaryTab } from './components';
export { ResidualChart, DensityChart } from './components';

// Export hooks
export { useCheckAssumptionData } from './hooks';

// Export services
export { CheckAssumptionService } from './services';

// Export types
export type * from './types';

// Export constants
export { CHART_CONFIGS, TAB_CONFIGS } from './constants';
