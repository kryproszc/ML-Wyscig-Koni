import React from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Area,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceLine,
} from 'recharts';

interface DensityChartProps {
  title: string;
  curve: Array<[number, number]>;
  ciArea: Array<[number, number]>;
  referenceValue: number;
  domain?: [number, number];
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-gray-100 border-2 border-gray-500 rounded-md px-3 py-2 shadow-lg">
        <div className="text-gray-900 text-sm font-medium">
          <div>x = {Number(label).toFixed(4)}</div>
          <div>f(x) = {Number(payload[0].value).toFixed(6)}</div>
        </div>
      </div>
    );
  }
  return null;
};

export const DensityChart: React.FC<DensityChartProps> = ({
  title,
  curve,
  ciArea,
  referenceValue,
  domain,
}) => {
  const curveData = curve.map(([x, y]) => ({ x, y }));
  const areaData = ciArea.map(([x, y]) => ({ x, y }));

  const chartDomain = domain || [
    Math.min(...curve.map(([x]) => x)),
    Math.max(...curve.map(([x]) => x)),
  ];

  return (
    <div className="bg-gray-50 border border-gray-400 rounded-lg shadow-sm p-6 text-gray-900 w-full">
      {title && (
        <h4 className="text-base font-semibold mb-4 text-gray-900 text-center border-b border-gray-300 pb-2">
          {title}
        </h4>
      )}
      <ResponsiveContainer width="100%" height={450}>
        <ComposedChart 
          data={curveData}
          margin={{ top: 30, right: 40, left: 40, bottom: 40 }}
        >
          <defs>
            {/* Wzór do kreskowania obszaru CI */}
            <pattern id="diagonalHatch" patternUnits="userSpaceOnUse" width="4" height="4">
              <path d="M-1,1 l2,-2 M0,4 l4,-4 M3,5 l2,-2" stroke="#374151" strokeWidth="0.8"/>
            </pattern>
          </defs>
          
          <CartesianGrid 
            strokeDasharray="2 2" 
            stroke="#9ca3af" 
            strokeWidth={1}
          />
          
          <XAxis 
            type="number" 
            dataKey="x" 
            domain={chartDomain}
            stroke="#374151"
            fontSize={12}
            fontFamily="serif"
            tickLine={{ stroke: '#374151', strokeWidth: 1 }}
            axisLine={{ stroke: '#374151', strokeWidth: 2 }}
            tickFormatter={(value) => Number(value).toFixed(2)}
            label={{ value: 'Wartość statystyki testowej', position: 'insideBottom', offset: -10, style: { textAnchor: 'middle', fontSize: '12px', fontFamily: 'serif' } }}
          />
          
          <YAxis 
            stroke="#374151"
            fontSize={12}
            fontFamily="serif"
            tickLine={{ stroke: '#374151', strokeWidth: 1 }}
            axisLine={{ stroke: '#374151', strokeWidth: 2 }}
            tickFormatter={(value) => Number(value).toFixed(2)}
            label={{ value: 'Gęstość prawdopodobieństwa', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fontSize: '12px', fontFamily: 'serif' } }}
          />
          
          <Tooltip content={<CustomTooltip />} />
          
          {/* Obszar przedziału ufności - z kreskowaniem */}
          <Area
            type="monotone"
            dataKey="y"
            data={areaData}
            fill="url(#diagonalHatch)"
            stroke="#374151"
            strokeWidth={1.5}
            strokeDasharray="3 3"
            isAnimationActive={false}
          />
          
          {/* Główna krzywa rozkładu - wyraźna czarna linia */}
          <Line
            type="monotone"
            dataKey="y"
            stroke="#000000"
            strokeWidth={2.5}
            dot={false}
            isAnimationActive={false}
          />
          
          {/* Linia statystyki T - wyraźna czerwona */}
          <ReferenceLine
            x={referenceValue}
            stroke="#dc2626"
            strokeWidth={3}
            strokeDasharray="6 3"
            label={{
              value: `T = ${referenceValue.toFixed(4)}`,
              position: 'insideTopRight' as any,
              fill: '#dc2626',
              fontSize: 13,
              fontWeight: 'bold',
              fontFamily: 'serif',
              offset: 5
            }}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
};
