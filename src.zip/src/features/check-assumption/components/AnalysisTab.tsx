import React, { useMemo, useState } from 'react';
import { TableDataCor } from '@/components/TableDataCor';
import { DensityChart } from './DensityChart';
import type { DependenceResp } from '../types';
import type { CorRowData } from '@/components/TableDataCor';

interface AnalysisTabProps {
  data: DependenceResp | null;
  isLoading: boolean;
  error: string | null;
  ci: number;
  onCiChange: (value: number) => void;
}

export const AnalysisTab: React.FC<AnalysisTabProps> = ({
  data,
  isLoading,
  error,
  ci,
  onCiChange,
}) => {
  // Lokalny stan dla pola tekstowego (jako procenty)
  const [localCi, setLocalCi] = useState((ci * 100).toString());
  const [showModal, setShowModal] = useState(false);

  // Synchronizuj lokalny stan z zewnętrznym parametrem
  React.useEffect(() => {
    setLocalCi((ci * 100).toString());
  }, [ci]);

  const handleCalculate = () => {
    const numValue = parseFloat(localCi);
    
    // Sprawdź czy wartość jest poprawna
    if (isNaN(numValue)) {
      setLocalCi((ci * 100).toString());
      return;
    }
    
    // Sprawdź granice - pokaż modal dla 0 i 100
    if (numValue <= 0 || numValue >= 100) {
      setShowModal(true);
      return;
    }
    
    // Wartość jest OK - wyślij na backend
    const ciValue = numValue / 100;
    onCiChange(ciValue);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleCalculate();
    }
  };

  const formattedSummary: CorRowData[] = useMemo(() => {
    if (!data) return [];
    return [
      ['T', data.T_stat ?? null],
      ['E[T]', 0], // Wartość oczekiwana = 0 dla rozkładu normalnego
      ['Var[T]', data.Var ?? null],
      ['Lower', data.Range?.[0] ?? null],
      ['Upper', data.Range?.[1] ?? null],
    ];
  }, [data]);

  return (
    <div className="text-white px-8 py-6 min-h-screen w-full">
      {/* Header z kontrolkami */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-100">
            Analiza korelacji czynników rozwoju
          </h2>
          
          {/* Kompaktowe kontrolki CI */}
          <div className="flex items-center gap-4 bg-slate-800/80 px-6 py-4 rounded-lg border-2 border-slate-600 shadow-lg backdrop-blur-sm">
            <label className="text-sm font-semibold text-slate-200">
              Przedział ufności:
            </label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="0"
                max="100"
                step="0.01"
                value={localCi}
                onChange={(e) => setLocalCi(e.target.value)}
                onKeyPress={handleKeyPress}
                className="w-24 px-3 py-2 text-white bg-slate-800 rounded-md border-2 border-slate-600 focus:outline-none focus:border-blue-400 focus:bg-slate-700 text-sm text-center font-mono shadow-inner"
                placeholder="95.0"
              />
              <span className="text-sm text-slate-300 font-medium">%</span>
              <button
                onClick={handleCalculate}
                disabled={isLoading}
                className="py-4 px-5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl font-bold hover:from-emerald-700 hover:to-emerald-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform disabled:from-slate-600 disabled:to-slate-600 disabled:hover:from-slate-600 disabled:hover:to-slate-600 disabled:hover:scale-100"
              >
                Oblicz
              </button>
            </div>
          </div>
        </div>
        
        {/* Status info */}
        <div className="text-sm text-gray-400">
          Aktualnie: {(ci * 100).toFixed(4)}% przedział ufności • Dozwolony zakres: (0, 100)
          {isLoading && <span className="ml-4 text-blue-400 animate-pulse">• Obliczanie...</span>}
        </div>

        {/* Skipped dependence info */}
        {data?.has_skipped_dependence && (
          <div className="mt-4 p-4 bg-yellow-900/20 border border-yellow-700 rounded-lg">
            <h4 className="text-sm font-semibold text-yellow-400 mb-2">
              ℹ️ Informacja o analizie zależności
            </h4>
            <p className="text-sm text-yellow-200">
              W części późnych okresów rozwoju współczynniki przejścia są równe 1, przez co ocena zależności nie jest możliwa.
            </p>
            <p className="text-xs text-yellow-300 mt-1">
              Te okresy zostały pominięte w analizie.
            </p>
          </div>
        )}
      </div>

      {/* Error display */}
      {error && (
        <div className="mb-6 p-4 bg-red-900/20 border border-red-700 rounded-lg">
          <p className="text-red-400">{error}</p>
        </div>
      )}

      {/* Main content - tabela obok wykresu */}
      {data && (
        <div className="grid grid-cols-1 xl:grid-cols-4 gap-8 items-start">
          {/* Tabela wyników - lewa strona */}
          <div className="xl:col-span-1">
            <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white">
              <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
                <h3 className="font-bold text-gray-800 text-lg tracking-tight">
                  Wyniki testu
                </h3>
              </div>
              <div className="p-6">
                <TableDataCor data={formattedSummary} />
                
                {/* Dodatkowe informacje */}
                <div className="mt-4 p-3 bg-gray-100 rounded text-xs text-gray-600">
                  <p><strong>T:</strong> Statystyka testu</p>
                  <p><strong>E[T]:</strong> Wartość oczekiwana</p>
                  <p><strong>Var[T]:</strong> Wariancja</p>
                  <p><strong>Lower/Upper:</strong> Granice przedziału ufności</p>
                </div>
              </div>
            </div>
          </div>

          {/* Wykres gęstości - prawa strona */}
          <div className="xl:col-span-3">
            {data.density_plot && (
              <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white">
                <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
                  <h3 className="font-bold text-gray-800 text-lg tracking-tight">
                    Rozkład gęstości prawdopodobieństwa
                  </h3>
                </div>
                <div className="p-6">
                  <DensityChart
                    title=""
                    curve={data.density_plot.curve}
                    ciArea={data.density_plot.ci_area}
                    referenceValue={data.density_plot.T_stat}
                    domain={[-1, 1]}
                  />
                  
                  {/* Legenda */}
                  <div className="mt-4 flex items-center justify-center gap-6 text-sm text-gray-600">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-0.5 bg-black"></div>
                      <span>Rozkład gęstości</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-3 bg-gray-400 opacity-40"></div>
                      <span>Przedział ufności ({(ci * 100).toFixed(4)}%)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-0.5 bg-red-500"></div>
                      <span>Statystyka T = {data.density_plot.T_stat.toFixed(4)}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Loading state */}
      {isLoading && !data && (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
          <span className="ml-3 text-gray-400">Ładowanie analizy...</span>
        </div>
      )}

      {/* Empty state */}
      {!data && !isLoading && !error && (
        <div className="text-center py-12 text-gray-500">
          <div className="text-4xl mb-4">📊</div>
          <p>Ustaw przedział ufności i kliknij "Oblicz", aby rozpocząć analizę korelacji</p>
        </div>
      )}

      {/* Modal ostrzeżenia */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-lg p-6 max-w-md mx-4 border border-gray-600">
            <div className="flex items-center mb-4">
              <div className="text-yellow-400 text-2xl mr-3">⚠️</div>
              <h3 className="text-lg font-semibold text-white">Nieprawidłowa wartość</h3>
            </div>
            <p className="text-gray-300 mb-6">
              Wartość przedziału ufności musi być z zakresu <strong>(0, 100)</strong>.
              <br />
              Wartości 0 i 100 nie są dozwolone.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowModal(false);
                  setLocalCi((ci * 100).toString()); // Reset do aktualnej wartości
                }}
                className="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded transition-colors"
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
