import React, { useMemo, useState } from 'react';
import { ResidualChart } from './ResidualChart';
import { CHART_CONFIGS } from '../constants';
import type { ResidualsResp } from '../types';

interface AssumptionsTabProps {
  data: ResidualsResp | null;
  isLoading: boolean;
  error: string | null;
  alpha: number;
  onAlphaChange: (value: number) => void;
}

export const AssumptionsTab: React.FC<AssumptionsTabProps> = ({
  data,
  isLoading,
  error,
  alpha,
  onAlphaChange,
}) => {
  // Lokalny stan dla pola tekstowego
  const [localAlpha, setLocalAlpha] = useState(alpha.toString());
  const [showModal, setShowModal] = useState(false);

  // Synchronizuj lokalny stan z zewnętrznym parametrem
  React.useEffect(() => {
    setLocalAlpha(alpha.toString());
  }, [alpha]);

  const handleCalculate = () => {
    const numValue = parseFloat(localAlpha);
    
    // Sprawdź czy wartość jest poprawna
    if (isNaN(numValue)) {
      setLocalAlpha(alpha.toString());
      return;
    }
    
    // Sprawdź granice - pokaż modal dla 0
    if (numValue <= 0) {
      setShowModal(true);
      return;
    }
    
    // Sprawdź górną granicę
    if (numValue > 2) {
      setLocalAlpha(alpha.toString());
      return;
    }
    
    // Wartość jest OK - wyślij na backend
    onAlphaChange(numValue);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleCalculate();
    }
  };

  const chartData = useMemo(() => {
    if (!data) return [];
    
    return CHART_CONFIGS.map((cfg) => ({
      ...cfg,
      scatter: data.obs_vs_fitted.map((d) => ({
        x: cfg.xAccessor(d),
        y: d.standard_residuals,
      })),
      lowess: data.lowess_results[cfg.key].map((d) => ({
        x: d.x,
        y: d.lowess,
      })),
    }));
  }, [data]);

  return (
    <div className="text-white px-8 py-6 min-h-screen w-full">
      {/* Header z kontrolkami */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-100">
            Analiza reszt modelu
          </h2>
          
          {/* Kompaktowe kontrolki Alpha */}
          <div className="flex items-center gap-4 bg-slate-800/80 px-6 py-4 rounded-lg border-2 border-slate-600 shadow-lg backdrop-blur-sm">
            <label className="text-sm font-semibold text-slate-200">
              Parametr Alpha:
            </label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="0"
                max="2"
                step="0.001"
                value={localAlpha}
                onChange={(e) => setLocalAlpha(e.target.value)}
                onKeyPress={handleKeyPress}
                className="w-24 px-3 py-2 text-white bg-slate-800 rounded-md border-2 border-slate-600 focus:outline-none focus:border-blue-400 focus:bg-slate-700 text-sm text-center font-mono shadow-inner"
                placeholder="1.000"
              />
              <button
                onClick={handleCalculate}
                disabled={isLoading}
                className="py-4 px-5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl font-bold hover:from-emerald-700 hover:to-emerald-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform disabled:from-slate-600 disabled:to-slate-600 disabled:hover:from-slate-600 disabled:hover:to-slate-600 disabled:hover:scale-100"
              >
                Oblicz
              </button>
            </div>
          </div>
        </div>
        
        {/* Status info */}
        <div className="text-sm text-gray-400">
          Aktualnie: α = {alpha.toFixed(6)} (parametr wag dla reszt) • Dozwolony zakres: (0, 2]
          {isLoading && <span className="ml-4 text-blue-400 animate-pulse">• Obliczanie...</span>}
        </div>

        {/* Zero variance warning */}
        {data?.has_zero_variance && (
          <div className="mt-4 p-4 bg-yellow-900/20 border border-yellow-700 rounded-lg">
            <h4 className="text-sm font-semibold text-yellow-400 mb-2">
              ℹ️ Informacja o wariancji reszt
            </h4>
            <p className="text-sm text-yellow-200">
              W późnych okresach rozwoju wariancja reszt zanika (σ = 0), co oznacza pełne rozwinięcie trójkąta.
            </p>
            <p className="text-xs text-yellow-300 mt-1">
              Wyznaczenie reszt w tym obszarze nie wnosi dodatkowej informacji i została pominięta.
            </p>
          </div>
        )}

        {/* Transition equals one info */}
        {data?.transition_equals_one && data.transition_equals_one.length > 0 && (
          <div className="mt-4 p-4 bg-amber-900/20 border border-amber-700 rounded-lg">
            <h4 className="text-sm font-semibold text-amber-400 mb-2">
              ⚠️ Okresy rozwoju z współczynnikiem f = 1
            </h4>
            <p className="text-sm text-amber-200">
              Wykryto okresy przejściowe gdzie współczynnik f dokładnie równa się 1.0: <strong>{data.transition_equals_one.join(', ')}</strong>
            </p>
            <p className="text-xs text-amber-300 mt-1">
              Może to wskazywać na potencjalne problemy z estymacją lub specyficzne wzorce w danych.
            </p>
          </div>
        )}
      </div>

      {/* Error display */}
      {error && (
        <div className="mb-6 p-4 bg-red-900/20 border border-red-700 rounded-lg">
          <p className="text-red-400">{error}</p>
        </div>
      )}

      {/* Charts */}
      {data && (
        <div className="space-y-8">
          <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white">
            <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
              <h3 className="font-bold text-gray-800 text-lg tracking-tight">
                Wykresy diagnostyczne reszt
              </h3>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                {chartData.map(({ title, xLabel, scatter, lowess }, idx) => (
                  <div key={idx} className="bg-gray-50 rounded-lg border border-gray-200 p-4">
                    <h4 className="font-semibold text-gray-800 mb-4 text-center">
                      {title}
                    </h4>
                    <ResidualChart
                      title=""
                      xLabel={xLabel}
                      scatter={scatter}
                      lowess={lowess}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Loading state */}
      {isLoading && !data && (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
          <span className="ml-3 text-gray-400">Ładowanie analizy reszt...</span>
        </div>
      )}

      {/* Empty state */}
      {!data && !isLoading && !error && (
        <div className="text-center py-12 text-gray-500">
          <div className="text-4xl mb-4">📉</div>
          <p>Ustaw parametr Alpha i kliknij "Oblicz", aby rozpocząć analizę reszt</p>
        </div>
      )}

      {/* Modal ostrzeżenia */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-lg p-6 max-w-md mx-4 border border-gray-600">
            <div className="flex items-center mb-4">
              <div className="text-yellow-400 text-2xl mr-3">⚠️</div>
              <h3 className="text-lg font-semibold text-white">Nieprawidłowa wartość</h3>
            </div>
            <p className="text-gray-300 mb-6">
              Wartość parametru Alpha musi być z zakresu <strong>(0, 2]</strong>.
              <br />
              Wartość 0 nie jest dozwolona.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowModal(false);
                  setLocalAlpha(alpha.toString()); // Reset do aktualnej wartości
                }}
                className="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded transition-colors"
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
