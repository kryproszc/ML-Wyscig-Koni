/* -------------------------------------------------------------------------- */
/*                              CHECK ASSUMPTION TYPES                        */
/* -------------------------------------------------------------------------- */

export interface ObsRow {
  origin_period: number;
  dev_period: number;
  cal_period: number;
  residuals: number;
  standard_residuals: number;
  fitted_value: number;
}

export interface LowessRow {
  x: number;
  lowess: number;
}

export interface LowessResults {
  fitted_value: LowessRow[];
  origin_period: LowessRow[];
  cal_period: LowessRow[];
  dev_period: LowessRow[];
}

export interface ResidualsResp {
  obs_vs_fitted: ObsRow[];
  lowess_results: LowessResults;
  transition_equals_one: string[];
  has_zero_variance: boolean;
}

export interface DependenceSummary {
  results: { [key: string]: number | null };
  range: { Lower: number | null; Upper: number | null };
}

export interface DensityPlot {
  curve: [number, number][];
  ci_area: [number, number][];
  T_stat: number;
  T_y: number;
}

export interface DependenceResp {
  T_stat: number | null;
  Var: number | null;
  Range: [number | null, number | null];
  ci: number;
  density_plot?: DensityPlot;
  has_skipped_dependence: boolean;
}

export interface DensityPlot2 {
  curve: [number, number][];
  ci_area: [number, number][];
  Z_stat: number;
  Z_y: number;
}

export type Totals = {
  Z: number;
  "E[Z]": number;
  "Var[Z]": number;
};

export interface Dep2Resp {
  totals: Totals;
  range: { Lower: number; Upper: number };
  ci: number;
  density_plot?: DensityPlot2;
}

export type TabKey = "model" | "assumptions" | "analysis" | "summary";

export interface ChartConfig {
  key: keyof LowessResults;
  title: string;
  xLabel: string;
  xAccessor: (d: ObsRow) => number;
}
