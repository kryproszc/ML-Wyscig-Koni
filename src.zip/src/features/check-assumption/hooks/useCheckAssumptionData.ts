// src/features/check-assumption/hooks/useCheckAssumptionData.ts
import { useState, useEffect, useMemo } from "react";
import { CheckAssumptionService } from "../apiClient";
import { useTrainDevideStoreDet } from "@/stores/trainDevideStoreDeterministyczny";
import { useTrainDevideStoreDetIncurred } from "@/stores/trainDevideStoreDeterministycznyIncurred";
import { useLabelsStore } from "@/stores/useLabelsStore";
import type { ResidualsResp, DependenceResp, Dep2Resp, TabKey } from "../types";

// ⬇️ używamy globalnego store’a (względny import, działa u Ciebie)
import { useTriangleType } from "../../../stores/useTriangleType";

export const useCheckAssumptionData = (
  activeTab: TabKey,
  triangleTypeProp: 'paid' | 'incurred',
  setTriangleTypeProp: (type: 'paid' | 'incurred') => void
) => {
  // Zakładki + niezależne parametry dla każdej zakładki
  const [alphaAssumptions, setAlphaAssumptions] = useState(1.0);
  const [ciAnalysis, setCiAnalysis] = useState(0.95); // 95% - bezpieczna wartość domyślna
  const [ciSummary, setCiSummary] = useState(0.95);   // 95% - bezpieczna wartość domyślna

  // Wspólny wybór trójkąta - synchronizujemy ze store'em i propsem
  const triangleType = triangleTypeProp;
  const setTriangleTypeStore = useTriangleType((s) => s.setTriangleType);
  
  const setTriangleType = (type: 'paid' | 'incurred') => {
    setTriangleTypeProp(type);
    setTriangleTypeStore(type);
  };

  // Źródła trójkątów
  const paidTri = useTrainDevideStoreDet((s) => s.paidTriangle);
  const incTri = useTrainDevideStoreDetIncurred((s) => s.incurredTriangle);

  // Etykiety
  const paidRowLabels = useLabelsStore((s) => s.detRowLabels);
  const paidColLabels = useLabelsStore((s) => s.detColumnLabels);
  const incRowLabels = useLabelsStore((s) => s.incurredRowLabels);
  const incColLabels = useLabelsStore((s) => s.incurredColumnLabels);

  // Arkusz (string|number)[][] z nagłówkami – spójnie z ChooseDataStoch
  const triangleData = useMemo<(string | number)[][] | null>(() => {
    const tri = triangleType === "paid" ? paidTri : incTri;
    if (!tri || tri.length === 0) return null;

    const body = tri.map((r) => r.map((c) => (c == null ? "" : c)));
    const rows = body.length;
    const cols = body[0]?.length ?? 0;

    const rLabels =
      triangleType === "paid"
        ? paidRowLabels.length > 0
          ? paidRowLabels
          : Array.from({ length: rows }, (_, i) => `${i + 1}`)
        : incRowLabels.length > 1
        ? incRowLabels.slice(1)
        : Array.from({ length: rows }, (_, i) => `${i + 1}`);

    const cLabels =
      triangleType === "paid"
        ? paidColLabels.length > 0
          ? paidColLabels
          : Array.from({ length: cols }, (_, i) => `${i + 1}`)
        : incColLabels.length > 1
        ? incColLabels.slice(1)
        : Array.from({ length: cols }, (_, i) => `${i + 1}`);

    const safeRow =
      rLabels.length === rows
        ? rLabels
        : Array.from({ length: rows }, (_, i) => rLabels[i] ?? `${i + 1}`);
    const safeCol =
      cLabels.length === cols
        ? cLabels
        : Array.from({ length: cols }, (_, i) => cLabels[i] ?? `${i + 1}`);

    return [["", ...safeCol], ...body.map((row, i) => [safeRow[i] ?? `${i + 1}`, ...row])];
  }, [
    triangleType,
    paidTri,
    incTri,
    paidRowLabels,
    paidColLabels,
    incRowLabels,
    incColLabels,
  ]);

  // Debug
  if (process.env.NODE_ENV !== "production") {
    console.log("[useCheckAssumptionData] type:", triangleType);
    if (triangleData) {
      console.log(`wymiary: ${triangleData.length} x ${triangleData[0]?.length || 0}`);
    } else {
      console.log("brak danych do analizy");
    }
  }

  // Dane zwrotne i loading
  const [error, setError] = useState<string | null>(null);
  const [residualsData, setResidualsData] = useState<ResidualsResp | null>(null);
  const [dependenceData, setDependenceData] = useState<DependenceResp | null>(null);
  const [dep2Data, setDep2Data] = useState<Dep2Resp | null>(null);
  const [isLoadingResiduals, setIsLoadingResiduals] = useState(false);
  const [isLoadingDependence, setIsLoadingDependence] = useState(false);
  const [isLoadingDep2, setIsLoadingDep2] = useState(false);

  // ⬅️ Wyczyść cache wyników po zmianie źródła danych
  useEffect(() => {
    setResidualsData(null);
    setDependenceData(null);
    setDep2Data(null);
    setError(null);
  }, [triangleType, triangleData]);

  // Fetch – ASSUMPTIONS
  useEffect(() => {
    if (activeTab !== "assumptions") return;
    if (residualsData) return;
    if (!triangleData || triangleData.length === 0) return;

    let cancelled = false;
    setIsLoadingResiduals(true);
    setError(null);

    CheckAssumptionService.analyzeResiduals(triangleData, alphaAssumptions)
      .then((resp) => {
        if (!cancelled) setResidualsData(resp);
      })
      .catch((e: unknown) => {
        if (!cancelled) setError(e instanceof Error ? e.message : String(e));
      })
      .finally(() => {
        if (!cancelled) setIsLoadingResiduals(false);
      });

    return () => {
      cancelled = true;
    };
  }, [activeTab, alphaAssumptions, residualsData, triangleData, triangleType]);

  // Fetch – ANALYSIS
  useEffect(() => {
    if (activeTab !== "analysis") return;
    if (dependenceData) return;
    if (!triangleData || triangleData.length === 0) return;

    let cancelled = false;
    setIsLoadingDependence(true);
    setError(null);

    CheckAssumptionService.analyzeDependence(triangleData, ciAnalysis)
      .then((resp) => {
        if (!cancelled) setDependenceData(resp);
      })
      .catch((e: unknown) => {
        if (!cancelled) setError(e instanceof Error ? e.message : String(e));
      })
      .finally(() => {
        if (!cancelled) setIsLoadingDependence(false);
      });

    return () => {
      cancelled = true;
    };
  }, [activeTab, ciAnalysis, dependenceData, triangleData, triangleType]);

  // Fetch – SUMMARY
  useEffect(() => {
    if (activeTab !== "summary") return;
    if (dep2Data) return;
    if (!triangleData || triangleData.length === 0) return;

    let cancelled = false;
    setIsLoadingDep2(true);
    setError(null);

    CheckAssumptionService.analyzeDep2(triangleData, ciSummary)
      .then((resp) => {
        if (!cancelled) setDep2Data(resp);
      })
      .catch((e: unknown) => {
        if (!cancelled) setError(e instanceof Error ? e.message : String(e));
      })
      .finally(() => {
        if (!cancelled) setIsLoadingDep2(false);
      });

    return () => {
      cancelled = true;
    };
  }, [activeTab, ciSummary, dep2Data, triangleData, triangleType]);

  // Czyść przy zmianie parametrów (niezależnie dla każdej zakładki)
  useEffect(() => setResidualsData(null), [alphaAssumptions]);
  useEffect(() => setDependenceData(null), [ciAnalysis]);
  useEffect(() => setDep2Data(null), [ciSummary]);

  return {
    // Niezależne parametry dla każdej zakładki (activeTab i setActiveTab NIE zwracamy - są w propsach)
    alphaAssumptions,
    setAlphaAssumptions,
    ciAnalysis,
    setCiAnalysis,
    ciSummary,
    setCiSummary,

    // Dane wynikowe
    residualsData,
    dependenceData,
    dep2Data,

    // Ładowanie
    isLoadingResiduals,
    isLoadingDependence,
    isLoadingDep2,

    // Błędy
    error,
    setError,

    // Wybór trójkąta (z globalnego store’a)
    triangleType,
    setTriangleType,
  };
};
