'use client';

import { useState } from 'react';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { ComparisonTable } from '@/shared/components/ComparisonTable';
import { DataSelectionPanel } from './DataSelectionPanel';
import { useDataOptions } from '@/shared/hooks/useDataOptions';
import { usePayloadBuilder } from '@/shared/hooks/usePayloadBuilder';
import { useExcelExport } from '@/shared/hooks/useExcelExport';
import { useCalculationsExport } from '@/shared/hooks/useCalculationsExport';
import { useDataSubmission } from '../hooks/useDataSubmission';
import { CalculationsExportDialog } from '@/shared/components/CalculationsExportDialog';

export default function PaidResultsPage() {
  const [showModal, setShowModal] = useState(false);
  const detRowLabels = useLabelsStore((s) => s.detRowLabels);

  /* ---------- STORE ---------- */
  const removeComparisonTable = useTrainDevideStoreDet((s) => s.removeComparisonTable);

  const selectedA = useTrainDevideStoreDet((s) => s.selectedDataA);
  const selectedB = useTrainDevideStoreDet((s) => s.selectedDataB);
  const setSelectedA = useTrainDevideStoreDet((s) => s.setSelectedDataA);
  const setSelectedB = useTrainDevideStoreDet((s) => s.setSelectedDataB);

  const simResults = useTrainDevideStoreDet((s) => s.simResults) ?? {};
  const devJResults = useTrainDevideStoreDet((s) => s.devJResults) ?? [];
  const finalDevVector = useTrainDevideStoreDet((s) => s.finalDevVector) ?? [];
  const combinedDevJSummary = useTrainDevideStoreDet((s) => s.combinedDevJSummary) ?? [];

  const comparisonTables = useTrainDevideStoreDet((s) => s.comparisonTables);
  const addComparisonTable = useTrainDevideStoreDet((s) => s.addComparisonTable);
  const clearComparisonTables = useTrainDevideStoreDet((s) => s.clearComparisonTables);
  
  // Get selected volume for color highlighting
  const finalDevJ = useTrainDevideStoreDet((s) => s.finalDevJ);

  // Labels from store for column headers
  const detColumnLabels = useLabelsStore((s) => s.detColumnLabels);

  // Debug - sprawdźmy co jest w comparisonTables
  console.log('🔍 PaidResults comparisonTables:', comparisonTables);

  /* ---------- HOOKS ---------- */
  const { allOptions, keyToLabelMap } = useDataOptions({
    simResults,
    devJResults,
    combinedDevJSummary,
    finalDevVector,
  });

  const { buildPayload } = usePayloadBuilder({
    simResults,
    devJResults,
    combinedDevJSummary,
    finalDevVector,
    finalDevJ,
  });

  const { exportToExcel } = useExcelExport();

  const calculationsExport = useCalculationsExport({
    allOptions,
    simResults,
    devJResults,
    combinedDevJSummary,
    finalDevVector,
    buildPayload,
    columnLabels: detColumnLabels,
    triangleType: 'paid',
    comparisonTables,
    selectedVolume: finalDevJ?.volume,
    selectedSubIndex: finalDevJ?.subIndex,
  });

  const { handleSend } = useDataSubmission({
    buildFormData: buildPayload,
    keyToLabelMap,
    getTriangleData: () => useTrainDevideStoreDet.getState().paidTriangle ?? [],
    addComparisonTable,
    apiEndpoint: 'paid',
    rowLabels: detRowLabels, // przekazujemy etykiety wierszy
  });

  /* ---------- HANDLERS ---------- */
  const handleSendData = () => {
    handleSend(selectedA, selectedB, () => setShowModal(true));
  };

  const handleExportToExcel = () => {
    exportToExcel(comparisonTables, 'porownania_paid.xlsx');
  };

  /* ---------- UI ---------- */
  return (
    <div className="flex gap-8 p-8 text-white">
      {/* Lewa kolumna */}
      <DataSelectionPanel
        selectedA={selectedA}
        selectedB={selectedB}
        setSelectedA={setSelectedA}
        setSelectedB={setSelectedB}
        allOptions={allOptions}
        onSendData={handleSendData}
        onClearComparisons={clearComparisonTables}
        onExportToExcel={handleExportToExcel}
        onExportCalculations={calculationsExport.initializeExportItems}
        showModal={showModal}
        setShowModal={setShowModal}
        methodType="Paid"
      />

      {/* Prawa kolumna */}
      <div className="flex-1 overflow-auto flex flex-col gap-10">
        {comparisonTables.map((entry, idx) => (
          <div key={`${entry.labelA}-${entry.labelB}-${idx}`} className="relative">
            <button
              onClick={() => removeComparisonTable(idx)}
              className="absolute top-0 right-0 text-red-500 hover:text-red-700 text-xl p-2"
              title="Usuń porównanie"
            >
              ❌
            </button>

            <ComparisonTable
              data={entry.data}
              labelA={entry.labelA}
              labelB={entry.labelB}
              rowLabels={detRowLabels}
              areDifferentVectors={entry.areDifferentVectors}
            />
          </div>
        ))}
      </div>

      {/* Dialog eksportu obliczeń */}
      <CalculationsExportDialog
        isOpen={calculationsExport.isDialogOpen}
        exportItems={calculationsExport.exportItems}
        selectedCount={calculationsExport.selectedCount}
        onClose={calculationsExport.closeDialog}
        onToggleItem={calculationsExport.toggleItemSelection}
        onToggleAll={calculationsExport.toggleAllSelection}
        onExport={calculationsExport.exportSelectedCalculations}
      />
    </div>
  );
}
