import { useCallback } from 'react';

const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export interface UseDataSubmissionParams {
  buildFormData: (key: string | null) => any | null;
  keyToLabelMap: Record<string, string>;
  getTriangleData: () => any[][];
  addComparisonTable: (entry: { data: any[]; labelA: string; labelB: string; areDifferentVectors?: boolean }) => void;
  apiEndpoint: string; // np. 'paid' lub 'incurred'
  rowLabels: string[]; // etykiety wierszy (lata) do mapowania kolumny "Wiersz"
}

/* ===================== helpers ===================== */

// 1) "Projection A..." -> "<labelA>...", "Projection B..." -> "<labelB>..."
function applyProjectionLabelsToKey(key: string, labelA?: string, labelB?: string) {
  if (labelA) key = key.replace(/^Projection A(\b.*)?$/i, (_m, r = '') => `${labelA}${r}`);
  if (labelB) key = key.replace(/^Projection B(\b.*)?$/i, (_m, r = '') => `${labelB}${r}`);
  return key;
}

// 2) "Selected …" / "Initial Selection …" / PL -> "<selectedLabel>…"
function applySelectedLabelToKey(key: string, selectedLabel?: string) {
  if (!selectedLabel) return key;
  return key.replace(
    /^(?:Selected(?:\s+Value)?|Initial(?:\s+Selection)?|Wybrana(?:\s+wartość)?|Wybór(?:\s+początkowy)?)\b(.*)?$/i,
    (_m, r = '') => `${selectedLabel}${r}`
  );
}

// 3) kandydat na „Ultimate" (bazowa wartość, nie IBNR/%, nie Różnica)
function isUltimateCandidate(name: string) {
  if (name === 'Wiersz') return false;
  if (/IBNR/i.test(name)) return false;
  if (/%/.test(name)) return false;
  if (/^Różnica/i.test(name)) return false;
  return true;
}

// 4) wybór etykiety dla „Selected …" tak, aby ZAWSZE mieć parę A/B
function decideSelectedLabel(originalKeys: string[], labelA: string, labelB: string): string {
  const after = originalKeys.map((k) => applyProjectionLabelsToKey(k, labelA, labelB));
  const candidates = after.filter(isUltimateCandidate);
  const hasA = candidates.some((k) => k.includes(labelA));
  const hasB = candidates.some((k) => k.includes(labelB));
  if (!hasA && hasB) return labelA;
  if (!hasB && hasA) return labelB;
  return labelA; // fallback
}

// 5) przenieś "IBNR" na początek nazwy, jeśli występuje
function moveIbnrToFront(name: string) {
  if (!/IBNR/i.test(name)) return name;
  if (/^IBNR\b/i.test(name)) return name;
  const without = name.replace(/\s*IBNR\s*/i, '').replace(/\s+/g, ' ').trim();
  return `IBNR ${without}`;
}

// 6) „Ultimate " dla Różnica / Różnica %
function ultimateForDifferences(name: string) {
  return name === 'Różnica' || name === 'Różnica %' ? `Ultimate ${name}` : name;
}

// 7) standaryzacja "Wiersz": -, suma, SUMA -> "Suma"
function normalizeSumCell(value: unknown) {
  const v = String(value ?? '').trim();
  if (v === '-' || v.toLowerCase() === 'suma') return 'Suma';
  return value;
}

// 8) zamiana prefiksu IBNR na docelowy (np. "IBNR + RBNP")
function applyIbnrPrefix(name: string, ibnrPrefix: string) {
  return name.replace(/^IBNR\b/i, ibnrPrefix);
}

/* ===================== remap ===================== */

function remapComparisonRowKeys(
  row: Record<string, any>,
  opts: {
    labelA: string;
    labelB: string;
    selectedLabel: string;
    allKeysOrder: string[];
    apiEndpoint: string;
    rowLabels: string[];
    rowIndex: number;
  }
) {
  const ibnrPrefix = opts.apiEndpoint === 'incurred' ? 'IBNR + RBNP' : 'IBNR';

  // A) normalizacja nazw
  const renamed: Record<string, any> = {};
  for (const k of Object.keys(row)) {
    let nk = applyProjectionLabelsToKey(k, opts.labelA, opts.labelB);
    nk = moveIbnrToFront(nk);
    renamed[nk] = row[k];
  }

  // porządek po transformacjach
  const keysInOrder = opts.allKeysOrder
    .map((k) => {
      let nk = applyProjectionLabelsToKey(k, opts.labelA, opts.labelB);
      nk = moveIbnrToFront(nk);
      return nk;
    })
    .filter((k) => k in renamed);

  const out: Record<string, any> = {};

  // 1) Wiersz - mapowanie z indeksów na właściwe etykiety (lata)
  if ('Wiersz' in renamed) {
    const originalValue = renamed['Wiersz'];
    if (originalValue === 'Suma' || String(originalValue).toLowerCase() === 'suma') {
      out['Wiersz'] = 'Suma';
    } else {
      const numericIndex = Number(originalValue);
      if (!isNaN(numericIndex) && opts.rowLabels && opts.rowLabels[numericIndex]) {
        out['Wiersz'] = opts.rowLabels[numericIndex];
      } else {
        out['Wiersz'] = normalizeSumCell(originalValue);
      }
    }
  }

  // kandydaci
  const ultimateCandidates: string[] = keysInOrder.filter(isUltimateCandidate);
  const ibnrCandidates: string[] = keysInOrder.filter((k) => /^IBNR\b/i.test(k));

  // 2) Kolumny Ultimate z nazwami wybranymi przez użytkownika
  const u0 = ultimateCandidates[0];
  const u1 = ultimateCandidates[1];
  
  // Zawsze dwie kolumny Ultimate z nazwami labelA i labelB
  if (u0) {
    out[`Ultimate ${opts.labelA}`] = renamed[u0];
  }
  
  if (u1) {
    out[`Ultimate ${opts.labelB}`] = renamed[u1];
  }

  // 3) Kolumny IBNR z nazwami wybranymi przez użytkownika
  const i0 = ibnrCandidates[0];
  const i1 = ibnrCandidates[1];
  
  // Zawsze dwie kolumny IBNR z nazwami labelA i labelB
  if (i0) {
    out[`${ibnrPrefix} ${opts.labelA}`] = renamed[i0];
  }
  
  if (i1) {
    out[`${ibnrPrefix} ${opts.labelB}`] = renamed[i1];
  }

  // 4) Reszta – „Ultimate " dla różnic + podmiana prefiksu IBNR w nazwach różnic
  const skip = new Set<string>([
    'Wiersz',
    ...(typeof u0 === 'string' ? [u0] : []),
    ...(typeof u1 === 'string' ? [u1] : []),
    ...(typeof i0 === 'string' ? [i0] : []),
    ...(typeof i1 === 'string' ? [i1] : []),
  ]);

  for (const k of keysInOrder) {
    if (skip.has(k)) continue;
    const withUltimate = ultimateForDifferences(k);
    const finalName = applyIbnrPrefix(withUltimate, ibnrPrefix);
    out[finalName] = renamed[k];
  }

  return out;
}

/* ===================== hook ===================== */

export function useDataSubmission({
  buildFormData,
  keyToLabelMap,
  getTriangleData,
  addComparisonTable,
  apiEndpoint,
  rowLabels,
}: UseDataSubmissionParams) {
  const handleSend = useCallback(
    async (
      selectedA: string | null,
      selectedB: string | null,
      onShowModal: () => void
    ) => {
      if (!selectedA && !selectedB) {
        onShowModal();
        return;
      }

      const triangle = getTriangleData();
      
      const dataA = selectedA ? buildFormData(selectedA) : null;
      const dataB = selectedB ? buildFormData(selectedB) : null;
      
      let coeff_sets: any[] = [];
      
      if (dataA && dataB) {
        coeff_sets = [dataA, dataB];
      } else if (dataA && !dataB) {
        coeff_sets = [dataA, dataA];
      } else if (!dataA && dataB) {
        coeff_sets = [dataB, dataB];
      } else {
        console.error('❌ Oba zestawy współczynników są null');
        onShowModal();
        return;
      }

      const payload = {
        [`${apiEndpoint}_data_det`]: triangle,
        coeff_sets,
      };

      console.log('🚀 ===== WYSYŁANIE NA BACKEND =====');
      console.log('🚀 Wybrane opcje:');
      console.log('   A:', selectedA, '→', selectedA ? keyToLabelMap[selectedA] : 'null');
      console.log('   B:', selectedB, '→', selectedB ? keyToLabelMap[selectedB] : 'null');
      console.log('');
      console.log('🚀 Współczynniki A:');
      console.log(JSON.stringify(dataA, null, 2));
      console.log('');
      console.log('🚀 Współczynniki B:');
      console.log(JSON.stringify(dataB, null, 2));
      console.log('');
      console.log('🚀 Cały payload (triangle + coeff_sets):');
      console.log(JSON.stringify(payload, null, 2));
      console.log('🚀 ==================================');

      try {
        const res = await fetch(`${API}/calc/${apiEndpoint}/save_vector`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });

        if (!res.ok) {
          const errorText = await res.text();
          console.error('❌ Server error:', errorText);
          throw new Error(`❌ Błąd serwera: ${res.status}`);
        }

        const json = await res.json();

        const labelA = selectedA ? (keyToLabelMap[selectedA] ?? 'Projection A') : (keyToLabelMap[selectedB!] ?? 'Projection A');
        const labelB = selectedB ? (keyToLabelMap[selectedB] ?? 'Projection B') : (keyToLabelMap[selectedA!] ?? 'Projection B');

        if (json.comparison && Array.isArray(json.comparison) && json.comparison.length > 0) {
          const originalKeys: string[] = Object.keys(json.comparison[0] as Record<string, any>);
          const selectedLabel = decideSelectedLabel(originalKeys, labelA, labelB);
          
          const areDifferentVectors = !!(selectedA && selectedB && selectedA !== selectedB);
          
          if (!areDifferentVectors && (selectedA || selectedB)) {
            const singleCoeff = selectedA || selectedB;
            const singleLabel = keyToLabelMap[singleCoeff!] ?? 'Wybrana krzywa';
            
            const mappedSingle = (json.comparison as any[]).map((row, rowIndex) => {
              const result: Record<string, any> = {};
              
              if ('Wiersz' in row) {
                const originalValue = row['Wiersz'];
                if (originalValue === 'Suma' || String(originalValue).toLowerCase() === 'suma') {
                  result['Wiersz'] = 'Suma';
                } else {
                  const numericIndex = Number(originalValue);
                  if (!isNaN(numericIndex) && rowLabels && rowLabels[numericIndex]) {
                    result['Wiersz'] = rowLabels[numericIndex];
                  } else {
                    result['Wiersz'] = originalValue;
                  }
                }
              }
              
              if ('Projection A' in row) {
                result['Ultimate'] = row['Projection A'];
              }
              
              if ('Projection A IBNR' in row) {
                const ibnrColumnName = apiEndpoint === 'incurred' ? 'IBNR + RBNP' : 'IBNR';
                result[ibnrColumnName] = row['Projection A IBNR'];
              }
              
              return result;
            });
            
            addComparisonTable({ 
              data: mappedSingle, 
              labelA: singleLabel, 
              labelB: singleLabel, 
              areDifferentVectors: false 
            });
            return;
          }
          
          const mapped = (json.comparison as any[]).map((row, rowIndex) => {
            return remapComparisonRowKeys(row, {
              labelA,
              labelB,
              selectedLabel,
              allKeysOrder: originalKeys,
              apiEndpoint,
              rowLabels,
              rowIndex,
            });
          });

          addComparisonTable({ data: mapped, labelA, labelB, areDifferentVectors });
        }
      } catch (err) {
        console.error('❌ Błąd wysyłki:', err);
      }
    },
    [buildFormData, keyToLabelMap, getTriangleData, addComparisonTable, apiEndpoint, rowLabels]
  );

  return { handleSend };
}
