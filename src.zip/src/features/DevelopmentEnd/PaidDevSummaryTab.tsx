/* ------------------------------------------------------------------ */
/*                       PaidDevSummaryTab.tsx                       */
/* ------------------------------------------------------------------ */
"use client"

import React, { useEffect, useMemo, useState } from "react";
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny'
import { useLabelsStore } from '@/stores/useLabelsStore'
import { DevSummaryLayout } from '@/shared/components/DevelopmentEnd'

export default function PaidDevSummaryTab() {
  // Store selectors
  const leftCount = useTrainDevideStoreDet(s => s.leftCountSummary)
  const setLeftCount = useTrainDevideStoreDet(s => s.setLeftCountSummary)
  const selectedCurve = useTrainDevideStoreDet(s => s.selectedCurveSummary)
  const setSelectedCurve = useTrainDevideStoreDet(s => s.setSelectedCurveSummary)
  const manualOverrides = useTrainDevideStoreDet(s => s.manualOverridesSummary)
  const setManualOverrides = useTrainDevideStoreDet(s => s.setManualOverridesSummary)
  const sourceSwitches = useTrainDevideStoreDet(s => s.sourceSwitchesSummary)
  const setSourceSwitches = useTrainDevideStoreDet(s => s.setSourceSwitchesSummary)
  const devJPreview = useTrainDevideStoreDet(s => s.devJPreview)
  const simResults = useTrainDevideStoreDet(s => s.simResults)
  const setCombinedDevJSummary = useTrainDevideStoreDet(s => s.setCombinedDevJSummary)

  // Labels from store
  const rawDetColumnLabels = useLabelsStore(s => s.detColumnLabels)
  console.log("RAW detColumnLabels ze store:", rawDetColumnLabels)
  
  const detColumnLabels = useMemo(
    () => ["", ...rawDetColumnLabels],
    [rawDetColumnLabels]
  )

  console.log("FINAL detColumnLabels:", detColumnLabels)  
  // Callback to save remaining dev_j headers
  const setRemainingDevJHeaders = useTrainDevideStoreDet(s => s.setRemainingDevJHeaders)

  return (
    <DevSummaryLayout
      leftCount={leftCount}
      setLeftCount={setLeftCount}
      selectedCurve={selectedCurve}
      setSelectedCurve={setSelectedCurve}
      manualOverrides={manualOverrides}
      setManualOverrides={setManualOverrides}
      sourceSwitches={sourceSwitches}
      setSourceSwitches={setSourceSwitches}
      devJPreview={devJPreview}
      simResults={simResults}
      setCombinedDevJ={setCombinedDevJSummary}
      columnLabels={detColumnLabels}
      onRemainingDevJHeaders={setRemainingDevJHeaders}
    />
  )
}
