export { default as PaidTriangleView } from './components/PaidTriangleView';
export { default as IncurredTriangleView } from './components/IncurredTriangleView';
