'use client';

import { useEffect, useState, useRef } from 'react';
import { useIncurredTableStore } from '@/stores/useIncurredTableStore';
import { useTrainDevideStoreDetIncurred } from '@/stores/trainDevideStoreDeterministycznyIncurred';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { useDisplaySettingsStore } from '@/stores/useDisplaySettingsStore';
import { TriangleTableView } from '@/shared';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { Maximize2, Minimize2, Plus, Minus } from 'lucide-react';
import { DevelopmentChart } from './DevelopmentChart';
import dynamic from 'next/dynamic';

const IncurredTriangleDet = dynamic(() => import('../../../app/_components/IncurredTriangleDet'), { ssr: false });

export default function IncurredTriangleView() {
  /* ── 1. dane ze stanu loadera XLSX ─────────────────────────── */
  const isValid = useIncurredTableStore((s) => s.isValid);
  const json = useIncurredTableStore((s) => s.selectedSheetJSON);

  /* ── 2. trójkąt Incurred w głównym store ────── */
  const incurredTriangle = useTrainDevideStoreDetIncurred((s) => s.incurredTriangle);

  /* ── 3. labels dla Incurred ──── */
  const incurredRowLabels = useLabelsStore((s) => s.incurredRowLabels);
  const incurredColumnLabels = useLabelsStore((s) => s.incurredColumnLabels);
  
  /* ── 4. ustawienia wyświetlania ──── */
  const roundNumbers = useDisplaySettingsStore((s) => s.roundNumbers);
  const fullscreenMode = useDisplaySettingsStore((s) => s.fullscreenMode);
  const tableScale = useDisplaySettingsStore((s) => s.tableScale);
  const setRoundNumbers = useDisplaySettingsStore((s) => s.setRoundNumbers);
  const setFullscreenMode = useDisplaySettingsStore((s) => s.setFullscreenMode);
  const increaseScale = useDisplaySettingsStore((s) => s.increaseScale);
  const decreaseScale = useDisplaySettingsStore((s) => s.decreaseScale);

  // Stan dla animacji zamykania
  const [isClosing, setIsClosing] = useState(false);
  
  // Stan dla wyświetlania wykresów
  const [showCharts, setShowCharts] = useState(false);
  
  // Stan dla pełnego ekranu wykresów
  const [chartsFullscreen, setChartsFullscreen] = useState(false);
  const [isChartsClosing, setIsChartsClosing] = useState(false);
  
  // Ref dla przewijania do wykresów
  const chartsRef = useRef<HTMLDivElement>(null);

  // Funkcja do zamykania z animacją
  const handleCloseFullscreen = () => {
    setIsClosing(true);
    // Opóźnienie zamknięcia o czas trwania animacji
    setTimeout(() => {
      setFullscreenMode(false);
      setIsClosing(false);
    }, 300); // 300ms - szybsze zamykanie
  };
  
  // Funkcja do zamykania pełnego ekranu wykresów
  const handleCloseChartsFullscreen = () => {
    setIsChartsClosing(true);
    setTimeout(() => {
      setChartsFullscreen(false);
      setIsChartsClosing(false);
    }, 300);
  };
  
  // Dodatkowe logi dla wszystkich labels ze store
  const globalRowLabels = useLabelsStore((s) => s.globalRowLabels);
  const globalColumnLabels = useLabelsStore((s) => s.globalColumnLabels);
  const lastLoadedFile = useLabelsStore((s) => s.lastLoadedFile);

  /* ── 4.1. logi dla debugowania ──── */
  useEffect(() => {
    console.log('[IncurredTriangleView] isValid:', isValid);
    console.log('[IncurredTriangleView] json:', json);
    console.log('[IncurredTriangleView] incurredTriangle:', incurredTriangle);
    console.log('[IncurredTriangleView] incurredTriangle structure:');
    if (incurredTriangle) {
      console.log('  - Number of rows:', incurredTriangle.length);
      console.log('  - First row length:', incurredTriangle[0]?.length);
      console.log('  - First row:', incurredTriangle[0]);
      console.log(
        '  - Max row length:',
        Math.max(...incurredTriangle.map((row) => row?.length || 0))
      );
    }
    console.log('[IncurredTriangleView] incurredRowLabels:', incurredRowLabels);
    console.log('[IncurredTriangleView] incurredColumnLabels:', incurredColumnLabels, 'length:', incurredColumnLabels.length);
    console.log('[IncurredTriangleView] globalRowLabels:', globalRowLabels);
    console.log('[IncurredTriangleView] globalColumnLabels:', globalColumnLabels, 'length:', globalColumnLabels.length);
    console.log('[IncurredTriangleView] lastLoadedFile:', lastLoadedFile);
  }, [isValid, json, incurredTriangle, incurredRowLabels, incurredColumnLabels, globalRowLabels, globalColumnLabels, lastLoadedFile]);

  // Etykiety już są dopasowane 1:1 do body — NIE przycinamy ich ponownie.
  const actualRowLabels = incurredRowLabels;
  const actualColumnLabels = incurredColumnLabels;

  // Funkcja do formatowania liczb na podstawie ustawienia roundNumbers
  const formatTriangleData = (data: (number | null)[][] | null | undefined) => {
    if (!data) return data;
    
    return data.map(row => 
      row.map(cell => {
        if (cell === null || cell === undefined) return cell;
        return roundNumbers ? Math.round(cell) : cell;
      })
    );
  };

  // Funkcja formatowania liczb z separatorami tysięcy
  const numberFormatter = (num: number | null): string => {
    if (num === null || num === undefined) return '';
    
    const processedNumber = roundNumbers ? Math.round(num) : num;
    
    // Formatowanie z separatorami tysięcy (spacja co 3 cyfry)
    return processedNumber.toLocaleString('pl-PL', {
      useGrouping: true,
      minimumFractionDigits: roundNumbers ? 0 : 2,
      maximumFractionDigits: roundNumbers ? 0 : 2
    }).replace(/\u00A0/g, ' '); // Zastępujemy non-breaking space zwykłą spacją
  };

  const formattedTriangle = formatTriangleData(incurredTriangle);

  // Transformacja danych dla wykresów development
  const transformTriangleToChartData = () => {
    if (!incurredTriangle || !incurredTriangle.length) return [];
    
    return incurredTriangle.map((row, rowIndex) => {
      const scatter = [];
      
      for (let colIndex = 0; colIndex < row.length; colIndex++) {
        const value = row[colIndex];
        const previousValue = colIndex > 0 ? row[colIndex - 1] : null;
        const period = colIndex + 1;
        
        if (value !== null && value !== undefined) {
          scatter.push({
            x: period,
            y: value,
            previousValue: previousValue,
            incrementalDamage: previousValue !== null && previousValue !== undefined ? value - previousValue : null
          });
        }
      }

      return {
        title: actualRowLabels[rowIndex] || `Rok ${rowIndex + 1}`,
        xLabel: 'Okres rozwoju',
        scatter: scatter
      };
    }).filter(item => item.scatter.length > 0);
  };

  const chartDataByYear = transformTriangleToChartData();

  // Przewijanie do wykresów gdy się pokazują
  useEffect(() => {
    if (showCharts && chartsRef.current) {
      setTimeout(() => {
        chartsRef.current?.scrollIntoView({ 
          behavior: 'smooth', 
          block: 'start' 
        });
      }, 100); // Małe opóźnienie żeby DOM się zaktualizował
    }
  }, [showCharts]);

  // Komponent kontrolek rozmiaru - używany w obu miejscach
  const ScaleControls = () => (
    <div className="flex items-center gap-2">
      <button
        onClick={decreaseScale}
        disabled={tableScale <= 0.5}
        className="w-8 h-8 p-0 bg-gradient-to-r from-gray-600 to-gray-500 hover:from-gray-700 hover:to-gray-600 text-white rounded-lg font-bold transition-all duration-200 shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
      >
        <Minus className="w-4 h-4" />
      </button>
      
      <span className="text-white text-sm min-w-[3rem] text-center">
        {Math.round(tableScale * 100)}%
      </span>
      
      <button
        onClick={increaseScale}
        disabled={tableScale >= 2.0}
        className="w-8 h-8 p-0 bg-gradient-to-r from-gray-600 to-gray-500 hover:from-gray-700 hover:to-gray-600 text-white rounded-lg font-bold transition-all duration-200 shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
      >
        <Plus className="w-4 h-4" />
      </button>
    </div>
  );

  return (
    <>
      {/* Normalny widok z panelem bocznym */}
      <div className="flex gap-8 p-8">
        {/* Lewy panel */}
        <div className="w-64 shrink-0 space-y-4">
          <div className="bg-gray-800 rounded-lg p-4">
            <Checkbox
              checked={roundNumbers}
              onChange={(e) => setRoundNumbers(e.target.checked)}
              label="Zaokrąglij liczby"
              labelClassName="text-white text-sm"
            />
          </div>
          
          <div className="bg-gray-800 rounded-lg p-4">
            <label className="text-white text-sm font-medium mb-2 block">
              Rozmiar tabeli
            </label>
            <ScaleControls />
          </div>
          
          <button
            onClick={() => setShowCharts(!showCharts)}
            className="w-full py-4 px-5 bg-gradient-to-r from-gray-600 to-gray-500 hover:from-gray-700 hover:to-gray-600 text-white rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
          >
            {showCharts ? "Ukryj wykresy" : "Wyświetl wykresy"}
          </button>
        </div>
        
        {/* Główna tabela */}
        <div className="flex-1 flex flex-col min-w-0">
          <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white">
            <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl flex justify-between items-center">
              <h3 className="font-bold text-gray-800 text-lg tracking-tight">Wczytany trójkąt danych</h3>
              <button
                onClick={() => setFullscreenMode(true)}
                className="py-3 px-4 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 text-white rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform flex items-center gap-2"
              >
                <Maximize2 className="w-4 h-4" />
                Pełny ekran
              </button>
            </div>
            <div className="overflow-auto p-4" style={{ maxHeight: 'calc(100vh - 300px)' }}>
              <div 
                style={{ 
                  transform: `scale(${tableScale})`, 
                  transformOrigin: 'top left',
                  width: `${100 / tableScale}%`,
                  height: `${100 / tableScale}%`
                }}
              >
                <TriangleTableView
                  title=""
                  triangle={formattedTriangle}
                  noDataMessage="Brak danych do wyświetlenia. Najpierw wczytaj plik poniżej."
                  fallbackComponent={IncurredTriangleDet}
                  withNumericHeaders={false}
                  rowLabels={actualRowLabels}
                  columnLabels={actualColumnLabels}
                  numberFormatter={numberFormatter}
                  variant="light"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Grid - niezależny wykres rozwoju szkód */}
      {showCharts && chartDataByYear.length > 0 && (
        <div ref={chartsRef} className="mt-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-white text-xl font-semibold">Wykresy rozwoju szkód w czasie</h2>
            <button
              onClick={() => setChartsFullscreen(true)}
              className="py-4 px-5 bg-gradient-to-br from-blue-600 to-blue-500 text-white rounded-xl font-bold shadow-lg hover:shadow-2xl hover:scale-[1.02] transform transition-all duration-200 hover:from-blue-700 hover:to-blue-600 flex items-center gap-2"
            >
              <Maximize2 className="w-4 h-4" />
              Pełny ekran
            </button>
          </div>
          
          <div className="space-y-6">
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
              {chartDataByYear.map((chartConfig, idx) => (
                <div key={idx} className="bg-gray-800/30 rounded-lg border border-gray-700 p-6">
                  <DevelopmentChart
                    title={chartConfig.title}
                    xLabel={chartConfig.xLabel}
                    scatter={chartConfig.scatter}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Overlay pełnoekranowy - wyświetla się NAD wszystkim */}
      {fullscreenMode && (
        <div 
          className="fixed inset-0 bg-gray-900 z-50 flex flex-col transition-all duration-300 ease-out"
          style={{
            animation: isClosing ? 'fadeOut 0.2s ease-in forwards' : 'fadeIn 0.3s ease-out'
          }}
        >
          {/* Górny pasek z przyciskiem zamknięcia */}
          <div 
            className="bg-gray-800 p-4 flex justify-between items-center border-b border-gray-700 transition-all duration-300 ease-out"
            style={{
              animation: isClosing 
                ? 'slideOutToTop 0.25s ease-in forwards' 
                : 'slideInFromTop 0.4s ease-out 0.1s both'
            }}
          >
            <h2 className="text-white text-lg font-medium">Wczytany trójkąt danych - Widok pełnoekranowy</h2>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-white text-sm">Rozmiar:</span>
                <ScaleControls />
              </div>
              
              <button
                onClick={handleCloseFullscreen}
                className="py-3 px-4 bg-gradient-to-br from-gray-600 to-gray-500 text-white rounded-xl font-bold shadow-lg hover:shadow-2xl hover:scale-[1.02] transform transition-all duration-200 hover:from-gray-700 hover:to-gray-600 flex items-center gap-2"
              >
                <Minimize2 className="w-4 h-4" />
                Zamknij pełny ekran
              </button>
            </div>
          </div>
          
          {/* Tabela zajmująca całą dostępną przestrzeń */}
          <div 
            className="flex-1 p-6 bg-gray-900 transition-all duration-500 ease-out"
            style={{
              animation: isClosing 
                ? 'zoomOut 0.3s ease-in forwards'
                : 'zoomIn 0.5s ease-out 0.2s both'
            }}
          >
            <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white">
              <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
                <h3 className="font-bold text-gray-800 text-lg tracking-tight">Wczytany trójkąt danych</h3>
              </div>
              <div className="overflow-auto p-4" style={{ maxHeight: 'calc(100vh - 200px)' }}>
                <div 
                  style={{ 
                    transform: `scale(${tableScale})`, 
                    transformOrigin: 'top left',
                    width: `${100 / tableScale}%`,
                    height: `${100 / tableScale}%`
                  }}
                >
                  <TriangleTableView
                    title=""
                    triangle={formattedTriangle}
                    noDataMessage="Brak danych do wyświetlenia. Najpierw wczytaj plik poniżej."
                    fallbackComponent={IncurredTriangleDet}
                    withNumericHeaders={false}
                    rowLabels={actualRowLabels}
                    columnLabels={actualColumnLabels}
                    numberFormatter={numberFormatter}
                    variant="light"
                  />
                </div>
              </div>
            </div>
          </div>
          
          {/* Style animacji - otwieranie i zamykanie */}
          <style jsx>{`
            /* Animacje otwierania */
            @keyframes fadeIn {
              from {
                opacity: 0;
              }
              to {
                opacity: 1;
              }
            }
            
            @keyframes slideInFromTop {
              from {
                transform: translateY(-20px);
                opacity: 0;
              }
              to {
                transform: translateY(0);
                opacity: 1;
              }
            }
            
            @keyframes zoomIn {
              from {
                transform: scale(0.95);
                opacity: 0;
              }
              to {
                transform: scale(1);
                opacity: 1;
              }
            }
            
            /* Animacje zamykania */
            @keyframes fadeOut {
              from {
                opacity: 1;
              }
              to {
                opacity: 0;
              }
            }
            
            @keyframes slideOutToTop {
              from {
                transform: translateY(0);
                opacity: 1;
              }
              to {
                transform: translateY(-20px);
                opacity: 0;
              }
            }
            
            @keyframes zoomOut {
              from {
                transform: scale(1);
                opacity: 1;
              }
              to {
                transform: scale(0.95);
                opacity: 0;
              }
            }
          `}</style>
        </div>
      )}

      {/* Overlay pełnoekranowy dla wykresów */}
      {chartsFullscreen && (
        <div 
          className="fixed inset-0 bg-gray-900 z-50 flex flex-col transition-all duration-300 ease-out"
          style={{
            animation: isChartsClosing ? 'fadeOut 0.2s ease-in forwards' : 'fadeIn 0.3s ease-out'
          }}
        >
          {/* Górny pasek z przyciskiem zamknięcia */}
          <div 
            className="bg-gray-800 p-4 flex justify-between items-center border-b border-gray-700 transition-all duration-300 ease-out"
            style={{
              animation: isChartsClosing 
                ? 'slideOutToTop 0.25s ease-in forwards' 
                : 'slideInFromTop 0.4s ease-out 0.1s both'
            }}
          >
            <h2 className="text-white text-lg font-medium">Wykresy rozwoju szkód w czasie - Widok pełnoekranowy</h2>
            
            <button
              onClick={handleCloseChartsFullscreen}
              className="py-3 px-4 bg-gradient-to-br from-gray-600 to-gray-500 text-white rounded-xl font-bold shadow-lg hover:shadow-2xl hover:scale-[1.02] transform transition-all duration-200 hover:from-gray-700 hover:to-gray-600 flex items-center gap-2"
            >
              <Minimize2 className="w-4 h-4" />
              Zamknij pełny ekran
            </button>
          </div>
          
          {/* Wykresy zajmujące całą dostępną przestrzeń */}
          <div 
            className="flex-1 p-6 bg-gray-900 transition-all duration-500 ease-out overflow-auto"
            style={{
              animation: isChartsClosing 
                ? 'zoomOut 0.3s ease-in forwards'
                : 'zoomIn 0.5s ease-out 0.2s both'
            }}
          >
            <div className="space-y-8">
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-10">
                {chartDataByYear.map((chartConfig, idx) => (
                  <div key={idx} className="bg-gray-800/30 rounded-lg border border-gray-700 p-8 min-h-[700px]">
                    <DevelopmentChart
                      title={chartConfig.title}
                      xLabel={chartConfig.xLabel}
                      scatter={chartConfig.scatter}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
