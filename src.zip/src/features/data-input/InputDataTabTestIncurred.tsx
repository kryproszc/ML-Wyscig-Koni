'use client';

import { useForm } from 'react-hook-form';
import { useState, useEffect } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import ExcelJS from 'exceljs';
import { z } from 'zod';
import { useTestTriangleStoreIncurred } from '@/stores/useTestTriangleStoreIncurred';
import { useTrainDevideStoreDetIncurred } from '@/stores/trainDevideStoreDeterministycznyIncurred';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardFooter,
} from '@/components/ui/card';
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Loader2 } from 'lucide-react';
import { VisuallyHidden } from '@/components/ui/visually-hidden';
import { HeadersSelector } from '@/components/HeadersSelector';

// Funkcje konwersji Excel notacji
const colLetterToNumber = (col: string): number => {
  let result = 0;
  for (let i = 0; i < col.length; i++) {
    result = result * 26 + (col.charCodeAt(i) - 'A'.charCodeAt(0) + 1);
  }
  return result;
};

const colNumberToLetter = (num: number): string => {
  let result = '';
  while (num > 0) {
    num--;
    result = String.fromCharCode((num % 26) + 'A'.charCodeAt(0)) + result;
    num = Math.floor(num / 26);
  }
  return result;
};

const parseExcelCell = (cell: string): { row: number; col: number } | null => {
  const match = cell.match(/^([A-Z]+)(\d+)$/);
  if (!match || !match[1] || !match[2]) return null;
  
  const colLetter = match[1];
  const rowNumber = parseInt(match[2], 10);
  
  if (isNaN(rowNumber)) return null;
  
  return {
    row: rowNumber,
    col: colLetterToNumber(colLetter)
  };
};

const schema = z.object({
  rowStart: z.union([z.coerce.number().min(1, "Wiersz początkowy musi być co najmniej 1"), z.string()]),
  rowEnd: z.coerce.number().min(1, "Wiersz końcowy musi być co najmniej 1"),
  colStart: z.coerce.number().min(1, "Kolumna początkowa musi być co najmniej 1"),
  colEnd: z.coerce.number().min(1, "Kolumna końcowa musi być co najmniej 1"),
  cellStart: z.string().optional(),
  cellEnd: z.string().optional(),
  rangeMode: z.enum(['numeric', 'excel']),
  file: z.any(),
}).refine((data) => {
  if (data.rangeMode === 'excel') {
    return data.cellStart && data.cellEnd;
  }
  return true;
}, {
  message: "W trybie Excel musisz podać obie komórki (np. A1 i Z99)",
  path: ['cellStart']
});

interface TestFormData {
  file?: FileList | null;
  rowStart: string | number;
  rowEnd: number;
  colStart: number;
  colEnd: number;
  cellStart?: string;
  cellEnd?: string;
  rangeMode: 'numeric' | 'excel';
}

// Komponent do wyboru arkusza
function SheetSelectTestIncurred() {
  const { workbook, selectedSheetName, setSelectedSheetName } = useTestTriangleStoreIncurred();
  
  if (!workbook) return null;
  
  const wb = workbook as any; // ExcelJS Workbook
  const sheets = wb.worksheets || [];
  
  return (
    <select
      value={selectedSheetName || ''}
      onChange={(e) => setSelectedSheetName(e.target.value)}
      className="bg-slate-700 border border-slate-600 text-white p-2 rounded-lg"
    >
      {sheets.map((sheet: any) => (
        <option key={sheet.name} value={sheet.name}>
          {sheet.name}
        </option>
      ))}
    </select>
  );
}

export function InputDataTabTestIncurred() {
  const [errorMessage, setErrorMessage] = useState("");
  const [showErrorDialog, setShowErrorDialog] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [rangeMode, setRangeMode] = useState<'numeric' | 'excel'>('numeric');
  const [hasHeaders, setHasHeaders] = useState(true);
  
  const {
    workbook,
    selectedSheetName,
    uploadedFileName,
    startRow,
    endRow,
    startCol,
    endCol,
    testData,
    setWorkbook,
    setSelectedSheetName,
    setUploadedFileName,
    setRange,
    setTestData,
  } = useTestTriangleStoreIncurred();

  const { setClInitialInc, cl_initial_inc } = useTrainDevideStoreDetIncurred();
  
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<TestFormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      file: null,
      rowStart: startRow,
      rowEnd: endRow,
      colStart: startCol,
      colEnd: endCol,
      cellStart: "A1",
      cellEnd: "A1",
      rangeMode: 'numeric',
    },
  });

  const file = watch('file');
  const watchedRangeMode = watch('rangeMode');
  
  useEffect(() => {
    if (watchedRangeMode && watchedRangeMode !== rangeMode) {
      setRangeMode(watchedRangeMode);
    }
  }, [watchedRangeMode]);
  
  // Wczytanie pliku
  const handleFileLoad = async () => {
    const f = file?.[0];
    if (!f) {
      setErrorMessage("Najpierw wybierz plik Excel (.xlsx lub .xls).");
      setShowErrorDialog(true);
      return;
    }

    if (f.size > 10 * 1024 * 1024) {
      setErrorMessage("Plik jest za duży. Maksymalny rozmiar to 10MB.");
      setShowErrorDialog(true);
      return;
    }

    const validExtensions = ['.xlsx', '.xls'];
    const fileName = f.name.toLowerCase();
    const hasValidExtension = validExtensions.some(ext => fileName.endsWith(ext));
    
    if (!hasValidExtension) {
      setErrorMessage("Nieprawidłowy format pliku. Wybierz plik Excel (.xlsx lub .xls).");
      setShowErrorDialog(true);
      return;
    }

    try {
      setIsLoading(true);
      setProgress(0);
      
      const arrayBuffer = await f.arrayBuffer();
      setProgress(50);
      
      const workbook = new ExcelJS.Workbook();
      await workbook.xlsx.load(arrayBuffer);
      
      setProgress(100);
      setWorkbook(workbook as any);
      setSelectedSheetName(workbook.worksheets[0]?.name ?? null);
      setUploadedFileName(f.name);
      
      console.log('✅ Plik wczytany przez ExcelJS (Incurred)!');
      console.log('📋 Dostępne arkusze:', workbook.worksheets.map(ws => ws.name));
      
      setIsLoading(false);
    } catch (err) {
      console.error("Błąd:", err);
      setErrorMessage("Nie można odczytać pliku.");
      setShowErrorDialog(true);
      setIsLoading(false);
    }
  };

  // Wykryj zakres automatycznie
  const handleAutoRange = () => {
    if (!workbook || !selectedSheetName) {
      setErrorMessage("Najpierw wczytaj plik i wybierz arkusz.");
      setShowErrorDialog(true);
      return;
    }

    const sheet = (workbook as any).getWorksheet(selectedSheetName);
    if (!sheet || !sheet.dimensions) {
      setErrorMessage("Nie można wykryć zakresu dla tego arkusza.");
      setShowErrorDialog(true);
      return;
    }

    const dims = sheet.dimensions;
    const top = dims.top;
    const left = dims.left;
    const bottom = dims.bottom;
    const right = dims.right;

    if (rangeMode === 'numeric') {
      setValue('rowStart', top);
      setValue('rowEnd', bottom);
      setValue('colStart', left);
      setValue('colEnd', right);
    } else {
      const startCell = `${colNumberToLetter(left)}${top}`;
      const endCell = `${colNumberToLetter(right)}${bottom}`;
      setValue('cellStart', startCell);
      setValue('cellEnd', endCell);
    }
  };
  
  // Przetworzenie danych z odczytem formatowania
  const onSubmit = (data: TestFormData) => {
    console.log('🔍 [onSubmit Incurred] START:', data);
    
    if (!workbook || !selectedSheetName) {
      setErrorMessage("Najpierw wczytaj plik i wybierz arkusz.");
      setShowErrorDialog(true);
      return;
    }
    
    const sheet = (workbook as any).getWorksheet(selectedSheetName);
    if (!sheet) {
      setErrorMessage("Nie znaleziono arkusza.");
      setShowErrorDialog(true);
      return;
    }

    let startRow: number, endRow: number, startCol: number, endCol: number;

    if (data.rangeMode === 'excel') {
      const parsedStart = parseExcelCell(data.cellStart?.toUpperCase() || '');
      const parsedEnd = parseExcelCell(data.cellEnd?.toUpperCase() || '');

      if (!parsedStart || !parsedEnd) {
        setErrorMessage("Nieprawidłowy format komórek. Użyj formatu A1, B2 itd.");
        setShowErrorDialog(true);
        return;
      }

      startRow = parsedStart.row;
      startCol = parsedStart.col;
      endRow = parsedEnd.row;
      endCol = parsedEnd.col;
    } else {
      startRow = Number(data.rowStart);
      endRow = Number(data.rowEnd);
      startCol = Number(data.colStart);
      endCol = Number(data.colEnd);
    }

    if (startRow > endRow || startCol > endCol) {
      setErrorMessage("Zakres jest nieprawidłowy. Sprawdź czy początek jest przed końcem.");
      setShowErrorDialog(true);
      return;
    }
    
    console.log('📊 Zakres:', startRow, '-', endRow, '×', startCol, '-', endCol);
    
    setRange(startRow, endRow, startCol, endCol);
    
    // Odczytaj dane z formatowaniem przez ExcelJS
    const result: any[][] = [];
    const offsetRow = hasHeaders ? 1 : 0;
    const offsetCol = hasHeaders ? 1 : 0;
    
    for (let row = startRow + offsetRow; row <= endRow; row++) {
      const rowData: any[] = [];
      
      for (let col = startCol + offsetCol; col <= endCol; col++) {
        const cell = sheet.getRow(row).getCell(col);
        const value = cell.value ?? null;
        
        // Odczytaj formatowanie
        const formatting: any = {};
        
        if (cell.font?.strike) {
          formatting.isStrikethrough = true;
        }
        
        if (cell.font?.color) {
          const fontColor = cell.font.color;
          if (fontColor.argb) {
            formatting.fontColor = `#${fontColor.argb.substring(2)}`;
          } else if (fontColor.theme !== undefined) {
            formatting.fontColor = `theme-${fontColor.theme}`;
          }
        }
        
        if (cell.fill && 'fgColor' in cell.fill) {
          const bgColor = (cell.fill as any).fgColor;
          if (bgColor && typeof bgColor === 'object' && 'argb' in bgColor) {
            formatting.backgroundColor = `#${bgColor.argb.substring(2)}`;
          }
        }
        
        rowData.push({
          value,
          formatting: Object.keys(formatting).length > 0 ? formatting : undefined
        });
      }
      
      result.push(rowData);
    }
    
    // Generuj cl_initial_inc: 0 gdzie przekreślenie, 1 gdzie normalne/puste
    const cl_initialMatrix: number[][] = [];
    for (let row = startRow + offsetRow; row <= endRow; row++) {
      const clRow: number[] = [];
      for (let col = startCol + offsetCol; col <= endCol; col++) {
        const cell = sheet.getRow(row).getCell(col);
        const isStrikethrough = cell.font?.strike === true;
        clRow.push(isStrikethrough ? 0 : 1);
      }
      cl_initialMatrix.push(clRow);
    }
    
    setClInitialInc(cl_initialMatrix);
    setTestData(result);
    console.log('📊 Dane wczytane (wierszy):', result.length);
    console.log('🔢 cl_initial_inc (wierszy):', cl_initialMatrix.length, 'x', cl_initialMatrix[0]?.length || 0);
  };
  
  return (
    <div>
      <form onSubmit={handleSubmit(onSubmit)} className="p-4 border rounded flex flex-col gap-4">
        <Card className="bg-slate-800 border border-slate-700 shadow-2xl">
          <CardHeader>
            <CardTitle className="text-white font-bold text-sm mb-4 pb-2 border-b-2 border-gray-700">
              🧪 Testowanie wczytywania formatowania Excel (Incurred)
            </CardTitle>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {/* SEKCJA 1: Plik i arkusz */}
            <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-600">
              <Label className="text-white text-sm mb-3 block">Wybór pliku i arkusza</Label>
              
              <div className="flex items-center gap-4 mb-4">
                <input
                  type="file"
                  accept=".xlsx,.xls"
                  className="bg-slate-700 border border-slate-600 text-white p-2 rounded-lg file:bg-slate-600 file:border-none file:text-white file:rounded file:px-3 file:py-1 file:mr-2"
                  {...register('file')}
                />
                <button
                  type="button"
                  onClick={handleFileLoad}
                  disabled={!file || file.length === 0 || isLoading}
                  className="py-2 px-4 bg-gradient-to-br from-emerald-600 to-emerald-500 hover:from-emerald-700 hover:to-emerald-600 text-white rounded-xl font-bold shadow-lg hover:shadow-2xl hover:scale-[1.02] transform transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="inline w-4 h-4 mr-2 animate-spin" />
                      Ładowanie...
                    </>
                  ) : (
                    'Załaduj plik'
                  )}
                </button>
                {uploadedFileName && (
                  <span className="text-sm text-green-400 ml-2">
                    Wczytano: <strong>{uploadedFileName}</strong>
                  </span>
                )}
              </div>

              <div>
                <Label className="text-white text-sm">Wybór arkusza</Label>
                <SheetSelectTestIncurred />
              </div>
            </div>

            {/* SEKCJA 2: Wybór trybu zakresu */}
            <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-600">
              <Label className="text-white text-sm mb-3 block">Sposób podawania zakresu</Label>
              <div className="flex gap-8 mb-4">
                <div className="flex items-center space-x-3">
                  <input
                    type="radio"
                    id="numeric-mode-inc"
                    checked={rangeMode === 'numeric'}
                    onChange={() => {
                      setRangeMode('numeric');
                      setValue('rangeMode', 'numeric');
                    }}
                    className="text-emerald-500 focus:ring-emerald-400 w-4 h-4"
                  />
                  <Label htmlFor="numeric-mode-inc" className="text-white text-sm font-medium cursor-pointer">
                    🔢 Numeryczny (wiersze/kolumny)
                  </Label>
                </div>
                <div className="flex items-center space-x-3">
                  <input
                    type="radio"
                    id="excel-mode-inc"
                    checked={rangeMode === 'excel'}
                    onChange={() => {
                      setRangeMode('excel');
                      setValue('rangeMode', 'excel');
                    }}
                    className="text-emerald-500 focus:ring-emerald-400 w-4 h-4"
                  />
                  <Label htmlFor="excel-mode-inc" className="text-white text-sm font-medium cursor-pointer">
                    📊 Excel (A1:Z99)
                  </Label>
                </div>
              </div>

              <div className="mt-6">
                {rangeMode === 'numeric' && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-white text-sm">Wiersz początkowy</Label>
                      <Input
                        type="number"
                        placeholder="np. 2"
                        disabled={!workbook}
                        {...register('rowStart')}
                        className="mt-1"
                      />
                      {errors.rowStart && (
                        <p className="text-red-400 text-xs mt-1">{errors.rowStart.message}</p>
                      )}
                    </div>
                    <div>
                      <Label className="text-white text-sm">Wiersz końcowy</Label>
                      <Input
                        type="number"
                        placeholder="np. 11"
                        disabled={!workbook}
                        {...register('rowEnd')}
                        className="mt-1"
                      />
                      {errors.rowEnd && (
                        <p className="text-red-400 text-xs mt-1">{errors.rowEnd.message}</p>
                      )}
                    </div>
                    <div>
                      <Label className="text-white text-sm">Kolumna początkowa</Label>
                      <Input
                        type="number"
                        placeholder="np. 2"
                        disabled={!workbook}
                        {...register('colStart')}
                        className="mt-1"
                      />
                      {errors.colStart && (
                        <p className="text-red-400 text-xs mt-1">{errors.colStart.message}</p>
                      )}
                    </div>
                    <div>
                      <Label className="text-white text-sm">Kolumna końcowa</Label>
                      <Input
                        type="number"
                        placeholder="np. 11"
                        disabled={!workbook}
                        {...register('colEnd')}
                        className="mt-1"
                      />
                      {errors.colEnd && (
                        <p className="text-red-400 text-xs mt-1">{errors.colEnd.message}</p>
                      )}
                    </div>
                  </div>
                )}

                {rangeMode === 'excel' && (
                  <div className="flex items-end gap-4">
                    <div className="flex-1">
                      <Label className="text-white text-sm">Od komórki</Label>
                      <Input
                        type="text"
                        placeholder="A1"
                        disabled={!workbook}
                        {...register('cellStart')}
                        className="uppercase mt-1 text-center font-mono"
                      />
                      {errors.cellStart && (
                        <p className="text-red-400 text-xs mt-1">{errors.cellStart.message}</p>
                      )}
                    </div>
                    <div className="text-emerald-400 font-bold text-2xl pb-6">:</div>
                    <div className="flex-1">
                      <Label className="text-white text-sm">Do komórki</Label>
                      <Input
                        type="text"
                        placeholder="Z99"
                        disabled={!workbook}
                        {...register('cellEnd')}
                        className="uppercase mt-1 text-center font-mono"
                      />
                      {errors.cellEnd && (
                        <p className="text-red-400 text-xs mt-1">{errors.cellEnd.message}</p>
                      )}
                    </div>
                  </div>
                )}

                <div className="mt-4">
                  <Button
                    type="button"
                    onClick={handleAutoRange}
                    variant="outline"
                    disabled={!workbook}
                    className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600 hover:border-slate-500"
                  >
                    Wykryj zakres automatycznie
                  </Button>
                </div>
              </div>
            </div>

            {/* SEKCJA 3: Ustawienia */}
            <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-600">
              <HeadersSelector 
                hasHeaders={hasHeaders} 
                onHeadersChange={setHasHeaders} 
              />
            </div>
          </CardContent>

          <CardFooter>
            <input type="hidden" {...register('rangeMode')} />
            <button
              type="submit"
              className="py-2 px-4 bg-gradient-to-br from-emerald-600 to-emerald-500 hover:from-emerald-700 hover:to-emerald-600 text-white rounded-xl font-bold shadow-lg hover:shadow-2xl hover:scale-[1.02] transform transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={!workbook}
            >
              Wczytaj dane
            </button>
          </CardFooter>
        </Card>
      </form>

      {/* AlertDialog dla błędów */}
      <AlertDialog open={showErrorDialog} onOpenChange={setShowErrorDialog}>
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center">
            <VisuallyHidden>
              <AlertDialogTitle>Błąd walidacji</AlertDialogTitle>
            </VisuallyHidden>
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-red-100 mb-4">
              <span className="text-red-600 text-2xl">✕</span>
            </div>
            <AlertDialogDescription className="text-center text-base">
              {errorMessage}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex justify-center">
            <AlertDialogCancel className="bg-slate-700 text-white hover:bg-slate-600">
              OK
            </AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Wyniki */}
      {testData && testData.length > 0 && (
        <Card className="bg-slate-800 border border-slate-700 shadow-2xl mt-6">
          <CardHeader>
            <CardTitle className="text-white font-bold">
              📊 Wyniki analizy formatowania
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-auto">
              <table className="min-w-full border-collapse">
                <thead>
                  <tr>
                    {testData[0]?.map((_, colIdx) => (
                      <th
                        key={colIdx}
                        className="border border-slate-600 px-3 py-2 bg-slate-700 text-white text-sm"
                      >
                        Kol {startCol + colIdx + (hasHeaders ? 1 : 0)}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {testData.map((row, rowIdx) => (
                    <tr key={rowIdx}>
                      {row.map((cell: any, colIdx) => {
                        const isStrikethrough = cell.formatting?.isStrikethrough;
                        
                        return (
                          <td
                            key={colIdx}
                            className="border border-slate-600 px-3 py-2 text-center bg-slate-800 text-white"
                            style={{
                              textDecoration: isStrikethrough ? 'line-through' : 'none',
                            }}
                          >
                            {cell.value ?? '–'}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            <div className="mt-4 p-4 bg-slate-900/50 rounded-lg border border-slate-600">
              <h4 className="text-white font-semibold mb-2">Legenda:</h4>
              <ul className="text-sm text-slate-300 space-y-1">
                <li><span className="line-through">Przekreślone</span> = komórka z przekreśleniem w Excelu</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}

      {/* cl_initial_inc Matrix */}
      {cl_initial_inc && cl_initial_inc.length > 0 && (
        <Card className="bg-slate-800 border border-slate-700 shadow-2xl mt-6">
          <CardHeader>
            <CardTitle className="text-white font-bold">
              🔢 Macierz cl_initial_inc
            </CardTitle>
            <p className="text-slate-400 text-sm mt-2">
              0 = komórka przekreślona (wykluczona), 1 = komórka normalna/pusta (uwzględniona)
            </p>
          </CardHeader>
          <CardContent>
            <div className="overflow-auto">
              <table className="min-w-full border-collapse">
                <thead>
                  <tr>
                    {cl_initial_inc[0]?.map((_, colIdx) => (
                      <th
                        key={colIdx}
                        className="border border-slate-600 px-3 py-2 bg-slate-700 text-white text-sm"
                      >
                        Kol {colIdx + 1}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {cl_initial_inc.map((row, rowIdx) => (
                    <tr key={rowIdx}>
                      {row.map((value, colIdx) => (
                        <td
                          key={colIdx}
                          className={`border border-slate-600 px-3 py-2 text-center font-semibold ${
                            value === 0 
                              ? 'bg-red-900/50 text-red-300' 
                              : 'bg-green-900/30 text-green-300'
                          }`}
                        >
                          {value}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
