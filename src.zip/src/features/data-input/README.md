# Data Input Feature

Ten folder zawiera komponenty odpowiedzialne za wczytywanie i przetwarzanie danych Excel.

## Struktura

```
src/features/data-input/
├── index.ts                        # Eksporty publiczne
├── InputDataTabRefactored.tsx      # Główna zakładka (Paid)
├── InputDataTabDet.tsx             # Zakładka Det (Deterministic)
├── InputDataTabDetIncurred.tsx     # Zakładka Incurred
└── README.md                       # Ta dokumentacja
```

## Komponenty

### InputDataTab (InputDataTabRefactored)
- **Przeznaczenie**: Główna zakładka wczytywania danych (Paid)
- **Store**: `useTableStore`, `useInputSettingsStore`
- **Funkcje**: Wczytywanie plików Excel, wybór arkusza, konwersja danych

### InputDataTabDet
- **Przeznaczenie**: Zakładka dla metod deterministycznych
- **Store**: `useDetailTableStore`, `useInputSettingsStore`
- **Funkcje**: Specializowane przetwarzanie dla obliczeń deterministycznych

### InputDataTabIncurred
- **Przeznaczenie**: Zakładka dla danych Incurred
- **Store**: `useIncurredTableStore`, `useInputSettingsStore`
- **Funkcje**: Obsługa danych typu Incurred z dedykowaną walidacją

## Wspólne funkcjonalności

- **Global State Management**: Wszystkie komponenty używają `useInputSettingsStore` dla ustawień (typ danych, typ trójkąta)
- **Modal Warning**: Ostrzeżenia o utracie danych przy wczytywaniu nowych plików
- **Data Conversion**: Automatyczna konwersja danych inkrementalnych na skumulowane
- **Label Management**: Zapisywanie nazw wierszy i kolumn z plików Excel

## Używane komponenty wspólne

Z `src/components/`:
- `DataTypeSelector` - Wybór typu danych (skumulowane/inkrementalne)
- `TriangleTypeSelector` - Wybór typu trójkąta (Paid/Incurred)
- `Modal` - Modale ostrzeżeń
- `InputFormSections` - Sekcje formularzy
- `SheetSelect*` - Komponenty wyboru arkusza

## Import/Export

```typescript
// Import pojedynczych komponentów
import { InputDataTab, InputDataTabDet, InputDataTabIncurred } from '@/features/data-input';

// Import wszystkich
import * as DataInputComponents from '@/features/data-input';
```
