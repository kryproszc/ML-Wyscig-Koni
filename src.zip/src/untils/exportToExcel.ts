import * as XLSX from 'xlsx';

export type DevJResult = {
  volume: number;
  subIndex?: number;
  values: number[];
  sdValues?: number[]; // odchylenia standardowe
};

export type OverrideRow = { index: number; curve: string; value: number };

export function exportDevJToExcel(
  devJResults: DevJResult[],
  finalDevJ?: DevJResult,
  customFinal?: number[],
  overrides: OverrideRow[] = [],   // <── NOWY, opcjonalny parametr
  columnLabels?: string[],         // <── Etykiety kolumn (np. 'b', 'c', '4', '5'...)
  finalSdValues?: number[],        // <── Odchylenia standardowe dla Initial Selection
  filename: string = 'wspolczynniki.xlsx' // <── Nazwa pliku
) {
  const maxLength = Math.max(...devJResults.map((r) => r.values.length));

  /* 1) Tabela porównawcza współczynników */
  const comparisonHeader = [
    'volume', 
    ...Array.from({ length: maxLength }, (_, j) => 
      (columnLabels && columnLabels.length > j) ? columnLabels[j] : `j=${j}`
    )
  ];
  const comparisonRows = devJResults.map((r) => [
    r.subIndex !== undefined ? `${r.volume},${r.subIndex}` : `${r.volume}`,
    ...r.values,
  ]);
  const comparisonTable = [comparisonHeader, ...comparisonRows];

  /* 2) Tabela odchyleń standardowych */
  const sdHeader = [
    'Volume', 
    ...Array.from({ length: maxLength }, (_, j) => 
      (columnLabels && columnLabels.length > j) ? columnLabels[j] : `j=${j}`
    )
  ];
  const sdRows = devJResults.map((r) => [
    `Volume ${r.volume}${r.subIndex !== undefined ? `.${r.subIndex}` : ''}`,
    ...(r.sdValues ?? Array(maxLength).fill('–')),
  ]);
  const sdTable = [sdHeader, ...sdRows];

  /* 3) Finalny wektor współczynników */
  const finalValues = customFinal ?? finalDevJ?.values ?? [];
  const finalHeader = [
    'Wektor finalny', 
    ...Array.from({ length: finalValues.length }, (_, j) => 
      (columnLabels && columnLabels.length > j) ? columnLabels[j] : `j=${j}`
    )
  ];
  const finalRow    = ['Initial Selection', ...finalValues];
  
  // Wiersz z odchyleniami standardowymi dla Initial Selection
  const finalSdRow = finalSdValues && finalSdValues.length > 0
    ? ['Odchyl. Standardowe', ...finalSdValues]
    : null;
  
  const finalTable  = finalSdRow 
    ? [finalHeader, finalRow, finalSdRow]
    : [finalHeader, finalRow];

  /* 4) Overrides (jeśli są) */
  const overridesTable =
    overrides.length > 0
      ? [
          ['j (index)', 'curve', 'value'],
          ...overrides.map(o => [o.index, o.curve, o.value]),
        ]
      : [];

  /* 5) Składamy arkusz główny (wszystkie tabele) */
  const wsMain = XLSX.utils.aoa_to_sheet([
    ...comparisonTable,
    [], // pusta linia
    ...sdTable,
    [], // pusta linia
    ...finalTable,
  ]);

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, wsMain, 'dev_j');

  /* 6) Drugi arkusz z overrides (opcjonalny) */
  if (overridesTable.length) {
    const wsOv = XLSX.utils.aoa_to_sheet(overridesTable);
    XLSX.utils.book_append_sheet(wb, wsOv, 'overrides');
  }

  XLSX.writeFile(wb, filename);
}
