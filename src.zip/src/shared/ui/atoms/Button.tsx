import clsx from "clsx";
import React from "react";

export type ButtonVariant = "primary" | "success" | "secondary";

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  full?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = "primary", full, className, children, ...rest }, ref) => (
    <button
      ref={ref}
      {...rest}
      className={clsx(
        "px-4 py-2 rounded font-medium transition disabled:opacity-50",
        full && "w-full",
        variant === "primary" && "bg-blue-600 hover:bg-blue-700",
        variant === "success" && "bg-green-600 hover:bg-green-700",
        variant === "secondary" && "bg-gray-600 hover:bg-gray-700",
        className
      )}
    >
      {children}
    </button>
  )
);
Button.displayName = "Button";
