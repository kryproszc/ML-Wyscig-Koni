import { Button } from "../atoms/Button";
import { InputNumber } from "../atoms/InputNumber";
import { Card } from "../atoms/Card";

type Props = {
  currentVectorLength: number;
  tailCount: number | "";
  onTailChange: (v: number | "") => void;
  onUpdateVector: () => void;
  onSend: () => void;
  disableSend: boolean;
  fittingMethod: "log_regression" | "least_squares";
  onFittingMethodChange: (method: "log_regression" | "least_squares") => void;
  useWeighting: boolean;
  onUseWeightingChange: (value: boolean) => void;
};

export const ControlPanel = ({
  currentVectorLength,
  tailCount,
  onTailChange,
  onUpdateVector,
  onSend,
  disableSend,
  fittingMethod,
  onFittingMethodChange,
  useWeighting,
  onUseWeightingChange,
}: Props) => (
  <div className="w-64 h-fit shrink-0 space-y-4">
    <div className="bg-gray-800 rounded-lg p-4">
      <h3 className="text-white text-lg font-medium mb-4">Panel sterowania</h3>

      <button
        onClick={onUpdateVector}
        disabled={!currentVectorLength}
        className={`w-full py-4 px-5 rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform mb-4 ${
          currentVectorLength
            ? 'bg-gradient-to-r from-gray-600 to-gray-500 hover:from-gray-700 hover:to-gray-600 text-white'
            : 'bg-gray-600 text-gray-400 cursor-not-allowed'
        }`}
      >
        Zaktualizuj wektor
      </button>

      {/* Metoda dopasowania */}
      <div className="mb-4 pb-4 border-b border-gray-700">
        <label className="block text-white text-sm font-medium mb-3">
          Metoda dopasowania:
        </label>
        <div className="space-y-2">
          <label className="flex items-center gap-2 cursor-pointer text-white text-sm">
            <input
              type="radio"
              value="least_squares"
              checked={fittingMethod === "least_squares"}
              onChange={(e) => onFittingMethodChange(e.target.value as "least_squares")}
              className="w-4 h-4 text-purple-600 bg-gray-700 border-gray-600 focus:ring-2 focus:ring-purple-500 cursor-pointer"
            />
            <span>Least Squares</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer text-white text-sm">
            <input
              type="radio"
              value="log_regression"
              checked={fittingMethod === "log_regression"}
              onChange={(e) => onFittingMethodChange(e.target.value as "log_regression")}
              className="w-4 h-4 text-purple-600 bg-gray-700 border-gray-600 focus:ring-2 focus:ring-purple-500 cursor-pointer"
            />
            <span>Log Regression</span>
          </label>
        </div>
      </div>

      {/* Ważenie współczynników */}
      <div className="mb-4 pb-4 border-b border-gray-700">
        <label className="flex items-center gap-3 cursor-pointer text-white">
          <input
            type="checkbox"
            checked={useWeighting}
            onChange={(e) => onUseWeightingChange(e.target.checked)}
            className="w-5 h-5 text-purple-600 bg-gray-700 border-gray-600 rounded focus:ring-2 focus:ring-purple-500 cursor-pointer"
          />
          <span className="text-sm font-medium">Włącz ważenie współczynników</span>
        </label>
      </div>

      <label className="block text-white text-sm font-medium mb-2">
        Ile obserwacji w&nbsp;ogonie:
      </label>
      <input
        type="number"
        min={0}
        value={tailCount}
        placeholder="np. 2"
        onChange={(e) => {
          const value = e.target.value;
          if (value === "") {
            onTailChange("");
          } else {
            const parsed = parseInt(value, 10);
            if (!isNaN(parsed)) {
              onTailChange(parsed);
            }
          }
        }}
        className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent mb-4"
      />

      <button
        onClick={onSend}
        disabled={disableSend}
        className={`w-full py-4 px-5 rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform ${
          disableSend
            ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
            : 'bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-700 hover:to-emerald-600 text-white'
        }`}
      >
        Dopasuj krzywe
      </button>
    </div>
  </div>
);
