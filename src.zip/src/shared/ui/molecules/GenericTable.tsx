import React from "react";
import clsx from "clsx";

export type CellRenderer = (row: number, col: number) => React.ReactNode;

export interface GenericTableProps {
  cols: React.ReactNode[];   // nagłówki
  rows: number;              // liczba wierszy
  renderCell: CellRenderer;  // renderer komórki
  stickyFirstCol?: boolean;
  className?: string;
}

export const GenericTable = ({
  cols,
  rows,
  renderCell,
  stickyFirstCol,
  className,
}: GenericTableProps) => (
  <div className="relative w-full max-w-full overflow-x-auto">
    <table
      className={clsx(
        "min-w-max bg-white rounded-xl shadow-md text-sm",
        className
      )}
      style={{ borderCollapse: 'separate', borderSpacing: 0 }}
    >
      <thead>
        <tr>
          {cols.map((c, i) => (
            <th
              key={i}
              className={clsx(
                "border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold text-center whitespace-nowrap",
                i === 0 && "rounded-tl-xl",
                i === cols.length - 1 && "rounded-tr-xl"
              )}
            >
              {c}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {Array.from({ length: rows }).map((_, r) => (
          <tr key={r}>
            {cols.map((_, c) => (
              <td
                key={c}
                className={clsx(
                  "border border-gray-300 px-3 py-2 text-center text-gray-900 whitespace-nowrap",
                  stickyFirstCol && c === 0 && "sticky left-0 bg-gray-50 font-medium",
                  r === rows - 1 && c === 0 && "rounded-bl-xl",
                  r === rows - 1 && c === cols.length - 1 && "rounded-br-xl"
                )}
              >
                {renderCell(r, c)}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);
