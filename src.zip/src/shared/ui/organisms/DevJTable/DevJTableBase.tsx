'use client';

import Modal from '@/components/Modal';
import { fmt } from './useDevJHelpers';

export type DevJResult = {
  volume: number;
  subIndex?: number;
  values: number[];
  sdValues?: number[]; // odchylenia standardowe dla tego volume
};

export type DevJTableBaseProps = {
  results: DevJResult[];
  maxLength: number;
  columnLabels?: string[]; // opcjonalne etykiety kolumn

  displayed: (j: number) => number | undefined;
  selectedVolume?: number;
  selectedSubIndex?: number;
  onSelectVolume: (v: number, subIndex?: number) => void;

  onCellToggle?: (j: number, value: number, sourceVolume: number, sourceSubIndex?: number, event?: React.MouseEvent) => void;
  
  finalSelectedVolume?: number; // dodane dla Final?
  finalSelectedSubIndex?: number; // dodane dla Final?
  onSelectFinal?: (v: number, subIndex?: number) => void; // dodane dla Final?

  isConfirmModalOpen : boolean;
  onConfirmFinal     : () => void;
  onCancelConfirm    : () => void;
  
  formatNumber?: (n?: number) => string; // opcjonalna funkcja formatowania
  
  // Nowa prop dla precyzyjnej kontroli podświetleń
  customSelections?: Record<number, { sourceVolume: number; sourceSubIndex?: number }>;
};

export default function DevJTableBase({
  results,
  maxLength,
  columnLabels,
  displayed,
  selectedVolume,
  selectedSubIndex,
  onSelectVolume,
  onCellToggle,
  finalSelectedVolume,  // dodane dla Final?
  finalSelectedSubIndex, // dodane dla Final?
  onSelectFinal,        // dodane dla Final?
  isConfirmModalOpen,
  onConfirmFinal,
  onCancelConfirm,
  formatNumber = fmt, // domyślnie używa fmt, ale może być nadpisane
  customSelections, // nowa prop dla precyzyjnych podświetleń
}: DevJTableBaseProps) {
  return (
    <div className="overflow-x-auto bg-white rounded-lg border border-gray-300">
      <table className="min-w-full text-sm border-collapse">
        <thead>
          <tr>
            <th className="border border-gray-300 px-2 py-2 bg-gray-200 text-gray-900 font-semibold">Final?</th>
            <th className="border border-gray-300 px-2 py-2 bg-gray-200 text-gray-900 font-semibold">volume</th>
            {Array.from({ length: maxLength }).map((_, j) => (
              <th
                key={j}
                className="border border-gray-300 px-2 py-2 bg-gray-200 text-center text-gray-900 font-semibold"
              >
                {columnLabels && columnLabels.length > j ? columnLabels[j] : `j=${j}`}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {results.map((r) => {
            const key = `${r.volume}-${r.subIndex ?? 0}`;
            return (
              <tr key={key}>
                <td className="border border-gray-300 px-2 py-2 text-center bg-gray-200">
                  <input
                    type="radio"
                    name="finalDevJSelection"
                    checked={finalSelectedVolume === r.volume && (finalSelectedSubIndex ?? 0) === (r.subIndex ?? 0)}
                    onChange={() => onSelectFinal?.(r.volume, r.subIndex)}
                  />
                </td>
                <td className="border border-gray-300 px-2 py-2 bg-gray-200 text-gray-900 font-semibold">
                  {r.subIndex !== undefined ? `${r.volume},${r.subIndex}` : r.volume}
                </td>

                {Array.from({ length: maxLength }).map((_, j) => {
                  const val = r.values[j];
                  
                  // Precyzyjne sprawdzenie czy ta konkretna komórka jest wybrana
                  let selected = false;
                  
                  if (customSelections?.[j]) {
                    // Sprawdź czy to jest konkretnie ta komórka z tego volume
                    selected = customSelections[j].sourceVolume === r.volume && 
                              (customSelections[j].sourceSubIndex ?? 0) === (r.subIndex ?? 0);
                  } else {
                    // Fallback do starej logiki jeśli nie ma customSelections
                    selected = displayed(j) === val;
                  }
                  
                  return (
                    <td
                      key={`${key}-${j}`}
                      className={`border border-gray-300 px-2 py-2 text-center transition-all duration-200 ${
                        typeof val === 'number' 
                          ? selected 
                            ? 'bg-blue-200/70 text-gray-900 cursor-pointer' 
                            : 'bg-white text-gray-900 hover:bg-opacity-80 cursor-pointer'
                          : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                      }`}
                      onClick={(event) =>
                        typeof val === 'number' && onCellToggle?.(j, val, r.volume, r.subIndex, event)
                      }
                    >
                      {val !== undefined ? formatNumber(val) : '–'}
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>

      <Modal
        title="Zmiana wektora finalnego"
        message="Czy na pewno chcesz zmienić wektor finalny? Utracisz zmiany."
        isOpen={isConfirmModalOpen}
        onConfirm={onConfirmFinal}
        onCancel={onCancelConfirm}
      />
    </div>
  );
}
