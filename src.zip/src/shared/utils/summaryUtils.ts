/* ------------------------------------------------------------------ */
/*                         Summary Utils                               */
/* ------------------------------------------------------------------ */

import type { DevJ, Sim, PayloadResult } from '../types/summary';

/**
 * Buduje payload na podstawie wybranego klucza i danych
 */
export const buildPayload = (
  key: string | null,
  simResults: Sim,
  devJResults: DevJ[],
  finalDevVector: number[],
  combinedDevJSummary: (number | string)[],
): PayloadResult | null => {
  if (!key) return null;

  /* 1. krzywa CL */
  if (key.startsWith('curve-')) {
    const curve = key.replace('curve-', '');
    const raw = simResults[curve];
    if (!raw) return null;
    const coeffs = Object.values(raw).filter(
      (v): v is number => typeof v === 'number' && Number.isFinite(v),
    );
    return { curve_name: curve, coeffs };
  }

  /* 2. dev_j z volume */
  if (key.startsWith('volume-')) {
    const [, volStr] = key.split('-');
    const vol = Number(volStr);
    const item = devJResults.find(v => v.volume === vol);
    return item ? { volume: item.volume, values: item.values } : null;
  }

  /* 3. combined / raw */
  if (key === 'final-dev-j') {
    const cleaned = combinedDevJSummary
      .map(Number)
      .filter(v => Number.isFinite(v));
    return { final_dev_vector: cleaned };
  }
  if (key === 'final-dev-raw') {
    return { final_dev_vector: finalDevVector };
  }

  return null;
};
