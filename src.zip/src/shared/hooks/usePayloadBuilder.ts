import { useCallback } from 'react';
import type { DevJResult, SimResults } from './useDataOptions';

export interface UsePayloadBuilderParams {
  simResults: SimResults;
  devJResults: DevJResult[];
  combinedDevJSummary: (number | string)[];
  finalDevVector: number[];
  finalDevJ?: DevJResult; // dodane dla odchyleń standardowych
}

export function usePayloadBuilder({
  simResults,
  devJResults,
  combinedDevJSummary,
  finalDevVector,
  finalDevJ,
}: UsePayloadBuilderParams) {
  const buildPayload = useCallback((key: string | null): any | null => {
    if (!key) return null;

    console.log('🔧 buildPayload wywołane z key:', key);

    // Krzywa z symulacji
    if (key.startsWith('curve-')) {
      const curve = key.replace('curve-', '');
      const raw = simResults[curve];
      if (!raw) return null;
      
      const coeffs = Object.values(raw).filter(
        (v): v is number => typeof v === 'number' && Number.isFinite(v),
      );
      console.log('🔧 Krzywa:', curve, 'coeffs:', coeffs);
      return { curve_name: curve, coeffs };
    }

    // Volume z devJResults
    if (key.startsWith('volume-')) {
      const parts = key.replace('volume-', '').split('-');
      const vol = parseInt(parts[0] ?? '0', 10);
      const subIdx = parts[1] ? parseInt(parts[1], 10) : 0;
      
      const found = devJResults.find((v) => v.volume === vol && (v.subIndex ?? 0) === subIdx);
      console.log('🔧 Volume:', vol, 'subIdx:', subIdx, 'found:', found);
      return found ? { volume: found.volume, values: found.values } : null;
    }

    // Combined dev_j (Selected Value) - zawsze używaj combinedDevJSummary!
    if (key === 'final-dev-j') {
      console.log('🔧 Selected Value - combinedDevJSummary:', combinedDevJSummary);
      
      // Selected Value to combinedDevJSummary - wartości z "Tabela współczynników Selected Value"
      const values = combinedDevJSummary
        .map((v) => {
          const n = parseFloat(String(v));
          return Number.isFinite(n) ? n : null;
        })
        .filter((v): v is number => v !== null);
      
      console.log('🔧 Selected Value - wysyłane values:', values);
      return { 
        final_dev_vector: values,
      };
    }

    // Raw final dev vector (Initial Selection)
    if (key === 'final-dev-raw') {
      console.log('🔧 Initial Selection - finalDevVector:', finalDevVector);
      return { final_dev_vector: finalDevVector };
    }

    return null;
  }, [simResults, devJResults, combinedDevJSummary, finalDevVector]);

  return { buildPayload };
}
