import { useEffect } from 'react';
import type { TriangleData } from '@/shared/types/triangle';

interface UseIncurredTriangleProcessingProps {
  isValid: boolean | undefined;
  json: any[][] | null | undefined;
  triangle: TriangleData | null | undefined;
  setTriangle: (data: TriangleData) => void;
  cacheKey: string;
  componentName: string;
}

export function useIncurredTriangleProcessing({
  isValid,
  json,
  triangle,
  setTriangle,
  cacheKey,
  componentName
}: UseIncurredTriangleProcessingProps) {
  
  useEffect(() => {
    if (
      isValid &&
      json &&
      (!triangle || triangle.length === 0)
    ) {
      /* wycinamy nagłówki (wiersz 0 i kolumna 0) + parsujemy liczby */
      const numericData = json
        .slice(1)
        .map((row) =>
          row.slice(1).map((cell) => {
            const num = typeof cell === 'string' ? parseFloat(cell) : cell;
            return isNaN(num) ? null : num;
          })
        );

      setTriangle(numericData);
      localStorage.setItem(cacheKey, JSON.stringify(numericData));
      console.log(`[${componentName}] setTriangle → OK (oczyszczone)`);
    }
  }, [isValid, json, triangle, setTriangle, cacheKey, componentName]);

  return {
    hasValidData: isValid && json,
    processedTriangle: triangle
  };
}
