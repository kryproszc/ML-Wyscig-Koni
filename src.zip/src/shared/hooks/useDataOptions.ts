import { useMemo } from 'react';

export type SelectOption = {
  type: 'curve' | 'volume' | 'devj' | 'devj_raw';
  label: string;
  key: string;
};

export type DevJResult = {
  volume: number;
  values: number[];
  subIndex?: number;
};

export type SimResults = Record<string, Record<string, number>>;

export interface UseDataOptionsParams {
  simResults: SimResults;
  devJResults: DevJResult[];
  combinedDevJSummary: (number | string)[];
  finalDevVector: number[];
}

export function useDataOptions({
  simResults,
  devJResults,
  combinedDevJSummary,
  finalDevVector,
}: UseDataOptionsParams) {
  const allOptions = useMemo<SelectOption[]>(() => [
    // Krzywe z symulacji
    ...Object.keys(simResults).map((curve) => ({
      type: 'curve' as const,
      label: `Krzywa: ${curve}`,
      key: `curve-${curve}`,
    })),
    
    // Volume z devJResults - nazwy zgodne z tabelą UI
    ...devJResults.map((d) => ({
      type: 'volume' as const,
      label: `Volume ${d.subIndex !== undefined ? `${d.volume},${d.subIndex}` : d.volume}`,
      key: `volume-${d.volume}-${d.subIndex ?? 0}`,
    })),

    // Combined dev_j (jeśli istnieje)
    ...(combinedDevJSummary.length > 0
      ? [{
          type: 'devj' as const,
          label: 'Selected Value',
          key: 'final-dev-j',
        }]
      : []),
      
    // Raw final dev vector (jeśli istnieje)
    ...(finalDevVector.length > 0
      ? [{
          type: 'devj_raw' as const,
          label: 'Initial Selection',
          key: 'final-dev-raw',
        }]
      : []),
  ], [simResults, devJResults, combinedDevJSummary, finalDevVector]);

  const keyToLabelMap = useMemo(() => 
    Object.fromEntries(allOptions.map((o) => [o.key, o.label])),
    [allOptions]
  );

  return {
    allOptions,
    keyToLabelMap,
  };
}
