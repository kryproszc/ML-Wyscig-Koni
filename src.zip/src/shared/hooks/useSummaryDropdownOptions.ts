/* ------------------------------------------------------------------ */
/*                       Summary Dropdown Hook                         */
/* ------------------------------------------------------------------ */

import { useMemo } from 'react';
import type { DevJ, Sim, DropdownOption } from '../types/summary';

/**
 * Hook do generowania opcji dropdown dla paid/incurred
 */
export const useSummaryDropdownOptions = (
  simResults: Sim,
  devJResults: DevJ[],
  combinedDevJSummary: (number | string)[],
  finalDevVector: number[],
  prefix: string // 'Paid' lub 'Incurred'
): DropdownOption[] => {
  return useMemo(() => [
    ...Object.keys(simResults).map(c => ({
      key: `curve-${c}`, 
      label: `${prefix} → krzywa ${c}`,
    })),
    ...devJResults.map(d => ({
      key: `volume-${d.volume}-${d.subIndex ?? 0}`,
      label: `${prefix} → volume ${d.volume}${d.subIndex !== undefined ? ` (v${d.subIndex + 1})` : ''}`,
    })),
    ...(combinedDevJSummary.length ? [{ 
      key: 'final-dev-j', 
      label: `${prefix} → Selected Value` 
    }] : []),
    ...(finalDevVector.length ? [{ 
      key: 'final-dev-raw', 
      label: `${prefix} → Initial Value` 
    }] : []),
  ], [simResults, devJResults, combinedDevJSummary, finalDevVector, prefix]);
};
