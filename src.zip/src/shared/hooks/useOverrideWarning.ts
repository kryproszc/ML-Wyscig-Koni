/* ------------------------------------------------------------------ */
/*                      useOverrideWarning Hook                      */
/* ------------------------------------------------------------------ */

import { useMemo } from 'react'
import type { OverrideMap, SourceSwitchMap } from '@/shared/types/developmentEnd'

export function useOverrideWarning(
  manualOverrides: OverrideMap,
  sourceSwitches: SourceSwitchMap,
  devJPreview?: number[]
) {
  const overrideStats = useMemo(() => {
    const totalColumns = devJPreview?.length ?? 0
    const manualCount = Object.keys(manualOverrides).length
    const switchedCount = Object.keys(sourceSwitches).length
    const totalOverridden = new Set([
      ...Object.keys(manualOverrides).map(Number),
      ...Object.keys(sourceSwitches).map(Number)
    ]).size

    const overridePercentage = totalColumns > 0 ? (totalOverridden / totalColumns) * 100 : 0

    const isHighOverride = overridePercentage > 50
    const isFullOverride = overridePercentage === 100

    return {
      totalColumns,
      manualCount,
      switchedCount,
      totalOverridden,
      overridePercentage,
      isHighOverride,
      isFullOverride
    }
  }, [manualOverrides, sourceSwitches, devJPreview])

  const warningMessage = useMemo(() => {
    if (overrideStats.isFullOverride) {
      return {
        level: 'error' as const,
        title: 'Wszystkie wartości zostały nadpisane!',
        message: 'Utraciłeś wszystkie oryginalne dane. Rozważ użycie przycisku "Resetuj wszystko".'
      }
    }
    
    if (overrideStats.isHighOverride) {
      return {
        level: 'warning' as const,
        title: `${overrideStats.overridePercentage.toFixed(0)}% wartości zostało nadpisanych`,
        message: `Nadpisano ${overrideStats.totalOverridden} z ${overrideStats.totalColumns} kolumn.`
      }
    }

    return null
  }, [overrideStats])

  return {
    overrideStats,
    warningMessage
  }
}