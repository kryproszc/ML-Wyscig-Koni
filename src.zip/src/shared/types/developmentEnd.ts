/* ------------------------------------------------------------------ */
/*                     Development End Shared Types                   */
/* ------------------------------------------------------------------ */

export type OverrideMap = Record<number, { 
  curve: string; 
  value: number;
  // Dla zachowania poprzedniego stanu przy undo
  previousState?: {
    wasFromCurve?: string;
    wasFromSourceSwitch?: boolean;
    wasValue?: number;
  };
}>

// Nowy typ dla przełączania źródła współczynników w lewej części
export type SourceSwitchMap = Record<number, { curve: string; value: number }> // indeks -> {krzywa, wartość}

export interface DevSummaryProps {
  leftCount: number
  setLeftCount: (count: number) => void
  selectedCurve: string | null
  setSelectedCurve: (curve: string) => void
  manualOverrides: OverrideMap
  setManualOverrides: (overrides: OverrideMap) => void
  devJPreview: number[] | undefined
  simResults: Record<string, Record<string, number>> | null | undefined
  setCombinedDevJ: (combined: (number | string)[]) => void
  columnLabels: string[]
  // Nowe pola dla przełączania źródła
  sourceSwitches: SourceSwitchMap
  setSourceSwitches: (switches: SourceSwitchMap) => void
  // Opcjonalny callback do zapisywania nagłówków z FinalTable
  onRemainingDevJHeaders?: (headers: string[]) => void
}

export interface DevBasicTableProps {
  devJPreview: number[] | undefined
  columnLabels: string[]
  leftCount: number
  // Nowe pola dla przełączania źródła
  sourceSwitches: SourceSwitchMap
  setSourceSwitches: (switches: SourceSwitchMap) => void
  selectedCurve: string | null
  simResults: Record<string, Record<string, number>> | null | undefined
  // Dodano do obsługi ręcznych nadpisań
  manualOverrides: OverrideMap
  setManualOverrides: (overrides: OverrideMap) => void
}

export interface SimulationTableProps {
  simResults: Record<string, Record<string, number>>
  dpHeaders: string[]
  leftCount: number
  selectedCurve: string | null
  setSelectedCurve: (curve: string) => void
  manualOverrides: OverrideMap
  setManualOverrides: (overrides: OverrideMap) => void
  // Nowe pola dla przełączania źródła
  sourceSwitches: SourceSwitchMap
  setSourceSwitches: (switches: SourceSwitchMap) => void
}

export interface FinalTableProps {
  combinedDevJ: (number | string)[]
  maxLen: number
  leftCount: number
  columnLabels: string[]  
  manualOverrides: OverrideMap
  setManualOverrides: (overrides: OverrideMap) => void
  // Dodane dla informacji o źródle współczynników
  sourceSwitches: SourceSwitchMap
  setSourceSwitches: (switches: SourceSwitchMap) => void
  selectedCurve: string | null
  // Dodane dla dostępu do oryginalnych wartości Initial Selection
  devJPreview: number[] | undefined
  // Opcjonalny callback do zapisywania nagłówków
  onHeadersGenerated?: (headers: string[]) => void
  // Callback wywoływany gdy użytkownik ręcznie edytuje wartość
  onManualEdit?: (index: number) => void
}
