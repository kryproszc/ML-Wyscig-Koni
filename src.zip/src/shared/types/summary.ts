/* ------------------------------------------------------------------ */
/*                            Summary Types                            */
/* ------------------------------------------------------------------ */

export type DevJ = { 
  volume: number; 
  values: number[]; 
  subIndex?: number; 
};

export type Sim = Record<string, Record<string, number>>;

export interface DropdownOption {
  key: string;
  label: string;
}

export interface PayloadResult {
  curve_name?: string;
  coeffs?: number[];
  volume?: number;
  values?: number[];
  final_dev_vector?: number[];
}

export interface WeightValidationError {
  rowIndex: number;
  message: string;
}
