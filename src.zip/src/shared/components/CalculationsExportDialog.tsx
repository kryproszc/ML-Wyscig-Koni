import React from 'react';
import Modal from '@/components/Modal';
import type { ExportItem } from '@/shared/hooks/useCalculationsExport';

export interface CalculationsExportDialogProps {
  isOpen: boolean;
  exportItems: ExportItem[];
  selectedCount: number;
  onClose: () => void;
  onToggleItem: (key: string) => void;
  onToggleAll: () => void;
  onExport: () => void;
}

export const CalculationsExportDialog: React.FC<CalculationsExportDialogProps> = ({
  isOpen,
  exportItems,
  selectedCount,
  onClose,
  onToggleItem,
  onToggleAll,
  onExport,
}) => {
  if (!isOpen) return null;

  const allSelected = exportItems.length > 0 && exportItems.every(item => item.selected);
  const someSelected = selectedCount > 0 && selectedCount < exportItems.length;

  return (
    <div className="fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-gray-700 rounded-lg p-6 max-w-md w-full mx-4 max-h-[80vh] flex flex-col border border-gray-600">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-white">Eksportuj obliczenia</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white text-2xl leading-none"
          >
            ×
          </button>
        </div>

        <div className="mb-4">
          <label className="flex items-center text-white cursor-pointer">
            <input
              type="checkbox"
              checked={allSelected}
              ref={input => {
                if (input) input.indeterminate = someSelected;
              }}
              onChange={onToggleAll}
              className="mr-2 scale-110"
            />
            <span className="font-medium">
              {allSelected ? 'Odznacz wszystko' : 'Zaznacz wszystko'} 
              {selectedCount > 0 && ` (${selectedCount}/${exportItems.length})`}
            </span>
          </label>
        </div>

        <div className="flex-1 overflow-y-auto mb-4 max-h-96">
          <div className="space-y-2">
            {exportItems.map((item) => (
              <label
                key={item.key}
                className="flex items-center text-white cursor-pointer hover:bg-gray-700 p-2 rounded"
              >
                <input
                  type="checkbox"
                  checked={item.selected}
                  onChange={() => onToggleItem(item.key)}
                  className="mr-3 scale-110"
                />
                <span className="text-sm">{item.label}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="flex gap-3 pt-4 border-t border-gray-600">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2 rounded bg-gray-600 hover:bg-gray-700 text-white font-medium transition"
          >
            Anuluj
          </button>
          <button
            onClick={onExport}
            disabled={selectedCount === 0}
            className={`flex-1 px-4 py-2 rounded font-medium transition ${
              selectedCount === 0
                ? 'bg-gray-500 text-gray-300 cursor-not-allowed'
                : 'bg-yellow-600 hover:bg-yellow-700 text-white'
            }`}
          >
            📁 Eksportuj ({selectedCount})
          </button>
        </div>
      </div>
    </div>
  );
};
