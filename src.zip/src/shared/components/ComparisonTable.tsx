import React from 'react';

export type ComparisonTableProps = {
  data: any[];
  labelA?: string;
  labelB?: string;
  rowLabels?: string[]; // <= nowy opcjonalny prop
  areDifferentVectors?: boolean; // <= flaga czy to różne wektory
};

const formatNumber = (val: any, isPercent = false) => {
  if (val === null || val === undefined || val === '' || !isFinite(Number(val))) {
    return '-';
  }
  const num = Number(val);
  if (!isFinite(num)) return '-';
  const formatted = Math.round(num).toLocaleString('pl-PL');
  return isPercent ? `${formatted}\u00A0%` : formatted;
};

export const ComparisonTable: React.FC<ComparisonTableProps> = ({
  data,
  labelA,
  labelB,
  rowLabels,
  areDifferentVectors = true, // domyślnie true = pokaż pełną tabelę
}) => {
  console.log('🏓 ComparisonTable received data:', data);
  console.log('🏓 ComparisonTable first row:', data[0]);
  console.log('🏓 ComparisonTable all columns:', data.length > 0 ? Object.keys(data[0]) : []);
  
  if (!data || data.length === 0) return null;

  const allColumns = Object.keys(data[0]);
  
  // Filtruj kolumny w zależności od tego czy to różne wektory
  let allowedColumns;
  if (areDifferentVectors) {
    // Różne wektory = pokaż wszystkie kolumny (pełna tabela)
    allowedColumns = allColumns;
  } else {
    // Ten sam wektor = pokaż tylko: Wiersz, Ultimate, IBNR/IBNR + RBNP
    allowedColumns = allColumns.filter(col => 
      col === 'Wiersz' || 
      col === 'Ultimate' ||
      col === 'IBNR' ||
      col === 'IBNR + RBNP'
    );
  }
  
  const columns = allowedColumns.length > 0 ? allowedColumns : allColumns; // fallback do wszystkich jeśli nie znajdzie
  
  console.log('🏓 areDifferentVectors:', areDifferentVectors);
  console.log('🏓 Filtered columns:', columns);

  const renamedColumns = columns.map((col) => {
    if (col === 'Projection A') return labelA || col;
    if (col === 'Projection B') return labelB || col;
    return col;
  });

  // Generuj tytuł w zależności od liczby wektorów
  const getTitle = () => {
    if (areDifferentVectors && labelA && labelB) {
      return `Porównaj wyniki dla ${labelA} i ${labelB}`;
    } else if (labelA) {
      return `Wyniki dla ${labelA}`;
    }
    return '📊 Porównanie wyników'; // fallback
  };

  return (
    <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white">
      <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
        <h2 className="font-bold text-gray-800 text-lg tracking-tight">{getTitle()}</h2>
      </div>
      <div className="overflow-x-auto bg-white rounded-lg border border-gray-300">
        <table className="min-w-full text-sm border-collapse">
          <thead>
            <tr>
              {renamedColumns.map((label, i) => (
                <th key={i} className="border border-gray-300 px-2 py-2 bg-gray-200 text-gray-900 font-semibold">
                  {label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row, rowIndex) => {
              const isSumRow = row['Wiersz'] === 'Suma';

              return (
                <tr
                  key={rowIndex}
                  className={isSumRow ? 'bg-gray-100 font-bold text-sm' : 'hover:bg-gray-50'}
                >
                  {columns.map((key, colIndex) => {
                    // Specjalne traktowanie kolumny "Wiersz"
                    if (key === 'Wiersz') {
                      // jeśli to wiersz sumy -> zawsze "SUMA"
                      if (isSumRow) {
                        return (
                          <td key={colIndex} className="border border-gray-300 px-2 py-2 bg-gray-200 text-gray-900 font-semibold text-xs">
                            SUMA
                          </td>
                        );
                      }
                      // w przeciwnym razie, jeśli podano rowLabels, pokaż etykietę po indeksie
                      const labelFromStore =
                        Array.isArray(rowLabels) && rowLabels[rowIndex] ? rowLabels[rowIndex] : row[key];

                      return (
                        <td key={colIndex} className="border border-gray-300 px-2 py-2 bg-gray-200 text-gray-900 font-semibold text-xs">
                          {labelFromStore ?? '-'}
                        </td>
                      );
                    }

                    const rawVal = row[key];
                    const isPercent = key.toLowerCase().includes('%');
                    const formatted = formatNumber(rawVal, isPercent);

                    return (
                      <td key={colIndex} className="border border-gray-300 px-2 py-2 bg-white text-gray-900">
                        {formatted}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
