/* ------------------------------------------------------------------ */
/*                         DevBasicTable                             */
/* ------------------------------------------------------------------ */

import React from 'react'
import type { DevBasicTableProps } from '@/shared/types/developmentEnd'

export function DevBasicTable({ 
  devJPreview, 
  columnLabels, 
  leftCount, 
  sourceSwitches, 
  setSourceSwitches, 
  selectedCurve,
  simResults,
  manualOverrides,
  setManualOverrides
}: DevBasicTableProps) {
  if (!devJPreview) return null

  const handleCellClick = (idx: number) => {
    console.log(`🔵 BASIC TABLE KLIK - idx: ${idx}, selectedCurve: ${selectedCurve}`);
    
    // Tylko dla komórek w lewej części (< leftCount)
    if (idx >= leftCount) return
    
    // Jeśli nie ma wybranej krzywej, nie można przełączać
    if (!selectedCurve || !simResults) return

    // Przełącz stan sourceSwitches dla tej komórki
    const newSwitches = { ...sourceSwitches }
    const currentSwitch = sourceSwitches[idx]
    
    console.log(`🔍 Bieżący stan dla idx ${idx}:`, currentSwitch);
    
    if (currentSwitch && currentSwitch.curve !== 'Initial Selection') {
      // Jeśli była ustawiona inna krzywa (nie Initial Selection), ustaw na 'Initial Selection'
      const initialValue = devJPreview?.[idx]
      if (initialValue !== undefined) {
        newSwitches[idx] = { curve: 'Initial Selection', value: initialValue }
        console.log(`🔄 DevBasicTable - Ustawiam Initial Selection dla idx ${idx}:`, {
          initialValue,
          previousCurve: currentSwitch.curve
        })
        
        // Usuń ręczne nadpisania gdy przełączamy na Initial Selection
        const newOverrides = { ...manualOverrides }
        if (newOverrides[idx]) {
          delete newOverrides[idx]
          setManualOverrides(newOverrides)
        }
      }
    } else if (currentSwitch && currentSwitch.curve === 'Initial Selection') {
      // Jeśli już jest Initial Selection, przełącz na wybraną krzywą
      const dpKey = `dp: ${idx + 1}`
      const value = simResults[selectedCurve]?.[dpKey]
      if (Number.isFinite(value)) {
        newSwitches[idx] = { curve: selectedCurve, value: value as number }
        console.log(`🔄 DevBasicTable - Ustawiam krzywą ${selectedCurve} dla idx ${idx}:`, {
          value,
          previousCurve: 'Initial Selection'
        })
      }
    } else {
      // Brak wpisu - ustaw krzywą
      const dpKey = `dp: ${idx + 1}`
      const value = simResults[selectedCurve]?.[dpKey]
      if (Number.isFinite(value)) {
        newSwitches[idx] = { curve: selectedCurve, value: value as number }
        console.log(`🔄 DevBasicTable - Ustawiam krzywą ${selectedCurve} dla idx ${idx} (pierwszy raz):`, {
          value
        })
      }
    }
    setSourceSwitches(newSwitches)
  }
  
  return (
    <section className="block w-full rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white">
      <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
        <h2 className="font-bold text-gray-800 text-lg tracking-tight">Tabela współczynników Initial Selection</h2>
      </div>
      <div className="overflow-auto p-4">
        <div className="relative w-full max-w-full overflow-x-auto">
        <table className="min-w-max bg-white rounded-xl shadow-md text-sm" style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
          <thead>
            <tr>
              <th className="border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold rounded-tl-xl">-</th>
              {devJPreview.map((_, idx) => {
                const label = columnLabels.length > idx + 2 
                  ? columnLabels[idx + 2] 
                  : `j=${idx}`
                const isLast = idx === devJPreview.length - 1
                return (
                  <th key={idx} className={`border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold ${isLast ? 'rounded-tr-xl' : ''}`}>
                    {label}
                  </th>
                )
              })}
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border border-gray-300 px-3 py-2 bg-gray-50 text-gray-800 font-medium rounded-bl-xl">Initial Selection</td>
              {devJPreview.map((val, idx) => {
                const isInLeftPart = idx < leftCount
                const switchedSource = sourceSwitches[idx]
                const canSwitch = isInLeftPart && selectedCurve
                const isManuallyOverridden = manualOverrides[idx]?.curve === 'manual'
                
                // Kolory tła - uwzględnij ręczne nadpisania
                let bgClass = ""
                let isClickable = canSwitch && !isManuallyOverridden
                
                if (isInLeftPart) {
                  if (isManuallyOverridden) {
                    bgClass = "bg-gray-300/70 text-gray-600" // Szary - komórka została ręcznie nadpisana w FinalTable
                  } else {
                    bgClass = "bg-blue-200/70 text-gray-900" // Jednolity kolor podświetlenia
                  }
                } else {
                  bgClass = "bg-white text-gray-800" // Brak podświetlenia poza lewą częścią
                }

                const isLastCell = idx === devJPreview.length - 1
                return (
                  <td
                    key={idx}
                    onClick={() => isClickable ? handleCellClick(idx) : undefined}
                    className={`border border-gray-300 px-3 py-2 text-center transition-colors ${isLastCell ? 'rounded-br-xl' : ''} ${bgClass} ${
                      isClickable ? "cursor-pointer hover:bg-opacity-90 hover:shadow-sm" : isManuallyOverridden ? "cursor-not-allowed opacity-60" : ""
                    }`}
                    title={
                      isManuallyOverridden
                        ? "Wartość została ręcznie nadpisana w tabeli Selected Value - nie można przełączać"
                        : canSwitch
                        ? switchedSource
                          ? switchedSource.curve === 'Initial Selection'
                            ? `Źródło: Initial Selection - kliknij aby użyć krzywej "${selectedCurve}"`
                            : `Źródło: krzywa "${switchedSource.curve}" - kliknij aby przywrócić Initial Selection`
                          : `Źródło: krzywa "${selectedCurve}" - kliknij aby przywrócić Initial Selection`
                        : isInLeftPart && !selectedCurve
                        ? "Wybierz krzywę, aby móc przełączać źródło"
                        : ""
                    }
                  >
                    {val !== undefined ? val.toFixed(6) : "-"}
                  </td>
                )
              })}
            </tr>
          </tbody>
        </table>
        </div>
      </div>
    </section>
  )
}
