/* ------------------------------------------------------------------ */
/*                         DevSummarySidebar                         */
/* ------------------------------------------------------------------ */

import React, { useState } from 'react'
import { ConfirmDialog } from '@/shared/components/ConfirmDialog'

interface DevSummarySidebarProps {
  leftCount: number
  setLeftCount: (count: number) => void
  // Info o nadpisaniach
  sourceSwitchesCount?: number
}

export function DevSummarySidebar({ 
  leftCount, 
  setLeftCount,
  sourceSwitchesCount = 0
}: DevSummarySidebarProps) {
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean
    action: (() => void) | null
    title: string
    message: string
    variant: 'danger' | 'warning'
  }>({
    isOpen: false,
    action: null,
    title: '',
    message: '',
    variant: 'warning'
  })

  const handleLeftCountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value)
    if (!Number.isNaN(val) && val >= 0) setLeftCount(val)
  }

  const showConfirm = (action: () => void, title: string, message: string, variant: 'danger' | 'warning' = 'warning') => {
    setConfirmDialog({ isOpen: true, action, title, message, variant })
  }

  const closeConfirm = () => {
    setConfirmDialog({ isOpen: false, action: null, title: '', message: '', variant: 'warning' })
  }

  const handleConfirm = () => {
    if (confirmDialog.action) {
      confirmDialog.action()
    }
    closeConfirm()
  }

  return (
    <aside className="w-64 shrink-0 bg-gray-900 border-r border-gray-800 p-6 flex flex-col space-y-4">
      <div className="bg-gray-800 rounded-lg p-4">
        <label className="text-white text-sm font-medium mb-2 block">
          Ilość pozostawionych
        </label>
        <input
          type="number"
          id="left-count-input"
          min={0}
          value={leftCount}
          onChange={handleLeftCountChange}
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>


      
      <ConfirmDialog
        isOpen={confirmDialog.isOpen}
        onClose={closeConfirm}
        onConfirm={handleConfirm}
        title={confirmDialog.title}
        message={confirmDialog.message}
        variant={confirmDialog.variant}
        confirmText="Resetuj"
        cancelText="Anuluj"
      />
    </aside>
  )
}
