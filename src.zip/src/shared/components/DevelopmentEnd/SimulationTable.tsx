/* ------------------------------------------------------------------ */
/*                         SimulationTable                           */
/* ------------------------------------------------------------------ */

import React from 'react'
import type { SimulationTableProps, OverrideMap } from '@/shared/types/developmentEnd'
import { formatDpHeader } from '@/shared/utils/developmentEndUtils'

export function SimulationTable({
  simResults,
  dpHeaders,
  leftCount,
  selectedCurve,
  setSelectedCurve,
  manualOverrides,
  setManualOverrides,
  sourceSwitches,
  setSourceSwitches
}: SimulationTableProps) {
  
  const handleCurveChange = (curve: string) => {
    console.log(`📻 GLOBALNA ZMIANA KRZYWEJ na: "${curve}"`);
    
    // 1) ustaw nową krzywą
    setSelectedCurve(curve)

    // 2) usuń WSZYSTKIE stare overrides (także ręczne!) - zostaw tylko lewą część
    const oldCount = Object.keys(manualOverrides).length;
    const cleaned: OverrideMap = {}
    Object.entries(manualOverrides).forEach(([k, cell]) => {
      const idxNum = Number(k)
      // Zachowaj TYLKO lewą część (sourceSwitches), usuń wszystko inne
      if (idxNum < leftCount) {
        cleaned[idxNum] = cell
      }
    })
    console.log(`🧹 Czyszczę overrides (także ręczne): ${oldCount} -> ${Object.keys(cleaned).length}`);
    
    // 3) NOWE: Automatycznie załaduj całą nową krzywą do Selected Value
    console.log(`🔄 Auto-ładowanie krzywej "${curve}" do całej tabeli Selected Value`);
    const newOverrides: OverrideMap = { ...cleaned } // zachowaj manual + lewą część
    const curveData = simResults[curve]
    
    if (curveData) {
      dpHeaders.forEach((dpKey, idx) => {
        const val = curveData[dpKey]
        // Dodaj tylko jeśli nie ma już ręcznego nadpisania (manual) lub wpisu w lewej części
        if (Number.isFinite(val) && !newOverrides[idx]) {
          newOverrides[idx] = { curve: curve, value: val as number }
        }
      })
      console.log(`📝 Dodano ${Object.keys(newOverrides).length - Object.keys(cleaned).length} nowych nadpisań z krzywej "${curve}"`);
    } else {
      console.log(`⚠️ Brak danych dla krzywej "${curve}"`);
    }
    
    setManualOverrides(newOverrides)
  }

  // Nowa funkcja - załaduj całą krzywą do Selected Value
  const handleLoadWholeCurve = (curve: string) => {
    console.log(`🔄 ŁADOWANIE CAŁEJ KRZYWEJ "${curve}" do Selected Value`)
    console.log(`📊 Przed czyszczeniem - manualOverrides:`, Object.keys(manualOverrides).length, `sourceSwitches:`, Object.keys(sourceSwitches).length);
    
    // Wyczyść wszystkie nadpisania i sourceSwitches
    setManualOverrides({})
    setSourceSwitches({})
    
    // Ustaw tę krzywą jako selectedCurve
    console.log(`🎯 Ustawiam selectedCurve na: "${curve}"`);
    setSelectedCurve(curve)
    
    // Opcjonalnie: utwórz manualOverrides dla wszystkich dostępnych wartości tej krzywej
    const newOverrides: OverrideMap = {}
    const curveData = simResults[curve]
    if (curveData) {
      dpHeaders.forEach((dpKey, idx) => {
        const val = curveData[dpKey]
        if (Number.isFinite(val)) {
          newOverrides[idx] = { curve: curve, value: val as number }
        }
      })
      console.log(`📝 Tworzę ${Object.keys(newOverrides).length} nadpisań dla krzywej "${curve}"`);
      setManualOverrides(newOverrides)
    } else {
      console.log(`⚠️ Brak danych dla krzywej "${curve}"`);
    }
  }

  const handleCellClick = (idx: number, curve: string, val: number | undefined) => {
    if (!Number.isFinite(val)) return
    
    console.log(`🎯 KLIKNIĘCIE W KRZYWĄ - idx: ${idx}, krzywa: ${curve}, wartość: ${val}`);
    
    // Jeśli to zablokowana komórka (idx < leftCount)
    if (idx < leftCount) {
      // Przełącz sourceSwitches dla tej pozycji z dowolnej krzywej
      const newSwitches = { ...sourceSwitches }
      const currentSwitch = sourceSwitches[idx]
      
      console.log(`📍 Lewa część - bieżący switch:`, currentSwitch);
      
      if (currentSwitch && currentSwitch.curve === curve) {
        delete newSwitches[idx] // Usuń przełączenie - wróć do dev podstawowego
        console.log(`❌ Usuwam switch - wracam do dev podstawowego`);
      } else {
        newSwitches[idx] = { curve, value: val! } // Przełącz na tę krzywą
        console.log(`✅ Przełączam na krzywą "${curve}" z wartością ${val}`);
      }
      setSourceSwitches(newSwitches)
    } else {
      // Standardowa logika dla prawej części (manual overrides)
      console.log(`📍 Prawa część - bieżący override:`, manualOverrides[idx]);
      
      const copy: OverrideMap = { ...manualOverrides }
      if (manualOverrides[idx]?.curve === curve) {
        delete copy[idx]
        console.log(`❌ Usuwam manual override`);
      } else {
        copy[idx] = { curve, value: val! }
        console.log(`✅ Dodaję manual override: krzywa="${curve}", wartość=${val}`);
      }
      setManualOverrides(copy)
    }
  }

  return (
    <section className="block w-full rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white">
      <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
        <h2 className="font-bold text-gray-800 text-lg tracking-tight">Tabela współczynników z dopasowanych krzywych</h2>
      </div>
      <div className="overflow-auto p-4">
        <div className="relative w-full max-w-full overflow-x-auto">
        <table className="min-w-max table-fixed bg-white shadow-md text-sm" style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
          <thead>
            <tr>
              <th className="border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold sticky left-0 z-20 rounded-tl-xl">
                Źródło
              </th>
              <th className="border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold sticky left-[62px] z-20">
                Krzywa
              </th>
              {dpHeaders.map((dpKey, idx) => {
                const isLast = idx === dpHeaders.length - 1
                return (
                  <th key={dpKey} className={`border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold w-[80px] text-center ${isLast ? 'rounded-tr-xl' : ''}`}>
                    {formatDpHeader(dpKey)}
                  </th>
                )
              })}
            </tr>
          </thead>
          <tbody>
            {Object.entries(simResults).map(([curve, values], rowIdx) => {
              const isLastRow = rowIdx === Object.entries(simResults).length - 1
              return (
              <tr key={curve} className="hover:bg-gray-100/50">
                {/* Wybór */}
                <td className={`border border-gray-300 px-3 py-2 text-center sticky left-0 bg-white z-10 ${isLastRow ? 'rounded-bl-xl' : ''}`}>
                  <input
                    type="radio"
                    id={`curve-${curve.replace(/\s+/g, '-').toLowerCase()}`}
                    name="curve-select"
                    checked={selectedCurve === curve}
                    onChange={() => handleCurveChange(curve)}
                    className="form-radio text-blue-600 bg-white border-gray-400"
                  />
                </td>

                {/* Nazwa krzywej - klikalna do załadowania całej krzywej */}
                <td 
                  className="border border-gray-300 px-3 py-2 bg-gray-50 text-gray-800 font-semibold sticky left-[62px] z-10 cursor-pointer hover:bg-blue-100 transition-colors"
                  onClick={() => handleLoadWholeCurve(curve)}
                  title={`Kliknij aby załadować wszystkie współczynniki krzywej "${curve}" do Selected Value`}
                >
                  {curve}
                  <span className="ml-2 text-xs text-blue-600 opacity-60">⬇️</span>
                </td>

                {/* wartości dp */}
                {dpHeaders.map((dpKey, idx) => {
                  const val = (values as Record<string, number | undefined>)[dpKey]
                  const blocked = idx < leftCount
                  const isManual = manualOverrides[idx]?.curve === curve
                  const selectedRow = selectedCurve === curve
                  const switchedSource = sourceSwitches[idx]
                  const isSourceSwitched = switchedSource && switchedSource.curve === curve

                  // wyliczamy klasę tła
                  let bg = ""
                  let textColor = "text-gray-800"
                  let cursorClass = "cursor-pointer"
                  
                  if (blocked) {
                    if (isSourceSwitched) {
                      bg = "bg-purple-200/70" // Przełączone na tę krzywą
                      textColor = "text-purple-900"
                    } else {
                      bg = "bg-gray-100/50" // Dostępne do przełączenia
                      textColor = "text-gray-700"
                    }
                  } else {
                    if (isManual) {
                      bg = "bg-blue-200/70"
                      textColor = "text-blue-900"
                    } else if (selectedRow && !manualOverrides[idx]) {
                      bg = "bg-blue-100/60"
                      textColor = "text-blue-800"
                    } else {
                      bg = "bg-white"
                      textColor = "text-gray-800"
                    }
                  }

                  const isLastCell = idx === dpHeaders.length - 1
                  return (
                    <td
                      key={dpKey}
                      onClick={() => handleCellClick(idx, curve, val)}
                      className={`border border-gray-300 px-3 py-2 w-[80px] text-center transition-colors ${isLastRow && isLastCell ? 'rounded-br-xl' : ''} ${cursorClass} ${bg} ${textColor} hover:shadow-sm`}
                      title={
                        blocked
                          ? isSourceSwitched
                            ? "Przełączone na tę krzywą - kliknij aby wrócić do dev_j"
                            : `Kliknij aby przełączyć na krzywą "${curve}"`
                          : isManual
                          ? "Ręcznie wybrana wartość – kliknij ponownie, by usunąć"
                          : "Kliknij, aby ustawić ręcznie"
                      }
                    >
                      {Number.isFinite(val) ? Number(val).toFixed(6) : "-"}
                    </td>
                  )
                })}
              </tr>
            )})}
          </tbody>
        </table>
        </div>
        
        <div className="mt-4 space-y-2 text-sm px-4 pb-2">
          {!selectedCurve && (
            <p className="text-yellow-600 text-center font-medium">
              Wybierz krzywą, aby uzupełnić współczynniki po pozycji {leftCount}.
            </p>
          )}
        </div>
      </div>
    </section>
  )
}
