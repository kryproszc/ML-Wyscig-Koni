'use client';

import React from 'react';

interface TrainDevideTableProps {
  data: (number | null)[][];
  rowHeaders: (string | number)[];
  colHeaders: (string | number)[];
  selected?: number[][]; // Tablica 0/1 do zaznaczania komórek
  onClick?: (rowIdx: number, colIdx: number) => void;
  onToggleRow?: (rowIndex: number) => void;
  showRowToggle?: boolean;
  decimalPlaces?: number;
  // Min/Max highlighting
  minCells?: [number, number][];
  maxCells?: [number, number][];
  minMaxCells?: [number, number][];
}

// Funkcja pomocnicza do liczenia ostatniej niepustej kolumny
const getMaxNonEmptyCols = (matrix: (number | null)[][]) => {
  return Math.max(
    ...matrix.map((row) => {
      for (let i = row.length - 1; i >= 0; i--) {
        if (row[i] !== null && row[i] !== 0) {
          return i + 1;
        }
      }
      return 0;
    })
  );
};

export const TrainDevideTable = ({
  data,
  rowHeaders,
  colHeaders,
  selected,
  onClick,
  onToggleRow,
  showRowToggle = false,
  decimalPlaces = 6,
  minCells = [],
  maxCells = [],
  minMaxCells = [],
}: TrainDevideTableProps): React.ReactElement => {
  if (data.length === 0) {
    return (
      <div className="text-red-400 text-center py-4">Brak danych</div>
    );
  }

  // 🔥 Automatyczne przycięcie kolumn
  const maxCols = getMaxNonEmptyCols(data);
  const trimmedData = data.map((row) => row.slice(0, maxCols));
  const trimmedColHeaders = colHeaders.slice(0, maxCols);
  const trimmedSelected = selected?.map((row) => row.slice(0, maxCols));

  // Funkcja sprawdzająca czy cały wiersz jest zaznaczony
  const isRowSelected = (rowIndex: number): boolean => {
    if (!trimmedSelected || rowIndex >= trimmedSelected.length) return false;
    
    const row = trimmedData[rowIndex];
    const selectedRow = trimmedSelected[rowIndex];
    
    if (!row || !selectedRow) return false;
    
    let hasAnyData = false;
    let allSelected = true;
    
    for (let j = 0; j < row.length; j++) {
      const cell = row[j];
      if (cell !== null && cell !== undefined) {
        hasAnyData = true;
        if (selectedRow[j] !== 1) {
          allSelected = false;
          break;
        }
      }
    }
    
    return hasAnyData && allSelected;
  };

  // Funkcja obsługująca toggle całego wiersza
  const handleRowToggle = (rowIndex: number) => {
    if (!onToggleRow) return;
    onToggleRow(rowIndex);
  };

  // Funkcja pomocnicza do sprawdzania czy komórka jest min/max
  const isMinMaxCell = (rowIndex: number, colIndex: number): { isMin: boolean; isMax: boolean } => {
    const cellKey = `${rowIndex + 1},${colIndex + 1}`; // +1 bo Min/Max używa pozycji z nagłówkami
    const isMin = minCells.some(([r, c]) => `${r},${c}` === cellKey);
    const isMax = maxCells.some(([r, c]) => `${r},${c}` === cellKey);
    return { isMin, isMax };
  };

  return (
    <div className="overflow-auto rounded-xl border border-gray-300 shadow-md bg-white">
      <table className="min-w-full table-auto text-sm" style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
        <thead>
          <tr>
            {showRowToggle && (
              <th className="bg-gray-200 px-3 py-2 text-center font-semibold border border-gray-300 rounded-tl-xl">
                <span className="text-gray-800 text-xs">Cały wiersz</span>
              </th>
            )}
            <th className={`bg-gray-200 px-4 py-2 text-left font-semibold text-gray-800 border border-gray-300 ${!showRowToggle ? 'rounded-tl-xl' : ''}`}>AY</th>
            {trimmedColHeaders.map((header, colIdx) => {
              const isLast = colIdx === trimmedColHeaders.length - 1;
              return (
                <th
                  key={colIdx}
                  className={`bg-gray-200 px-4 py-2 text-center font-semibold text-gray-800 border border-gray-300 ${isLast ? 'rounded-tr-xl' : ''}`}
                >
                  {header}
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody>
          {trimmedData.map((row, i) => {
            const isLastRow = i === trimmedData.length - 1;
            return (
              <tr key={i}>
                {showRowToggle && (
                  <td className={`bg-gray-100 px-3 py-2 text-center border border-gray-300 ${isLastRow ? 'rounded-bl-xl' : ''}`}>
                    <input
                      type="checkbox"
                      checked={isRowSelected(i)}
                      onChange={() => handleRowToggle(i)}
                      className="w-4 h-4 text-blue-600 bg-white border-gray-400 rounded focus:ring-blue-500 focus:ring-2 cursor-pointer"
                    />
                  </td>
                )}
                <td className={`bg-gray-200 px-4 py-2 text-gray-700 font-bold border border-gray-300 ${isLastRow && !showRowToggle ? 'rounded-bl-xl' : ''}`}>
                  {rowHeaders[i]}
                </td>
                {row.map((cell, j) => {
                  const isNone = cell === null || cell === undefined;
                  const isSelected = trimmedSelected?.[i]?.[j] === 1;
                  const isLastCell = j === row.length - 1;
                  
                  // Sprawdź czy to komórka min/max
                  const { isMin, isMax } = isMinMaxCell(i, j);

                  let cellClasses = [
                    'px-4 py-2 text-center border border-gray-300 whitespace-nowrap transition-colors duration-200',
                  ];

                  if (isNone) {
                    cellClasses.push('bg-gray-200 text-gray-500'); // Brak danych
                  } else if (isMin && isMax) {
                    // Jeśli komórka jest jednocześnie min i max (np. jedna wartość w kolumnie)
                    cellClasses.push('bg-yellow-100 text-gray-900 font-semibold shadow-md border-2 border-yellow-500');
                  } else if (isMin) {
                    cellClasses.push('bg-green-50 text-gray-900 font-semibold shadow-md border-2 border-green-500');
                  } else if (isMax) {
                    cellClasses.push('bg-red-50 text-gray-900 font-semibold shadow-md border-2 border-red-500');
                  } else if (isSelected) {
                    cellClasses.push('bg-white text-gray-900 hover:bg-gray-50'); // Wybrane
                  } else {
                    cellClasses.push('bg-gray-300 text-gray-500'); // Wyłączone
                  }

                  if (isLastRow && isLastCell) {
                    cellClasses.push('rounded-br-xl');
                  }

                  return (
                    <td
                      key={j}
                      onClick={() => !isNone && onClick?.(i, j)}
                      className={cellClasses.join(' ')}
                      style={{ cursor: isNone ? 'default' : 'pointer' }}
                      title={isMin && isMax ? 'Min & Max' : isMin ? 'Min' : isMax ? 'Max' : undefined}
                    >
                      {typeof cell === 'number'
                        ? cell.toLocaleString('pl-PL', { 
                            minimumFractionDigits: decimalPlaces,
                            maximumFractionDigits: decimalPlaces 
                          })
                        : '-'}
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
