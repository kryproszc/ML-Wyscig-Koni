'use client';

import { useUltimateStore } from '@/stores/useUltimateStore';
import { useTableStore } from '@/stores/tableStore';

const tableBox = "w-full rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white hover:shadow-3xl transition-all duration-300";
const tableStyle = "w-full text-sm";
const cellClass = "px-4 py-2.5 border border-gray-300 text-center whitespace-nowrap transition-colors duration-150 hover:bg-gray-50";
const headerCellClass = "px-4 py-3 border border-gray-300 text-center font-bold whitespace-nowrap tracking-wide";

// Helper function to format stat keys: 0.1 -> Q:10%, 0.2 -> Q:20%, etc.
const formatStatKey = (key: string): string => {
  const num = parseFloat(key);
  if (!isNaN(num) && num >= 0 && num <= 1) {
    return `Q:${(num * 100).toFixed(0)}%`;
  }
  return key;
};

/* ============== LEWY BLOK ============== */
function SimResults() {
  const { stats, quantileResult, percentileMatch, percentileInputSim } = useUltimateStore();
  if (!quantileResult) return null;

  return (
    <div className={tableBox}>
      <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
        <h4 className="font-bold text-gray-800 text-lg tracking-tight">Statystyki i kwantyle: Ultimate</h4>
      </div>

      <div className="flex flex-col lg:flex-row gap-0 p-4">
        <table className={tableStyle} style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
          <thead>
            <tr>
              <th className={`${headerCellClass} rounded-tl-xl`} style={{ backgroundColor: '#e5e7eb', color: '#111827' }}>Statystyka</th>
              <th className={`${headerCellClass} rounded-tr-xl`} style={{ backgroundColor: '#e5e7eb', color: '#111827' }}>Wartość</th>
            </tr>
          </thead>
          <tbody>
            {stats && Object.entries(stats).map(([key, val], idx, arr) => {
              const isLast = idx === arr.length - 1 && Object.entries(quantileResult).length === 0;
              return (
              <tr key={`sim-stat-${key}`}>
                <td className={`${cellClass} ${isLast ? 'rounded-bl-xl' : ''}`} style={{ backgroundColor: '#ffffff', color: '#111827' }}>{formatStatKey(key)}</td>
                <td className={`${cellClass} ${isLast ? 'rounded-br-xl' : ''}`} style={{ backgroundColor: '#ffffff', color: '#111827' }}>{val?.value?.toLocaleString('pl-PL') ?? '—'}</td>
              </tr>
            )})}
            {Object.entries(quantileResult).map(([key, val], idx, arr) => {
              const isLast = idx === arr.length - 1;
              return (
              <tr key={`sim-q-${key}`}>
                <td className={`${cellClass} ${isLast ? 'rounded-bl-xl' : ''}`} style={{ backgroundColor: '#ffffff', color: '#111827' }}>{formatStatKey(key)}</td>
                <td className={`${cellClass} ${isLast ? 'rounded-br-xl' : ''}`} style={{ backgroundColor: '#ffffff', color: '#111827' }}>{val?.value?.toLocaleString('pl-PL') ?? '—'}</td>
              </tr>
            )})}
          </tbody>
        </table>

        {percentileMatch?.sim != null && (
          <table className={`${tableStyle} lg:w-1/3 lg:ml-6`} style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
            <caption className="font-semibold text-left mb-2 px-4 py-2 border border-gray-300 rounded-lg" style={{ backgroundColor: '#e5e7eb', color: '#111827' }}>
              Percentyl dla: {percentileInputSim}
            </caption>
            <thead>
              <tr>
                <th className={`${headerCellClass} rounded-tl-xl`} style={{ backgroundColor: '#e5e7eb', color: '#111827' }}>Statystyka</th>
                <th className={`${headerCellClass} rounded-tr-xl`} style={{ backgroundColor: '#e5e7eb', color: '#111827' }}>Percentyl</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className={`${cellClass} rounded-bl-xl`} style={{ backgroundColor: '#ffffff', color: '#111827' }}>Ultimate</td>
                <td className={`${cellClass} rounded-br-xl`} style={{ backgroundColor: '#ffffff', color: '#111827' }}>{(percentileMatch.sim * 100).toFixed(2).replace('.', ',')}%</td>
              </tr>
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

/* ============== PRAWY BLOK ============== */
function SimDiff() {
  const { stats, quantileResult, percentileMatch, percentileInputDiff } = useUltimateStore();
  const activeType = useTableStore((s) => s.activeStochTriangle ?? 'paid');
  const ibnrLabel = activeType === 'paid' ? 'IBNR' : 'IBNR + RBNP';

  if (!quantileResult) return null;

  return (
    <div className={tableBox}>
      <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
        <h4 className="font-bold text-gray-800 text-lg tracking-tight">Statystyki i kwantyle: {ibnrLabel}</h4>
      </div>

      <div className="flex flex-col lg:flex-row gap-0 p-4">
        <table className={tableStyle} style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
          <thead>
            <tr>
              <th className={`${headerCellClass} rounded-tl-xl`} style={{ backgroundColor: '#e5e7eb', color: '#111827' }}>Metryka</th>
              <th className={`${headerCellClass} rounded-tr-xl`} style={{ backgroundColor: '#e5e7eb', color: '#111827' }}>Wartość</th>
            </tr>
          </thead>
          <tbody>
            {stats && Object.entries(stats).map(([key, val], idx, arr) => {
              const isLast = idx === arr.length - 1 && Object.entries(quantileResult).length === 0;
              return (
              <tr key={`diff-stat-${key}`}>
                <td className={`${cellClass} ${isLast ? 'rounded-bl-xl' : ''}`} style={{ backgroundColor: '#ffffff', color: '#111827' }}>{formatStatKey(key)}</td>
                <td className={`${cellClass} ${isLast ? 'rounded-br-xl' : ''}`} style={{ backgroundColor: '#ffffff', color: '#111827' }}>{val?.value_minus_latest?.toLocaleString('pl-PL') ?? '—'}</td>
              </tr>
            )})}
            {Object.entries(quantileResult).map(([key, val], idx, arr) => {
              const isLast = idx === arr.length - 1;
              return (
              <tr key={`diff-q-${key}`}>
                <td className={`${cellClass} ${isLast ? 'rounded-bl-xl' : ''}`} style={{ backgroundColor: '#ffffff', color: '#111827' }}>{formatStatKey(key)}</td>
                <td className={`${cellClass} ${isLast ? 'rounded-br-xl' : ''}`} style={{ backgroundColor: '#ffffff', color: '#111827' }}>{val?.value_minus_latest?.toLocaleString('pl-PL') ?? '—'}</td>
              </tr>
            )})}
          </tbody>
        </table>

        {percentileMatch?.diff != null && (
          <table className={`${tableStyle} lg:w-1/3 lg:ml-6`} style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
            <caption className="font-semibold text-left mb-2 px-4 py-2 border border-gray-300 rounded-lg" style={{ backgroundColor: '#e5e7eb', color: '#111827' }}>
              Percentyl dla: {percentileInputDiff} — {ibnrLabel}
            </caption>
            <thead>
              <tr>
                <th className={`${headerCellClass} rounded-tl-xl`} style={{ backgroundColor: '#e5e7eb', color: '#111827' }}>Rezerwa</th>
                <th className={`${headerCellClass} rounded-tr-xl`} style={{ backgroundColor: '#e5e7eb', color: '#111827' }}>Percentyl</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className={`${cellClass} rounded-bl-xl`} style={{ backgroundColor: '#ffffff', color: '#111827' }}>{ibnrLabel}</td>
                <td className={`${cellClass} rounded-br-xl`} style={{ backgroundColor: '#ffffff', color: '#111827' }}>{(percentileMatch.diff * 100).toFixed(2).replace('.', ',')}%</td>
              </tr>
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export const StatsTables = {
  SimResults,
  SimDiff,
};
