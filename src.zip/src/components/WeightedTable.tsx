'use client';

import { useState, useMemo, useEffect, useRef } from 'react';
import type { ChangeEvent } from 'react';
import clsx from 'clsx';
import * as XLSX from 'xlsx';
import Modal from '@/components/Modal';

// ────────────────────────────────────────────
// Types
// ────────────────────────────────────────────

type Row = {
  paid: number;
  incurred: number;
};

type Weight = {
  wPaid: number;
  wInc: number;
};

type EnrichedRow = Row & Weight & { sum: number };

/**
 * Struktura wierszy eksportowanych do Excela (używa etykiet kolumnowych).
 */
interface ExcelRow {
  Paid: number | string;
  'Waga paid': number | string;
  Incurred: number | string;
  'Waga incurred': number | string;
  Sum: number | string;
}

interface Props {
  rows: Row[];
  onChange?: (rows: EnrichedRow[], grandTotal: number) => void;
  /** Opcjonalna nazwa pliku XLSX, domyślnie `weighted_table.xlsx` */
  fileName?: string;
  /** Współczynniki CL do eksportu (np. [3.245785, 3.401558]) */
  clCoefficients?: number[];
  /** Opcjonalny nagłówek sekcji CL, np. 'Paid' lub 'Incurred' */
  clLabel?: string;
}

// ────────────────────────────────────────────
// Component
// ────────────────────────────────────────────

function WeightedTable({
  rows,
  onChange,
  fileName = 'weighted_table.xlsx',
  clCoefficients,
  clLabel,
}: Props) {
  const [weights, setWeights] = useState<Weight[]>(() =>
    rows.map(() => ({ wPaid: 1, wInc: 0 }))
  );

  // Modal do błędów zakresu 0–1
  const [showModal, setShowModal] = useState(false);

  // Używamy useRef do śledzenia poprzednich wartości
  const prevEnrichedRowsRef = useRef<EnrichedRow[]>([]);
  const prevGrandTotalRef = useRef<number>(0);

  // ▸ Synchronizuj długość tablic przy zmianie `rows` - tylko gdy rzeczywiście się zmieniła
  useEffect(() => {
    if (rows.length !== weights.length) {
      setWeights((prev) => rows.map((_, i) => prev[i] ?? { wPaid: 1, wInc: 0 }));
    }
  }, [rows.length, weights.length]);

  // ▸ Zmiana wag z auto-uzupełnianiem komplementu (1 - wpisana_waga)
  const handleWeightChange = (
    rowIdx: number,
    field: keyof Weight,
    e: ChangeEvent<HTMLInputElement>
  ) => {
    const num = parseFloat(e.target.value.replace(',', '.')); // dopuszczamy przecinek

    // walidacja 0–1 i czy liczba
    if (!Number.isFinite(num) || num < 0 || num > 1) {
      setShowModal(true);
      return;
    }

    const comp = +(1 - num).toFixed(4); // komplement z lekkim zaokrągleniem

    setWeights((prev) => {
      const next = [...prev];
      next[rowIdx] =
        field === 'wPaid'
          ? { wPaid: num, wInc: comp }
          : { wPaid: comp, wInc: num };
      return next;
    });
  };

  // ▸ Walidacja wag - sprawdź czy suma wag w każdym wierszu = 1
  const validationErrors = useMemo(() => {
    const errors: Array<{ rowIndex: number; message: string }> = [];
    weights.forEach((weight, index) => {
      const sum = weight.wPaid + weight.wInc;
      if (Math.abs(sum - 1) > 0.001) {
        errors.push({
          rowIndex: index,
          message: 'Suma wag musi być równa 1',
        });
      }
    });
    return errors;
  }, [weights]);

  // ▸ Enrichment + total
  const { enrichedRows, grandTotal } = useMemo(() => {
    const merged: EnrichedRow[] = rows.map((row, i) => {
      const { wPaid, wInc } = weights[i] ?? { wPaid: 1, wInc: 0 };
      const sum = row.paid * wPaid + row.incurred * wInc;
      return { ...row, wPaid, wInc, sum };
    });
    const total = merged.reduce((acc, r) => acc + r.sum, 0);
    return { enrichedRows: merged, grandTotal: total };
  }, [rows, weights]);

  // ▸ Callback do rodzica - tylko gdy wartości rzeczywiście się zmieniają
  useEffect(() => {
    if (!onChange) return;

    const rowsChanged =
      enrichedRows.length !== prevEnrichedRowsRef.current.length ||
      enrichedRows.some((row, index) => {
        const prevRow = prevEnrichedRowsRef.current[index];
        return (
          !prevRow ||
          row.paid !== prevRow.paid ||
          row.incurred !== prevRow.incurred ||
          row.wPaid !== prevRow.wPaid ||
          row.wInc !== prevRow.wInc ||
          row.sum !== prevRow.sum
        );
      });

    const totalChanged = Math.abs(grandTotal - prevGrandTotalRef.current) > 0.001;

    if (rowsChanged || totalChanged) {
      onChange(enrichedRows, grandTotal);
      prevEnrichedRowsRef.current = [...enrichedRows];
      prevGrandTotalRef.current = grandTotal;
    }
  }, [enrichedRows, grandTotal, onChange]);

  // ──────────────────────────────────────
  // Excel export ↓↓↓
  // ──────────────────────────────────────
  const handleExport = () => {
    // 1. Dane → ExcelRow[]
    const data: ExcelRow[] = enrichedRows.map(({ paid, wPaid, incurred, wInc, sum }) => ({
      Paid: paid,
      'Waga paid': wPaid,
      Incurred: incurred,
      'Waga incurred': wInc,
      Sum: sum,
    }));

    // 2. Dodaj wiersz z sumą ważoną
    data.push({ Paid: '', 'Waga paid': '', Incurred: '', 'Waga incurred': 'TOTAL', Sum: grandTotal });

    // 3. Dodaj sekcję "5. Współczynniki CL"
    if (clCoefficients && clCoefficients.length > 0) {
      // Separator
      data.push({ Paid: '', 'Waga paid': '', Incurred: '', 'Waga incurred': '', Sum: '' });
      data.push({
        Paid: `=== 5. Współczynniki CL${clLabel ? ` (${clLabel})` : ''} ===`,
        'Waga paid': '',
        Incurred: '',
        'Waga incurred': '',
        Sum: '',
      });
      data.push({ Paid: 'Indeks', 'Waga paid': '', Incurred: 'Współczynnik', 'Waga incurred': '', Sum: '' });
      clCoefficients.forEach((coef, idx) => {
        data.push({ Paid: `Indeks ${idx + 1}`, 'Waga paid': '', Incurred: coef, 'Waga incurred': '', Sum: '' });
      });
    }

    // 4. SheetJS
    const ws = XLSX.utils.json_to_sheet(data, {
      header: ['Paid', 'Waga paid', 'Incurred', 'Waga incurred', 'Sum'],
    });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'WeightedTable');
    XLSX.writeFile(wb, fileName);
  };

  // ──────────────────────────────────────
  // UI
  // ──────────────────────────────────────
  const TABLE_HEADERS = ['Paid', 'Waga paid', 'Incurred', 'Waga incurred', 'Sum'];

  return (
    <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white">
      {/* Modal z komunikatem o błędnych wagach */}
      <Modal
        isOpen={showModal}
        title="Błąd wag"
        message="Wagi muszą być w przedziale 0–1 i sumować się do 1."
        onCancel={() => setShowModal(false)}
        onlyOk
      />

      <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
        <h2 className="font-bold text-gray-800 text-lg tracking-tight">Podsumowanie Paid + Incurred</h2>
      </div>

      {/* ▸ Komunikaty błędów walidacji */}
      {validationErrors.length > 0 && (
        <div className="m-4 p-3 bg-red-50 border border-red-300 rounded-lg">
          <div className="text-red-700 text-sm font-semibold mb-2">
            ⚠️ Błędy walidacji wag:
          </div>
          {validationErrors.map((error, index) => (
            <div key={index} className="text-red-600 text-sm">
              • Wiersz {error.rowIndex + 1}: {error.message}
            </div>
          ))}
        </div>
      )}

      {/* ▸ Przycisk eksportu */}
      <div className="flex justify-start p-4">
        <button
          onClick={handleExport}
          className="w-64 py-4 px-5 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-700 hover:to-amber-600 text-white rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
        >
          ⬇️ Eksportuj Excel
        </button>
      </div>

      <div className="overflow-x-auto bg-white rounded-lg m-4 border border-gray-300">
      <table className="min-w-full border-collapse text-sm">
        <thead>
          <tr>
            {TABLE_HEADERS.map((h) => (
              <th
                key={h}
                scope="col"
                className="px-4 py-2 text-center border border-gray-300 bg-gray-200 text-gray-900 font-semibold"
              >
                {h}
              </th>
            ))}
          </tr>
        </thead>

        <tbody>
          {enrichedRows.map((row, i) => {
            const hasError = validationErrors.some((err) => err.rowIndex === i);
            return (
              <tr
                key={i}
                className={clsx(
                  'hover:bg-gray-50 transition-colors',
                  hasError && 'bg-red-50 border-red-300'
                )}
              >
                {/* Paid */}
                <td className="px-4 py-2 text-right tabular-nums border border-gray-300 bg-white text-gray-900">
                  {row.paid.toLocaleString()}
                </td>

                {/* Waga paid */}
                <td className="px-4 py-2 border border-gray-300 bg-white">
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    max={1}
                    value={row.wPaid}
                    onChange={(e) => handleWeightChange(i, 'wPaid', e)}
                    className={clsx(
                      'w-24 bg-white rounded px-2 py-1 text-right text-gray-900 border focus:outline-none focus:ring-2',
                      hasError ? 'border-red-500 focus:ring-red-500' : 'border-gray-400 focus:ring-indigo-500'
                    )}
                  />
                </td>

                {/* Incurred */}
                <td className="px-4 py-2 text-right tabular-nums border border-gray-300 bg-white text-gray-900">
                  {row.incurred.toLocaleString()}
                </td>

                {/* Waga incurred */}
                <td className="px-4 py-2 border border-gray-300 bg-white">
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    max={1}
                    value={row.wInc}
                    onChange={(e) => handleWeightChange(i, 'wInc', e)}
                    className={clsx(
                      'w-24 bg-white rounded px-2 py-1 text-right text-gray-900 border focus:outline-none focus:ring-2',
                      hasError ? 'border-red-500 focus:ring-red-500' : 'border-gray-400 focus:ring-indigo-500'
                    )}
                  />
                </td>

                {/* Sum */}
                <td className="px-4 py-2 text-right tabular-nums font-semibold border border-gray-300 bg-white text-gray-900">
                  {row.sum.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                </td>
              </tr>
            );
          })}
        </tbody>

        <tfoot>
          <tr className="font-semibold">
            <td colSpan={4} className="px-4 py-2 text-right border border-gray-300 bg-gray-200 text-gray-900">
              Suma ważona
            </td>
            <td className="px-4 py-2 text-right tabular-nums border border-gray-300 bg-gray-200 text-gray-900">
              {grandTotal.toLocaleString(undefined, { maximumFractionDigits: 2 })}
            </td>
          </tr>
        </tfoot>
      </table>
      </div>
    </div>
  );
}

export default WeightedTable;
