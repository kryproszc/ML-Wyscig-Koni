
'use client';
import { useState } from 'react';
import { Button } from '@/components/ui/button';

interface Props {
  onLoad: (file: File) => void;
  loadedFileName?: string;
  accept?: string;
  disabled?: boolean;
}

export function FileUploader({ onLoad, loadedFileName, accept = '.xlsx,.xls', disabled }: Props) {
  const [file, setFile] = useState<File | null>(null);

  return (
    <div className="flex items-center gap-4">
      <input
        type="file"
        accept={accept}
        className="border p-2 rounded-lg"
        onChange={(e) => setFile(e.target.files?.[0] ?? null)}
      />
      <Button
        type="button"
        onClick={() => file && onLoad(file)}
        disabled={disabled || !file}
        className="bg-blue-500 text-white"
      >
        Załaduj plik
      </Button>
      {loadedFileName && (
        <span className="text-sm text-green-400 ml-2">
          Wczytano: <strong>{loadedFileName}</strong>
        </span>
      )}
    </div>
  );
}
