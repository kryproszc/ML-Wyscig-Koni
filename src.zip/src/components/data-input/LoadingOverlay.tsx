'use client';
import { Loader2 } from 'lucide-react';

export function LoadingOverlay({ visible, progress }: { visible: boolean; progress: number }) {
  if (!visible) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="bg-[#1e1e2f] rounded-lg p-8 flex flex-col items-center w-80">
        <Loader2 className="animate-spin h-10 w-10 text-white mb-6" />
        <div className="w-full bg-gray-700 rounded-full h-4 mb-4 overflow-hidden">
          <div className="bg-gray-300 h-full transition-all" style={{ width: `${progress}%` }} />
        </div>
        <span className="text-white text-sm">Ładowanie... {progress}%</span>
      </div>
    </div>
  );
}
