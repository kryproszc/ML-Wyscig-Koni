'use client';
import {
  AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogFooter,
  AlertDialogCancel, AlertDialogTitle, AlertDialogDescription,
} from '@/components/ui/alert-dialog';
import { VisuallyHidden } from '@/components/ui/visually-hidden';

export type AlertVariant = 'error' | 'warning' | 'success' | 'info';

interface Props { open: boolean; onOpenChange: (o: boolean) => void; variant: AlertVariant; message: string; }

const icons = {
  error:   '❌', warning: '⚠️', success: '✅', info: 'ℹ️',
} as const;

export function DataAlert({ open, onOpenChange, variant, message }: Props) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader className="flex flex-col items-center">
          <VisuallyHidden><AlertDialogTitle>Komunikat</AlertDialogTitle></VisuallyHidden>
          <div className="text-4xl mb-4">{icons[variant]}</div>
          <AlertDialogDescription className="text-center">{message}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter><AlertDialogCancel>OK</AlertDialogCancel></AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
