'use client';

import { useState } from 'react';
import * as XLSX from 'xlsx';
import { useTableStore } from '@/stores/tableStore';

export function useFileUpload() {
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  
  const { setWorkbook, setUploadedFileName } = useTableStore();

  const handleFileLoad = (file: File) => {
    if (!file) {
      alert("Najpierw wybierz plik.");
      return;
    }

    console.log("📁 Wybrany plik:", file);

    const reader = new FileReader();
    let lastProgressUpdate = 0;

    reader.onloadstart = () => {
      console.log("📥 Rozpoczynam odczyt pliku");
      setIsLoading(true);
      setProgress(0);
    };

    reader.onprogress = (event) => {
      if (event.lengthComputable) {
        const now = Date.now();
        // Aktualizuj progress maksymalnie co 100ms aby uniknąć migania
        if (now - lastProgressUpdate > 100) {
          const percent = Math.round((event.loaded / event.total) * 100);
          console.log(`📊 Postęp odczytu: ${percent}%`);
          setProgress(percent);
          lastProgressUpdate = now;
        }
      }
    };

    reader.onload = (evt) => {
      const binaryStr = evt.target?.result;
      console.log("📚 Zawartość reader.onload typeof:", typeof binaryStr);

      if (typeof binaryStr === "string") {
        try {
          const wb = XLSX.read(binaryStr, { type: "binary" });
          console.log("✅ Plik Excel wczytany:", wb);

          const sheetName = wb.SheetNames[0];
          console.log("📄 Wybrany arkusz:", sheetName);

          // Reset tylko store'a dla zakładki stochastycznej (nie wszystkich store'ów)
          useTableStore.getState().resetData();

          setWorkbook(wb);
          useTableStore.getState().setSelectedSheetName(sheetName);
          setUploadedFileName(file.name);
        } catch (error) {
          console.error("❌ Błąd podczas parsowania pliku:", error);
          alert("Błąd podczas wczytywania pliku: " + (error as Error).message);
        }
      } else {
        console.error("❌ Niepoprawny typ danych z FileReadera.");
      }

      setIsLoading(false);
      setProgress(0);
    };

    reader.onerror = (e) => {
      console.error("❌ Błąd odczytu pliku:", e);
      alert("Błąd podczas wczytywania pliku.");
      setIsLoading(false);
    };

    reader.readAsBinaryString(file);
  };

  return {
    isLoading,
    progress,
    handleFileLoad,
  };
}
