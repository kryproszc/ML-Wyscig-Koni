import { create } from 'zustand';
import * as XLSX from 'xlsx';

interface CellFormatting {
  isStrikethrough?: boolean;
  fontColor?: string;
  backgroundColor?: string;
}

interface TestCell {
  value: string | number | null;
  formatting?: CellFormatting;
}

interface TestTriangleStoreIncurred {
  // Workbook i arkusze
  workbook: XLSX.WorkBook | null;
  selectedSheetName: string | null;
  uploadedFileName: string | null;
  
  // Zakres danych
  startRow: number;
  endRow: number;
  startCol: number;
  endCol: number;
  
  // Dane z formatowaniem
  testData: TestCell[][] | null;
  
  // Akcje
  setWorkbook: (wb: XLSX.WorkBook | null) => void;
  setSelectedSheetName: (name: string | null) => void;
  setUploadedFileName: (name: string | null) => void;
  setRange: (startRow: number, endRow: number, startCol: number, endCol: number) => void;
  setTestData: (data: TestCell[][] | null) => void;
  reset: () => void;
}

export const useTestTriangleStoreIncurred = create<TestTriangleStoreIncurred>((set) => ({
  workbook: null,
  selectedSheetName: null,
  uploadedFileName: null,
  startRow: 7,
  endRow: 17,
  startCol: 12,
  endCol: 22,
  testData: null,
  
  setWorkbook: (wb) => set({ workbook: wb }),
  setSelectedSheetName: (name) => set({ selectedSheetName: name }),
  setUploadedFileName: (name) => set({ uploadedFileName: name }),
  setRange: (startRow, endRow, startCol, endCol) => 
    set({ startRow, endRow, startCol, endCol }),
  setTestData: (data) => set({ testData: data }),
  
  reset: () => set({
    workbook: null,
    selectedSheetName: null,
    uploadedFileName: null,
    startRow: 7,
    endRow: 17,
    startCol: 12,
    endCol: 22,
    testData: null,
  }),
}));
