import { create } from 'zustand';
import type { RowData } from '@/types/table';
import { useTableStore } from './tableStore';

type BootParamStore = {
  selectedSheetJSON?: RowData[];
  selectedSheetName?: string;
  selectedCells?: number[][];
  volume?: number;
  trainDevide?: number[][]; // Dodane - przechowuje przetworzone dane trójkąta

  // Min/Max highlighting
  minMaxHighlighting: boolean;
  minMaxCells: [number, number][];
  minCells: [number, number][];
  maxCells: [number, number][];

  setSelectedCells: (cells: number[][]) => void;
  setTrainDevide: (data: number[][]) => void; // Dodane
  resetSelection: () => void;
  hydrateFromTableStore: () => void;
  reset: () => void;
  setVolume: (v: number) => void;
  
  // Min/Max functions
  setMinMaxHighlighting: (enabled: boolean) => void;
  calculateMinMaxCells: () => void;
};

export const useBootParamStore = create<BootParamStore>((set, get) => ({
  selectedSheetJSON: undefined,
  selectedSheetName: undefined,
  selectedCells: undefined,
  volume: undefined,
  trainDevide: undefined,

  // Min/Max state
  minMaxHighlighting: false,
  minMaxCells: [],
  minCells: [],
  maxCells: [],

  setSelectedCells: (cells) => {
    set({ selectedCells: cells });
    // Auto-recalculate min/max if highlighting is enabled
    if (get().minMaxHighlighting) {
      get().calculateMinMaxCells();
    }
  },
  
  setTrainDevide: (data) => set({ trainDevide: data }),

  setVolume: (v: number) => {
    set({ volume: v });
    const matrix = get().trainDevide;
    if (!matrix || matrix.length === 0 || !matrix[0]) return;

    const numRows = matrix.length;
    const numCols = matrix[0].length;
    const weights: number[][] = Array.from({ length: numRows }, () =>
      new Array(numCols).fill(0)
    );

    // Dla każdej kolumny zaznacz v ostatnich niezerowych wartości od dołu
    for (let col = 0; col < numCols; col++) {
      let filled = 0;
      for (let row = numRows - 1; row >= 0 && filled < v; row--) {
        const val = matrix[row]?.[col];
        if (typeof val === 'number' && val !== 0 && val !== null) {
          weights[row]![col] = 1;
          filled++;
        }
      }
    }
    set({ selectedCells: weights });
    
    // Auto-recalculate min/max if highlighting is enabled
    if (get().minMaxHighlighting) {
      get().calculateMinMaxCells();
    }
  },

  resetSelection: () => {
    const matrix = get().trainDevide;
    if (!matrix) return;
    const selected = matrix.map((row) => row.map(() => 1));
    set({ selectedCells: selected });
    
    // Auto-recalculate min/max if highlighting is enabled
    if (get().minMaxHighlighting) {
      get().calculateMinMaxCells();
    }
  },

  hydrateFromTableStore: () => {
    const {
      selectedSheetJSON,
      selectedSheetName,
    } = useTableStore.getState();

    if (!selectedSheetJSON) return;

    console.log('[BootParamStore] Hydrating from TableStore');

    set({
      selectedSheetJSON,
      selectedSheetName,
      // NIE kopiujemy selectedCells - Boot ma własne zaznaczenia
    });
  },

  reset: () => set({
    selectedSheetJSON: undefined,
    selectedSheetName: undefined,
    selectedCells: undefined,
    volume: undefined,
    trainDevide: undefined,
    minMaxHighlighting: false,
    minMaxCells: [],
    minCells: [],
    maxCells: [],
  }),

  // Min/Max highlighting functions
  setMinMaxHighlighting: (enabled) => {
    console.log('setMinMaxHighlighting (Boot):', enabled);
    set({ minMaxHighlighting: enabled });
    if (enabled) get().calculateMinMaxCells();
    else set({ minMaxCells: [], minCells: [], maxCells: [] });
  },

  calculateMinMaxCells: () => {
    const trainData = get().trainDevide;
    const weights = get().selectedCells;
    if (!trainData || !weights || trainData.length === 0) return;

    console.log('🔢 calculateMinMaxCells (Boot) started', { 
      trainDataRows: trainData.length, 
      trainDataCols: trainData[0]?.length,
      weightsRows: weights.length, 
      weightsCols: weights[0]?.length 
    });

    const minMaxCells: [number, number][] = [];
    const minCells: [number, number][] = [];
    const maxCells: [number, number][] = [];
    
    // Dla każdej kolumny znajdź min/max spośród zaznaczonych komórek
    const numCols = trainData[0]?.length || 0;
    
    for (let col = 0; col < numCols; col++) {
      const selectedValues: { value: number; row: number }[] = [];
      
      for (let row = 0; row < trainData.length; row++) {
        const cellValue = trainData[row]?.[col];
        const isSelected = weights[row]?.[col] === 1;
        
        if (isSelected && cellValue != null && typeof cellValue === 'number') {
          selectedValues.push({ 
            value: cellValue, 
            row 
          });
        }
      }
      
      console.log(`📊 Boot Kolumna ${col}:`, {
        selectedCount: selectedValues.length,
        values: selectedValues.map(v => `[${v.row}] = ${v.value}`)
      });
      
      if (selectedValues.length > 1) {
        const minItem = selectedValues.reduce((min, curr) => 
          curr.value < min.value ? curr : min
        );
        const maxItem = selectedValues.reduce((max, curr) => 
          curr.value > max.value ? curr : max
        );
        
        // +1 bo w TrainDevideTable mamy nagłówki!
        minCells.push([minItem.row + 1, col + 1]);
        maxCells.push([maxItem.row + 1, col + 1]);
        minMaxCells.push([minItem.row + 1, col + 1]);
        if (minItem.row !== maxItem.row) {
          minMaxCells.push([maxItem.row + 1, col + 1]);
        }
        
        console.log(`✅ Boot Kolumna ${col} - Min: [${minItem.row}]=${minItem.value}, Max: [${maxItem.row}]=${maxItem.value}`);
      } else {
        console.log(`⚠️ Boot Kolumna ${col} - za mało wybranych wartości (${selectedValues.length})`);
      }
    }
    
    console.log('🎯 calculateMinMaxCells (Boot) RESULT:', { 
      minCells: minCells.length, 
      maxCells: maxCells.length,
      minCellsData: minCells,
      maxCellsData: maxCells
    });
    set({ minMaxCells, minCells, maxCells });
  },
}));
