import { create } from 'zustand';
import * as XLSX from 'xlsx';
import { validateDataValues, ValidationPresets } from '@/utils/dataValidation';
import type { RowData } from '@/types/table';
import { parseRange, toExcelRange } from '@/utils/parseTableRange';

/* -------------------------------------------------------------------- */
/* Typ stanu – skopiowany z głównego, możesz usunąć pola których nie    */
/* potrzebujesz w zakładce „Det”, żeby store był lżejszy                */
/* -------------------------------------------------------------------- */
type DetailTableStore = {
  table?: File;
  isHydrated: boolean;
  workbook?: XLSX.WorkBook;
  selectedSheet?: XLSX.WorkSheet;
  selectedSheetJSON?: RowData[];
  selectedCells?: number[][];
  selectedSheetName?: string;
  isValid?: boolean;
  validationErrorReason?: string;

  // 🆕 ID generacji danych dla wymuszenia odświeżenia komponentów
  dataGenerationId: number;
  incrementDataGeneration: () => void;

  // 🆕 Indywidualne ustawienia typu danych dla zakładki "Deterministic"
  triangleType: 'paid' | 'incurred';
  setTriangleType: (type: 'paid' | 'incurred') => void;
  dataType: 'cumulative' | 'incremental';
  setDataType: (type: 'cumulative' | 'incremental') => void;

  // 🆕 Ustawienie czy dane zawierają podpisy kolumn i wierszy
  hasHeaders: boolean;
  setHasHeaders: (hasHeaders: boolean) => void;

  // 🆕 Ostatnie zatwierdzone ustawienia dla sprawdzania zmian
  lastApprovedSettings?: {
    sheetName: string | null;
    rowStart: number;
    rowEnd: number;
    colStart: number;
    colEnd: number;
    hasHeaders: boolean;
    dataType: 'cumulative' | 'incremental';
  };
  setLastApprovedSettings: (settings: {
    sheetName: string | null;
    rowStart: number;
    rowEnd: number;
    colStart: number;
    colEnd: number;
    hasHeaders: boolean;
    dataType: 'cumulative' | 'incremental';
  }) => void;

  previousSheetJSON?: RowData[];
  setPreviousSheetJSON: (data: RowData[]) => void;

  sheetRange?: string;
  startRow: number;
  endRow: number;
  startCol: number;
  endCol: number;

  uploadedFileName?: string;

  processedData?: RowData[];
  setProcessedData: (data: RowData[]) => void;

  /* …jeśli tych pól nie używasz w Det – usuń… */
  processedTriangle?: RowData[];
  setProcessedTriangle: (data: RowData[]) => void;

  clData?: RowData[];
  setClData: (data: RowData[]) => void;

  clWeights?: RowData[];
  setClWeights: (weights: RowData[]) => void;

  /* setterów do zakresu */
  setStartRow: (n: number) => void;
  setEndRow: (n: number) => void;
  setStartCol: (n: number) => void;
  setEndCol: (n: number) => void;
  setRangeAndUpdate: (p: {
    startRow: number;
    endRow: number;
    startCol: number;
    endCol: number;
  }) => void;
  getDefaultRange: () =>
    | { startRow: number; startCol: number; endRow: number; endCol: number }
    | undefined;

  /* API ogólne */
  setIsHydrated: (b: boolean) => void;
  setWorkbook: (wb?: XLSX.WorkBook) => void;
  setSelectedSheetName: (name: string | undefined) => void;
  updateSheetJSON: () => void;
  resetData: () => void;

  getSheetNames: () => string[] | undefined;
  setSelectedCells: (cells: number[][]) => void;

  setUploadedFileName: (name: string) => void;
};

/* -------------------------------------------------------------------- */
/* Walidacja specyficzna dla danych w zakładce Det                      */
/* Jeśli Det ma inny format – dostosuj                                  */
/* -------------------------------------------------------------------- */
function customValidate(jsonData: any[][], hasHeaders: boolean = true) {
  // Walidacja z uwzględnieniem struktury trójkąta i ustawienia nagłówków
  const validationOptions = {
    ...ValidationPresets.paid(),
    validateTriangleStructure: true, // ✅ Włączamy walidację struktury trójkąta
    hasHeaders: hasHeaders, // ✅ Przekazujemy informację o nagłówkach
    enableLogging: true, // 🆕 Włączamy logi żeby zobaczyć proces walidacji
  };
  
  const result = validateDataValues(jsonData, validationOptions);
  
  if (!result.isValid) {
    return { isValid: false, reason: result.reason || 'Błąd walidacji danych.' };
  }

  return { isValid: true };
}

/* -------------------------------------------------------------------- */
/* GŁÓWNY HOOK                                                          */
/* -------------------------------------------------------------------- */
export const useDetailTableStore = create<DetailTableStore>((set, get) => ({
  /* --- state --- */
  table: undefined,
  isHydrated: false,

  startRow: 1,
  endRow: 1,
  startCol: 1,
  endCol: 1,

  uploadedFileName: undefined,

  // 🆕 ID generacji danych dla wymuszenia odświeżenia
  dataGenerationId: 0,
  incrementDataGeneration: () => set((state) => ({ dataGenerationId: state.dataGenerationId + 1 })),

  // 🆕 Ustawienia typu danych - domyślne dla zakładki deterministycznej (paid)
  triangleType: 'paid',
  setTriangleType: (type) => set({ triangleType: type }),
  dataType: 'cumulative',
  setDataType: (type) => set({ dataType: type }),

  // 🆕 Ustawienie czy dane zawierają podpisy - domyślnie TRUE
  hasHeaders: true,
  setHasHeaders: (hasHeaders) => {
    console.log('🔧 [DetailTableStore] setHasHeaders:', hasHeaders);
    
    // ✅ TYLKO ustaw wartość hasHeaders - NIE RUSZAJ ZAKRESU!
    set({ hasHeaders });
  },

  // 🆕 Ostatnie zatwierdzone ustawienia - początkowo undefined
  lastApprovedSettings: undefined,
  setLastApprovedSettings: (settings) => set({ lastApprovedSettings: settings }),

  processedData: undefined,
  setProcessedData: (data) => set({ processedData: data }),

  previousSheetJSON: undefined,
  setPreviousSheetJSON: (data) => set({ previousSheetJSON: data }),

  processedTriangle: undefined,
  setProcessedTriangle: (data) => set({ processedTriangle: data }),

  clData: undefined,
  setClData: (data) => set({ clData: data }),

  clWeights: undefined,
  setClWeights: (w) => set({ clWeights: w }),

  /* --- zakres --- */
  setStartRow: (n) => {
    console.log('🔧 [DetailTableStore] setStartRow:', n);
    set({ startRow: n });
  },
  setEndRow: (n) => {
    console.log('🔧 [DetailTableStore] setEndRow:', n);
    set({ endRow: n });
  },
  setStartCol: (n) => {
    console.log('🔧 [DetailTableStore] setStartCol:', n);
    set({ startCol: n });
  },
  setEndCol: (n) => {
    console.log('🔧 [DetailTableStore] setEndCol:', n);
    set({ endCol: n });
  },

  setRangeAndUpdate: (r) => {
    set({
      startRow: r.startRow,
      endRow: r.endRow,
      startCol: r.startCol,
      endCol: r.endCol,
    });
    get().updateSheetJSON();
  },

  getDefaultRange: () => {
    const sheet = get().selectedSheet;
    if (!sheet) return;
    
    let minRow = Infinity, maxRow = -Infinity;
    let minCol = Infinity, maxCol = -Infinity;
    let hasData = false;
    
    // Iteruj przez WSZYSTKIE komórki w arkuszu
    Object.keys(sheet).forEach(cellAddress => {
      if (cellAddress[0] === '!') return; // Pomiń metadane (!ref, !margins etc)
      
      const cell = sheet[cellAddress];
      // Sprawdź czy komórka ma wartość (nie pusta)
      if (cell && cell.v !== null && cell.v !== undefined && cell.v !== '') {
        const match = cellAddress.match(/^([A-Z]+)(\d+)$/);
        if (match && match[1] && match[2]) {
          const col = colLetterToNumber(match[1]);
          const row = parseInt(match[2], 10);
          
          minRow = Math.min(minRow, row);
          maxRow = Math.max(maxRow, row);
          minCol = Math.min(minCol, col);
          maxCol = Math.max(maxCol, col);
          hasData = true;
        }
      }
    });
    
    if (!hasData) return;
    
    return {
      startRow: minRow,
      endRow: maxRow,
      startCol: minCol,
      endCol: maxCol
    };
  },

  /* --- inicjalizacja / reset --- */
  setIsHydrated: (b) => set({ isHydrated: b }),

  setWorkbook: (wb) => {
    const firstSheetName = wb?.SheetNames[0];
    const sheet = firstSheetName ? wb?.Sheets[firstSheetName] : undefined;
    set({
      workbook: wb,
      selectedSheetName: firstSheetName,
      sheetRange: sheet ? sheet['!ref'] : undefined,
    });
  },

  setSelectedSheetName: (name) => {
    console.log('🔧 [DetailTableStore] setSelectedSheetName called with:', name, 'current range before resetData:', {
      startRow: get().startRow,
      endRow: get().endRow,
      startCol: get().startCol,
      endCol: get().endCol
    });
    get().resetData(); // resetuj tylko dane tego store'a
    console.log('🔧 [DetailTableStore] after resetData, range is:', {
      startRow: get().startRow,
      endRow: get().endRow,
      startCol: get().startCol,
      endCol: get().endCol
    });

    if (!name) {
      set({
        selectedSheetName: undefined,
        selectedSheet: undefined,
        selectedSheetJSON: undefined,
        isValid: undefined,
        validationErrorReason: undefined,
      });
      return;
    }

    const sheet = get().workbook?.Sheets[name];
    if (!sheet || !sheet['!ref']) {
      set({
        selectedSheetName: undefined,
        selectedSheet: undefined,
        selectedSheetJSON: undefined,
        isValid: undefined,
        validationErrorReason: undefined,
      });
      return;
    }

    set({
      selectedSheetName: name,
      selectedSheet: sheet,
      sheetRange: sheet['!ref'],
    });
  },

  /* --- główna konwersja + walidacja --- */
  updateSheetJSON: () => {
    const name = get().selectedSheetName;
    if (!name) return;

    const sheet = get().workbook?.Sheets[name];
    if (!sheet) return;

    const { startRow, endRow, startCol, endCol } = get();
    
    // Walidacja zakresu - sprawdź czy wartości są logiczne
    if (startRow > endRow) {
      set({
        isValid: false,
        validationErrorReason: "Wiersz początkowy nie może być większy od wiersza końcowego.",
        selectedSheetJSON: undefined,
        selectedCells: undefined,
      });
      return;
    }
    
    if (startCol > endCol) {
      set({
        isValid: false,
        validationErrorReason: "Kolumna początkowa nie może być większa od kolumny końcowej.",
        selectedSheetJSON: undefined,
        selectedCells: undefined,
      });
      return;
    }

    const range = toExcelRange({
      startRow,
      endRow,
      startCol,
      endCol,
    });

    const tempSheet = { ...sheet, ['!ref']: range };
    const jsonData = XLSX.utils.sheet_to_json<RowData>(tempSheet, {
      header: 1,
      blankrows: true,
      defval: '',
    });

    // Sprawdź czy arkusz ma jakiekolwiek dane
    if (!jsonData || jsonData.length === 0) {
      set({
        isValid: false,
        validationErrorReason: "Wybrany zakres nie zawiera żadnych danych. Sprawdź czy zakres jest poprawny.",
        selectedSheetJSON: undefined,
        selectedCells: undefined,
      });
      return;
    }

    const validation = customValidate(jsonData, get().hasHeaders);

    if (!validation.isValid) {
      set({
        isValid: false,
        validationErrorReason: validation.reason,
        selectedSheetJSON: undefined,
        selectedCells: undefined,
      });
      return;
    }

    const selectedCells = jsonData.map((row) =>
      row.map((cell) => {
        const n = typeof cell === 'number' ? cell : Number(cell);
        return isNaN(n) ? 0 : 1;
      }),
    );

    set({
      previousSheetJSON: get().selectedSheetJSON,
      selectedSheetJSON: jsonData,
      selectedCells,
      isValid: true,
      validationErrorReason: undefined,
    });
    
    console.log('[useDetailTableStore] 📊 updateSheetJSON SUCCESS:', {
      jsonDataLength: jsonData.length,
      firstRowLength: jsonData[0]?.length,
      isValid: true,
      firstRowSample: jsonData[0]?.slice(0, 3)
    });
  },

  resetData: () =>
    set({
      selectedSheetJSON: undefined,
      selectedCells: undefined,
      isValid: undefined,
      validationErrorReason: undefined,
      processedData: undefined,
      processedTriangle: undefined,
      clData: undefined,
      clWeights: undefined,
    }),

  /* --- helpers --- */
  getSheetNames: () => get().workbook?.SheetNames,
  setSelectedCells: (cells) => set({ selectedCells: cells }),
  setUploadedFileName: (name) => set({ uploadedFileName: name }),
}));
