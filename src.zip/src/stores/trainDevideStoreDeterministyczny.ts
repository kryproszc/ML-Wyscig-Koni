import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import * as XLSX from 'xlsx';

/* ──────────────────────────── TYPY ──────────────────────────── */

export type SourceType = 'base' | 'curve' | 'custom';

export type DevJResult = {
  volume: number;
  subIndex?: number;
  values: number[];
  sdValues?: number[];
};

export interface CustomCell {
  curve: string;
  value: number;
  sourceVolume?: number; // volume z którego pochodzi wartość
  sourceSubIndex?: number; // subIndex z którego pochodzi wartość
}

export type ComparisonEntry = {
  data: any[];
  labelA: string;
  labelB: string;
  areDifferentVectors?: boolean;
};

/* ─────────────────── INTERFEJS STANU (pełny) ─────────────────── */

export type TrainDevideStoreDet = {
  /* ————— Loader PaidTriangleDet ————— */
  workbookDet?: XLSX.WorkBook;
  setWorkbookDet: (wb: XLSX.WorkBook) => void;

  uploadedFileNameDet?: string;
  setUploadedFileNameDet: (n: string) => void;

  selectedSheetNameDet?: string;
  setSelectedSheetNameDet: (n: string) => void;

  /* zakres */
  startRowDet: number;
  endRowDet: number;
  startColDet: number;
  endColDet: number;
  setRangeAndUpdateDet: (r: {
    startRow: number;
    endRow: number;
    startCol: number;
    endCol: number;
  }) => void;
  getDefaultRangeDet: () =>
    | { startRow: number; endRow: number; startCol: number; endCol: number }
    | undefined;

  /* JSON + walidacja */
  selectedSheetDet?: (string | number)[][];
  previousSheetDet?: (string | number)[][];
  isValidDet: boolean;
  validationErrorReasonDet?: string;

  /* ————— Pozostałe pola aplikacji (jak dotąd) ————— */
  removeComparisonTable: (index: number) => void;

  comparisonTables: ComparisonEntry[];
  addComparisonTable: (entry: ComparisonEntry) => void;
  clearComparisonTables: () => void;

  comparisonLabels: { labelA: string; labelB: string };
  setComparisonLabels: (l: { labelA: string; labelB: string }) => void;

  comparisonTable: any[];
  setComparisonTable: (d: any[]) => void;

  selectedDataA: string | null;
  selectedDataB: string | null;
  setSelectedDataA: (k: string | null) => void;
  setSelectedDataB: (k: string | null) => void;

  paidTriangle?: (number | null)[][];
  originalPaidTriangle?: (number | null)[][];
  setPaidTriangle: (d: (number | null)[][]) => void;
  restoreOriginalPaidTriangle: () => void;
  clearOriginalPaidTriangle: () => void;

  /* ————— CL Initial - maska formatowania ————— */
  cl_initial?: number[][];
  setClInitial: (data: number[][]) => void;
  clearClInitial: () => void;

  combinedDevJSummary: (number | string)[];
  setCombinedDevJSummary: (v: (number | string)[]) => void;

  remainingDevJHeaders: string[];
  setRemainingDevJHeaders: (headers: string[]) => void;

  leftCountSummary: number;
  setLeftCountSummary: (n: number) => void;

  selectedCurveSummary: string | null;
  setSelectedCurveSummary: (c: string | null) => void;

  manualOverridesSummary: Record<number, { 
    curve: string; 
    value: number;
    previousState?: {
      wasFromCurve?: string;
      wasFromSourceSwitch?: boolean;
      wasValue?: number;
    };
  }>;
  setManualOverridesSummary: (
    o: Record<number, { 
      curve: string; 
      value: number;
      previousState?: {
        wasFromCurve?: string;
        wasFromSourceSwitch?: boolean;
        wasValue?: number;
      };
    }>
  ) => void;

  // Nowy stan dla przełączania źródła współczynników
  sourceSwitchesSummary: Record<number, { curve: string; value: number }>;
  setSourceSwitchesSummary: (switches: Record<number, { curve: string; value: number }>) => void;

  // Indeks początkowy dla Ultimate Factors
  ultimateFromIndexSummary: number;
  setUltimateFromIndexSummary: (n: number) => void;

  updateDevJAt: (idx: number, value: number) => void;

  selectedDevJVolume?: number;
  selectedDevJSubIndex?: number;
  setSelectedDevJVolume: (v: number, subIndex?: number) => void;

  /* ===== PREVIEW ===== */
  devPreviewCandidate?: number[];
  setDevPreviewCandidate: (v: number[]) => void;
  clearDevPreviewCandidate: () => void;

  /* ===== UI / CONFIG ===== */
  retainedCoeffCount: number;
  setRetainedCoeffCount: (val: number) => void;

  selectedCurve: string;
  setSelectedCurve: (name: string) => void;

  /* ===== Final vectors & custom overrides ===== */
  finalDevVector: number[];
  setFinalDevVector: (v: number[]) => void;

  devFinalCustom: Record<number, CustomCell>;
  setDevFinalValue: (idx: number, curve: string, value: number, sourceVolume?: number, sourceSubIndex?: number) => void;
  clearDevFinalValue: (idx: number) => void;
  clearAllDevFinalValues: () => void;

  /* ===== Dane do obliczeń dev_j ===== */
  trainDevideDet?: number[][];
  selectedWeightsDet?: number[][];
  selectedWeightsDet_clInitial?: number[][];
  manualWeightOverrides: Record<string, 0 | 1>;
  manualWeightOverrides_clInitial: Record<string, 0 | 1>;
  volume_default: number;
  volume_clInitial: number;
  selectedCellsDet: [number, number][];

  r2Scores?: Record<string, number>;
  setR2Scores: (r: Record<string, number>) => void;
  clearR2Scores: () => void;

  tailCount?: number | '';
  setTailCountGlobal: (n: number | '') => void;

  devJ?: number[];
  devJPending?: number[];
  setDevJ: (d: number[]) => void;
  setDevJPending: (d: number[]) => void;

  sdJ?: number[]; // odchylenia standardowe
  setSdJ: (d: number[]) => void;

  devJResults: DevJResult[];
  addDevJResult: (vol: number, values: number[], sdValues?: number[]) => void;
  clearDevJResults: () => void;

  finalDevJ?: DevJResult;
  setFinalDevJ: (d: DevJResult | undefined) => void;

  devJPreview?: number[];
  setDevJPreview: (v: number[]) => void;
  clearDevJPreview: () => void;

  /* ===== MODALE ===== */
  isConfirmModalOpen: boolean;
  pendingFinalDevJ?: DevJResult;
  openConfirmModal: (d: DevJResult) => void;
  closeConfirmModal: () => void;
  confirmFinalDevJ: () => void;

  isMissingFinalModalOpen: boolean;
  openMissingFinalModal: () => void;
  closeMissingFinalModal: () => void;

  /* ===== HELPERY / UI ===== */
  setVolume: (v: number) => void;
  getMaxVolume: () => number;
  getCurrentVolume: () => number;
  setTrainDevideDet: (d: number[][] | undefined) => void;
  setSelectedWeightsDet: (w: number[][]) => void;
  toggleCellDet: (r: number, c: number) => void;
  toggleWeightCellDet: (r: number, c: number) => void;
  toggleRowDet: (r: number) => void;
  setManualWeightOverride: (row: number, col: number, value: 0 | 1) => void;
  clearManualWeightOverrides: () => void;
  resetWeightsToInitial: () => void;
  clearAllWeightsDet: () => void;
  resetSelectionDet: () => void;
  resetDet: () => void;

  selectedDevJIndexes: number[];
  setSelectedDevJIndexes: (i: number[]) => void;

  simResults?: Record<string, Record<string, number>>;
  setSimResults: (r: Record<string, Record<string, number>>) => void;
  clearSimResults: () => void;

  /* ===== CLEAR FIT CURVE ===== */
  clearFitCurveData: () => void;

  /* ===== CLEAR DEVELOPMENT END SUMMARY ===== */
  clearDevSummaryData: () => void;

  /* ===== MIN/MAX HIGHLIGHTING ===== */
  minMaxHighlighting: boolean;
  minMaxCells: [number, number][];
  minCells: [number, number][];
  maxCells: [number, number][];
  setMinMaxHighlighting: (enabled: boolean) => void;
  calculateMinMaxCells: () => void;

  /* ===== NUMBER FORMATTING ===== */
  decimalPlaces: number;
  setDecimalPlaces: (places: number) => void;

  /* ===== CHART SETTINGS ===== */
  chartSelectedColumn: number;
  chartReferenceType: string;
  setChartSelectedColumn: (column: number) => void;
  setChartReferenceType: (type: string) => void;

  /* ===== CURVE FITTING SETTINGS ===== */
  fittingMethod: "log_regression" | "least_squares";
  useWeighting: boolean;
  setFittingMethod: (method: "log_regression" | "least_squares") => void;
  setUseWeighting: (value: boolean) => void;

  /* ===== WEIGHT SOURCE SELECTION ===== */
  weightSource: 'default' | 'cl_initial';
  setWeightSource: (source: 'default' | 'cl_initial') => void;
  getEffectiveWeights: () => number[][] | undefined;
};

/* ───────────────────────  STORE  ─────────────────────── */

export const useTrainDevideStoreDet = create(
  persist<TrainDevideStoreDet>(
    (set, get) => ({
      /* ——— INITIAL STATE ——— */
      workbookDet: undefined,
      uploadedFileNameDet: undefined,
      selectedSheetNameDet: undefined,

      startRowDet: 1,
      endRowDet: 1,
      startColDet: 1,
      endColDet: 1,

      selectedSheetDet: undefined,
      previousSheetDet: undefined,
      isValidDet: false,
      validationErrorReasonDet: undefined,

      manualWeightOverrides: {},
      selectedWeightsDet_clInitial: undefined,
      manualWeightOverrides_clInitial: {},

      comparisonTables: [],
      comparisonLabels: { labelA: 'Projection A', labelB: 'Projection B' },
      comparisonTable: [],

      selectedDataA: null,
      selectedDataB: null,

      paidTriangle: undefined,
      originalPaidTriangle: undefined,

      cl_initial: undefined,

      combinedDevJSummary: [],
      remainingDevJHeaders: [],
      leftCountSummary: 0,
      selectedCurveSummary: null,
      manualOverridesSummary: {},
      sourceSwitchesSummary: {},
      ultimateFromIndexSummary: 1,

      selectedDevJVolume: undefined,
      selectedDevJSubIndex: undefined,

      devPreviewCandidate: undefined,
      retainedCoeffCount: 0,
      selectedCurve: '',

      finalDevVector: [],
      devFinalCustom: {},

      trainDevideDet: undefined,
      selectedWeightsDet: undefined,
      volume_default: 19,
      volume_clInitial: 19,
      selectedCellsDet: [],

      r2Scores: undefined,
      tailCount: '',

      devJ: undefined,
      devJPending: undefined,
      sdJ: undefined, // odchylenia standardowe
      devJResults: [],
      finalDevJ: undefined,
      devJPreview: undefined,

      isConfirmModalOpen: false,
      pendingFinalDevJ: undefined,
      isMissingFinalModalOpen: false,

      selectedDevJIndexes: [],

      simResults: undefined,

      minMaxHighlighting: false,
      minMaxCells: [],
      minCells: [],
      maxCells: [],

      decimalPlaces: 6, // domyślnie 6 miejsc po przecinku
      chartSelectedColumn: 0, // domyślnie pierwsza kolumna
      chartReferenceType: 'none', // domyślnie brak linii odniesienia      
      fittingMethod: "log_regression", // domyślnie Log Regression
      useWeighting: false, // domyślnie bez ważenia
      weightSource: 'default', // domyślnie wagi domyślne

      /* ——— SETTERS & ACTIONS ——— */

      /* Loader PaidTriangleDet */
setWorkbookDet: (wb) => {
  set({ workbookDet: wb });

  const first = wb.SheetNames[0];
  if (first && get().selectedSheetNameDet !== first) {
    get().setSelectedSheetNameDet(first);
  }
},



      setUploadedFileNameDet: (n) => set({ uploadedFileNameDet: n }),
setSelectedSheetNameDet: (name) => {
  /* 1 ▸ jeżeli kliknięto ten sam arkusz – nic nie rób   */
  if (get().selectedSheetNameDet === name) return;

  const wb = get().workbookDet;
  if (!wb || !wb.Sheets[name]) return;   // brak workbooka lub arkusza

  /* 2 ▸ odczytamy dane wybranego arkusza */
  const json = XLSX.utils.sheet_to_json(
    wb.Sheets[name] as XLSX.WorkSheet,
    { header: 1, raw: false }
  ) as (string | number)[][];

  /* 3 ▸ zapisujemy w store  (jedno set!) */
  set({
    selectedSheetNameDet: name,
    previousSheetDet: get().selectedSheetDet,
    selectedSheetDet: json,
    isValidDet: json.length > 0,
    validationErrorReasonDet: json.length > 0 ? undefined : 'Pusty arkusz',
    /* aktualizujemy też domyślny zakres */
    startRowDet: 1,
    endRowDet: json.length,
    startColDet: 1,
    endColDet: json[0]?.length ?? 1,
  });
},

      getDefaultRangeDet: () => {
const sheet = get().selectedSheetDet;
  if (!sheet || sheet.length === 0) return undefined;

  const firstRow = sheet[0] ?? [];          // ← pewne istnienie

  return {
    startRow: 1,
    endRow: sheet.length,
    startCol: 1,
    endCol: firstRow.length,
  };
},

      setRangeAndUpdateDet: ({ startRow, endRow, startCol, endCol }) => {
        const wb = get().workbookDet;
        const sheetName = get().selectedSheetNameDet;
        if (!wb || !sheetName) return;

const ws = wb.Sheets[sheetName];
if (!ws) return;                       // ← ochrona przed undefined

const json: (string | number)[][] = XLSX.utils.sheet_to_json(ws as XLSX.WorkSheet, {
   header: 1,
   raw: false,
});

        const sliced = json
          .slice(startRow - 1, endRow)
          .map((r) => r.slice(startCol - 1, endCol));

        const isValid = sliced.length > 0;

        set({
          startRowDet: startRow,
          endRowDet: endRow,
          startColDet: startCol,
          endColDet: endCol,
          previousSheetDet: get().selectedSheetDet,
          selectedSheetDet: sliced,
          isValidDet: isValid,
          validationErrorReasonDet: isValid ? undefined : 'Niepoprawny format',
        });
      },

      /* Comparison tables */
      removeComparisonTable: (idx) =>
        set((s) => ({
          comparisonTables: s.comparisonTables.filter((_, i) => i !== idx),
        })),
      addComparisonTable: (e) =>
        set((s) => ({ comparisonTables: [...s.comparisonTables, e] })),
      clearComparisonTables: () => set({ comparisonTables: [] }),

      setComparisonLabels: (l) => set({ comparisonLabels: l }),
      setComparisonTable: (d) => set({ comparisonTable: d }),

      setSelectedDataA: (k) => set({ selectedDataA: k }),
      setSelectedDataB: (k) => set({ selectedDataB: k }),

      setPaidTriangle: (d) => {
        const currentOriginal = get().originalPaidTriangle;
        set({ 
          paidTriangle: d,
          // Zapisz oryginał tylko jeśli jeszcze go nie ma
          originalPaidTriangle: currentOriginal || (d && d.length > 0 ? d.map(row => [...row]) : undefined)
        });
      },

      restoreOriginalPaidTriangle: () => {
        const original = get().originalPaidTriangle;
        if (original && original.length > 0) {
          set({ paidTriangle: original.map(row => [...row]) });
        }
      },

      clearOriginalPaidTriangle: () => {
        set({ originalPaidTriangle: undefined });
      },

      /* CL Initial - maska formatowania */
      setClInitial: (data) => set({ cl_initial: data.map(row => [...row]) }),
      clearClInitial: () => set({ cl_initial: undefined }),

      /* Summaries */
      setCombinedDevJSummary: (v) => set({ combinedDevJSummary: [...v] }),
      setRemainingDevJHeaders: (headers) => set({ remainingDevJHeaders: [...headers] }),
      setLeftCountSummary: (n) => set({ leftCountSummary: n }),
      setSelectedCurveSummary: (c) => set({ selectedCurveSummary: c }),
      setManualOverridesSummary: (o) =>
        set({ manualOverridesSummary: { ...o } }),
      setSourceSwitchesSummary: (switches) =>
        set({ sourceSwitchesSummary: { ...switches } }),
      setUltimateFromIndexSummary: (n) => set({ ultimateFromIndexSummary: n }),

      /* Preview candidate */
      setDevPreviewCandidate: (v) => set({ devPreviewCandidate: [...v] }),
      clearDevPreviewCandidate: () => set({ devPreviewCandidate: undefined }),

      /* UI / config */
      setRetainedCoeffCount: (v) => set({ retainedCoeffCount: v }),
      setSelectedCurve: (n) => set({ selectedCurve: n }),

      /* Final vectors & overrides */
      setFinalDevVector: (v) => set({ finalDevVector: [...v] }),
      setDevFinalValue: (idx, curve, value, sourceVolume, sourceSubIndex) =>
        set((s) => {
          const upd = { 
            ...s.devFinalCustom, 
            [idx]: { curve, value, sourceVolume, sourceSubIndex } 
          };
          const vec = [...s.finalDevVector];
          vec[idx] = value;
          return { devFinalCustom: upd, finalDevVector: vec };
        }),
      clearDevFinalValue: (idx) =>
        set((s) => {
          const copy = { ...s.devFinalCustom };
          delete copy[idx];
          const vec = [...s.finalDevVector];
          if (s.devJPreview && s.devJPreview[idx] !== undefined)
            vec[idx] = s.devJPreview[idx]!;
          return { devFinalCustom: copy, finalDevVector: vec };
        }),
      clearAllDevFinalValues: () =>
        set((s) => ({
          devFinalCustom: {},
          finalDevVector: s.devJPreview ? [...s.devJPreview] : [...s.finalDevVector],
        })),

      /* Dev_J dane */
      setTrainDevideDet: (d) => {
        set({ trainDevideDet: d });
        // Automatycznie ustaw oba volume na liczbę kolumn
        if (d && d.length > 0 && d[0]) {
          const numCols = d[0].length;
          set({ volume_default: numCols, volume_clInitial: numCols });
        }
      },
      setSelectedWeightsDet: (w) => {
        const isClInitial = get().weightSource === 'cl_initial';
        if (isClInitial) {
          set({ selectedWeightsDet_clInitial: w });
        } else {
          set({ selectedWeightsDet: w });
        }
      },

      getMaxVolume: () => {
        const matrix = get().trainDevideDet;
        if (!matrix || matrix.length === 0 || !matrix[0]) return 19;
        return matrix[0].length;
      },

      getCurrentVolume: () => {
        const isClInitial = get().weightSource === 'cl_initial';
        return isClInitial ? get().volume_clInitial : get().volume_default;
      },

      setVolume: (v) => {
        const matrix = get().trainDevideDet;
        if (!matrix || matrix.length === 0 || !matrix[0]) return;
        
        const maxVolume = matrix[0].length;
        const clampedV = Math.min(Math.max(1, v), maxVolume); // Ogranicz do 1..maxVolume
        
        const isClInitial = get().weightSource === 'cl_initial';
        
        // Ustaw odpowiedni volume
        if (isClInitial) {
          set({ volume_clInitial: clampedV });
        } else {
          set({ volume_default: clampedV });
        }

        const numRows = matrix.length;
        const numCols = matrix[0].length;
        const overrides = isClInitial ? get().manualWeightOverrides_clInitial : get().manualWeightOverrides;
        
        // Stwórz nową macierz wag
        const weights: number[][] = Array.from({ length: numRows }, () =>
          new Array(numCols).fill(0)
        );

        // Dla każdej kolumny osobno: ostatnie clampedV wartości liczbowych od dołu
        for (let col = 0; col < numCols; col++) {
          let filled = 0;
          for (let row = numRows - 1; row >= 0 && filled < clampedV; row--) {
            const val = matrix[row]?.[col];
            if (typeof val === 'number' && val !== 0) {
              // Użyj manual override jeśli istnieje, w przeciwnym razie 1
              const key = `${row}_${col}`;
              weights[row]![col] = overrides[key] ?? 1;
              filled++;
            }
          }
        }

        if (isClInitial) {
          set({ selectedWeightsDet_clInitial: weights });
        } else {
          set({ selectedWeightsDet: weights });
        }
        
        // 🎯 Przelicz Min/Max po zmianie volume jeśli jest włączone
        if (get().minMaxHighlighting) {
          get().calculateMinMaxCells();
        }
      },

      toggleCellDet: (r, c) => {
        const sel = get().selectedCellsDet;
        const idx = sel.findIndex(([row, col]) => row === r && col === c);
        if (idx >= 0)
          set({ selectedCellsDet: sel.filter(([row, col]) => !(row === r && col === c)) });
        else set({ selectedCellsDet: [...sel, [r, c]] });
      },

      toggleWeightCellDet: (r, c) => {
        const isClInitial = get().weightSource === 'cl_initial';
        const cur = isClInitial ? get().selectedWeightsDet_clInitial : get().selectedWeightsDet;
        if (!cur) return;

        // Przełącz tylko konkretną komórkę
        const newValue = cur[r]?.[c] === 1 ? 0 : 1;
        const upd = cur.map((row, i) =>
          row.map((cell, j) => (i === r && j === c ? newValue : cell))
        );
        
        if (isClInitial) {
          set({ selectedWeightsDet_clInitial: upd });
        } else {
          set({ selectedWeightsDet: upd });
        }
        
        // Zapisz manualny override
        get().setManualWeightOverride(r, c, newValue);
        
        // Jeśli min/max highlighting jest włączone, przelicz ponownie
        if (get().minMaxHighlighting) {
          get().calculateMinMaxCells();
        }
      },

      toggleRowDet: (r) => {
        const isClInitial = get().weightSource === 'cl_initial';
        const cur = isClInitial ? get().selectedWeightsDet_clInitial : get().selectedWeightsDet;
        const trainData = get().trainDevideDet;
        if (!cur || !trainData) return;

        // Sprawdzamy czy cały wiersz jest zaznaczony
        const dataRow = trainData[r];
        if (!dataRow) return;

        let hasAnyData = false;
        let allSelected = true;
        
        // Sprawdzamy stan aktualny wiersza
        for (let j = 0; j < dataRow.length; j++) {
          const cell = dataRow[j];
          const hasData = cell !== null && cell !== undefined && typeof cell === 'number';
          
          if (hasData) {
            hasAnyData = true;
            if (cur[r]?.[j] !== 1) {
              allSelected = false;
              break;
            }
          }
        }

        // Jeśli nie ma danych, nie rób nic
        if (!hasAnyData) return;

        // Przełącz stan całego wiersza
        const upd = cur.map((row, i) => {
          if (i !== r) return row;
          return row.map((cell, j) => {
            const cellData = dataRow[j];
            const hasData = cellData !== null && cellData !== undefined && typeof cellData === 'number';
            // Jeśli komórka ma dane, ustaw przeciwny stan do aktualnego stanu wiersza
            if (hasData) {
              return allSelected ? 0 : 1;
            }
            // Jeśli komórka nie ma danych, zostaw bez zmian
            return cell;
          });
        });

        if (isClInitial) {
          set({ selectedWeightsDet_clInitial: upd });
        } else {
          set({ selectedWeightsDet: upd });
        }
        
        // Zapisz manualne zmiany w overrides
        for (let j = 0; j < dataRow.length; j++) {
          const cellData = dataRow[j];
          const hasData = cellData !== null && cellData !== undefined && typeof cellData === 'number';
          if (hasData) {
            get().setManualWeightOverride(r, j, allSelected ? 0 : 1);
          }
        }
        
        // Jeśli min/max highlighting jest włączone, przelicz ponownie
        if (get().minMaxHighlighting) {
          get().calculateMinMaxCells();
        }
      },

      setManualWeightOverride: (row, col, value) => {
        const key = `${row}_${col}`;
        const isClInitial = get().weightSource === 'cl_initial';
        
        if (isClInitial) {
          set((state) => ({
            manualWeightOverrides_clInitial: {
              ...state.manualWeightOverrides_clInitial,
              [key]: value,
            },
          }));
        } else {
          set((state) => ({
            manualWeightOverrides: {
              ...state.manualWeightOverrides,
              [key]: value,
            },
          }));
        }
      },

      clearManualWeightOverrides: () => {
        const isClInitial = get().weightSource === 'cl_initial';
        if (isClInitial) {
          set({ manualWeightOverrides_clInitial: {} });
        } else {
          set({ manualWeightOverrides: {} });
        }
      },

      resetWeightsToInitial: () => {
        const isClInitial = get().weightSource === 'cl_initial';
        
        if (isClInitial) {
          // Dla "Zadane" - resetuj do cl_initial
          const clInitial = get().cl_initial;
          if (clInitial) {
            // Skopiuj macierz
            set({ selectedWeightsDet_clInitial: clInitial.map(row => [...row]) });
            
            // Przepisz wszystkie wartości z cl_initial jako manual overrides
            const overrides: Record<string, 0 | 1> = {};
            clInitial.forEach((row, r) => {
              row.forEach((val, c) => {
                if (val === 0 || val === 1) {
                  overrides[`${r}_${c}`] = val;
                }
              });
            });
            set({ manualWeightOverrides_clInitial: overrides });
          }
        } else {
          // Dla "Domyślne" - resetuj do wszystko włączone
          const matrix = get().trainDevideDet;
          if (matrix) {
            set({ 
              selectedWeightsDet: matrix.map((row) => row.map(() => 1)),
              manualWeightOverrides: {}
            });
          }
        }
        
        // Przelicz Min/Max po resecie
        if (get().minMaxHighlighting) {
          get().calculateMinMaxCells();
        }
      },

      clearAllWeightsDet: () => {
        const isClInitial = get().weightSource === 'cl_initial';
        const cur = isClInitial ? get().selectedWeightsDet_clInitial : get().selectedWeightsDet;
        if (cur) {
          const cleared = cur.map((r) => r.map(() => 0));
          if (isClInitial) {
            set({ selectedWeightsDet_clInitial: cleared });
          } else {
            set({ selectedWeightsDet: cleared });
          }
        }
      },

      resetSelectionDet: () => {
        const isClInitial = get().weightSource === 'cl_initial';
        const matrix = get().trainDevideDet;
        if (!matrix) return;
        const reset = matrix.map((row) => row.map(() => 1));
        if (isClInitial) {
          set({ selectedWeightsDet_clInitial: reset });
        } else {
          set({ selectedWeightsDet: reset });
        }
      },

      /* Dev_J & preview */
      setDevJ: (d) => set({ devJ: d }),
      setSdJ: (d) => set({ sdJ: d }),
      setDevJPending: (d) => set({ devJPending: [...d] }),
      setDevJPreview: (v) =>
        set(() => ({ devJPreview: [...v], finalDevVector: [...v] })),
      clearDevJPreview: () => set({ devJPreview: undefined }),

      addDevJResult: (volume, values, sdValues) => {
        const curr = get().devJResults;
        const same = curr.filter((e) => e.volume === volume);
        const subIndex = same.length ? same.length : undefined;
        const entry: DevJResult = {
          volume,
          values: [...values],
          ...(subIndex !== undefined && { subIndex }),
          ...(sdValues && { sdValues: [...sdValues] }),
        };
        set({ devJResults: [...curr, entry] });
      },
      clearDevJResults: () => set({ devJResults: [] }),

      setFinalDevJ: (d) =>
        set({
          finalDevJ: d,
          devFinalCustom: {},
          finalDevVector: d ? [...d.values] : [],
        }),

      updateDevJAt: (idx, value) =>
        set((s) => {
          if (!Array.isArray(s.devJPreview)) return {};
          const prev = [...s.devJPreview];
          prev[idx] = value;
          const vec = [...s.finalDevVector];
          vec[idx] = value;
          return {
            devJPreview: prev,
            finalDevVector: vec,
            devFinalCustom: { ...s.devFinalCustom, [idx]: { curve: 'manual', value } },
          };
        }),

      /* Modal handlers */
      openConfirmModal: (pending) =>
        set({ isConfirmModalOpen: true, pendingFinalDevJ: pending }),
      closeConfirmModal: () =>
        set({ isConfirmModalOpen: false, pendingFinalDevJ: undefined }),
      confirmFinalDevJ: () => {
        const pending = get().pendingFinalDevJ;
        if (!pending) return;
        set({
          finalDevJ: pending,
          devFinalCustom: {},
          finalDevVector: [...pending.values],
          isConfirmModalOpen: false,
          pendingFinalDevJ: undefined,
        });
      },

      openMissingFinalModal: () => set({ isMissingFinalModalOpen: true }),
      closeMissingFinalModal: () => set({ isMissingFinalModalOpen: false }),

      /* Simulations / R2 */
      setR2Scores: (r) => set({ r2Scores: r }),
      clearR2Scores: () => set({ r2Scores: undefined }),
      setSimResults: (r) => set({ simResults: r }),
      clearSimResults: () => set({ simResults: undefined }),

      /* Clear FitCurve data */
      clearFitCurveData: () => set({
        devPreviewCandidate: undefined,
        devJPreview: undefined,
        finalDevVector: [],
        devFinalCustom: {},
        selectedDevJIndexes: [],
        r2Scores: undefined,
        simResults: undefined,
      }),

      /* Clear Development End Summary data */
      clearDevSummaryData: () => set({
        leftCountSummary: 0,
        selectedCurveSummary: null,
        manualOverridesSummary: {},
        sourceSwitchesSummary: {},
        ultimateFromIndexSummary: 1,
        combinedDevJSummary: [],
        remainingDevJHeaders: [],
        comparisonTables: [],
        selectedDataA: null,
        selectedDataB: null,
      }),

      /* Dev_J index selection */
      setSelectedDevJIndexes: (i) => set({ selectedDevJIndexes: i }),

      /* Comparison volume */
      setSelectedDevJVolume: (v, subIndex) => set({ selectedDevJVolume: v, selectedDevJSubIndex: subIndex }),

      /* Tail count */
      setTailCountGlobal: (n) => set({ tailCount: n }),

      /* Min/Max highlighting */
      setMinMaxHighlighting: (enabled) => {
        console.log('setMinMaxHighlighting:', enabled);
        set({ minMaxHighlighting: enabled });
        if (enabled) get().calculateMinMaxCells();
        else set({ minMaxCells: [], minCells: [], maxCells: [] });
      },

      /* Number formatting */
      setDecimalPlaces: (places) => {
        set({ decimalPlaces: Math.max(0, Math.min(10, places)) }); // ograniczenie 0-10 miejsc
      },

      /* Chart settings */
      setChartSelectedColumn: (column) => {
        set({ chartSelectedColumn: column });
      },
      setChartReferenceType: (type) => {
        set({ chartReferenceType: type });
      },

      /* Curve fitting settings */
      setFittingMethod: (method) => {
        console.log("🔧 DEBUG - setFittingMethod called with:", method, "current state:", get().fittingMethod);
        set({ fittingMethod: method });
      },
      setUseWeighting: (value) => {
        set({ useWeighting: value });
      },

      /* Weight source selection */
      setWeightSource: (source) => {
        const prevSource = get().weightSource;
        set({ weightSource: source });
        
        if (source === 'cl_initial') {
          // Przełączamy na 'cl_initial'
          // Jeśli selectedWeightsDet_clInitial jest undefined, zainicjuj z cl_initial
          if (!get().selectedWeightsDet_clInitial) {
            const clInitial = get().cl_initial;
            if (clInitial) {
              // Skopiuj macierz
              set({ selectedWeightsDet_clInitial: clInitial.map(row => [...row]) });
              
              // Przepisz wszystkie wartości z cl_initial jako manual overrides
              const overrides: Record<string, 0 | 1> = {};
              clInitial.forEach((row, r) => {
                row.forEach((val, c) => {
                  if (val === 0 || val === 1) {
                    overrides[`${r}_${c}`] = val;
                  }
                });
              });
              set({ manualWeightOverrides_clInitial: overrides });
            }
          }
          // Nie czyścimy overrides - zachowujemy poprzednie edycje użytkownika
        } else {
          // Przełączamy na 'default'
          // Jeśli selectedWeightsDet jest undefined, zainicjuj przez volume
          if (!get().selectedWeightsDet) {
            const currentVolume = get().getCurrentVolume();
            get().setVolume(currentVolume);
          }
          // Nie czyścimy overrides - zachowujemy poprzednie edycje użytkownika
        }
        
        // Przelicz Min/Max po zmianie
        if (get().minMaxHighlighting) {
          setTimeout(() => get().calculateMinMaxCells(), 0);
        }
      },

      getEffectiveWeights: () => {
        const isClInitial = get().weightSource === 'cl_initial';
        return isClInitial ? get().selectedWeightsDet_clInitial : get().selectedWeightsDet;
      },

      calculateMinMaxCells: () => {
        const trainData = get().trainDevideDet;
        const weights = get().getEffectiveWeights();
        if (!trainData || !weights || trainData.length === 0) return;

        console.log('🔢 calculateMinMaxCells started', { 
          trainDataRows: trainData.length, 
          trainDataCols: trainData[0]?.length,
          weightsRows: weights.length, 
          weightsCols: weights[0]?.length 
        });

        const minMaxCells: [number, number][] = [];
        const minCells: [number, number][] = [];
        const maxCells: [number, number][] = [];
        
        // Dla każdej kolumny znajdź min/max spośród zaznaczonych komórek
        const numCols = trainData[0]?.length || 0;
        
        for (let col = 0; col < numCols; col++) {
          const selectedValues: { value: number; row: number }[] = [];
          
          for (let row = 0; row < trainData.length; row++) {
            const cellValue = trainData[row]?.[col];
            const isSelected = weights[row]?.[col] === 1;
            
            if (isSelected && cellValue != null && typeof cellValue === 'number') {
              selectedValues.push({ 
                value: cellValue, 
                row 
              });
            }
          }
          
          console.log(`📊 Kolumna ${col}:`, {
            selectedCount: selectedValues.length,
            values: selectedValues.map(v => `[${v.row}] = ${v.value}`)
          });
          
          if (selectedValues.length > 1) {
            const minItem = selectedValues.reduce((min, curr) => 
              curr.value < min.value ? curr : min
            );
            const maxItem = selectedValues.reduce((max, curr) => 
              curr.value > max.value ? curr : max
            );
            
            // +1 bo w TableDataDet mamy nagłówki!
            minCells.push([minItem.row + 1, col + 1]);
            maxCells.push([maxItem.row + 1, col + 1]);
            minMaxCells.push([minItem.row + 1, col + 1]);
            if (minItem.row !== maxItem.row) {
              minMaxCells.push([maxItem.row + 1, col + 1]);
            }
            
            console.log(`✅ Kolumna ${col} - Min: [${minItem.row}]=${minItem.value}, Max: [${maxItem.row}]=${maxItem.value}`);
          } else {
            console.log(`⚠️ Kolumna ${col} - za mało wybranych wartości (${selectedValues.length})`);
          }
        }
        
        console.log('🎯 calculateMinMaxCells RESULT:', { 
          minCells: minCells.length, 
          maxCells: maxCells.length,
          minCellsData: minCells,
          maxCellsData: maxCells
        });
        set({ minMaxCells, minCells, maxCells });
      },

      /* Combined summary */

      /* RESET ALL */
      resetDet: () =>
        set({
          workbookDet: undefined,
          uploadedFileNameDet: undefined,
          selectedSheetNameDet: undefined,
          startRowDet: 1,
          endRowDet: 1,
          startColDet: 1,
          endColDet: 1,
          selectedSheetDet: undefined,
          previousSheetDet: undefined,
          isValidDet: false,
          validationErrorReasonDet: undefined,

          paidTriangle: undefined,
          originalPaidTriangle: undefined,
          cl_initial: undefined,
          trainDevideDet: undefined,
          selectedWeightsDet: undefined,
          selectedWeightsDet_clInitial: undefined,
          manualWeightOverrides: {},
          manualWeightOverrides_clInitial: {},
          selectedCellsDet: [],
          devJ: undefined,
          devJPending: undefined,
          devJResults: [],
          finalDevJ: undefined,
          devFinalCustom: {},
          devJPreview: undefined,
          isConfirmModalOpen: false,
          pendingFinalDevJ: undefined,
          isMissingFinalModalOpen: false,
          chartSelectedColumn: 0,
          chartReferenceType: 'none',
        }),
    }),
    {
      name: 'train-devide-det',
      storage: {
        getItem: (n) => {
          const i = sessionStorage.getItem(n);
          return i ? JSON.parse(i) : null;
        },
        setItem: (n, v) => sessionStorage.setItem(n, JSON.stringify(v)),
        removeItem: (n) => sessionStorage.removeItem(n),
      },
    }
  )
);
