import { create } from 'zustand';

export type ModelDataType = 'paid' | 'incurred';

interface ModelDataStore {
  selectedType: ModelDataType;
  setSelectedType: (type: ModelDataType) => void;
}

export const useModelDataStore = create<ModelDataStore>((set) => ({
  selectedType: 'paid',
  setSelectedType: (type) => set({ selectedType: type }),
}));
