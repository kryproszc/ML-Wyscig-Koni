import { create } from 'zustand';

type MultStoreIndependent = {
  trainDevide?: number[][];
  selectedWeights?: number[][];
  selectedSheetJSON?: any[][];
  selectedSheetName?: string;
  volume: number;

  // Min/Max highlighting
  minMaxHighlighting: boolean;
  minMaxCells: [number, number][];
  minCells: [number, number][];
  maxCells: [number, number][];

  setTrainDevide: (data: number[][]) => void;
  setSelectedWeights: (weights: number[][]) => void;
  setVolume: (volume: number) => void;
  resetSelection: () => void;
  hydrateFromTableStore: () => void;
  reset: () => void;
  
  // Min/Max functions
  setMinMaxHighlighting: (enabled: boolean) => void;
  calculateMinMaxCells: () => void;
};

export const useMultStoreIndependent = create<MultStoreIndependent>((set, get) => ({
  trainDevide: undefined,
  selectedWeights: undefined,
  selectedSheetJSON: undefined,
  selectedSheetName: undefined,
  volume: 1,

  // Min/Max state
  minMaxHighlighting: false,
  minMaxCells: [],
  minCells: [],
  maxCells: [],

  setTrainDevide: (data) => set({ trainDevide: data }),
  setSelectedWeights: (weights) => {
    set({ selectedWeights: weights });
    // Auto-recalculate min/max if highlighting is enabled
    if (get().minMaxHighlighting) {
      get().calculateMinMaxCells();
    }
  },
  
  setVolume: (v) => {
    set({ volume: v });
    const matrix = get().trainDevide;
    if (!matrix || matrix.length === 0 || !matrix[0]) return;

    const numRows = matrix.length;
    const numCols = matrix[0].length;
    const weights: number[][] = Array.from({ length: numRows }, () =>
      new Array(numCols).fill(0)
    );

    // Dla każdej kolumny zaznacz v ostatnich niezerowych wartości od dołu
    for (let col = 0; col < numCols; col++) {
      let filled = 0;
      for (let row = numRows - 1; row >= 0 && filled < v; row--) {
        const val = matrix[row]?.[col];
        if (typeof val === 'number' && val !== 0 && val !== null) {
          weights[row]![col] = 1;
          filled++;
        }
      }
    }
    set({ selectedWeights: weights });
    
    // Auto-recalculate min/max if highlighting is enabled
    if (get().minMaxHighlighting) {
      get().calculateMinMaxCells();
    }
  },

  resetSelection: () => {
    const matrix = get().trainDevide;
    if (!matrix) return;
    const selected = matrix.map((row) => row.map(() => 1));
    set({ selectedWeights: selected });
    
    // Auto-recalculate min/max if highlighting is enabled
    if (get().minMaxHighlighting) {
      get().calculateMinMaxCells();
    }
  },

  hydrateFromTableStore: () => {
    // Import here to avoid circular dependency
    const { useTableStore } = require('./tableStore');
    const table = useTableStore.getState();
    const sheet = table.selectedSheetJSON;
    const name = table.selectedSheetName;

    if (!sheet) return;

    console.log('[MultStoreIndependent] Hydrating from TableStore');

    set({
      selectedSheetJSON: sheet,
      selectedSheetName: name,
    });
  },

  reset: () => set({
    trainDevide: undefined,
    selectedWeights: undefined,
    selectedSheetJSON: undefined,
    selectedSheetName: undefined,
    volume: 1,
    minMaxHighlighting: false,
    minMaxCells: [],
    minCells: [],
    maxCells: [],
  }),

  // Min/Max highlighting functions
  setMinMaxHighlighting: (enabled) => {
    console.log('setMinMaxHighlighting (Mult Independent):', enabled);
    set({ minMaxHighlighting: enabled });
    if (enabled) get().calculateMinMaxCells();
    else set({ minMaxCells: [], minCells: [], maxCells: [] });
  },

  calculateMinMaxCells: () => {
    const trainData = get().trainDevide;
    const weights = get().selectedWeights;
    if (!trainData || !weights || trainData.length === 0) return;

    console.log('🔢 calculateMinMaxCells (Mult Independent) started', { 
      trainDataRows: trainData.length, 
      trainDataCols: trainData[0]?.length,
      weightsRows: weights.length, 
      weightsCols: weights[0]?.length 
    });

    const minMaxCells: [number, number][] = [];
    const minCells: [number, number][] = [];
    const maxCells: [number, number][] = [];
    
    // Dla każdej kolumny znajdź min/max spośród zaznaczonych komórek
    const numCols = trainData[0]?.length || 0;
    
    for (let col = 0; col < numCols; col++) {
      const selectedValues: { value: number; row: number }[] = [];
      
      for (let row = 0; row < trainData.length; row++) {
        const cellValue = trainData[row]?.[col];
        const isSelected = weights[row]?.[col] === 1;
        
        if (isSelected && cellValue != null && typeof cellValue === 'number') {
          selectedValues.push({ 
            value: cellValue, 
            row 
          });
        }
      }
      
      console.log(`📊 Mult Independent Kolumna ${col}:`, {
        selectedCount: selectedValues.length,
        values: selectedValues.map(v => `[${v.row}] = ${v.value}`)
      });
      
      if (selectedValues.length > 1) {
        const minItem = selectedValues.reduce((min, curr) => 
          curr.value < min.value ? curr : min
        );
        const maxItem = selectedValues.reduce((max, curr) => 
          curr.value > max.value ? curr : max
        );
        
        // +1 bo w TrainDevideTable mamy nagłówki!
        minCells.push([minItem.row + 1, col + 1]);
        maxCells.push([maxItem.row + 1, col + 1]);
        minMaxCells.push([minItem.row + 1, col + 1]);
        if (minItem.row !== maxItem.row) {
          minMaxCells.push([maxItem.row + 1, col + 1]);
        }
        
        console.log(`✅ Mult Independent Kolumna ${col} - Min: [${minItem.row}]=${minItem.value}, Max: [${maxItem.row}]=${maxItem.value}`);
      } else {
        console.log(`⚠️ Mult Independent Kolumna ${col} - za mało wybranych wartości (${selectedValues.length})`);
      }
    }
    
    console.log('🎯 calculateMinMaxCells (Mult Independent) RESULT:', { 
      minCells: minCells.length, 
      maxCells: maxCells.length,
      minCellsData: minCells,
      maxCellsData: maxCells
    });
    set({ minMaxCells, minCells, maxCells });
  },
}));