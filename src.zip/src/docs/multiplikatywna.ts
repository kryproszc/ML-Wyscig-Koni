// src/docs/multiplikatywna.ts
export const GLM_MULTIPLICATIVE_LATEX = String.raw`
<h2>Metoda Stochastyczna Chain Ladder</h2>

<p>
W rozszerzeniu metody chain ladder istnieje szereg kluczowych kroków prowadzących
do symulacji współczynników przejścia chain ladder z rozkładu lognormalnego. Kroki te są następujące:
</p>

<ol>
  <li>Oszacować deterministyczne średnie współczynniki przejścia chain ladder w każdym okresie rozwoju.</li>
  <li>Oszacować wariancję współczynników przejścia  chain ladder w każdym okresie rozwoju.</li>
  <li>Symulować rozkład normalny dla parametru średniej w rozkładzie lognormalnym w każdym okresie rozwoju.</li>
  <li>Symulować rozkład chi-kwadrat dostosowany do wolumenu wypłaconych szkód w każdym roku źródłowym i okresie rozwoju dla parametru wariancji.</li>
  <li>Symulować rozkład lognormalny dla rzeczywistego czynnika rozwoju na podstawie stochastycznej średniej i wariancji.</li>
</ol>

<p>
Stochastyczna średnia i wariancja dla rozkładu lognormalnego reprezentują niepewność parametryczną.
Aby zaparametryzować rozkład normalny dla średniego czynnika rozwoju, potrzebne są średnia i odchylenie standardowe.
</p>

<hr/>

<h3>Definicje</h3>

<ul>
  <li>\(Dev_j\) = czynnik rozwoju od okresu rozwoju \(j-1\) do \(j\)</li>
  <li>\(w_{i,j}\) = waga określona przez użytkownika dla roku źródłowego \(i\) i okresu rozwoju \(j\)</li>
  <li>\(p_{i,j}\) = skumulowane wypłacone szkody w roku źródłowym \(i\) i okresie rozwoju \(j\)</li>
  <li>\(m_i\) = liczba okresów rozwoju w trójkącie roku źródłowego \(i\)</li>
  <li>\(m\) = maksimum z \(m_i\), czyli najpóźniejszy okres rozwoju dla najwcześniejszego roku źródłowego</li>
</ul>

<p>
Średni czynnik od okresu rozwoju \(j-1\) do \(j\) jest równy czynnikowi rozwoju
opisanemu w metodzie paid chain ladder:
</p>

\[
\bar{x}_j = Dev_j
\]

<hr/>

<h3>Estymacja wariancji czynników</h3>

<p>
Błąd estymacji lub czynnik wariancji oblicza się w procesie dwuetapowym.
Najpierw wyznacza się \(\sigma_j\), czynnik wariancji reprezentujący zmienność czynników
chain ladder przed dostosowaniem do wolumenu szkód:
</p>

\[
\sigma_j = \frac{\sum_i w_{i,j-1}\, p_{i,j-1}\, (l_{i,j} - Dev_j)^2}
                {\left(\sum_i w_{i,j-1}\right) - 1}
\]

<p>
gdzie \(l_{i,j}\) to <strong>współczynnik rok-do-roku (year-to-year factor)</strong>.
</p>

<p>
Wariancję dla rozkładu normalnego oblicza się następnie przez dostosowanie do wolumenu szkód:
</p>

\[
sd_j^2 = \frac{\sigma_j}{\sum_i w_{i,j-1}\, p_{i,j-1}}
\]

<p>
Rozkład normalny reprezentujący średni czynnik chain ladder jest następnie symulowany
z rozkładu normalnego o parametrach: średnia \(\bar{x}_j\) i odchylenie standardowe \(sd_j\).
</p>

<hr/>

<h3>Symulacja wariancji</h3>

<p>
Aby obliczyć parametr wariancji do symulacji lognormalnej, model najpierw symuluje
stochastyczny rozkład dla \(\sigma_j\). Odbywa się to na podstawie rozkładu chi-kwadrat
wokół liczby stopni swobody dla każdego okresu rozwoju:
</p>

\[
\chi_j^2 = \max(1, m - j - 1)
\]

<p>
Stochastyczna wartość \(\sigma_j\) jest następnie obliczana w następujący sposób,
gdzie \(Chi_j^2\) to wylosowana wartość z rozkładu chi-kwadrat z parametrem \(\chi_j^2\):
</p>

\[
Stochastic\_sigma_j = \frac{Chi_j^2 \cdot \sigma_j}{\max(1, m - j - 1)}
\]

<p>
Można wtedy obliczyć wariancję czynnika chain ladder dla każdego roku źródłowego i okresu rozwoju:
</p>

\[
VAR_{i,j} = \frac{Stochastic\_sigma_j}{p_{i,j-1}}
\]

<hr/>

<h3>Losowanie współczynników przejścia</h3>

<ul>
  <li>\(\mu_j\) = rozkład normalny z parametrami: średnia \(\bar{x}_j\) i odchylenie standardowe \(sd_j\)</li>
  <li>\(VAR_{i,j}\) = dostosowany rozkład chi-kwadrat zdefiniowany powyżej</li>
  <li>\(CL_{i,j}\) = stochastyczny czynnik chain ladder dla roku źródłowego \(i\),
      aby przejść z okresu rozwoju \(j-1\) do \(j\)</li>
</ul>

<p>
Następnie czynnik chain ladder \(CL_{i,j}\) w każdym okresie rozwoju \(j\) jest symulowany
z rozkładu lognormalnego o parametrach:
</p>

\[
lmean_{i,j} = \ln\!\left(\frac{\mu_j^2}{\mu_j^2 + VAR_{i,j}}\right), \quad
lstdev_{i,j} = \sqrt{\ln\!\left(\frac{VAR_{i,j}}{\mu_j^2} + 1\right)}
\]

<hr/>

<h3>Ostateczne wyliczenia</h3>

<p>
Skumulowane wypłacone szkody w okresie rozwoju \(j\) dla roku źródłowego \(i\),
gdzie \(j > m_i\), obliczane są jako:
</p>

\[
p_{i,j} = p_{i,j-1} \cdot CL_{i,j}
\]

<p>
Stochastyczna pozycja końcowa (ultimate), obliczona przy użyciu metody paid chain ladder
dla roku źródłowego \(i\), jest równa skumulowanym wypłaconym szkodom
w ostatnim okresie rozwoju:
</p>

\[
u_i = \max_j(p_{i,j})
\]
`;
