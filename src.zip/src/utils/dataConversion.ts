export function convertIncrementalToCumulative(data: any[][]): any[][] {
  if (!data || data.length <= 1) return data;

  // Kopiujemy dane, żeby nie modyfikować oryginału
  const result = data.map(row => [...row]);

  // Przetwarzamy każdy wiersz oprócz nagłówka (indeks 0)
  for (let rowIndex = 1; rowIndex < result.length; rowIndex++) {
    const row = result[rowIndex];
    if (!row) continue; // Sprawdzenie bezpieczeństwa
    
    // Znajdź koniec "schodka" - ostatnią niepustą wartość w wierszu
    let lastNonEmptyIndex = row.length - 1;
    for (let i = row.length - 1; i >= 1; i--) {
      if (row[i] !== "" && row[i] !== null && row[i] !== undefined) {
        lastNonEmptyIndex = i;
        break;
      }
    }
    
    // Kumuluj tylko do końca schodka, pomijamy pierwszą kolumnę (etykiety wierszy)
    for (let colIndex = 2; colIndex <= lastNonEmptyIndex; colIndex++) {
      const currentValue = typeof row[colIndex] === 'number' ? row[colIndex] : parseFloat(row[colIndex]) || 0;
      const previousValue = typeof row[colIndex - 1] === 'number' ? row[colIndex - 1] : parseFloat(row[colIndex - 1]) || 0;
      
      // Kolumna = suma bieżącej + poprzedniej (tylko w obrębie schodka)
      row[colIndex] = previousValue + currentValue;
    }
  }

  return result;
}
