'use client';

import { TableData } from '@/components/TableData';
import { Button } from '@/components/ui/button';
import { useTableStore } from '@/stores/tableStore';
import { useMutation } from '@tanstack/react-query';
import { calcClCalcClPostMutation } from '@/client/@tanstack/react-query.gen';
import { useState } from 'react';

export function PaidView(): React.ReactElement {
const {
  selectedSheetName: sheetName,
  selectedSheetJSON: sheetJSON,
  selectedCells,
  setSelectedCells,
  setProcessedData,
  setProcessedTriangle,
  setClData,
  setClWeights,
  activeStochTriangle,
} = useTableStore();

  const [decimals, setDecimals] = useState(0);

  // Dynamiczny tytuł na podstawie aktywnego typu
  const triangleType = activeStochTriangle ?? 'paid';
  const title = triangleType === 'paid' ? 'Trójkąt Paid – wczytane dane' : 'Trójkąt Incurred – wczytane dane';


  const mutation = useMutation({
    ...calcClCalcClPostMutation(),
onSuccess: (data) => {
  const parsed = data as { data: (string | number)[][] };

  const numericData = parsed.data.map((row) =>
    row.map((cell) => {
      const result = typeof cell === 'number' ? cell : Number(cell);
      return result;
    })
  );

  const headerRow = (sheetJSON?.[0] ?? []).map((cell) => cell ?? "");
  const rowHeaders = (sheetJSON?.slice(1).map((row) => row[0] ?? "") ?? []);

  const trimmedNumericData = numericData.slice(1).map(row => row.slice(1));

  const maxLength = headerRow.length;
  
  const clDataWithHeaders = [
    ["", ...headerRow.slice(1)],
    ...trimmedNumericData.map((row, idx) => {
      const processedRow = row.map((cell) => (Number.isNaN(cell) ? null : cell));
      while (processedRow.length < maxLength - 1) {
        processedRow.push(null);
      }
      return [rowHeaders[idx] ?? "", ...processedRow];
    }),
  ];

  setProcessedData(trimmedNumericData);
  setProcessedTriangle(trimmedNumericData);
  setClData(clDataWithHeaders);

  const defaultWeights = trimmedNumericData.map((row) =>
    row.map(() => 1)
  );
  setClWeights(defaultWeights);
},



    onError: (err) => {
      console.error('❌ Błąd przetwarzania trójkąta:', err);
    },
  });

  const handleConfirm = (): void => {
    if (!sheetJSON || !selectedCells) return;

    const cleanedData = sheetJSON.map(row => 
      row.map(cell => cell ?? '')
    );
    const cleanedSelected = selectedCells.map(row => 
      row.map(cell => cell ?? 0)
    );

    mutation.mutate({
      body: {
        data: cleanedData,
        selected: cleanedSelected,
      },
    });
  };

  const handleClick = (i: number, j: number) => {
    if (!selectedCells) return;

    const updated = selectedCells.map((row, rowIndex) =>
      rowIndex === i
        ? row.map((cell, colIndex) =>
            colIndex === j ? (cell === 1 ? 0 : 1) : cell
          )
        : [...row]
    );

    setSelectedCells(updated);
  };

  const resetSelection = () => {
    if (!sheetJSON) return;

    const newSelected = sheetJSON.map((row) =>
      row.map(() => 1)
    );

    setSelectedCells(newSelected);
  };

  if (!sheetJSON) {
    return <div className="text-red-400">Brak danych arkusza</div>;
  }

 return (
  <div className="flex gap-8 p-8">
    {/* Panel boczny */}
    <div className="w-64 shrink-0 space-y-4">
      {/* Kontrolka miejsc po przecinku */}
      <div className="bg-gray-800 rounded-lg p-4">
        <label className="text-white text-sm font-medium mb-2 block">
          Miejsca po przecinku
        </label>
        <input
          type="number"
          min="0"
          max="6"
          value={decimals}
          onChange={(e) => setDecimals(Math.max(0, Math.min(6, parseInt(e.target.value) || 0)))}
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      {/* Zatwierdź trójkąt */}
      <button
        onClick={handleConfirm}
        className="w-full py-4 px-5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl font-bold hover:from-emerald-700 hover:to-emerald-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
      >
        Zatwierdź trójkąt
      </button>

      {/* Resetuj zaznaczenia */}
      <button
        onClick={resetSelection}
        className="w-full py-4 px-5 bg-gradient-to-r from-orange-600 to-orange-500 text-white rounded-xl font-bold hover:from-orange-700 hover:to-orange-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
      >
        Resetuj zaznaczenia
      </button>
    </div>

    {/* Tabela */}
    <div className="flex-1 flex flex-col min-w-0">
      <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white">
        <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
          <h3 className="font-bold text-gray-800 text-lg tracking-tight">{title}</h3>
        </div>
        <div className="overflow-auto p-4" style={{ maxHeight: 'calc(100vh - 300px)' }}>
          <TableData
            data={sheetJSON}
            selected={selectedCells}
            onClick={(i, j) => handleClick(i, j)}
            variant="light"
            decimals={decimals}
          />
        </div>
      </div>
    </div>
  </div>
);
}