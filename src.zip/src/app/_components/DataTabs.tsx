'use client';

import { InputDataTabDet, InputDataTabIncurred, InputDataTabTest, InputDataTabTestIncurred } from '@/features/data-input';
import { cn } from "@/lib/utils";

const tabs = [
  { key: "paid", label: "Trójkąt paid" },
  { key: "incurred", label: "Trójkąt incurred" },
  { key: "test", label: "Trójkąt test" },
  { key: "test-incurred", label: "Trójkąt test incurred" },
];

interface DataTabsProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export function DataTabs({ activeTab, setActiveTab }: DataTabsProps) {
  // Obsługa przełączania zakładek
  const handleTabChange = (tabKey: string) => {
    setActiveTab(tabKey);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Zakładki - Poziom 1 (główne) */}
      <div className="flex space-x-1 border-b border-slate-700">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => handleTabChange(tab.key)}
            className={cn(
              "px-6 py-3 text-base font-medium transition-all rounded-t-lg",
              activeTab === tab.key
                ? "bg-slate-800 border-t border-l border-r border-slate-600 border-b-2 border-b-blue-400 text-blue-400 shadow-lg"
                : "text-slate-300 hover:text-blue-300 hover:bg-slate-800/30"
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div>
        {activeTab === "paid" && <InputDataTabDet />}
        {activeTab === "incurred" && <InputDataTabIncurred />}
        {activeTab === "test" && <InputDataTabTest />}
        {activeTab === "test-incurred" && <InputDataTabTestIncurred />}
      </div>
    </div>
  );
}
