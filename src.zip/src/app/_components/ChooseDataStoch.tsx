'use client';

import React, {
  useEffect,
  useMemo,
  useState,
  useRef,
  useCallback,
} from 'react';
import { FileText, X } from 'lucide-react';

import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useTrainDevideStoreDetIncurred } from '@/stores/trainDevideStoreDeterministycznyIncurred';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { useTableStore } from '@/stores/tableStore';
import { TriangleTableView } from '@/shared';

import { resetAllStores } from '@/lib/resetAllStores';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

// 🔧 Podmień poniżej na własną ścieżkę do PDF (domyślny plik – nadal zostaje)
const PDF_URL = '/7_Mack_1994.pdf';

// 🔧 LaTeX: eksportuj string z pliku '@/docs/multiplikatywna'
import { GLM_MULTIPLICATIVE_LATEX } from '@/docs/multiplikatywna';

// ---------- NOWE: opis dokumentów ----------
type DocKey = 'intro' | 'bootstrap_np' | 'glm_multiplicative' | 'bootstrap_param';

type DocItem =
  | { type: 'pdf'; content: string }
  | { type: 'latex'; content: string };

const DOCS: Record<DocKey, DocItem> = {
  intro: { type: 'pdf', content: '/pdf/wstep.pdf' },
  bootstrap_np: { type: 'pdf', content: '/sm0201.pdf' },
  glm_multiplicative: { type: 'latex', content: GLM_MULTIPLICATIVE_LATEX },
  bootstrap_param: { type: 'pdf', content: '/pdf/bootstrap_parametryczny.pdf' },
};

const PDF_TITLES: Record<DocKey, string> = {
  intro: 'Wprowadzenie – Metody stochastyczne',
  bootstrap_np: 'Bootstrap nieparametryczny – Dokumentacja',
  glm_multiplicative: 'Multiplikatywna stochastyczna – Dokumentacja',
  bootstrap_param: 'Bootstrap parametryczny – Dokumentacja',
};

// ---------- NOWE: generator HTML z MathJax dla LaTeX ----------
function buildMathJaxHTML(latex: string, title = 'Dokument LaTeX'): string {
  return `
<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>${title}</title>
<style>
  body{font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; line-height:1.6; padding:24px; margin:0; color:#111827;}
  h1,h2,h3{margin:0 0 0.6em;}
  .container{max-width:980px; margin:0 auto;}
</style>
<script>
  window.MathJax = {
    tex: {
      packages: {'[+]': ['base', 'ams', 'noundefined']},
      inlineMath: [['$', '$'], ['\\\\(', '\\\\)']],
      displayMath: [['$$','$$'], ['\\\\[','\\\\]']],
      processEscapes: true
    },
    svg: { fontCache: 'global' }
  };
</script>
<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script>
</head>
<body>
  <div class="container">
    ${latex.replace(/<\/?script/gi, '')}
  </div>
</body>
</html>
`.trim();
}

interface ChooseDataStochProps {
  activeType: 'paid' | 'incurred';
  setActiveType: (type: 'paid' | 'incurred') => void;
}

export function ChooseDataStoch({ activeType: activeTypeProp, setActiveType: setActiveTypeProp }: ChooseDataStochProps) {
  // --- deterministyczny: Paid ---
  const setPaidTriangle = useTrainDevideStoreDet((s) => s.setPaidTriangle);
  const selectedSheetDet = useTrainDevideStoreDet((s) => s.selectedSheetDet);
  const paidTriangle = useTrainDevideStoreDet((s) => s.paidTriangle);

  // --- deterministyczny: Incurred ---
  const setIncurredTriangle = useTrainDevideStoreDetIncurred(
    (s) => s.setIncurredTriangle,
  );
  const selectedSheetDetIncurred = useTrainDevideStoreDetIncurred(
    (s) => s.selectedSheetDetIncurred,
  );
  const incurredTriangle = useTrainDevideStoreDetIncurred(
    (s) => s.incurredTriangle,
  );

  // --- labels z zakładek deterministycznych ---
  const paidRowLabels = useLabelsStore((s) => s.detRowLabels);
  const paidColumnLabels = useLabelsStore((s) => s.detColumnLabels);
  const incurredRowLabels = useLabelsStore((s) => s.incurredRowLabels);
  const incurredColumnLabels = useLabelsStore((s) => s.incurredColumnLabels);

  // --- global labels (używane przez tableStore) ---
  const setGlobalRowLabels = useLabelsStore((s) => s.setRowLabels);
  const setGlobalColumnLabels = useLabelsStore((s) => s.setColumnLabels);

  // --- tableStore ---
  const selectedSheetJSON = useTableStore((s) => s.selectedSheetJSON);
  // Używamy props zamiast bezpośrednio ze store'a
  const activeType = activeTypeProp;
  const setActiveTypeStore = useTableStore((s) => s.setActiveStochTriangle);
  
  // Wrapper który aktualizuje zarówno lokalny stan (przez props) jak i store
  const setActiveType = (type: 'paid' | 'incurred') => {
    setActiveTypeProp(type);
    setActiveTypeStore(type);
  };

  // --- modal potwierdzenia przełączenia trójkąta ---
  const [showSwitchDialog, setShowSwitchDialog] = useState(false);
  const [pendingType, setPendingType] = useState<'paid' | 'incurred' | null>(
    null,
  );

  // --- PDF/LaTeX modal: stan / refs ---
  const [showPDFModal, setShowPDFModal] = useState(false);
  const [modalSize, setModalSize] = useState({ width: 1200, height: 800 });
  const [modalPosition, setModalPosition] = useState({ x: 0, y: 0 });
  const [isResizing, setIsResizing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const modalRef = useRef<HTMLDivElement | null>(null);
  const resizeStartRef = useRef({ x: 0, y: 0, width: 0, height: 0 });
  const dragStartRef = useRef({ x: 0, y: 0, startX: 0, startY: 0 });

  // NOWE: aktualny dokument (PDF lub LaTeX) + tytuł
  const [currentDoc, setCurrentDoc] = useState<DocItem | null>({
    type: 'pdf',
    content: PDF_URL,
  });
  const [currentPdfTitle, setCurrentPdfTitle] =
    useState<string>('Dokumentacja modelu');

  // stary przycisk dalej działa – otwiera domyślny PDF_URL
  const openPDFModal = () => {
    setCurrentDoc({ type: 'pdf', content: PDF_URL });
    setCurrentPdfTitle('Dokumentacja modelu');
    setShowPDFModal(true);
    setModalPosition({ x: 0, y: 0 });
  };

  // NOWE: przycisk z kluczem – otwiera konkretny dokument (PDF/LaTeX)
  const openPDFModalFor = (key: DocKey) => {
    setCurrentDoc(DOCS[key]);
    setCurrentPdfTitle(PDF_TITLES[key]);
    setShowPDFModal(true);
    setModalPosition({ x: 0, y: 0 });
  };

  const closePDFModal = () => setShowPDFModal(false);

  // Dragging
  const handleDragStart = useCallback(
    (e: React.MouseEvent) => {
      if (isResizing) return;
      e.preventDefault();
      setIsDragging(true);

      dragStartRef.current = {
        x: e.clientX,
        y: e.clientY,
        startX: modalPosition.x,
        startY: modalPosition.y,
      };

      const handleMouseMove = (ev: MouseEvent) => {
        if (!isDragging) return;
        const deltaX = ev.clientX - dragStartRef.current.x;
        const deltaY = ev.clientY - dragStartRef.current.y;

        setModalPosition({
          x: dragStartRef.current.startX + deltaX,
          y: dragStartRef.current.startY + deltaY,
        });
      };

      const handleMouseUp = () => {
        setIsDragging(false);
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };

      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    },
    [isResizing, isDragging, modalPosition],
  );

  // Resizing (SE corner)
  const handleResizeStart = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      setIsResizing(true);

      resizeStartRef.current = {
        x: e.clientX,
        y: e.clientY,
        width: modalSize.width,
        height: modalSize.height,
      };

      const handleMouseMove = (ev: MouseEvent) => {
        if (!isResizing) return;

        const deltaX = ev.clientX - resizeStartRef.current.x;
        const deltaY = ev.clientY - resizeStartRef.current.y;

        const newWidth = Math.max(400, resizeStartRef.current.width + deltaX);
        const newHeight = Math.max(300, resizeStartRef.current.height + deltaY);

        setModalSize({ width: newWidth, height: newHeight });
      };

      const handleMouseUp = () => {
        setIsResizing(false);
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };

      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    },
    [isResizing, modalSize],
  );

  // Resizing (bottom edge)
  const handleResizeStartBottom = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      setIsResizing(true);

      resizeStartRef.current = {
        x: e.clientX,
        y: e.clientY,
        width: modalSize.width,
        height: modalSize.height,
      };

      const handleMouseMove = (ev: MouseEvent) => {
        const deltaY = ev.clientY - resizeStartRef.current.y;
        const newHeight = Math.max(300, resizeStartRef.current.height + deltaY);
        setModalSize((prev) => ({ ...prev, height: newHeight }));
      };

      const handleMouseUp = () => {
        setIsResizing(false);
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };

      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    },
    [modalSize],
  );

  // Resizing (right edge)
  const handleResizeStartRight = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      setIsResizing(true);

      resizeStartRef.current = {
        x: e.clientX,
        y: e.clientY,
        width: modalSize.width,
        height: modalSize.height,
      };

      const handleMouseMove = (ev: MouseEvent) => {
        const deltaX = ev.clientX - resizeStartRef.current.x;
        const newWidth = Math.max(400, resizeStartRef.current.width + deltaX);
        setModalSize((prev) => ({ ...prev, width: newWidth }));
      };

      const handleMouseUp = () => {
        setIsResizing(false);
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };

      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    },
    [modalSize],
  );

  const requestSwitch = (type: 'paid' | 'incurred') => {
    if (type === activeType) return;
    setPendingType(type);
    setShowSwitchDialog(true);
  };

  const confirmSwitch = () => {
    try {
      resetAllStores();
      if (pendingType) {
        setActiveType(pendingType);
      }
    } finally {
      setShowSwitchDialog(false);
      setPendingType(null);
    }
  };

  // 1) ustaw paid/incurred na podstawie selectedSheetDet*
  useEffect(() => {
    if (selectedSheetDet && typeof setPaidTriangle === 'function') {
      const paid = selectedSheetDet.map((row) =>
        row.map((cell) => (typeof cell === 'number' ? cell : null)),
      );
      setPaidTriangle(paid);
    }
  }, [selectedSheetDet, setPaidTriangle]);

  useEffect(() => {
    if (selectedSheetDetIncurred && typeof setIncurredTriangle === 'function') {
      const inc = selectedSheetDetIncurred.map((row) =>
        row.map((cell) => (typeof cell === 'number' ? cell : null)),
      );
      setIncurredTriangle(inc);
    }
  }, [selectedSheetDetIncurred, setIncurredTriangle]);

  // helper: buduje arkusz z nagłówkami dla aktywnego trójkąta
  const buildSheetWithHeaders = (
    tri: (number | null)[][] | undefined,
    type: 'paid' | 'incurred',
  ): (string | number)[][] => {
    const body = (tri ?? []).map((r) => r.map((c) => (c == null ? '' : c)));
    const rows = body.length;
    const cols = body[0]?.length ?? 0;

    const rLabels =
      type === 'paid'
        ? paidRowLabels.length > 1
          ? paidRowLabels
          : Array.from({ length: rows }, (_, i) => `${i + 1}`)
        : incurredRowLabels.length > 1
        ? incurredRowLabels
        : Array.from({ length: rows }, (_, i) => `${i + 1}`);

    const cLabels =
      type === 'paid'
        ? paidColumnLabels.length > 1
          ? paidColumnLabels
          : Array.from({ length: cols }, (_, i) => `${i + 1}`)
        : incurredColumnLabels.length > 1
        ? incurredColumnLabels
        : Array.from({ length: cols }, (_, i) => `${i + 1}`);

    const safeRowLabels =
      rLabels.length === rows
        ? rLabels
        : Array.from({ length: rows }, (_, i) => rLabels[i] ?? `${i + 1}`);
    const safeColLabels =
      cLabels.length === cols
        ? cLabels
        : Array.from({ length: cols }, (_, i) => cLabels[i] ?? `${i + 1}`);

    const withHeaders: (string | number)[][] = [
      ['', ...safeColLabels],
      ...body.map((row, i) => [safeRowLabels[i] ?? `${i + 1}`, ...row]),
    ];

    setGlobalRowLabels(safeRowLabels.map(String));
    setGlobalColumnLabels(safeColLabels.map(String));

    return withHeaders;
  };

  // aktualny trójkąt wg wyboru
  const activeTriangle = useMemo(
    () => (activeType === 'paid' ? paidTriangle : incurredTriangle),
    [activeType, paidTriangle, incurredTriangle],
  );

  // 2) SYNC: zapisuj do tableStore arkusz z nagłówkami
  useEffect(() => {
    if (!activeTriangle || activeTriangle.length === 0) return;

    const sheetWithHeaders = buildSheetWithHeaders(activeTriangle, activeType);
    const same =
      Array.isArray(selectedSheetJSON) &&
      JSON.stringify(selectedSheetJSON) === JSON.stringify(sheetWithHeaders);

    if (!same) {
      useTableStore.setState({
        selectedSheetJSON: sheetWithHeaders,
        triangleType: activeType,
        hasHeaders: true,
        selectedCells: sheetWithHeaders.map((row) => row.map(() => 1)),
      });
    }
  }, [activeType, activeTriangle, selectedSheetJSON]);

  // klasy pomocnicze do „pill toggle”
  const baseBtn =
    'px-5 py-2 rounded-full text-sm font-medium transition-colors border';
  const activeBtn = 'bg-white text-black border-white shadow';
  const inactiveBtn =
    'bg-transparent text-zinc-200/80 border-zinc-600 hover:bg-zinc-800/60';

  return (
    <div className="p-4 text-white">
      <h2 className="text-lg font-bold mb-2 text-center">
        Wybierz dane do analizy stochastycznej
      </h2>
{/* Wycentrowany przełącznik Paid/Incurred */}
<div className="flex justify-center mt-2 mb-6">
  <div className="inline-flex flex-col items-center gap-3 rounded-2xl border border-slate-700 bg-slate-800 px-6 py-5 shadow-2xl max-w-md text-center">
    <div className="text-xs uppercase tracking-wider text-gray-300">
      Aktywny trójkąt
    </div>

    <p className="text-sm text-zinc-300 mb-2">
      Wybierz, czy chcesz przeprowadzić analizy na wczytanym trójkącie{" "}
      <span className="font-semibold text-white">Paid</span> lub{" "}
      <span className="font-semibold text-white">Incurred</span>.
    </p>

    <div className="flex items-center gap-2 bg-zinc-800/60 rounded-full p-1">
      <button
        type="button"
        onClick={() => requestSwitch('paid')}
        disabled={!paidTriangle || paidTriangle.length === 0}
        className={`${baseBtn} ${
          activeType === 'paid' ? activeBtn : inactiveBtn
        } disabled:opacity-50 disabled:cursor-not-allowed`}
      >
        Paid
      </button>

      <button
        type="button"
        onClick={() => requestSwitch('incurred')}
        disabled={!incurredTriangle || incurredTriangle.length === 0}
        className={`${baseBtn} ${
          activeType === 'incurred' ? activeBtn : inactiveBtn
        } disabled:opacity-50 disabled:cursor-not-allowed`}
      >
        Incurred
      </button>
    </div>

    <div className="text-xs text-zinc-400">
      Aktywny:{" "}
      <span className="font-semibold text-zinc-200">
        {activeType.toUpperCase()}
      </span>
    </div>
  </div>
</div>


      {/* Dokumentacja (PDF/LaTeX) */}
      <div className="space-y-6">
        <div className="bg-gray-800 rounded-lg p-6">
          <h4 className="text-lg font-medium mb-4 text-blue-400">
            Dokumentacja
          </h4>
<p className="text-gray-300 mb-4">
  W tej sekcji znajdują się metody stochastyczne służące do analizy rezerw.
  Każda z zakładek uruchamia inny wariant modelu, którego wspólnym celem
  jest <strong>symulacja rozkładu możliwych przyszłych strat</strong> na
  podstawie danych z trójkąta rozwojowego. Dzięki temu zamiast pojedynczej
  wartości otrzymujemy <strong>pełny rozkład rezerw</strong>, z którego
  można odczytać m.in. wartość oczekiwaną, zmienność czy percentyle.
  <br />
  <br />
  Poniżej znajdują się trzy metody dostępne w aplikacji. Każda ma swój opis
  w dedykowanym pliku PDF/LaTeX:
</p>

<ul className="space-y-4 text-gray-300">
  <li>
    <span className="font-semibold text-white">Bootstrap nieparametryczny</span> – opis metody znajduje się w pliku:{" "}
    <button
      onClick={() => openPDFModalFor('bootstrap_np')}
      className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors ml-2"
    >
      <FileText size={18} />
      Bootstrap nieparametryczny – PDF
    </button>
  </li>

  <li>
    <span className="font-semibold text-white">Multiplikatywna stochastyczna</span> – opis metody dostępny jako LaTeX:{" "}
    <button
      onClick={() => openPDFModalFor('glm_multiplicative')}
      className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors ml-2"
    >
      <FileText size={18} />
      Multiplikatywna stochastyczna – LaTeX
    </button>
  </li>

  <li>
    <span className="font-semibold text-white">Bootstrap parametryczny</span> – opis metody znajduje się w pliku:{" "}
    <button
      onClick={() => openPDFModalFor('bootstrap_param')}
      className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors ml-2"
    >
      <FileText size={18} />
      Bootstrap parametryczny – PDF
    </button>
  </li>
</ul>


        </div>
      </div>

      {/* Modal potwierdzenia zmiany trójkąta */}
      <AlertDialog open={showSwitchDialog} onOpenChange={setShowSwitchDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Zmiana trójkąta</AlertDialogTitle>
            <AlertDialogDescription>
              Zmiana aktywnego trójkąta spowoduje{' '}
              <strong>
                usunięcie wszystkich dotychczasowych wyników i ustawień
              </strong>
              : symulacji, percentyli, wykresów, parametrów itp.
              <br />
              Czy na pewno chcesz kontynuować?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Anuluj</AlertDialogCancel>
            <AlertDialogAction onClick={confirmSwitch}>
              Tak, wyczyść i przełącz
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Modal z PDF/LaTeX */}
      {showPDFModal && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
          <div
            ref={modalRef}
            className="bg-white rounded-lg flex flex-col relative select-none shadow-2xl"
            style={{
              width: `${modalSize.width}px`,
              height: `${modalSize.height}px`,
              minWidth: '400px',
              minHeight: '300px',
              maxWidth: '90vw',
              maxHeight: '90vh',
              transform: `translate(${modalPosition.x}px, ${modalPosition.y}px)`,
              cursor: isDragging ? 'grabbing' : 'default',
            }}
          >
            {/* Header */}
            <div
              className="flex items-center justify-between p-4 border-b border-gray-200 cursor-grab active:cursor-grabbing bg-gray-50 rounded-t-lg"
              onMouseDown={handleDragStart}
            >
              <h3 className="text-lg font-semibold text-gray-900 pointer-events-none">
                {currentPdfTitle}
              </h3>
              <button
                onClick={closePDFModal}
                className="text-gray-500 hover:text-gray-700 p-1 z-10 cursor-pointer"
                onMouseDown={(e) => e.stopPropagation()}
              >
                <X size={24} />
              </button>
            </div>

            {/* Zawartość: PDF albo LaTeX (MathJax w iframe srcDoc) */}
            <div className="flex-1 p-4 overflow-hidden">
              {currentDoc?.type === 'pdf' ? (
                <iframe
                  src={currentDoc.content}
                  width="100%"
                  height="100%"
                  className="border-0 rounded"
                  title="Dokumentacja modelu"
                >
                  <p className="text-gray-600">
                    Twoja przeglądarka nie obsługuje wyświetlania PDF.
                    <a
                      href={currentDoc.content}
                      className="text-blue-600 underline ml-1"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Pobierz plik
                    </a>
                  </p>
                </iframe>
              ) : (
                <iframe
                  srcDoc={buildMathJaxHTML(
                    (currentDoc as Extract<DocItem, { type: 'latex' }>).content,
                    currentPdfTitle,
                  )}
                  width="100%"
                  height="100%"
                  className="border-0 rounded"
                  title="Dokument LaTeX"
                />
              )}
            </div>

            {/* Resize handles */}
            <div
              className="absolute bottom-0 right-0 w-4 h-4 cursor-se-resize opacity-60 hover:opacity-100 transition-opacity z-20"
              onMouseDown={handleResizeStart}
              style={{
                background:
                  'linear-gradient(-45deg, transparent 30%, #9ca3af 30%, #9ca3af 35%, transparent 35%, transparent 45%, #9ca3af 45%, #9ca3af 50%, transparent 50%, transparent 60%, #9ca3af 60%, #9ca3af 65%, transparent 65%)',
                borderRadius: '0 0 8px 0',
              }}
              title="Przeciągnij aby zmienić rozmiar"
            />

            <div
              className="absolute bottom-0 left-4 right-4 h-1 cursor-s-resize hover:bg-blue-200 hover:h-2 transition-all opacity-0 hover:opacity-70"
              onMouseDown={handleResizeStartBottom}
              title="Przeciągnij aby zmienić wysokość"
            />

            <div
              className="absolute top-4 right-0 bottom-4 w-1 cursor-e-resize hover:bg-blue-200 hover:w-2 transition-all opacity-0 hover:opacity-70"
              onMouseDown={handleResizeStartRight}
              title="Przeciągnij aby zmienić szerokość"
            />

            <div
              className="absolute bottom-0 left-0 w-4 h-4 cursor-sw-resize opacity-0 hover:opacity-40 hover:bg-blue-200 transition-all"
              onMouseDown={(e) => {
                e.preventDefault();
                setIsResizing(true);

                resizeStartRef.current = {
                  x: e.clientX,
                  y: e.clientY,
                  width: modalSize.width,
                  height: modalSize.height,
                };

                const handleMouseMove = (ev: MouseEvent) => {
                  const deltaX = ev.clientX - resizeStartRef.current.x;
                  const deltaY = ev.clientY - resizeStartRef.current.y;

                  const newWidth = Math.max(
                    400,
                    resizeStartRef.current.width - deltaX,
                  );
                  const newHeight = Math.max(
                    300,
                    resizeStartRef.current.height + deltaY,
                  );

                  setModalSize({ width: newWidth, height: newHeight });
                  setModalPosition((prev) => ({ ...prev, x: prev.x + deltaX }));
                };

                const handleMouseUp = () => {
                  setIsResizing(false);
                  document.removeEventListener('mousemove', handleMouseMove);
                  document.removeEventListener('mouseup', handleMouseUp);
                };

                document.addEventListener('mousemove', handleMouseMove);
                document.addEventListener('mouseup', handleMouseUp);
              }}
              title="Przeciągnij aby zmienić rozmiar"
            />

            {(isDragging || isResizing) && (
              <div className="absolute inset-0 border-2 border-blue-400 rounded-lg pointer-events-none opacity-50" />
            )}
          </div>
        </div>
      )}
    </div>
  );
}
