'use client';

import { useTableStore } from '@/stores/tableStore';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';

// ——— widoki Paid / Incurred ———
import { PaidTriangleView, IncurredTriangleView } from '@/features/triangle-view';
import PaidCLCoefficientsPage from '@/features/cl-coefficients/pages/PaidCLCoefficientsPage';

import IncurredCLCoefficientsPage from '@/features/cl-coefficients/pages/IncurredCLCoefficientsPage';
import DevJSelectorPaid from '@/features/FitCurve/FitCurvePaid';
import DevJSelectorPaidIncurred from '@/features/FitCurve/FitCurveIncurred';
import { PaidDevSummaryTab, IncurredDevSummaryTab } from '@/features/DevelopmentEnd';
import { PaidResultsPage, IncurredResultsPage } from '@/features/summary';
import { ResultsSummaryPage } from '@/features/ResultSummary';


const STEP_TABS = [
  'Trójkąt',
  'Współczynniki CL',
//  'Wybór dev_j',
  'Dopasowanie krzywej CL',
  'Wybór współczynników rozwoju',
  'Wyniki',
];

const METHOD_TABS: { id: 'paid' | 'incurred' | 'summary'; label: string }[] = [
  { id: 'paid', label: 'Metoda Paid' },
  { id: 'incurred', label: 'Metoda Incurred' },
  { id: 'summary', label: 'Results Summary' },
];

interface DeterministicMethodsTabProps {
  method: 'paid' | 'incurred' | 'summary';
  setMethod: (method: 'paid' | 'incurred' | 'summary') => void;
  paidStep: number;
  setPaidStep: (step: number) => void;
  incurredStep: number;
  setIncurredStep: (step: number) => void;
}

export function DeterministicMethodsTab({
  method,
  setMethod,
  paidStep,
  setPaidStep,
  incurredStep,
  setIncurredStep,
}: DeterministicMethodsTabProps) {
  const { clData } = useTableStore(); // eslint‑disable‑line @typescript-eslint/no-unused-vars
  const { finalDevJ } = useTrainDevideStoreDet(); // eslint‑disable‑line @typescript-eslint/no-unused-vars

  // Aktualny krok na podstawie wybranej metody
  const currentStep = method === 'paid' ? paidStep : incurredStep;
  const setCurrentStep = method === 'paid' ? setPaidStep : setIncurredStep;

  // Zmiana głównej zakładki BEZ resetowania kroków
  const handleChangeMethod = (newMethod: 'paid' | 'incurred' | 'summary') => {
    setMethod(newMethod);
    // Stan kroków jest teraz w HomeTabs - nic nie resetujemy
  };

  return (
    <div className="w-full text-white">
      {/* ──────────────────  Główne zakładki - Poziom 1  ────────────────── */}
      <div className="flex space-x-1 mb-6 border-b border-slate-700">
        {METHOD_TABS.map(({ id, label }) => (
          <button
            key={id}
            onClick={() => handleChangeMethod(id)}
            className={`px-6 py-3 text-base font-medium transition-all rounded-t-lg ${
              method === id
                ? 'bg-slate-800 border-t border-l border-r border-slate-600 border-b-2 border-b-blue-400 text-blue-400 shadow-lg'
                : 'text-slate-300 hover:text-blue-300 hover:bg-slate-800/30'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* ──────────────────  Pod‑zakładki kroków  ────────────────── */}
      {method !== 'summary' && (
        <div className="flex w-full rounded overflow-hidden border border-slate-700 bg-[#1e293b] mb-4">
          {STEP_TABS.map((label, index) => (
            <button
              key={index}
              onClick={() => setCurrentStep(index)}
              className={`flex-1 px-3 py-2 text-sm text-center transition-all ${
                currentStep === index
                  ? 'bg-[#0f172a] text-white border-r border-slate-700 border-b-4 border-b-blue-400 font-medium'
                  : 'hover:bg-slate-700 text-blue-200 border-r border-slate-700'
              }`}
            >
              {index + 1}. {label}
            </button>
          ))}
        </div>
      )}

      {/* ──────────────────  Treść kroków  ────────────────── */}
      {/**  🔹 Metoda Paid */}
      {method === 'paid' && (
        <>
          {paidStep === 0 && <PaidTriangleView />}
          {paidStep === 1 && <PaidCLCoefficientsPage />}
          {paidStep === 2 && <DevJSelectorPaid />}
          {paidStep === 3 && <PaidDevSummaryTab />}
          {paidStep === 4 && <PaidResultsPage />}
        </>
      )}

      {/**  🔹 Metoda Incurred */}
      {method === 'incurred' && (
        <>
          {incurredStep === 0 && <IncurredTriangleView />}
          {incurredStep === 1 && <IncurredCLCoefficientsPage />}
          {incurredStep === 2 && <DevJSelectorPaidIncurred />}
          {incurredStep === 3 && <IncurredDevSummaryTab />}
          {incurredStep === 4 && <IncurredResultsPage />}
        </>
      )}

      {/* ──────────────────  Results Summary (pusta)  ────────────────── */}
      {method === 'summary' && <ResultsSummaryPage />}
    </div>
  );
}
