'use client';

import { useTableStore } from '@/stores/tableStore';
import { PaidViewBootParam } from './PaidViewBootParam';
import { IncurredViewBootParam } from './IncurredViewBootParam';

export function UniversalTriangleViewBootParam() {
  const activeType = useTableStore((s) => s.activeStochTriangle ?? 'paid');

  if (activeType === 'incurred') {
    return <IncurredViewBootParam />;
  }

  return <PaidViewBootParam />;
}