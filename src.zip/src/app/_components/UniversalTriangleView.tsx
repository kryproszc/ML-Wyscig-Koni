'use client';

import { useTableStore } from '@/stores/tableStore';
import { PaidView } from './PaidView';
import { IncurredView } from './IncurredView';

export function UniversalTriangleView() {
  const activeType = useTableStore((s) => s.activeStochTriangle ?? 'paid');

  if (activeType === 'incurred') {
    return <IncurredView />;
  }

  return <PaidView />;
}