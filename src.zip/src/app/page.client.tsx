'use client'
import { HomeTabs } from "./_components/HomeTabs";
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { client } from '../client/client.gen';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60000,
    },
  },
});

// configure internal service client
client.setConfig({
  // set default base url for requests
  baseUrl: 'http://localhost:8000/',
  // set default headers for requests
  headers: {
    //Authorization: 'Bearer <token_from_service_client>',
  },
});

export default function HomePageClient() {
  return (
    <QueryClientProvider client={queryClient}>
      <div>
        <HomeTabs />
        <ReactQueryDevtools initialIsOpen={false} />
      </div>
    </QueryClientProvider>
  );
}
