'use client';
import { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { resetAllStores } from '@/lib/resetAllStores';
import { SheetSelect } from '@/components/SheetSelect';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { FileUploader, RangeSelector, DataAlert, LoadingOverlay } from '@/components/data-input';
import { useTableStore } from '@/stores/tableStore';
import { validateDataValues } from '@/utils/dataValidation';

const schema = z.object({ rowStart: z.coerce.number(), rowEnd: z.coerce.number(),
  colStart: z.coerce.number(), colEnd: z.coerce.number() });
type FormField = z.infer<typeof schema>;

export default function InputDataTab() {
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [alert, setAlert] = useState<{ type: 'error'|'warning'|'success'|'info'; msg: string }|null>(null);

  const store = useTableStore();
  const { setWorkbook, setUploadedFileName, getDefaultRange, setRangeAndUpdate } = store;

  const { register, handleSubmit, setValue, watch } = useForm<FormField>({ resolver: zodResolver(schema) });
  const watchValues = watch();

  /* … synchronizacje zakresu ze store dokładnie jak wcześniej … */

  /* ————— handleFileLoad ————— */
  const handleFileLoad = (file: File) => {
    const reader = new FileReader();
    reader.onloadstart = () => { setIsLoading(true); setProgress(0); };
    reader.onprogress   = (e) => e.lengthComputable && setProgress(Math.round(e.loaded / e.total * 100));
    reader.onload       = (e) => {
      try {
        const wb = XLSX.read(e.target?.result as string, { type: 'binary' });
        resetAllStores(); setWorkbook(wb); setUploadedFileName(file.name);
        store.setSelectedSheetName(wb.SheetNames[0]);
      } catch (err) { setAlert({ type: 'error', msg: (err as Error).message }); }
      setIsLoading(false); setProgress(0);
    };
    reader.onerror = () => { setAlert({ type: 'error', msg: 'Błąd wczytywania pliku.' }); setIsLoading(false); };
    reader.readAsBinaryString(file);
  };

  /* ————— onSubmit ————— */
  const onSubmit = (form: FormField) => {
    setRangeAndUpdate({ startRow: form.rowStart, endRow: form.rowEnd, startCol: form.colStart, endCol: form.colEnd });

    setTimeout(() => {
      const s = useTableStore.getState();
      if (!s.isValid)                return setAlert({ type: 'error', msg: s.validationErrorReason || 'Zły format.' });
      if (JSON.stringify(s.selectedSheetJSON) === JSON.stringify(s.previousSheetJSON))
                                      return setAlert({ type: 'info', msg: 'Brak zmian.' });
      if (!validateDataValues(s.selectedSheetJSON || []))
                                      return setAlert({ type: 'warning', msg: 'Braki lub błędne wartości.' });
      setAlert({ type: 'success', msg: 'Dane poprawnie wczytane.' });
    }, 0);
  };

  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)} className="p-4 border rounded flex flex-col gap-4">
        <Card>
          <CardHeader><CardTitle>Import Excel</CardTitle></CardHeader>
          <CardContent className="space-y-4">

            {/* uploader */}
            <FileUploader onLoad={handleFileLoad} loadedFileName={store.uploadedFileName} />

            {/* arkusz */}
            <div><SheetSelect /></div>

            {/* zakres */}
            <RangeSelector
              value={{ rowStart: watchValues.rowStart, rowEnd: watchValues.rowEnd,
                       colStart: watchValues.colStart, colEnd: watchValues.colEnd }}
              onChange={(r: { rowStart: number; rowEnd: number; colStart: number; colEnd: number }) => { 
                setValue('rowStart', r.rowStart); 
                setValue('rowEnd', r.rowEnd);
                setValue('colStart', r.colStart); 
                setValue('colEnd', r.colEnd); 
              }}
              onAutoDetect={() => {
                const r = getDefaultRange(); r && Object.entries(r).forEach(([k, v]) => setValue(k as any, v));
              }}
              disabled={!store.workbook}
            />
          </CardContent>
          <CardFooter><Button type="submit" disabled={!store.workbook}>Wybierz</Button></CardFooter>
        </Card>
      </form>

      {alert && (
        <DataAlert
          open={true}
          onOpenChange={() => setAlert(null)}
          variant={alert.type}
          message={alert.msg}
        />
      )}
      <LoadingOverlay visible={isLoading} progress={progress} />
    </>
  );
}
