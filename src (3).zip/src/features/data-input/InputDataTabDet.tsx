'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as XLSX from 'xlsx';
import { useEffect, useState, useRef } from 'react';
import { useDetailTableStore } from '@/stores/useDetailTableStore';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useTrainDevideStoreSummary } from '@/stores/trainDevideStoreSummary';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { useInflacjaStore } from '@/stores/inflacjaStore';
import { inflationApiService } from '@/services/inflationApi';
import { useUserStore } from '@/app/_components/useUserStore';
import { z } from 'zod';
import { SheetSelectDet } from '@/components/SheetSelectDet';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardFooter,
} from '@/components/ui/card';

import type { DataType } from '@/components/DataTypeSelector';
import { convertIncrementalToCumulative } from '@/utils/dataConversion';
import { validateDataValues, ValidationPresets } from '@/utils/dataValidation';
import Modal from '@/components/Modal';
import { 
  InflationSelector, 
  parsePolishNumber, 
  isMostlyNonNumeric, 
  looksLikeYears, 
  looksLikeDevPeriods,
  DataInputDialogs,
  DataInputLoading,
  FileUploadSection,
  DataConfigurationSection 
} from '@/shared/components/data-input';

const schema = z.object({
  rowStart: z.coerce.number().min(1),
  rowEnd: z.coerce.number().min(1),
  colStart: z.coerce.number().min(1),
  colEnd: z.coerce.number().min(1),
  file: z.any(),
});
type FormField = z.infer<typeof schema>;

/* ---------- DODATKOWA WALIDACJA (dziury, nienumeryczne itd.) ---------- */
function localValidateDataValues(data: any[][]): boolean {
  // Ta funkcja została przeniesiona do @/utils/dataValidation
  // Używamy teraz importowanej wersji z ValidationPresets dla Paid
  const result = validateDataValues(data, ValidationPresets.paid());
  return result.isValid;
}

/* --------------------------------------------------------------------- */
export function InputDataTabDet() {
  /* ---------- Lokalny UI‑owy stan ---------- */
  const [showDialog, setShowDialog] = useState(false);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [showWarningDialog, setShowWarningDialog] = useState(false);
  const [showWarningModal, setShowWarningModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [pendingFormData, setPendingFormData] = useState<FormField | null>(null);
  const [showInflationErrorModal, setShowInflationErrorModal] = useState(false);
  const [showInflationSuccessModal, setShowInflationSuccessModal] = useState(false);
  const [inflationErrorMessage, setInflationErrorMessage] = useState('');
  const [showInflationWarningModal, setShowInflationWarningModal] = useState(false);
  const [pendingInflationData, setPendingInflationData] = useState<any>(null);



  /* ---------- Zustanda – store „detaliczny” ---------- */
  const {
    workbook,
    isValid,
    selectedSheetJSON,
    previousSheetJSON,
    validationErrorReason,
    setWorkbook,
    getDefaultRange,
    setRangeAndUpdate,
    uploadedFileName,
    setUploadedFileName,
    selectedSheetName,
    lastApprovedSettings,
    setLastApprovedSettings,
  } = useDetailTableStore();

  const { 
    detRowLabels: rowLabels, 
    detColumnLabels: columnLabels, 
    setDetRowLabels: setRowLabels, 
    setDetColumnLabels: setColumnLabels,
    globalRowLabels,
    globalColumnLabels,
    lastLoadedFile
  } = useLabelsStore();

  // Store Paid dla funkcji czyszczących
  const paidStore = useTrainDevideStoreDet();
  const summaryStore = useTrainDevideStoreSummary();

const setPaidTriangle = useTrainDevideStoreDet((s) => s.setPaidTriangle);
const setPaidTriangle_bez_inf = useTrainDevideStoreDet((s) => s.setPaidTriangle_bez_inf);
const paidTriangle_bez_inf = useTrainDevideStoreDet((s) => s.paidTriangle_bez_inf);

  // Store dla ustawień input'a - używamy indywidualnych ustawień z detailTableStore
  const {
    dataType,
    setDataType,
    incrementDataGeneration,
    hasHeaders,
    setHasHeaders,
    useInflation,
    setUseInflation,
  } = useDetailTableStore();

  // Store inflacji - do sprawdzania czy są dane
  const { inflacjaTriangle, selectedInflacjaLine, availableInflacjaLines } = useInflacjaStore();

  // User ID dla API
  const userId = useUserStore((s) => s.userId);

  /* ---------- React‑hook‑form ---------- */
  const {
    register,
    handleSubmit,
    watch,
    setValue,
  } = useForm<FormField>({
    resolver: zodResolver(schema),
    defaultValues: {
      rowStart: 1,
      rowEnd: 1,
      colStart: 1,
      colEnd: 1,
    },
  });

  const file = watch('file');

  /* ---------- Synchronizacja zakresu z store’em ---------- */
  // Używamy normalnych selektorów zamiast subscribe  
  const startRow = useDetailTableStore((s) => s.startRow);
  const endRow = useDetailTableStore((s) => s.endRow);
  const startCol = useDetailTableStore((s) => s.startCol);
  const endCol = useDetailTableStore((s) => s.endCol);
  
  useEffect(() => {
    setValue('rowStart', startRow);
    setValue('rowEnd', endRow);
    setValue('colStart', startCol);
    setValue('colEnd', endCol);
  }, [setValue, startRow, endRow, startCol, endCol]);

  /* ---------- Reset dialogów przy montowaniu komponentu ---------- */
  useEffect(() => {
    // Reset wszystkich dialogów gdy użytkownik wraca do zakładki
    setShowDialog(false);
    setShowSuccessDialog(false);
    setShowWarningDialog(false);
  }, []); // Wykonaj tylko raz przy montowaniu



  /* ---------- Ładowanie pliku ---------- */
  const handleFileLoad = () => {
    const f = file?.[0];
    if (!f) {
      alert('Najpierw wybierz plik.');
      return;
    }

    const reader = new FileReader();

    reader.onloadstart = () => {
      setIsLoading(true);
      setProgress(0);
    };

    reader.onprogress = (e) => {
      if (e.lengthComputable) {
        setProgress(Math.round((e.loaded / e.total) * 100));
      }
    };

    reader.onload = (evt) => {
      const binaryStr = evt.target?.result;
      if (typeof binaryStr === 'string') {
        try {
          const wb = XLSX.read(binaryStr, { type: 'binary' });

          // 🆕 Wyczyść paidTriangle PRZED resetowaniem DetailTableStore
          console.log('🧹 [handleFileLoad] Czyszczę paidTriangle przed wczytaniem nowego pliku...');
          paidStore.setPaidTriangle([]);
          paidStore.setPaidTriangle_bez_inf(null); // Wyczyść też dane bez inflacji
          
          // 🆕 Wyczyść trainDevideDet żeby wymusić przeliczenie w zakładce CL
          console.log('🧹 [handleFileLoad] Czyszczę trainDevideDet...');
          paidStore.setTrainDevideDet(undefined);
          
          // Reset tylko store'a dla zakładki Det (nie wszystkich store'ów)
          useDetailTableStore.getState().resetData();
          setWorkbook(wb);
          useDetailTableStore
            .getState()
            .setSelectedSheetName(wb.SheetNames[0]);

          setUploadedFileName(f.name);
        } catch (err) {
          alert('Błąd podczas wczytywania pliku: ' + (err as Error).message);
        }
      } else {
        alert('Niepoprawny typ danych z FileReadera.');
      }

      setIsLoading(false);
      setProgress(0);
    };

    reader.onerror = () => {
      alert('Błąd podczas wczytywania pliku.');
      setIsLoading(false);
    };

    reader.readAsBinaryString(f);
  };

  /* ---------- Wykryj zakres automatycznie ---------- */
  const handleAutoRange = () => {
    const range = getDefaultRange();
    if (!range) return;
    setValue('rowStart', range.startRow);
    setValue('rowEnd', range.endRow);
    setValue('colStart', range.startCol);
    setValue('colEnd', range.endCol);
  };



  /* ---------- Submit formularza ---------- */
  const onSubmit = async (data: FormField) => {
    console.log('📝 Submit formularza:', data);
    
    // Sprawdź czy są już wczytane dane paid - jeśli tak, pokaż modal ostrzeżenia
    const currentPaidTriangle = paidStore.paidTriangle;
    const hasExistingData = currentPaidTriangle && currentPaidTriangle.length > 0;
    
    if (hasExistingData) {
      console.log('⚠️ Wykryto istniejące dane paid, pokazuję modal ostrzeżenia');
      setPendingFormData(data);
      setShowWarningModal(true);
      return;
    }

    // Jeśli nie ma danych, wykonaj normalnie
    console.log('✅ Brak istniejących danych, przetwarzam od razu');
    await processFormData(data);
  };

  // Funkcja do przetwarzania danych formularza
const processFormData = async (data: FormField, showDialogs = true) => {
  console.log('🔄 [processFormData] Rozpoczynam przetwarzanie danych...', data, 'showDialogs:', showDialogs);

  // reset dialogów
  setShowDialog(false);
  setShowSuccessDialog(false);
  setShowWarningDialog(false);

  setRangeAndUpdate({
    startRow: data.rowStart,
    endRow: data.rowEnd,
    startCol: data.colStart,
    endCol: data.colEnd,
  });

  setTimeout(async () => {
    let { isValid: v, selectedSheetJSON: json, previousSheetJSON: prev } =
      useDetailTableStore.getState();

    // (1) ewentualna konwersja inkrementalnych -> skumulowane
    if (dataType === 'incremental' && json) {
      const converted = convertIncrementalToCumulative(json);
      useDetailTableStore.setState({ selectedSheetJSON: converted });
      json = converted;
    }

// (2) budowa body + etykiet zgodnie z hasHeaders
let body: any[][] = [];
let rowNames: string[] = [];
let colNames: string[] = [];

if (json && json.length > 1) {
  if (hasHeaders) {
    // ✅ Mamy podpisy – wyciągamy je z pierwszego wiersza/kolumny
    colNames = (json[0] ?? []).slice(1).map(c => String(c ?? ''));
    rowNames = json.slice(1).map(r => String((r && r[0]) ?? ''));
    body = json.slice(1).map(r => r.slice(1)); // samo „ciało”
  } else {
    // ❌ Brak podpisów – generujemy 1..N po wycięciu pierwszego wiersza/kolumny
    body = json.slice(1).map(r => r.slice(1));
    rowNames = Array.from({ length: body.length }, (_, i) => String(i + 1));
    colNames = Array.from({ length: body[0]?.length || 0 }, (_, i) => String(i + 1));
  }

  // zapis etykiet do store'a
  setRowLabels(rowNames);
  setColumnLabels(colNames);

  // numericTriangle (number|null) na bazie body z polskim formatowaniem liczb
  let numericTriangle: (number | null)[][] = body.map(row =>
    row.map(cell => parsePolishNumber(cell))
  );

  setPaidTriangle(numericTriangle);
  // Zapisz również surowe dane bez inflacji
  setPaidTriangle_bez_inf(numericTriangle);

  // widok tabeli do podglądu (string|number)
  const sheetForStore: (string | number)[][] = body.map(row =>
    row.map(cell => (cell == null ? '' : typeof cell === 'number' ? cell : String(cell)))
  );
  useTrainDevideStoreDet.setState({ selectedSheetDet: sheetForStore });
}



    // (3) walidacje i komunikaty - pokazuj tylko jeśli showDialogs = true
    if (showDialogs) {
      if (!v) {
        setShowDialog(true);
      } else if (!localValidateDataValues(body || [])) {
        setShowWarningDialog(true);
      } else {
        setShowSuccessDialog(true);
        setLastApprovedSettings({
          sheetName: selectedSheetName || null,
          rowStart: data.rowStart,
          rowEnd: data.rowEnd,
          colStart: data.colStart,
          colEnd: data.colEnd,
          hasHeaders,
          dataType,
          useInflation,
        });
      }
    } else {
      // Przy automatycznym przeliczaniu - tylko zapisz ustawienia bez dialogów
      if (v && localValidateDataValues(body || [])) {
        setLastApprovedSettings({
          sheetName: selectedSheetName || null,
          rowStart: data.rowStart,
          rowEnd: data.rowEnd,
          colStart: data.colStart,
          colEnd: data.colEnd,
          hasHeaders,
          dataType,
          useInflation,
        });
      }
    }
  }, 0);
};

  // Obsługa potwierdzenia w modalu
  const handleConfirmDataReplace = () => {
    console.log('🚨 [handleConfirmDataReplace] Użytkownik potwierdził wczytanie nowych danych');
    setShowWarningModal(false);
    
    // Wyczyść wszystkie dane paid
    console.log('🧹 Czyszczę wszystkie dane paid...');
    paidStore.setPaidTriangle([]);
    paidStore.setPaidTriangle_bez_inf(null); // Wyczyść też dane bez inflacji
    paidStore.setTrainDevideDet(undefined);
    paidStore.clearDevJResults();
    paidStore.setFinalDevJ(undefined);
    paidStore.clearAllDevFinalValues();
    paidStore.clearFitCurveData();
    paidStore.clearDevSummaryData();
    
    // Wyczyść tabele ResultSummary
    summaryStore.clearSummaryData();
    
    // Wyczyść store dla zakładki Det
    useDetailTableStore.getState().resetData();
    
    if (pendingFormData) {
      console.log('📝 Przetwarzam odłożone dane formularza...');
      
      // Wymusimy odświeżenie komponentów
      incrementDataGeneration();
      
      // Małe opóźnienie żeby React zdążył przetworzyć zmiany
      setTimeout(async () => {
        await processFormData(pendingFormData);
      }, 0);
      
      setPendingFormData(null);
    }
  };

  // Obsługa anulowania w modalu
  const handleCancelDataReplace = () => {
    console.log('❌ [handleCancelDataReplace] Użytkownik anulował wczytanie danych');
    setShowWarningModal(false);
    setPendingFormData(null);
  };

  /* ---------- Nakładanie inflacji na już wczytane dane ---------- */
  const handleApplyInflation = async () => {
    const currentPaidTriangle = paidStore.paidTriangle;
    
    if (!currentPaidTriangle || currentPaidTriangle.length === 0) {
      setInflationErrorMessage('Najpierw wczytaj dane paid.');
      setShowInflationErrorModal(true);
      return;
    }

    if (!useInflation) {
      setInflationErrorMessage('Włącz opcję "Uwzględnij współczynniki inflacji".');
      setShowInflationErrorModal(true);
      return;
    }

    if (selectedInflacjaLine === null || !userId) {
      setInflationErrorMessage('Brak danych inflacji lub user ID.');
      setShowInflationErrorModal(true);
      return;
    }

    // Sprawdź czy są już obliczone dane - jeśli tak, pokaż modal ostrzeżenia
    const hasCalculatedData = (
      paidStore.trainDevideDet?.length ||
      paidStore.devJResults?.length ||
      paidStore.sigmaResults?.length ||
      paidStore.devJ?.length ||
      paidStore.sigma?.length ||
      paidStore.sd?.length
    );
    
    if (hasCalculatedData) {
      console.log('⚠️ Wykryto obliczone dane, pokazuję modal ostrzeżenia inflacji');
      setPendingInflationData({ currentPaidTriangle, inflationLine: availableInflacjaLines.find(line => line.index === selectedInflacjaLine) });
      setShowInflationWarningModal(true);
      return;
    }

    // Jeśli nie ma obliczonych danych, wykonaj normalnie
    console.log('✅ Brak obliczonych danych, nakładam inflację od razu');
    await processInflation();
  };

  // Funkcja do nakładania inflacji
  const processInflation = async () => {
    const currentPaidTriangle = paidStore.paidTriangle;
    const inflationLine = availableInflacjaLines.find(line => line.index === selectedInflacjaLine);
    
    if (!currentPaidTriangle || currentPaidTriangle.length === 0) {
      setInflationErrorMessage('Brak danych paid do przetworzenia.');
      setShowInflationErrorModal(true);
      return;
    }
    
    if (!inflationLine) {
      setInflationErrorMessage('Nie znaleziono wybranej linii inflacji');
      setShowInflationErrorModal(true);
      return;
    }

    if (!userId) {
      setInflationErrorMessage('Brak user ID.');
      setShowInflationErrorModal(true);
      return;
    }

    try {
      console.log('🔥 [processInflation] Nakładanie inflacji na wczytane dane...');
      
      setIsLoading(true);
      setProgress(50);
      
      // Przygotuj request
      const inflationRequest = {
        user_id: userId,
        triangle: currentPaidTriangle || [],
        inflationVector: inflationLine.values,
        triangleMetadata: {
          rowLabels: rowLabels,
          columnLabels: columnLabels,
          dataType: dataType,
          hasHeaders: hasHeaders
        }
      };

      console.log('📊 [processInflation] Request dla backendu - podstawowe info:', {
        triangleRows: currentPaidTriangle?.length || 0,
        triangleCols: currentPaidTriangle?.[0]?.length || 0,
        inflationVectorLength: inflationLine.values.length
      });

      console.log('🚀 [processInflation] DOKŁADNY REQUEST WYSYŁANY NA BACKEND /calc/paid/inflation:', {
        user_id: inflationRequest.user_id,
        triangle: inflationRequest.triangle,
        inflationVector: inflationRequest.inflationVector,
        triangleMetadata: inflationRequest.triangleMetadata
      });

      // Walidacja
      const validation = inflationApiService.validateRequest(inflationRequest);
      if (!validation.isValid) {
        throw new Error(`Błędy walidacji: ${validation.errors.join(', ')}`);
      }

      // Wyslij na backend
      const response = await inflationApiService.applyInflationToTriangle(inflationRequest);

      if (!response.success) {
        throw new Error(response.error || 'Nieznany błąd backendu');
      }

      // Jeśli nie mamy jeszcze zapisanych oryginalnych danych, zapisz je teraz
      if (!paidTriangle_bez_inf) {
        setPaidTriangle_bez_inf(currentPaidTriangle);
      }

      // Zastąp dane skorygowanymi o inflację
      setPaidTriangle(response.adjustedTriangle);
      
      // 🔥 WYMUSIMY ODŚWIEŻENIE KOMPONENTÓW - kluczowe dla przeliczenia współczynników CL
      incrementDataGeneration();
      
      // Wyczyść wszystkie obliczone dane z zakładek (jak przy wczytywaniu nowych danych)
      console.log('🔄 [processInflation] Czyszczę wszystkie obliczone dane po nałożeniu inflacji...');
      paidStore.setTrainDevideDet(undefined);
      paidStore.clearDevJResults();
      paidStore.setFinalDevJ(undefined);
      paidStore.clearAllDevFinalValues();
      paidStore.clearFitCurveData();
      paidStore.clearDevSummaryData();
      
      // Wyczyść również wyniki obliczeń CL (devJ, sigma, sd)
      paidStore.setDevJ([]);
      paidStore.setSigma([]);
      paidStore.setSd([]);
      
      // Wyczyść tabele ResultSummary
      summaryStore.clearSummaryData();
      
      console.log('✅ [processInflation] Inflacja nakoładana pomyślnie');
      setShowInflationSuccessModal(true);

    } catch (error) {
      console.error('❌ [processInflation] Błąd:', error);
      const errorMessage = error instanceof Error ? error.message : 'Nieznany błąd';
      setInflationErrorMessage(`Błąd podczas nakładania inflacji: ${errorMessage}`);
      setShowInflationErrorModal(true);
    } finally {
      setIsLoading(false);
      setProgress(0);
    }
  };

  // Obsługa potwierdzenia modalu inflacji
  const handleConfirmInflation = () => {
    console.log('🚨 [handleConfirmInflation] Użytkownik potwierdził nałożenie inflacji');
    setShowInflationWarningModal(false);
    setPendingInflationData(null);
    processInflation();
  };

  // Obsługa anulowania modalu inflacji
  const handleCancelInflation = () => {
    console.log('❌ [handleCancelInflation] Użytkownik anulował nałożenie inflacji');
    setShowInflationWarningModal(false);
    setPendingInflationData(null);
  };



  





  /* ------------------------------- JSX ------------------------------- */
  return (
    <div>
      {/* ---------- FORMULARZ ---------- */}
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="p-4 border rounded flex flex-col gap-4"
      >
        <Card>
          <CardHeader>
            <CardTitle>Wprowadź trójkąt danych paid, który wykorzystasz w dalszej analizie</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* --- Plik --- */}
            <FileUploadSection
              file={file}
              uploadedFileName={uploadedFileName}
              onFileChange={(e) => setValue('file', e.target.files)}
              onFileLoad={handleFileLoad}
              isLoading={isLoading}
            />

            {/* --- Arkusz --- */}
            <div>
              <Label>Wybór arkusza</Label>
              {/* Jeśli Twój SheetSelect nie przyjmuje „store”, usuń ten prop */}
              <SheetSelectDet />
            </div>

          <CardHeader>
            <CardTitle>Podaj zakres danych, które chcesz wczytać.</CardTitle>
          </CardHeader>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Wiersz początkowy</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('rowStart')}
                />
              </div>
              <div>
                <Label>Wiersz końcowy</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('rowEnd')}
                />
              </div>
              <div>
                <Label>Kolumna początkowa</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('colStart')}
                />
              </div>
              <div>
                <Label>Kolumna końcowa</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('colEnd')}
                />
              </div>
            </div>

            <Button
              type="button"
              onClick={handleAutoRange}
              variant="outline"
              disabled={!workbook}
              className="bg-blue-500 text-white"
            >
              Wykryj zakres automatycznie
            </Button>

            {/* --- Konfiguracja danych --- */}
            <DataConfigurationSection
              hasHeaders={hasHeaders}
              onHeadersChange={setHasHeaders}
              dataType={dataType}
              onDataTypeChange={setDataType}
              hasInflationData={Object.keys(inflacjaTriangle).length > 0 && selectedInflacjaLine !== null}
              useInflation={useInflation}
              onInflationChange={setUseInflation}
            />

            {/* Przycisk Wybierz - po całej konfiguracji */}
            <Button
              type="submit"
              className="bg-blue-500 text-white w-full"
              disabled={!workbook}
            >
              Wybierz
            </Button>
          </CardContent>
          <CardFooter>
            <Button
              type="button"
              onClick={handleApplyInflation}
              className="bg-orange-500 text-white hover:bg-orange-600 w-full"
              disabled={!paidStore.paidTriangle || paidStore.paidTriangle.length === 0 || !useInflation}
            >
              Nałóż inflację
            </Button>
          </CardFooter>
        </Card>
      </form>

      {/* ---------- DIALOGI ---------- */}
      <DataInputDialogs
        showErrorDialog={showDialog}
        onErrorDialogChange={setShowDialog}
        errorMessage={validationErrorReason || 'Dane wejściowe nie spełniają określonego formatu. Sprawdź dane!'}
        showWarningDialog={showWarningDialog}
        onWarningDialogChange={setShowWarningDialog}
        showSuccessDialog={showSuccessDialog}
        onSuccessDialogChange={setShowSuccessDialog}
        successMessage={dataType === 'incremental' 
          ? "Dane inkrementalne zostały przekonwertowane na skumulowane i poprawnie wczytane (Det)."
          : "Dane skumulowane zostały poprawnie wczytane (Det)."}
        showInfoDialog={false}
        onInfoDialogChange={() => {}}
      />

      {/* ---------- DIALOGI INFLACJI ---------- */}
      <DataInputDialogs
        showErrorDialog={showInflationErrorModal}
        onErrorDialogChange={setShowInflationErrorModal}
        errorMessage={inflationErrorMessage}
        showWarningDialog={false}
        onWarningDialogChange={() => {}}
        showSuccessDialog={showInflationSuccessModal}
        onSuccessDialogChange={setShowInflationSuccessModal}
        successMessage="Inflacja została pomyślnie nałożona na dane paid."
        showInfoDialog={false}
        onInfoDialogChange={() => {}}
      />

      {/* ---------- LOADING ---------- */}
      <DataInputLoading 
        isLoading={isLoading} 
        progress={progress} 
      />

      {/* MODAL OSTRZEŻENIA O UTRACIE DANYCH */}
      <Modal
        title="Ostrzeżenie"
        message="Czy na pewno chcesz wczytać nowe dane? Wszystkie dotychczasowe obliczenia w zakładce Metody deterministyczne zostaną utracone."
        isOpen={showWarningModal}
        onConfirm={handleConfirmDataReplace}
        onCancel={handleCancelDataReplace}
      />

      {/* MODAL OSTRZEŻENIA PRZED NAŁOŻENIEM INFLACJI */}
      <Modal
        title="Ostrzeżenie"
        message="Czy na pewno chcesz nałożyć inflację? Wszystkie dotychczasowe obliczenia w zakładce Metody deterministyczne zostaną utracone."
        isOpen={showInflationWarningModal}
        onConfirm={handleConfirmInflation}
        onCancel={handleCancelInflation}
      />










    </div>
  );
}


