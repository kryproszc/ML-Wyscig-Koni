// Eksport komponentów wczytywania danych
export { InputDataTabDet } from './InputDataTabDet';
export { InputDataTabIncurred } from './InputDataTabIncurred';

// Główny komponent do użycia w innych miejscach
export { InputDataTabDet as InputDataTab } from './InputDataTabDet';
