'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as XLSX from 'xlsx';
import { useEffect, useState } from 'react';
import { useIncurredTableStore } from '@/stores/useIncurredTableStore';
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useTrainDevideStoreSummary } from '@/stores/trainDevideStoreSummary';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { useInflacjaStore } from '@/stores/inflacjaStore';
import { inflationApiService } from '@/services/inflationApi';
import { useUserStore } from '@/app/_components/useUserStore';
import { z } from 'zod';
import { SheetSelectIncurred } from '@/components/SheetSelectIncurred';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardFooter,
} from '@/components/ui/card';

import type { DataType } from '@/components/DataTypeSelector';
import { convertIncrementalToCumulative } from '@/utils/dataConversion';
import { validateDataValues, ValidationPresets } from '@/utils/dataValidation';
import Modal from '@/components/Modal';
import { 
  InflationSelector, 
  parsePolishNumber, 
  isMostlyNonNumeric, 
  looksLikeYears, 
  looksLikeDevPeriods,
  DataInputDialogs,
  DataInputLoading,
  FileUploadSection,
  DataConfigurationSection 
} from '@/shared/components/data-input';

const schema = z.object({
  rowStart: z.coerce.number().min(1),
  rowEnd: z.coerce.number().min(1),
  colStart: z.coerce.number().min(1),
  colEnd: z.coerce.number().min(1),
  file: z.any(),
});
type FormField = z.infer<typeof schema>;

/* ---------- DODATKOWA WALIDACJA (dziury, nienumeryczne itd.) ---------- */
function localValidateDataValues(data: any[][]): boolean {
  // Ta funkcja została przeniesiona do @/utils/dataValidation
  // Używamy teraz importowanej wersji z ValidationPresets dla Incurred
  const result = validateDataValues(data, ValidationPresets.paid()); // Używamy paid bo nie ma incurred preset
  return result.isValid;
}

/* --------------------------------------------------------------------- */
export function InputDataTabIncurred() {
  /* ---------- Lokalny UI‑owy stan ---------- */
  const [showDialog, setShowDialog] = useState(false);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [showNoChangesDialog, setShowNoChangesDialog] = useState(false);
  const [showWarningDialog, setShowWarningDialog] = useState(false);
  const [showWarningModal, setShowWarningModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [pendingFormData, setPendingFormData] = useState<FormField | null>(null);
  const [showInflationErrorModal, setShowInflationErrorModal] = useState(false);
  const [showInflationSuccessModal, setShowInflationSuccessModal] = useState(false);
  const [inflationErrorMessage, setInflationErrorMessage] = useState('');
  const [showInflationWarningModal, setShowInflationWarningModal] = useState(false);
  const [pendingInflationData, setPendingInflationData] = useState<any>(null);

  /* ---------- Zustanda – store „incurred" ---------- */
  const {
    workbook,
    isValid,
    selectedSheetJSON,
    previousSheetJSON,
    validationErrorReason,
    setWorkbook,
    getDefaultRange,
    setRangeAndUpdate,
    uploadedFileName,
    setUploadedFileName,
    selectedSheetName,
    lastApprovedSettings,
    setLastApprovedSettings,
  } = useIncurredTableStore();

  const { 
    incurredRowLabels: rowLabels, 
    incurredColumnLabels: columnLabels, 
    setIncurredRowLabels: setRowLabels, 
    setIncurredColumnLabels: setColumnLabels,
    detRowLabels: paidRowLabels,
    detColumnLabels: paidColumnLabels,
    globalRowLabels,
    globalColumnLabels,
    lastLoadedFile
  } = useLabelsStore();

  // Store Incurred dla funkcji czyszczących
  const incurredStore = useTrainDevideStoreIncurred();
  const summaryStore = useTrainDevideStoreSummary();

  // 🆕 Store Paid dla dostępu do danych paid bez inflacji
  const paidStore = useTrainDevideStoreDet();

  const setIncurredTriangle = useTrainDevideStoreIncurred((s) => s.setIncurredTriangle);
  const setIncurredTriangle_bez_inf = useTrainDevideStoreIncurred((s) => s.setIncurredTriangle_bez_inf);
  const incurredTriangle_bez_inf = useTrainDevideStoreIncurred((s) => s.incurredTriangle_bez_inf);
  const setReserve = useTrainDevideStoreIncurred((s) => s.setReserve);
  const reserve = useTrainDevideStoreIncurred((s) => s.reserve);

  // Store dla ustawień input'a - używamy indywidualnych ustawień z incurredTableStore
  const {
    dataType,
    setDataType,
    incrementDataGeneration,
    hasHeaders,
    setHasHeaders,
    useInflation,
    setUseInflation,
  } = useIncurredTableStore();

  // Store inflacji - do sprawdzania czy są dane
  const { inflacjaTriangle, selectedInflacjaLine, availableInflacjaLines } = useInflacjaStore();

  // User ID dla API
  const userId = useUserStore((s) => s.userId);

  /* ---------- React‑hook‑form ---------- */
  const {
    register,
    handleSubmit,
    watch,
    setValue,
  } = useForm<FormField>({
    resolver: zodResolver(schema),
    defaultValues: {
      rowStart: 1,
      rowEnd: 1,
      colStart: 1,
      colEnd: 1,
    },
  });

  const file = watch('file');

  // Używamy normalnych selectorów zamiast subscribe
  const startRow = useIncurredTableStore((s) => s.startRow);
  const endRow = useIncurredTableStore((s) => s.endRow);
  const startCol = useIncurredTableStore((s) => s.startCol);
  const endCol = useIncurredTableStore((s) => s.endCol);

  /* ---------- Synchronizacja zakresu z form ---------- */
  useEffect(() => {
    setValue('rowStart', startRow);
    setValue('rowEnd', endRow);
    setValue('colStart', startCol);
    setValue('colEnd', endCol);
  }, [setValue, startRow, endRow, startCol, endCol]);

  /* ---------- Ładowanie pliku ---------- */
  const handleFileLoad = () => {
    const f = file?.[0];
    if (!f) {
      alert('Najpierw wybierz plik.');
      return;
    }

    const reader = new FileReader();

    reader.onloadstart = () => {
      setIsLoading(true);
      setProgress(0);
    };

    reader.onprogress = (e) => {
      if (e.lengthComputable) {
        setProgress(Math.round((e.loaded / e.total) * 100));
      }
    };

    reader.onload = (evt) => {
      const binaryStr = evt.target?.result;
      if (typeof binaryStr === 'string') {
        try {
          const wb = XLSX.read(binaryStr, { type: 'binary' });

          // 🆕 Wyczyść incurredTriangle PRZED resetowaniem IncurredTableStore
          console.log('🧹 [handleFileLoad] Czyszczę incurredTriangle przed wczytaniem nowego pliku...');
          incurredStore.setIncurredTriangle([]);
          incurredStore.setIncurredTriangle_bez_inf(null); // Wyczyść też dane bez inflacji
          incurredStore.setReserve(null); // Wyczyść też dane reserve
          
          // 🆕 Wyczyść trainDevideIncurred żeby wymusić przeliczenie w zakładce CL
          console.log('🧹 [handleFileLoad] Czyszczę trainDevideIncurred...');
          incurredStore.setTrainDevideIncurred(undefined);
          
          // Reset tylko store'a dla zakładki Incurred (nie wszystkich store'ów)
          useIncurredTableStore.getState().resetData();
          setWorkbook(wb);
          if (wb.SheetNames && wb.SheetNames.length > 0) {
            const firstSheetName = wb.SheetNames[0];
            if (firstSheetName) {
              useIncurredTableStore
                .getState()
                .setSelectedSheetName(firstSheetName);
            }
          }

          setUploadedFileName(f.name);
        } catch (err) {
          alert('Błąd podczas wczytywania pliku: ' + (err as Error).message);
        }
      } else {
        alert('Niepoprawny typ danych z FileReadera.');
      }

      setIsLoading(false);
      setProgress(0);
    };

    reader.onerror = () => {
      alert('Błąd podczas wczytywania pliku.');
      setIsLoading(false);
    };

    reader.readAsBinaryString(f);
  };

  /* ---------- Wykryj zakres automatycznie ---------- */
  const handleAutoRange = () => {
    const range = getDefaultRange();
    if (!range) return;
    setValue('rowStart', range.startRow);
    setValue('rowEnd', range.endRow);
    setValue('colStart', range.startCol);
    setValue('colEnd', range.endCol);
  };

  /* ---------- Sprawdzanie czy ustawienia się zmieniły ---------- */
  const hasSettingsChanged = (newData: FormField) => {
    console.log('🔍 Sprawdzanie zmian ustawień:', {
      selectedSheetJSON: selectedSheetJSON?.length || 0,
      lastApprovedSettings,
      currentSheetName: selectedSheetName,
      newData,
      currentHasHeaders: hasHeaders,
      currentDataType: dataType
    });

    // Sprawdź czy nie ma zapisanych ostatnich ustawień - to oznacza pierwsze użycie
    if (!lastApprovedSettings) {
      console.log('❌ Brak ostatnich ustawień - pierwsze użycie');
      return false;
    }
    
    // Sprawdź czy arkusz się zmienił
    if (selectedSheetName !== lastApprovedSettings.sheetName) {
      console.log('✅ Arkusz się zmienił:', selectedSheetName, '!=', lastApprovedSettings.sheetName);
      return true;
    }

    // Sprawdź czy zakres się zmienił
    if (newData.rowStart !== lastApprovedSettings.rowStart ||
        newData.rowEnd !== lastApprovedSettings.rowEnd ||
        newData.colStart !== lastApprovedSettings.colStart ||
        newData.colEnd !== lastApprovedSettings.colEnd) {
      console.log('✅ Zakres się zmienił');
      return true;
    }

    // 🆕 Sprawdź czy ustawienia nagłówków się zmieniły
    if (hasHeaders !== lastApprovedSettings.hasHeaders) {
      console.log('✅ Ustawienie nagłówków się zmieniło:', hasHeaders, '!=', lastApprovedSettings.hasHeaders);
      return true;
    }

    // 🆕 Sprawdź czy typ danych się zmienił
    if (dataType !== lastApprovedSettings.dataType) {
      console.log('✅ Typ danych się zmienił:', dataType, '!=', lastApprovedSettings.dataType);
      return true;
    }

    // 🆕 Sprawdź czy ustawienie inflacji się zmieniło
    if (useInflation !== lastApprovedSettings.useInflation) {
      console.log('✅ Ustawienie inflacji się zmieniło:', useInflation, '!=', lastApprovedSettings.useInflation);
      return true;
    }

    console.log('❌ Brak zmian');
    return false;
  };

  /* ---------- Submit formularza ---------- */
  const onSubmit = async (data: FormField) => {
    console.log('📝 Submit formularza:', data);
    
    // Sprawdź czy ustawienia się zmieniły względem już wczytanych danych
    const settingsChanged = hasSettingsChanged(data);
    console.log('🔄 Ustawienia się zmieniły:', settingsChanged);
    
    if (settingsChanged) {
      // Zapisz dane formularza i pokaż modal ostrzeżenia
      console.log('⚠️ Pokazuję modal ostrzeżenia');
      setPendingFormData(data);
      setShowWarningModal(true);
      return;
    }

    // Jeśli nie ma zmian lub nie ma danych, wykonaj normalnie
    console.log('✅ Przetwarzam dane bez modala');
    await processFormData(data);
  };

  // Funkcja do przetwarzania danych formularza
  const processFormData = async (data: FormField) => {
    console.log('🔄 [processFormData] Rozpoczynam przetwarzanie danych incurred...', data);

    // reset dialogów
    setShowDialog(false);
    setShowSuccessDialog(false);
    setShowNoChangesDialog(false);
    setShowWarningDialog(false);

    setRangeAndUpdate({
      startRow: data.rowStart,
      endRow: data.rowEnd,
      startCol: data.colStart,
      endCol: data.colEnd,
    });

    setTimeout(async () => {
      let { isValid: v, selectedSheetJSON: json, previousSheetJSON: prev } =
        useIncurredTableStore.getState();

      // (1) ewentualna konwersja inkrementalnych -> skumulowane
      if (dataType === 'incremental' && json) {
        const converted = convertIncrementalToCumulative(json);
        useIncurredTableStore.setState({ selectedSheetJSON: converted });
        json = converted;
      }

      // (2) budowa body + etykiet zgodnie z hasHeaders
      let body: any[][] = [];
      let rowNames: string[] = [];
      let colNames: string[] = [];

      if (json && json.length > 1) {
        if (hasHeaders) {
          // ✅ Mamy podpisy – wyciągamy je z pierwszego wiersza/kolumny
          colNames = (json[0] ?? []).slice(1).map(c => String(c ?? ''));
          rowNames = json.slice(1).map(r => String((r && r[0]) ?? ''));
          body = json.slice(1).map(r => r.slice(1)); // samo „ciało"
        } else {
          // ❌ Brak podpisów – generujemy 1..N po wycięciu pierwszego wiersza/kolumny
          body = json.slice(1).map(r => r.slice(1));
          rowNames = Array.from({ length: body.length }, (_, i) => String(i + 1));
          colNames = Array.from({ length: body[0]?.length || 0 }, (_, i) => String(i + 1));
        }

        // zapis etykiet do store'a
        setRowLabels(rowNames);
        setColumnLabels(colNames);

        // numericTriangle (number|null) na bazie body z polskim formatowaniem liczb
        let numericTriangle: (number | null)[][] = body.map(row =>
          row.map(cell => parsePolishNumber(cell))
        );

        // � USUNIĘTO: Automatyczne nakładanie inflacji podczas wczytywania
        // Inflacja będzie nakładana tylko przez przycisk "Nałóż inflację"

        if (numericTriangle && numericTriangle.length > 0) {
          // 🔥 NOWA LOGIKA: wczytywane dane to RESERVE
          console.log('📊 [processFormData] Zapisuję wczytane dane jako reserve...');
          setReserve(numericTriangle);
          
          // 🔥 incurredTriangle_bez_inf = paidTriangle_bez_inf + reserve
          const currentPaidTriangle_bez_inf = paidStore.paidTriangle_bez_inf;
          
          if (currentPaidTriangle_bez_inf && currentPaidTriangle_bez_inf.length > 0) {
            console.log('➕ [processFormData] Sumuję paidTriangle_bez_inf + reserve...');
            console.log('📊 Paid triangle (bez inflacji):', {
              rows: currentPaidTriangle_bez_inf.length,
              cols: currentPaidTriangle_bez_inf[0]?.length || 0
            });
            console.log('📊 Reserve triangle:', {
              rows: numericTriangle.length,
              cols: numericTriangle[0]?.length || 0
            });
            
            // Sprawdź czy wymiary się zgadzają
            const maxRows = Math.max(currentPaidTriangle_bez_inf.length, numericTriangle.length);
            const maxCols = Math.max(
              currentPaidTriangle_bez_inf[0]?.length || 0, 
              numericTriangle[0]?.length || 0
            );
            
            // Stwórz nowy trójkąt jako suma paid_bez_inf + reserve
            const summedTriangle: (number | null)[][] = [];
            
            for (let i = 0; i < maxRows; i++) {
              const row: (number | null)[] = [];
              for (let j = 0; j < maxCols; j++) {
                const paidValue = currentPaidTriangle_bez_inf[i]?.[j] ?? 0;
                const reserveValue = numericTriangle[i]?.[j] ?? 0;
                
                // Suma: paid_bez_inf + reserve
                const sum = (paidValue || 0) + (reserveValue || 0);
                row.push(sum === 0 ? null : sum);
              }
              summedTriangle.push(row);
            }
            
            console.log('✅ [processFormData] Summed triangle (paid_bez_inf + reserve):', {
              rows: summedTriangle.length,
              cols: summedTriangle[0]?.length || 0
            });
            
            setIncurredTriangle_bez_inf(summedTriangle);
            setIncurredTriangle(summedTriangle); // Domyślnie bez inflacji
          } else {
            console.log('⚠️ [processFormData] Brak danych paid_bez_inf - używam tylko reserve');
            setIncurredTriangle_bez_inf(numericTriangle);
            setIncurredTriangle(numericTriangle); // Domyślnie bez inflacji
          }
        }

        // widok tabeli do podglądu (string|number)
        const sheetForStore: (string | number)[][] = body.map(row =>
          row.map(cell => (cell == null ? '' : typeof cell === 'number' ? cell : String(cell)))
        );
        if (sheetForStore && sheetForStore.length > 0) {
          useTrainDevideStoreIncurred.setState({ selectedSheetIncurred: sheetForStore });
        }
      }

      // (3) walidacje i komunikaty  
      // 🔥 DODATKOWY IDENTYFIKATOR - zawsze różne dane dla incurred vs paid
      const currentDataId = `incurred_${selectedSheetName}_${uploadedFileName}_${Date.now()}`;
      const previousDataId = lastApprovedSettings?.dataId || '';
      
      // 🔥 DODATKOWE ZABEZPIECZENIE: sprawdź czy to są dane z tego samego kontekstu (incurred)
      const isFromSameContext = previousDataId.startsWith('incurred_') || previousDataId === '';
      const same = JSON.stringify(json) === JSON.stringify(prev) 
                  && currentDataId === previousDataId 
                  && isFromSameContext;

      console.log('🔍 [processFormData] Porównanie danych:', {
        jsonLength: json?.length || 'undefined',
        prevLength: prev?.length || 'undefined', 
        jsonType: typeof json,
        prevType: typeof prev,
        currentDataId,
        previousDataId,
        isFromSameContext,
        same: same,
        v: v
      });

      if (!v) {
        setShowDialog(true);
      } else if (same && prev !== undefined) {
        // Pokaż "brak zmian" tylko jeśli poprzednie dane rzeczywiście istniały
        console.log('⚠️ [processFormData] Pokazuję dialog "brak zmian"');
        setShowNoChangesDialog(true);
      } else if (!localValidateDataValues(body || [])) {
        console.log('⚠️ [processFormData] Pokazuję dialog walidacji');
        setShowWarningDialog(true);
      } else {
        console.log('✅ [processFormData] Pokazuję dialog sukcesu');
        setShowSuccessDialog(true);
        setLastApprovedSettings({
          sheetName: selectedSheetName || null,
          rowStart: data.rowStart,
          rowEnd: data.rowEnd,
          colStart: data.colStart,
          colEnd: data.colEnd,
          hasHeaders,
          dataType,
          useInflation,
          dataId: currentDataId, // 🔥 Unikalny identyfikator dla tej operacji
        });
      }
    }, 0);
  };

  // Obsługa potwierdzenia w modalu
  const handleConfirmDataReplace = () => {
    console.log('🚨 [handleConfirmDataReplace] Rozpoczynam czyszczenie danych incurred...');
    setShowWarningModal(false);
    
    // 🔥 RESETUJ TYLKO DANE INCURRED - nie wszystkie stores!
    // Wyczyść trójkąt incurred
    incurredStore.setIncurredTriangle([]);
    incurredStore.setIncurredTriangle_bez_inf(null); // Wyczyść też dane bez inflacji
    incurredStore.setReserve(null); // Wyczyść też dane reserve
    incurredStore.setTrainDevideIncurred(undefined);
    
    // Wyczyść obliczenia z zakładek Incurred
    incurredStore.clearDevJResults();
    incurredStore.setFinalDevJ(undefined);
    incurredStore.clearAllDevFinalValues();
    incurredStore.clearFitCurveData();
    incurredStore.clearDevSummaryData();
    
    // 🆕 Wyczyść trainDevideIncurred żeby wymusić przeliczenie w zakładce CL
    console.log('🧹 [handleConfirmDataReplace] Czyszczę trainDevideIncurred...');
    incurredStore.setTrainDevideIncurred(undefined);
    
    // 🆕 Wyczyść dane trójkąta żeby wymusiło przeliczenie
    console.log('🧹 [handleConfirmDataReplace] Czyszczę incurredTriangle...', {
      currentTriangleLength: incurredStore.incurredTriangle?.length || 0,
      currentTriangleType: Array.isArray(incurredStore.incurredTriangle) ? 'array' : typeof incurredStore.incurredTriangle
    });
    incurredStore.setIncurredTriangle([]);
    console.log('🧹 [handleConfirmDataReplace] incurredTriangle po wyczyszczeniu:', {
      newTriangleLength: incurredStore.incurredTriangle?.length || 0
    });
    
    // Wyczyść tabele ResultSummary - gdy kasujemy dane Incurred
    summaryStore.clearSummaryData();
    
    // Reset table store dla zakładki Incurred
    useIncurredTableStore.getState().resetData();
    
    if (pendingFormData) {
      console.log('📝 [handleConfirmDataReplace] Przetwarzam odłożone dane formularza...');
      
      // 🆕 Wymusimy odświeżenie komponentów przez incrementDataGeneration - PRZED processFormData
      console.log('🔄 [handleConfirmDataReplace] Incrementing dataGenerationId...');
      incrementDataGeneration();
      
      // Małe opóźnienie żeby React zdążył przetworzyć zmianę dataGenerationId
      setTimeout(async () => {
        console.log('⏰ [handleConfirmDataReplace] Wywołuję processFormData po timeout...');
        await processFormData(pendingFormData);
      }, 0);
      
      setPendingFormData(null);
    } else {
      console.log('⚠️ [handleConfirmDataReplace] Brak pendingFormData!');
    }
    console.log('✅ [handleConfirmDataReplace] Zakończono');
  };

  // Obsługa anulowania w modalu
  const handleCancelDataReplace = () => {
    setShowWarningModal(false);
    setPendingFormData(null);
  };

  /* ---------- Nakładanie inflacji na już wczytane dane ---------- */
  const handleApplyInflation = async () => {
    const currentIncurredTriangle = incurredStore.incurredTriangle;
    
    if (!currentIncurredTriangle || currentIncurredTriangle.length === 0) {
      setInflationErrorMessage('Najpierw wczytaj dane reserve.');
      setShowInflationErrorModal(true);
      return;
    }

    if (!useInflation) {
      setInflationErrorMessage('Włącz opcję "Uwzględnij współczynniki inflacji".');
      setShowInflationErrorModal(true);
      return;
    }

    if (selectedInflacjaLine === null || !userId) {
      setInflationErrorMessage('Brak danych inflacji lub user ID.');
      setShowInflationErrorModal(true);
      return;
    }

    // Sprawdź czy są już obliczone dane - jeśli tak, pokaż modal ostrzeżenia
    const hasCalculatedData = (
      incurredStore.trainDevideIncurred?.length ||
      incurredStore.devJResults?.length ||
      incurredStore.sigmaResults?.length ||
      incurredStore.devJ?.length ||
      incurredStore.sigma?.length ||
      incurredStore.sd?.length
    );
    
    if (hasCalculatedData) {
      console.log('⚠️ Wykryto obliczone dane, pokazuję modal ostrzeżenia inflacji');
      setPendingInflationData({ currentIncurredTriangle, inflationLine: availableInflacjaLines.find(line => line.index === selectedInflacjaLine) });
      setShowInflationWarningModal(true);
      return;
    }

    // Jeśli nie ma obliczonych danych, wykonaj normalnie
    console.log('✅ Brak obliczonych danych, nakładam inflację od razu');
    await processInflation();
  };

  // Funkcja do nakładania inflacji
  const processInflation = async () => {
    // 🔥 UŻYWAJ ORYGINALNYCH DANYCH BEZ INFLACJI
    const originalReserveData = reserve; // Oryginalne dane reserve
    const originalPaidTriangle_bez_inf = paidStore.paidTriangle_bez_inf; // Oryginalne paid bez inflacji
    const inflationLine = availableInflacjaLines.find(line => line.index === selectedInflacjaLine);
    
    if (!originalReserveData || originalReserveData.length === 0) {
      setInflationErrorMessage('Brak oryginalnych danych reserve do przetworzenia.');
      setShowInflationErrorModal(true);
      return;
    }
    
    if (!originalPaidTriangle_bez_inf || originalPaidTriangle_bez_inf.length === 0) {
      setInflationErrorMessage('Brak danych paid_bez_inf do przetworzenia.');
      setShowInflationErrorModal(true);
      return;
    }
    
    if (!inflationLine) {
      setInflationErrorMessage('Nie znaleziono wybranej linii inflacji');
      setShowInflationErrorModal(true);
      return;
    }

    if (!userId) {
      setInflationErrorMessage('Brak user ID.');
      setShowInflationErrorModal(true);
      return;
    }

    try {
      console.log('🔥 [processInflation] Nakładanie inflacji - wysyłanie OSOBNYCH danych paid_bez_inf + reserve...');
      
      setIsLoading(true);
      setProgress(50);
      
      console.log('📊 OSOBNE dane dla backendu:');
      console.log('📊 Paid triangle (bez inflacji):', {
        rows: originalPaidTriangle_bez_inf.length,
        cols: originalPaidTriangle_bez_inf[0]?.length || 0
      });
      console.log('📊 Reserve triangle:', {
        rows: originalReserveData.length,
        cols: originalReserveData[0]?.length || 0
      });
      
      // 🔥 WYŚLIJ OSOBNE TRÓJKĄTY - backend zrobi sumowanie i inflację
      const inflationRequest = {
        user_id: userId,
        triangle_paid: originalPaidTriangle_bez_inf,    // Dane paid bez inflacji
        triangle_reserved: originalReserveData,         // 🔥 Dane reserve
        inflationVector: inflationLine.values
      };

      console.log('📊 [processInflation] Request dla backendu (paid_bez_inf + reserve):', {
        paidTriangleRows: originalPaidTriangle_bez_inf?.length || 0,
        paidTriangleCols: originalPaidTriangle_bez_inf?.[0]?.length || 0,
        reserveTriangleRows: originalReserveData?.length || 0,
        reserveTriangleCols: originalReserveData?.[0]?.length || 0,
        inflationVectorLength: inflationLine.values.length
      });

      // Wyślij na backend endpoint /calc/incurred/inflation
      const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';
      const response = await fetch(`${API_URL}/calc/incurred/inflation`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(inflationRequest),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Nieznany błąd backendu');
      }

      // Zastąp dane skorygowanymi o inflację z backendu
      // 🔥 WYNIK to zsumowane paid_bez_inf + reserve + inflacja
      setIncurredTriangle(result.adjustedTriangle || result.data);
      
      console.log('✅ [processInflation] Inflacja nałożona na paid_bez_inf + reserve - wynik zapisany do incurredTriangle');
      
      // 🔥 WYMUSIMY ODŚWIEŻENIE KOMPONENTÓW - kluczowe dla przeliczenia współczynników CL
      incrementDataGeneration();
      
      // Wyczyść wszystkie obliczone dane z zakładek (jak przy wczytywaniu nowych danych)
      console.log('🔄 [processInflation] Czyszczę wszystkie obliczone dane po nałożeniu inflacji...');
      incurredStore.setTrainDevideIncurred(undefined);
      incurredStore.clearDevJResults();
      incurredStore.setFinalDevJ(undefined);
      incurredStore.clearAllDevFinalValues();
      incurredStore.clearFitCurveData();
      incurredStore.clearDevSummaryData();
      
      // Wyczyść również wyniki obliczeń CL (devJ, sigma, sd)
      incurredStore.setDevJ([]);
      incurredStore.setSigma([]);
      incurredStore.setSd([]);
      
      // Wyczyść tabele ResultSummary
      summaryStore.clearSummaryData();
      
      console.log('✅ [processInflation] Inflacja nakoładana pomyślnie');
      setShowInflationSuccessModal(true);

    } catch (error) {
      console.error('❌ [processInflation] Błąd:', error);
      const errorMessage = error instanceof Error ? error.message : 'Nieznany błąd';
      setInflationErrorMessage(`Błąd podczas nakładania inflacji: ${errorMessage}`);
      setShowInflationErrorModal(true);
    } finally {
      setIsLoading(false);
      setProgress(0);
    }
  };

  // Obsługa potwierdzenia modalu inflacji
  const handleConfirmInflation = () => {
    console.log('🚨 [handleConfirmInflation] Użytkownik potwierdził nałożenie inflacji');
    setShowInflationWarningModal(false);
    setPendingInflationData(null);
    processInflation();
  };

  // Obsługa anulowania modalu inflacji
  const handleCancelInflation = () => {
    console.log('❌ [handleCancelInflation] Użytkownik anulował nałożenie inflacji');
    setShowInflationWarningModal(false);
    setPendingInflationData(null);
  };

  /* ------------------------------- JSX ------------------------------- */
  return (
    <div>
      {/* ---------- FORMULARZ ---------- */}
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="p-4 border rounded flex flex-col gap-4"
      >
        <Card>
          <CardHeader>
            <CardTitle>Wprowadź trójkąt danych reserve, który wykorzystasz w dalszej analizie</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* --- Plik --- */}
            <FileUploadSection
              file={file}
              uploadedFileName={uploadedFileName}
              onFileChange={(e) => setValue('file', e.target.files)}
              onFileLoad={handleFileLoad}
              isLoading={isLoading}
            />

            {/* --- Arkusz --- */}
            <div>
              <Label>Wybór arkusza</Label>
              <SheetSelectIncurred />
            </div>

          <CardHeader>
            <CardTitle>Podaj zakres danych, które chcesz wczytać.</CardTitle>
          </CardHeader>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Wiersz początkowy</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('rowStart')}
                />
              </div>
              <div>
                <Label>Wiersz końcowy</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('rowEnd')}
                />
              </div>
              <div>
                <Label>Kolumna początkowa</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('colStart')}
                />
              </div>
              <div>
                <Label>Kolumna końcowa</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('colEnd')}
                />
              </div>
            </div>

            <Button
              type="button"
              onClick={handleAutoRange}
              variant="outline"
              disabled={!workbook}
              className="bg-blue-500 text-white"
            >
              Wykryj zakres automatycznie
            </Button>

            {/* --- Konfiguracja danych --- */}
            <DataConfigurationSection
              hasHeaders={hasHeaders}
              onHeadersChange={setHasHeaders}
              dataType={dataType}
              onDataTypeChange={setDataType}
              hasInflationData={Object.keys(inflacjaTriangle).length > 0 && selectedInflacjaLine !== null}
              useInflation={useInflation}
              onInflationChange={setUseInflation}
            />
          </CardContent>
          <CardFooter>
            <Button
              type="submit"
              className="bg-blue-500 text-white w-full"
              disabled={!workbook}
            >
              Wybierz
            </Button>
          </CardFooter>
          <CardFooter>
            <Button
              type="button"
              onClick={handleApplyInflation}
              className="bg-orange-500 text-white hover:bg-orange-600 w-full"
              disabled={
                !incurredStore.incurredTriangle || 
                incurredStore.incurredTriangle.length === 0 || 
                !reserve || 
                reserve.length === 0 ||
                !paidStore.paidTriangle_bez_inf || 
                paidStore.paidTriangle_bez_inf.length === 0 ||
                !useInflation
              }
            >
              Nałóż inflację
            </Button>
          </CardFooter>
        </Card>
      </form>

      {/* ---------- DIALOGI ---------- */}
      <DataInputDialogs
        showErrorDialog={showDialog}
        onErrorDialogChange={setShowDialog}
        errorMessage={validationErrorReason || 'Dane wejściowe nie spełniają określonego formatu. Sprawdź dane!'}
        showWarningDialog={showWarningDialog}
        onWarningDialogChange={setShowWarningDialog}
        showSuccessDialog={showSuccessDialog}
        onSuccessDialogChange={setShowSuccessDialog}
        successMessage={dataType === 'incremental' 
          ? "Dane inkrementalne zostały przekonwertowane na skumulowane i poprawnie wczytane (Reserve)."
          : "Dane reserve zostały poprawnie wczytane i zsumowane z paid."}
        showInfoDialog={showNoChangesDialog}
        onInfoDialogChange={setShowNoChangesDialog}
      />

      {/* ---------- DIALOGI INFLACJI ---------- */}
      <DataInputDialogs
        showErrorDialog={showInflationErrorModal}
        onErrorDialogChange={setShowInflationErrorModal}
        errorMessage={inflationErrorMessage}
        showWarningDialog={false}
        onWarningDialogChange={() => {}}
        showSuccessDialog={showInflationSuccessModal}
        onSuccessDialogChange={setShowInflationSuccessModal}
        successMessage="Inflacja została pomyślnie nałożona na dane paid + reserve."
        showInfoDialog={false}
        onInfoDialogChange={() => {}}
      />

      {/* ---------- LOADING ---------- */}
      <DataInputLoading 
        isLoading={isLoading} 
        progress={progress} 
      />

      {/* MODAL OSTRZEŻENIA O UTRACIE DANYCH */}
      <Modal
        title="Ostrzeżenie"
        message="Czy napewno chcesz wczytać dane? Wszystkie obliczenia w zakładce Metody deterministyczne (incurred) zostaną utracone."
        isOpen={showWarningModal}
        onConfirm={handleConfirmDataReplace}
        onCancel={handleCancelDataReplace}
      />

      {/* MODAL OSTRZEŻENIA PRZED NAŁOŻENIEM INFLACJI */}
      <Modal
        title="Ostrzeżenie"
        message="Czy na pewno chcesz nałożyć inflację? Wszystkie dotychczasowe obliczenia w zakładce Metody deterministyczne (incurred) zostaną utracone."
        isOpen={showInflationWarningModal}
        onConfirm={handleConfirmInflation}
        onCancel={handleCancelInflation}
      />
    </div>
  );
}