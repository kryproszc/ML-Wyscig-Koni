/**
 * Hook do obsługi zmiennej selectedValuesSD z store'a
 * Umożliwia łatwe pobieranie finalnych wartości SD Selected Value
 */

'use client';

import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';

export function useSelectedValuesSD() {
  // Pobierz dane ze store'a
  const selectedValuesSD = useTrainDevideStoreDet(s => s.selectedValuesSD);
  const setSelectedValuesSD = useTrainDevideStoreDet(s => s.setSelectedValuesSD);

  // Helper functions
  const hasData = Boolean(selectedValuesSD?.length);
  
  const getLength = () => selectedValuesSD?.length || 0;
  
  const getAsNumbers = (): number[] => {
    if (!selectedValuesSD) return [];
    return selectedValuesSD.filter(val => Number.isFinite(val));
  };
  
  const getAsStrings = (): string[] => {
    if (!selectedValuesSD) return [];
    return selectedValuesSD.map(val => String(val));
  };

  const getValue = (index: number): number | undefined => {
    return selectedValuesSD?.[index];
  };

  const getStats = () => {
    if (!hasData) return null;
    
    const numbers = getAsNumbers();
    const validNumbers = numbers.filter(n => !isNaN(n));
    
    if (validNumbers.length === 0) return null;
    
    return {
      count: validNumbers.length,
      sum: validNumbers.reduce((a, b) => a + b, 0),
      avg: validNumbers.reduce((a, b) => a + b, 0) / validNumbers.length,
      min: Math.min(...validNumbers),
      max: Math.max(...validNumbers),
    };
  };

  // Funkcja do eksportowania danych dla API
  const getForAPI = () => {
    return {
      selectedValuesSD: selectedValuesSD || [],
      length: getLength(),
      hasData,
      asNumbers: getAsNumbers(),
      asStrings: getAsStrings(),
    };
  };

  // Funkcja do formatowania jako string rozdzielony tabulatorami (jak w tabeli)
  const getAsTableRow = () => {
    if (!hasData) return '';
    return 'Selected Value\t' + selectedValuesSD.join('\t');
  };

  return {
    // Podstawowe dane
    selectedValuesSD,
    
    // Setters
    setSelectedValuesSD,
    
    // Helper functions
    hasData,
    getLength,
    getAsNumbers,
    getAsStrings,
    getValue,
    getStats,
    getForAPI,
    getAsTableRow,
  };
}