'use client';

import { useMutation } from '@tanstack/react-query';
import { useUserStore } from '@/app/_components/useUserStore';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export function useSDVectors() {
  const userId = useUserStore((s) => s.userId);
  const { sd, sePred } = useTrainDevideStoreDet();

  // Mutation do wysłania obu wektorów na backend
  const sendSDVectors = useMutation({
    mutationKey: ['sendSDVectors'],
    mutationFn: async (additionalData?: Record<string, any>) => {
      // Walidacja - sprawdź czy mamy dane
      if (!sd || !sePred) {
        throw new Error('Brak wymaganych danych SD lub SE_PRED');
      }

      const payload = {
        user_id: userId,
        sd_vector: sd,           // Wektor SD z Chain Ladder
        se_pred_vector: sePred,  // Wektor SE_PRED z Fit Curve
        ...additionalData,       // Dodatkowe dane jeśli potrzebne
      };

      console.log('🚀 Wysyłam na backend:', payload);

      const response = await fetch(`${API_URL}/calc/paid/process_sd_vectors`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return response.json();
    },
    onSuccess: (data) => {
      console.log('✅ Sukces z backendu:', data);
    },
    onError: (error) => {
      console.error('❌ Błąd wysyłki:', error);
    },
  });

  // Funkcja pomocnicza do sprawdzenia dostępności danych
  const areVectorsReady = () => {
    return Boolean(sd?.length && sePred?.length);
  };

  // Funkcja pomocnicza do pobrania informacji o wektorach
  const getVectorInfo = () => {
    return {
      sdLength: sd?.length || 0,
      sePredLength: sePred?.length || 0,
      sdValues: sd,
      sePredValues: sePred,
      isReady: areVectorsReady(),
    };
  };

  return {
    // Dane
    sd,
    sePred,
    
    // Funkcje pomocnicze
    areVectorsReady,
    getVectorInfo,
    
    // Mutation
    sendSDVectors: sendSDVectors.mutate,
    sendSDVectorsAsync: sendSDVectors.mutateAsync,
    isLoading: sendSDVectors.isPending,
    error: sendSDVectors.error,
    data: sendSDVectors.data,
    
    // Reset mutation state
    reset: sendSDVectors.reset,
  };
}