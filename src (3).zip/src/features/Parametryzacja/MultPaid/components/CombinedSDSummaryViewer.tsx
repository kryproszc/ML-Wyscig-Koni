'use client';

import React from 'react';
import { useCombinedSDSummary } from '../hooks/useCombinedSDSummary';
import { Button } from '@/components/ui/button';

export default function CombinedSDSummaryViewer() {
  const {
    combinedSDSummary,
    hasData,
    getLength,
    getAsNumbers,
    getAsStrings,
    getStats,
    getForAPI,
    clearCombinedSDSummary,
  } = useCombinedSDSummary();

  const stats = getStats();

  if (!hasData) {
    return (
      <div className="p-4 rounded-lg bg-yellow-50 border border-yellow-200 text-yellow-700">
        <p className="font-medium">Brak danych Combined SD Summary</p>
        <p className="text-sm mt-1">Wykonaj selekcję w zakładce SD Summary, aby zobaczyć dane.</p>
      </div>
    );
  }

  const handleExportForAPI = () => {
    const apiData = getForAPI();
    console.log('🚀 Combined SD Summary for API:', apiData);
    
    // Skopiuj do schowka jako JSON
    navigator.clipboard.writeText(JSON.stringify(apiData, null, 2)).then(() => {
      alert('Dane skopiowane do schowka!');
    }).catch(() => {
      alert('Nie udało się skopiować danych.');
    });
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-md border border-gray-200">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-gray-800">
          📊 Combined SD Summary
        </h3>
        <div className="flex gap-2">
          <Button
            onClick={handleExportForAPI}
            variant="outline"
            size="sm"
            className="text-blue-600 border-blue-300 hover:bg-blue-50"
          >
            📤 Eksportuj dla API
          </Button>
          <Button
            onClick={clearCombinedSDSummary}
            variant="outline"
            size="sm"
            className="text-red-600 border-red-300 hover:bg-red-50"
          >
            🗑️ Wyczyść
          </Button>
        </div>
      </div>

      {/* Informacje podstawowe */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="text-center p-3 bg-gray-50 rounded">
          <div className="text-2xl font-bold text-blue-600">{getLength()}</div>
          <div className="text-sm text-gray-600">Elementów</div>
        </div>
        {stats && (
          <>
            <div className="text-center p-3 bg-gray-50 rounded">
              <div className="text-lg font-bold text-green-600">{stats.avg.toFixed(4)}</div>
              <div className="text-sm text-gray-600">Średnia</div>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded">
              <div className="text-lg font-bold text-orange-600">{stats.min.toFixed(4)}</div>
              <div className="text-sm text-gray-600">Min</div>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded">
              <div className="text-lg font-bold text-purple-600">{stats.max.toFixed(4)}</div>
              <div className="text-sm text-gray-600">Max</div>
            </div>
          </>
        )}
      </div>

      {/* Tabela z danymi */}
      <div className="overflow-x-auto">
        <h4 className="font-medium mb-3 text-gray-700">Wartości Combined SD Summary:</h4>
        <table className="w-full border-collapse border border-gray-300 text-sm">
          <thead>
            <tr className="bg-gray-100">
              <th className="border border-gray-300 px-3 py-2 text-left">Indeks</th>
              <th className="border border-gray-300 px-3 py-2 text-right">Wartość (Raw)</th>
              <th className="border border-gray-300 px-3 py-2 text-right">Jako Number</th>
              <th className="border border-gray-300 px-3 py-2 text-left">Typ</th>
            </tr>
          </thead>
          <tbody>
            {combinedSDSummary?.map((value, index) => (
              <tr key={index} className="hover:bg-gray-50">
                <td className="border border-gray-300 px-3 py-2 font-mono">
                  [{index}]
                </td>
                <td className="border border-gray-300 px-3 py-2 text-right font-mono">
                  {String(value)}
                </td>
                <td className="border border-gray-300 px-3 py-2 text-right font-mono">
                  {typeof value === 'number' ? value.toFixed(6) : parseFloat(String(value)).toFixed(6)}
                </td>
                <td className="border border-gray-300 px-3 py-2 text-xs">
                  <span className={`px-2 py-1 rounded ${
                    typeof value === 'number' 
                      ? 'bg-blue-100 text-blue-800' 
                      : 'bg-orange-100 text-orange-800'
                  }`}>
                    {typeof value}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* JSON Preview */}
      <details className="mt-6">
        <summary className="cursor-pointer font-medium text-gray-700 hover:text-gray-900">
          🔍 JSON Preview (kliknij aby rozwinąć)
        </summary>
        <pre className="mt-2 p-4 bg-gray-100 rounded text-xs overflow-x-auto">
          {JSON.stringify(getForAPI(), null, 2)}
        </pre>
      </details>
    </div>
  );
}