/**
 * Komponent do podglądu i zarządzania selectedValuesSD
 * Umożliwia podgląd danych i przygotowanie do wysłania na backend
 */

'use client';

import React from 'react';
import { useSelectedValuesSD } from '@/features/Parametryzacja/MultPaid/hooks/useSelectedValuesSD';

export default function SelectedValuesSDViewer() {
  const {
    selectedValuesSD,
    hasData,
    getLength,
    getAsNumbers,
    getStats,
    getForAPI,
    getAsTableRow,
  } = useSelectedValuesSD();

  const stats = getStats();

  if (!hasData) {
    return (
      <div className="p-4 rounded-lg bg-yellow-50 border border-yellow-200 text-yellow-700">
        <p className="font-medium">Brak danych Selected Values SD</p>
        <p className="text-sm mt-1">Wykonaj selekcję w zakładce SD Summary, aby zobaczyć dane.</p>
      </div>
    );
  }

  const handleExportForAPI = () => {
    const apiData = getForAPI();
    console.log('🚀 Selected Values SD for API:', apiData);
    
    // Skopiuj do schowka jako JSON
    if (navigator.clipboard) {
      navigator.clipboard.writeText(JSON.stringify(apiData, null, 2));
      alert('Dane zostały skopiowane do schowka jako JSON!');
    }
  };

  const handleCopyAsArray = () => {
    const numbersArray = getAsNumbers();
    console.log('📋 Selected Values SD as array:', numbersArray);
    
    // Skopiuj do schowka jako array
    if (navigator.clipboard) {
      navigator.clipboard.writeText(JSON.stringify(numbersArray));
      alert('Array został skopiowany do schowka!');
    }
  };

  const handleCopyAsTable = () => {
    const tableRow = getAsTableRow();
    console.log('📊 Selected Values SD as table row:', tableRow);
    
    // Skopiuj do schowka jako wiersz tabeli
    if (navigator.clipboard) {
      navigator.clipboard.writeText(tableRow);
      alert('Wiersz tabeli został skopiowany do schowka!');
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
      {/* Nagłówek */}
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-semibold text-gray-800">
          Selected Values SD - Podgląd i Export
        </h3>
        <div className="flex gap-2">
          <button
            onClick={handleCopyAsArray}
            className="px-3 py-1 text-sm bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            📋 Array
          </button>
          <button
            onClick={handleCopyAsTable}
            className="px-3 py-1 text-sm bg-green-500 text-white rounded hover:bg-green-600"
          >
            📊 Tabela
          </button>
          <button
            onClick={handleExportForAPI}
            className="px-3 py-1 text-sm bg-purple-500 text-white rounded hover:bg-purple-600"
          >
            🚀 API
          </button>
        </div>
      </div>

      {/* Informacje podstawowe */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="text-center p-3 bg-gray-50 rounded">
          <div className="text-2xl font-bold text-blue-600">{getLength()}</div>
          <div className="text-sm text-gray-600">Elementów</div>
        </div>
        {stats && (
          <>
            <div className="text-center p-3 bg-gray-50 rounded">
              <div className="text-lg font-bold text-green-600">{stats.avg.toFixed(6)}</div>
              <div className="text-sm text-gray-600">Średnia</div>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded">
              <div className="text-lg font-bold text-orange-600">{stats.min.toFixed(6)}</div>
              <div className="text-sm text-gray-600">Min</div>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded">
              <div className="text-lg font-bold text-purple-600">{stats.max.toFixed(6)}</div>
              <div className="text-sm text-gray-600">Max</div>
            </div>
          </>
        )}
      </div>

      {/* Podgląd danych (pierwsze 10) */}
      <div className="mb-6">
        <h4 className="font-medium mb-3 text-gray-700">Podgląd (pierwsze 10 wartości):</h4>
        <div className="bg-gray-50 p-3 rounded font-mono text-sm overflow-x-auto">
          {selectedValuesSD?.slice(0, 10).map((value, index) => (
            <span key={index} className="mr-4">
              [{index}]: {value.toFixed(6)}
            </span>
          ))}
          {selectedValuesSD && selectedValuesSD.length > 10 && (
            <span className="text-gray-500">... +{selectedValuesSD.length - 10} więcej</span>
          )}
        </div>
      </div>

      {/* Sekcja do wysyłania na backend */}
      <div className="border-t pt-4">
        <h4 className="font-medium mb-3 text-gray-700">🚀 Gotowe do wysłania na backend:</h4>
        <div className="bg-green-50 p-3 rounded">
          <p className="text-sm text-green-700 mb-2">
            Dane selectedValuesSD są gotowe do użycia w innych zakładkach lub wysłania na backend.
          </p>
          <p className="text-xs text-green-600">
            Użyj hook'a useSelectedValuesSD() w innych komponentach lub pobierz przez store.
          </p>
        </div>
      </div>
    </div>
  );
}