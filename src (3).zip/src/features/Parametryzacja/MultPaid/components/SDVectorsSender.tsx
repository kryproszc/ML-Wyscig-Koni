'use client';

import React from 'react';
import { useSDVectors } from '../hooks/useSDVectors';
import { Button } from '@/components/ui/button';

export default function SDVectorsSender() {
  const {
    sd,
    sePred,
    areVectorsReady,
    getVectorInfo,
    sendSDVectors,
    isLoading,
    error,
    data,
  } = useSDVectors();

  const vectorInfo = getVectorInfo();

  const handleSendVectors = () => {
    if (!areVectorsReady()) {
      alert('Brak wymaganych danych! Upewnij się, że masz obliczone SD i SE_PRED.');
      return;
    }

    // Opcjonalnie dodaj dodatkowe dane
    const additionalData = {
      timestamp: new Date().toISOString(),
      source: 'manual_send',
    };

    sendSDVectors(additionalData);
  };

  return (
    <div className="p-6 bg-gray-800 rounded-lg text-white">
      <h3 className="text-lg font-bold mb-4">Wysyłanie wektorów SD na backend</h3>
      
      {/* Informacje o dostępnych danych */}
      <div className="mb-6 space-y-2">
        <div className="flex justify-between">
          <span>SD Vector:</span>
          <span className={sd ? 'text-green-400' : 'text-red-400'}>
            {sd ? `✅ ${vectorInfo.sdLength} elementów` : '❌ Brak danych'}
          </span>
        </div>
        <div className="flex justify-between">
          <span>SE_PRED Vector:</span>
          <span className={sePred ? 'text-green-400' : 'text-red-400'}>
            {sePred ? `✅ ${vectorInfo.sePredLength} elementów` : '❌ Brak danych'}
          </span>
        </div>
        <div className="flex justify-between font-medium">
          <span>Status:</span>
          <span className={vectorInfo.isReady ? 'text-green-400' : 'text-yellow-400'}>
            {vectorInfo.isReady ? '✅ Gotowe do wysłania' : '⏳ Oczekuje na dane'}
          </span>
        </div>
      </div>

      {/* Podgląd pierwszych wartości */}
      {vectorInfo.isReady && (
        <div className="mb-6 grid grid-cols-2 gap-4 text-xs">
          <div>
            <h4 className="font-medium mb-2">SD (pierwsze 3 wartości):</h4>
            <div className="bg-gray-700 p-2 rounded">
              {sd?.slice(0, 3).map((val, i) => (
                <div key={i}>sd[{i}]: {val.toFixed(6)}</div>
              ))}
              {sd && sd.length > 3 && <div>... +{sd.length - 3} więcej</div>}
            </div>
          </div>
          <div>
            <h4 className="font-medium mb-2">SE_PRED (pierwsze 3 wartości):</h4>
            <div className="bg-gray-700 p-2 rounded">
              {sePred?.slice(0, 3).map((val, i) => (
                <div key={i}>se_pred[{i}]: {val.toFixed(6)}</div>
              ))}
              {sePred && sePred.length > 3 && <div>... +{sePred.length - 3} więcej</div>}
            </div>
          </div>
        </div>
      )}

      {/* Przycisk wysyłania */}
      <Button
        onClick={handleSendVectors}
        disabled={!vectorInfo.isReady || isLoading}
        className="w-full mb-4"
      >
        {isLoading ? 'Wysyłanie...' : 'Wyślij wektory na backend'}
      </Button>

      {/* Status odpowiedzi */}
      {error && (
        <div className="bg-red-900 p-3 rounded text-red-200 mb-4">
          <strong>Błąd:</strong> {error.message}
        </div>
      )}

      {data && (
        <div className="bg-green-900 p-3 rounded text-green-200">
          <strong>Sukces!</strong> Odpowiedź z backendu:
          <pre className="mt-2 text-xs overflow-x-auto">
            {JSON.stringify(data, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}