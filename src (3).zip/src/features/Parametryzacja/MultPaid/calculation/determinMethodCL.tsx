'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useParamsymStore } from '@/stores/paramsymStore';
import { useDiscountRatesStore } from '@/stores/discountRatesStore';
import { useUserStore } from '@/app/_components/useUserStore';
import { useChainLadderResultsStore } from '@/stores/chainLadderResultsStore';
import { 
  CalculationLayout, 
  DataStatusPanel, 
  ActionButtonsGroup, 
  SuccessModal,
  ResultsTable,
  EmptyState 
} from '@/shared/components/calculation';
import { useDataValidation } from '@/shared/hooks';
import { processSelectedRow, processSelectedValues } from '@/shared/utils';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? '';

export default function DeterminMethodCL() {
  // Store dla wyników Chain Ladder - zastępuje lokalny useState
  const { 
    results: calculationResults, 
    setResults, 
    clearResults, 
    hideResults,
    showResults,
    isCalculating, 
    setCalculating, 
    setError,
    hasResults 
  } = useChainLadderResultsStore();

  // State dla success modalu
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  // Importy stores do sprawdzania warunków
  const { paidTriangle, selectedDevJIndexes, selectedSigmaIndexes, leftCountCL, combinedDevJSummary, combinedSigmaSummary, devJ } = useTrainDevideStoreDet(); // Trójkąt paid
  
  // 🎯 DODANE: Pobierz selectedValuesCL reaktywnie (to są rzeczywiste wartości z tabeli Selected Value)
  const selectedValuesCL = useTrainDevideStoreDet((s) => s.selectedValuesCL);
  
  // 🎯 DODANE: Pobierz selectedValuesSigma reaktywnie (to są rzeczywiste wartości z tabeli Selected Value dla Sigma)
  const selectedValuesSigma = useTrainDevideStoreDet((s) => s.selectedValuesSigma);
  
  // USUNIĘTE: pobieranie z store na starcie - będziemy pobierać świeże dane w handleExecuteCalculations
  const userId = useUserStore((s: any) => s.userId);

  // Pobierz funkcje dostępu do store (nie same wartości)
  const getParamsymTriangle = useParamsymStore((s) => s.paramsymTriangle);
  const getSelectedParamsymLine = useParamsymStore((s) => s.selectedParamsymLine);
  const getDiscountRatesTriangle = useDiscountRatesStore((s) => s.discountRatesTriangle);
  const getSelectedDiscountRateLine = useDiscountRatesStore((s) => s.selectedDiscountRateLine);

  // console.log('🚀 [DeterminMethodCL] Component rendered with data:', {
  //   paidTriangle: paidTriangle,
  //   paramsymTriangle: getParamsymTriangle,
  //   discountRatesTriangle: getDiscountRatesTriangle
  // });

  // Walidacja danych za pomocą shared hook
  const {
    isPaidTriangleLoaded,
    isDiscountRatesLoaded, 
    isNettoBruttoLoaded,
    canSelectBrutto,
    canSelectBruttoDysk,
    canSelectNettoDysk
  } = useDataValidation(paidTriangle, getDiscountRatesTriangle, getParamsymTriangle);

  // console.log('🎯 [Validation Results]', {
  //   canSelectBrutto,
  //   canSelectBruttoDysk,
  //   canSelectNettoDysk,
  //   paidTriangleLoaded: !!isPaidTriangleLoaded(),
  //   discountRatesLoaded: !!isDiscountRatesLoaded(),
  //   nettoBruttoLoaded: !!isNettoBruttoLoaded()
  // });

  // USUNIĘTE: useEffect który powodował niepotrzebne re-rendery
  // useEffect(() => {
  //   console.log('🔄 [useEffect] Data changed - triggering re-render');
  // }, [paidTriangle, getParamsymTriangle, getDiscountRatesTriangle]);

  // 🔧 NAPRAWKA: Wyczyść wyniki tylko gdy należą do innego użytkownika - zachowaj wyniki przy przechodzeniu między zakładkami
  useEffect(() => {
    if (calculationResults && calculationResults.userId && userId) {
      if (calculationResults.userId !== userId) {
        console.log('🔄 Czyszczenie wyników innego użytkownika');
        clearResults();
      } else {
        console.log('✅ Zachowywanie wyników dla bieżącego użytkownika');
      }
    }
  }, [userId, calculationResults, clearResults]); // Uruchom gdy zmieni się userId lub wyniki

  // 🎯 NAPRAWIONE: Ukryj kolumny wyników TYLKO gdy rzeczywiście wczytano NOWE dane (nie przy przechodzeniu między zakładkami)
  const previousDiscountRates = React.useRef(getDiscountRatesTriangle);
  const previousParamsym = React.useRef(getParamsymTriangle);
  const hasInitialized = React.useRef(false);
  
  // Stabilna referencja do funkcji hideResults
  const stableHideResults = useCallback(() => {
    hideResults();
  }, [hideResults]);
  
  useEffect(() => {
    // Pomiń pierwsze uruchomienie (inicjalizacja komponentu)
    if (!hasInitialized.current) {
      hasInitialized.current = true;
      previousDiscountRates.current = getDiscountRatesTriangle;
      previousParamsym.current = getParamsymTriangle;
      return;
    }

    // Sprawdź czy dane rzeczywiście się zmieniły (nie tylko re-render)
    const discountRatesChanged = previousDiscountRates.current !== getDiscountRatesTriangle;
    const paramsymChanged = previousParamsym.current !== getParamsymTriangle;
    
    // Ukryj wyniki tylko jeśli:
    // 1. Wyniki są aktualnie pokazywane
    // 2. Dane rzeczywiście się zmieniły (nowe wczytanie pliku)
    // 3. Wyniki należą do bieżącego użytkownika
    if (calculationResults && 
        calculationResults.shouldShowResults && 
        calculationResults.userId === userId && 
        (discountRatesChanged || paramsymChanged)) {
      
      console.log('🚫 Ukrywam kolumny wyników - wykryto rzeczywistą zmianę danych:', {
        discountRatesChanged,
        paramsymChanged
      });
      stableHideResults();
    }
    
    // Aktualizuj referencje
    previousDiscountRates.current = getDiscountRatesTriangle;
    previousParamsym.current = getParamsymTriangle;
  }, [getDiscountRatesTriangle, getParamsymTriangle, calculationResults?.shouldShowResults, calculationResults?.userId, userId, stableHideResults]);
  
  // UWAGA: Teraz useEffect uruchomi się tylko gdy RZECZYWIŚCIE zmienią się dane (nowe pliki),
  // a nie przy każdym re-renderze komponentu czy przechodzeniu między zakładkami

  // USUNIĘTE: dublujący się useEffect - logika przeniesiona wyżej

  // Funkcja wysyłania danych do backend
  const handleExecuteCalculations = async () => {
    if (!userId) {
      console.error('❌ Brak userId - nie można wysłać danych');
      return;
    }

    // 🔄 POBIERZ ŚWIEŻE DANE W MOMENCIE KLIKNIĘCIA
    // console.log('🔄 [handleExecuteCalculations] Pobieranie świeżych danych przed wysłką...');
    // console.log('📊 Aktualne discount rates:', getDiscountRatesTriangle);
    // console.log('📈 Aktualne netto/brutto RAW:', getParamsymTriangle);
    // console.log('📈 Wybrana linia parametrów:', getSelectedParamsymLine);
    // console.log('📈 Aktualne netto/brutto STRUKTURA:', JSON.stringify(getParamsymTriangle, null, 2));

    // 🔄 Przetwarzanie danych za pomocą shared utils
    const processedNetBrutto = processSelectedRow(getParamsymTriangle, getSelectedParamsymLine);
    const processedDiscountRates = processSelectedRow(getDiscountRatesTriangle, getSelectedDiscountRateLine);

    // Sprawdź czy można wykonać obliczenia - wymagane dane podstawowe
    if (!Array.isArray(paidTriangle) || paidTriangle.length === 0) {
      console.error('❌ Brak trójkąta paid - nie można wykonać obliczeń');
      alert('❌ Wymagany trójkąt paid do wykonania obliczeń');
      return;
    }

    // 🎯 Przetwarzanie wybranych wartości za pomocą shared utils
    const selected_value_cl = processSelectedValues(selectedValuesCL, combinedDevJSummary, devJ as any[], 1.0);
    const selected_value_sigma = processSelectedValues(selectedValuesSigma, combinedSigmaSummary, undefined, 0.1);
    
    // 🎯 KONSOLA: Wypisz tylko selected_value_cl
    console.log('selected_value_cl:', selected_value_cl);

    // Przygotuj dane do wysyłki
    const requestData = {
      // ZAWSZE wysyłane
      user_id: userId,
      paid_triangle: Array.isArray(paidTriangle) ? paidTriangle : [],
      cl_indexes: Array.isArray(selectedDevJIndexes) ? selectedDevJIndexes : [],
      sigma_indexes: Array.isArray(selectedSigmaIndexes) ? selectedSigmaIndexes : [],
      left_count_cl: typeof leftCountCL === 'number' ? leftCountCL : 0,
      selected_value_cl: selected_value_cl,
      selected_value_sigma: selected_value_sigma,
      
      // Opcje obliczeń - automatycznie na podstawie dostępnych danych
      calculation_options: {
        brutto: canSelectBrutto,  // Oblicz jeśli paid triangle dostępny
        brutto_dysk: canSelectBruttoDysk,  // Oblicz jeśli paid + discount rates dostępne
        netto_dysk: canSelectNettoDysk  // Oblicz jeśli paid + discount rates + netto/brutto dostępne
      },
      
        // Dane opcjonalne - używamy przetworzone lub fallback
        discount_rates: Object.keys(processedDiscountRates).length > 0
          ? processedDiscountRates
          : { "0": { "0": -1 } },
        netto_brutto: Object.keys(processedNetBrutto).length > 0
          ? processedNetBrutto
          : { "0": { "0": -1 } }
    };
 
    try {
      // Oznacz rozpoczęcie obliczeń
      console.log('🚀 Rozpoczynanie obliczeń Chain Ladder...');
      setCalculating(true);
      
      const response = await fetch(`${API_URL}/calc/execute_calculations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData)
      });

      const result = await response.json();
      
      if (!response.ok) {
        console.error('❌ [handleExecuteCalculations] Backend error:', {
          status: response.status,
          statusText: response.statusText,
          details: result
        });
        console.error('❌ [handleExecuteCalculations] Full error details:', JSON.stringify(result, null, 2));
        const errorMsg = `Backend błąd ${response.status}: ${JSON.stringify(result, null, 2)}`;
        setError(errorMsg);
        alert(errorMsg);
        return;
      }
      
      // 🔍 DEBUG: Sprawdź strukturę odpowiedzi z backend
      console.log('🔍 [MultPaid] Otrzymana struktura odpowiedzi:', JSON.stringify(result, null, 2));
      console.log('🔍 [MultPaid] Typ result.status:', typeof result.status, result.status);
      console.log('🔍 [MultPaid] Czy result.vectors istnieje:', !!result.vectors);
      console.log('🔍 [MultPaid] Klucze result:', Object.keys(result));
      
      // ✅ OBSŁUGA SUKCESU - sprawdź oba możliwe formaty
      const hasVectorsFormat = result.status === 'ok' && result.vectors;
      const hasDirectFormat = result.last_col !== undefined || result.cum_trian !== undefined || result.ult_net_disc !== undefined;
      
      if (hasVectorsFormat) {
        console.log('🎉 [MultPaid] Format z vectors - obliczenia zakończone pomyślnie!');
        
        setResults({
          last_col: Array.isArray(result.vectors.last_col) ? result.vectors.last_col : [],
          cum_trian: Array.isArray(result.vectors.cum_trian) ? result.vectors.cum_trian : [],
          ult_net_disc: Array.isArray(result.vectors.ult_net_disc) ? result.vectors.ult_net_disc : [],
          userId: userId,
          calculationType: 'paid',
          shouldShowResults: true
        });
        
        setShowSuccessModal(true);
        
      } else if (hasDirectFormat) {
        console.log('🎉 [MultPaid] Format bezpośredni - obliczenia zakończone pomyślnie!');
        
        setResults({
          last_col: Array.isArray(result.last_col) ? result.last_col : (result.last_col !== undefined ? [result.last_col] : []),
          cum_trian: Array.isArray(result.cum_trian) ? result.cum_trian : [],
          ult_net_disc: Array.isArray(result.ult_net_disc) ? result.ult_net_disc : [],
          userId: userId,
          calculationType: 'paid',
          shouldShowResults: true
        });
        
        setShowSuccessModal(true);
        
      } else {
        console.error('❌ [MultPaid] Brak oczekiwanych danych w odpowiedzi:', {
          hasStatus: !!result.status,
          hasVectors: !!result.vectors,
          hasDirectData: hasDirectFormat,
          resultKeys: Object.keys(result)
        });
        const errorMsg = `❌ [MultPaid] Brak oczekiwanych danych w odpowiedzi. Otrzymane klucze: ${Object.keys(result).join(', ')}`;
        setError(errorMsg);
        alert(errorMsg);
      }
      
    } catch (error) {
      console.error('❌ [handleExecuteCalculations] Błąd wysyłki:', error);
      const errorMsg = `❌ Błąd wysyłki: ${error}`;
      setError(errorMsg);
      alert(errorMsg);
    } finally {
      // Zawsze zakończ stan ładowania
      setCalculating(false);
    }
  };



  // Konfiguracja kolumn dla ResultsTable
  const resultColumns = calculationResults ? [
    {
      key: 'last_col',
      header: 'Last Column (Brutto)',
      data: calculationResults.last_col || [],
      show: canSelectBrutto
    },
    {
      key: 'cum_trian', 
      header: 'Cumulative Triangle (Brutto Dysk.)',
      data: calculationResults.cum_trian || [],
      show: canSelectBruttoDysk
    },
    {
      key: 'ult_net_disc',
      header: 'Ultimate Net Discounted (Netto Dysk.)',
      data: calculationResults.ult_net_disc || [],
      show: canSelectNettoDysk
    }
  ] : [];

  // Przygotuj dane dla komponentów
  const statusItems = [
    { label: 'Trójkąt Paid', isLoaded: canSelectBrutto },
    { label: 'Stopy Dyskontowe', isLoaded: isDiscountRatesLoaded() },
    { label: 'Netto/Brutto', isLoaded: isNettoBruttoLoaded() }
  ];

  const actionButtons = [
    {
      label: isCalculating ? 'Obliczanie...' : 'Wykonaj obliczenia',
      onClick: handleExecuteCalculations,
      disabled: isCalculating || !canSelectBrutto,
      variant: 'primary' as const,
      icon: isCalculating ? '⏳' : '✅'
    },
    ...(calculationResults && calculationResults.shouldShowResults === false ? [{
      label: 'Pokaż wyniki',
      onClick: () => showResults(),
      variant: 'info' as const,
      icon: '👁️'
    }] : []),
    ...(calculationResults ? [{
      label: 'Wyczyść wyniki',
      onClick: () => clearResults(),
      variant: 'danger' as const,
      icon: '🗑️'
    }] : []),
    {
      label: 'Generuj raport',
      onClick: () => {},
      variant: 'secondary' as const,
      icon: '📊'
    }
  ];

  return (
    <>
      <CalculationLayout
        sidebar={
          <div className="space-y-6">
            <DataStatusPanel statusItems={statusItems} />
            <hr className="border-gray-600" />
            <ActionButtonsGroup buttons={actionButtons} />
          </div>
        }
      >
        <div className="space-y-6">
          {/* Wyniki z backendu - tabele */}
          {calculationResults ? (
            <div className="w-full">
              <ResultsTable
                title="Wyniki Obliczeń Chain Ladder"
                subtitle="Analiza trójkąta rozwoju szkód metodą deterministyczną"
                columns={resultColumns}
                userId={userId}
                resultsUserId={calculationResults?.userId}
                shouldShowResults={calculationResults?.shouldShowResults}
              />
            </div>
          ) : (
            <EmptyState
              title="Rozpocznij obliczenia"
              description={canSelectBrutto ? (
                `Dane są gotowe do obliczeń. Kliknij "Wykonaj obliczenia", aby wygenerować wyniki analizy.${
                  canSelectBruttoDysk ? '<br/><strong class="text-blue-400">📊 Dostępne:</strong> Brutto + Brutto Dyskontowane' : ''
                }${
                  canSelectNettoDysk ? '<br/><strong class="text-green-400">📈 Dostępne:</strong> + Netto Dyskontowane' : ''
                }`
              ) : (
                'Wczytaj trójkąt paid w pierwszej zakładce, aby rozpocząć obliczenia.'
              )}
            />
          )}
        </div>
      </CalculationLayout>
      
      {/* Success Modal */}
      <SuccessModal 
        isOpen={showSuccessModal}
        onClose={() => setShowSuccessModal(false)}
      />
    </>
  );
}

export { DeterminMethodCL };
