/* ---------------------------------------------------------------------- */
/*            src/features/Parametryzacja/MultPaid/FitCurve/FitCurvePaid.tsx (CLIENT)            */
/* ---------------------------------------------------------------------- */
"use client";

import React from "react";
import { 
  FitCurvePageLayout, 
  DEV_J_CONFIG, 
  DEV_J_STORE_MAPPING,
  useFitCurveData
} from "@/shared";

/* ------------------------------------------------------------------ */
/*                              KONTENER                              */
/* ------------------------------------------------------------------ */
import { useTrainDevideStoreDet } from "@/stores/trainDevideStoreDeterministyczny";

export default function FitCurvePaid() {
  const fitCurveProps = useFitCurveData({
    config: DEV_J_CONFIG,
    storeMapping: DEV_J_STORE_MAPPING,
    useStore: useTrainDevideStoreDet
  });

  return (
    <FitCurvePageLayout
      config={DEV_J_CONFIG}
      {...fitCurveProps}
    />
  );
}