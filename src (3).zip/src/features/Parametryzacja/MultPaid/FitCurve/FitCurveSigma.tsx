/* ---------------------------------------------------------------------- */
/*            src/features/Parametryzacja/MultPaid/FitCurve/FitCurveSigma.tsx            */
/* ---------------------------------------------------------------------- */
"use client";

import React, { useEffect } from "react";
import { useTrainDevideStoreDet } from "@/stores/trainDevideStoreDeterministyczny";
import { 
  FitCurvePageLayout, 
  SIGMA_CONFIG, 
  SIGMA_STORE_MAPPING,
  useFitCurveData
} from "@/shared";

/* ------------------------------------------------------------------ */
/*                              KONTENER                              */
/* ------------------------------------------------------------------ */
export default function FitCurveSigma() {
  // Dla synchronizacji tailCountSigma z tailCountCL
  const {
    tailCountCL,
    tailCountSigma,
    setTailCountSigma,
  } = useTrainDevideStoreDet();

  const fitCurveProps = useFitCurveData({
    config: SIGMA_CONFIG,
    storeMapping: SIGMA_STORE_MAPPING,
    useStore: useTrainDevideStoreDet
  });

  // Synchronizacja tailCount z CL
  useEffect(() => {
    if (tailCountCL !== undefined && tailCountCL !== tailCountSigma) {
      console.log('🔄 Synchronizing tailCountSigma with tailCountCL:', tailCountCL);
      setTailCountSigma(tailCountCL);
    }
  }, [tailCountCL, tailCountSigma, setTailCountSigma]);

  return (
    <FitCurvePageLayout
      config={SIGMA_CONFIG}
      {...fitCurveProps}
    />
  );
}