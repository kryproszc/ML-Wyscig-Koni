'use client';

import React, { useState } from 'react';
import { usePaidCL } from '../hooks/usePaidCL';
import SidebarPanelCL from '../components/SidebarPanelCL';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { useDisplaySettingsPaidStore } from '@/stores/useDisplaySettingsPaidStore';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import {
  CalculationPageLayout,
  type ResultRow,
} from '@/shared/components/calculation-tables';

export default function PaidCLCoefficientsPage() {
  // Labels from store (JUŻ 1:1 z body — bez rogu)
  const detRowLabels = useLabelsStore((s) => s.detRowLabels);
  const detColumnLabels = useLabelsStore((s) => s.detColumnLabels);

  // Display settings for fullscreen
  const fullscreenMode = useDisplaySettingsPaidStore((s) => s.fullscreenMode);
  const tableScale = useDisplaySettingsPaidStore((s) => s.tableScale);
  const setFullscreenMode = useDisplaySettingsPaidStore((s) => s.setFullscreenMode);
  const increaseScale = useDisplaySettingsPaidStore((s) => s.increaseScale);
  const decreaseScale = useDisplaySettingsPaidStore((s) => s.decreaseScale);

  // Stan dla animacji zamykania
  const [isClosing, setIsClosing] = useState(false);

  const {
    triangle,
    trainDevide,
    weights,
    selectedCells,
    devJ,
    sigma,
    sd,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    toggleRowDet,
    runSigma,
    isLoading,
  } = usePaidCL();

  // Dostęp do volume i setVolume ze store
  const store = useTrainDevideStoreDet();
  const { volume, setVolume, decimalPlaces } = store;

  // Funkcja do zamykania z animacją
  const handleCloseFullscreen = () => {
    setIsClosing(true);
    setTimeout(() => {
      setFullscreenMode(false);
      setIsClosing(false);
    }, 300);
  };

  // ---- Nagłówki kolumn dla tabeli współczynników ----
  const coeffHeaderLabels =
    detColumnLabels.length > 1
      ? detColumnLabels.slice(1, 1 + (trainDevide?.[0]?.length || 0))
      : Array.from({ length: trainDevide?.[0]?.length || 0 }, (_, i) => String(i + 2));

  // ---- Etykiety wierszy 1:1 (bez +1) ----
  const rowLabelAt = (i: number) => detRowLabels[i] ?? String(i + 1);

  // ---- Przygotowanie danych dla tabeli ----
  const tableData = trainDevide?.length ? [
    [''].concat(coeffHeaderLabels),
    ...trainDevide.map((row, i) => [
      rowLabelAt(i),
      ...row.map((c) => (c == null ? '' : c.toString())),
    ]),
  ] : [];

  // ---- Przygotowanie danych wyników ----
  const resultRows: ResultRow[] = [
    {
      label: 'dev_j',
      values: devJ || [],
      visible: !!devJ,
    },
    {
      label: 'sigma',
      values: sigma || [],
      visible: !!sigma,
    },
    {
      label: 'sd',
      values: sd || [],
      visible: true, // sd zawsze widoczny gdy tabela się wyświetla
    },
  ];

  return (
    <CalculationPageLayout
      title="Tabela współczynników rok do roku"
      loadingMessage={`⏳ Oczekiwanie na dane wejściowe paidTriangle…`}
      noDataMessage="Brak wyników 😢"
      
      // Table data
      tableData={tableData}
      headerLabels={coeffHeaderLabels}
      rowLabels={detRowLabels}
      hasData={!!triangle?.length && !!trainDevide?.length}
      
      // Table interactions
      weights={weights}
      selectedCells={selectedCells}
      minMaxCells={minMaxCells}
      minCells={minCells}
      maxCells={maxCells}
      minMaxHighlighting={minMaxHighlighting}
      showRowToggle={true}
      onToggleRow={toggleRowDet}
      
      // Results
      resultRows={resultRows}
      resultsTitle="Wyniki obliczeń"
      decimalPlaces={decimalPlaces}
      
      // Fullscreen
      fullscreenMode={fullscreenMode}
      isClosing={isClosing}
      onCloseFullscreen={handleCloseFullscreen}
      
      // Scale
      tableScale={tableScale}
      onIncreaseScale={increaseScale}
      onDecreaseScale={decreaseScale}
      
      // Volume and calculate
      volume={volume}
      onVolumeChange={setVolume}
      onCalculate={runSigma}
      calculateLabel="Oblicz"
      isLoading={isLoading}
      
      // Sidebar
      sidebar={
        <SidebarPanelCL
          onCalculate={runSigma}
          className="w-64 shrink-0"
        />
      }
    />
  );
}