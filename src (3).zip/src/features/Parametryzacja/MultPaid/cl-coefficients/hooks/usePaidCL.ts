'use client';

import { useEffect } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useUserStore } from '@/app/_components/useUserStore';
import {
  useTrainDevideStoreDet,
} from '@/stores/trainDevideStoreDeterministyczny';
import { useDetailTableStore } from '@/stores/useDetailTableStore';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export function usePaidCL() {
  const userId = useUserStore((s) => s.userId);
  const store  = useTrainDevideStoreDet();
  const { dataGenerationId } = useDetailTableStore();

  const {
    paidTriangle,
    trainDevideDet,
    selectedWeightsDet,
    safeWeights,
    selectedCellsDet,
    volume,
    devJResults,
    sigmaResults,
    devJ,
    sigma,
    sd,
    setTrainDevideDet,
    setSafeWeights,
    setDevJ,
    setSigma,
    setSd,
    addDevJResult,
    addSigmaResult,
    resetSelectionDet,
    toggleRowDet,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    setMinMaxHighlighting,
    selectedDevJVolume   : selectedVolume,
    selectedDevJSubIndex : selectedSubIndex,
    setSelectedDevJVolume: setSelectedVolume,
    selectedSigmaVolume,
    selectedSigmaSubIndex,
    setSelectedSigmaVolume,
  } = store;

  /* -------- mutation 1 -------- */
  const mTrainDivide = useMutation({
    mutationKey: ['trainDividePaid', volume],
    mutationFn : async () => {
      const triangle = (paidTriangle ?? []);
      const res = await fetch(`${API_URL}/calc/paid/train_devide_paid`, {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ user_id: userId, paid_data_det: triangle }),
      });
      return res.json() as Promise<{ train_devide?: number[][] }>;
    },
    onSuccess: (d) => {
      if (d.train_devide) {
        setTrainDevideDet(d.train_devide);
        // Ustaw wszystkie komórki jako zaznaczone domyślnie tylko jeśli weights nie istnieją
        if (!selectedWeightsDet) {
          resetSelectionDet();
        }
      }
    },
  });

  /* -------- mutation 2 -------- */
  const mCL = useMutation({
    mutationKey: ['clPaid', volume],
    mutationFn : async () => {
      // Użyj oryginalnej macierzy z Excela (paidTriangle) - usuń ostatni wiersz
      const processedTriangle = (paidTriangle ?? []).slice(0, -1);

      // Buduj macierz wag na podstawie trainDevideDet (przetworzonej przez backend)
      const trainMatrix = (trainDevideDet ?? []).slice(0, -1);
      const safeWeights = trainMatrix.map((row, rowIndex) => 
        row.map((cell, colIndex) => {
          // Jeśli komórka ma NaN/null/undefined - waga = 0 (nie ma danych)
          if (cell === null || cell === undefined || isNaN(cell)) return 0;
          
          // Jeśli komórka ma liczbę - użyj wagi z selectedWeightsDet
          const originalWeight = selectedWeightsDet?.[rowIndex]?.[colIndex];
          return originalWeight === 1 ? 1 : 0;
        })
      );

      // 🔥 ZAPISZ DO STORE dla innych zakładek
      setSafeWeights(safeWeights);
      
      console.log('📋 === ORYGINALNA MACIERZ Z EXCELA (paidTriangle) ===');
      paidTriangle?.forEach((row, i) => {
        console.log(`Wiersz ${i}:`, row);
      });
      
      console.log('🔺 === MACIERZ TRAINDEVIDDET (z backendu) ===');
      trainDevideDet?.forEach((row, i) => {
        console.log(`Wiersz ${i}:`, row);
      });
      
      console.log('🟦 === NOWA MACIERZ WAGI (z paidTriangle) ===');
      safeWeights.forEach((row, i) => {
        console.log(`Wiersz ${i}:`, row);
      });
      
      const res = await fetch(`${API_URL}/calc/paid/cl`, {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({
          user_id      : userId,
          paid_data_det: processedTriangle,
          weights      : safeWeights,
        }),
      });
      return res.json() as Promise<{ 
        message?: string; 
        dev_j?: number[]; 
        sigmas?: { 
          sd: number[]; 
          sigma: number[]; 
        };
      }>;
    },
    onSuccess: (d) => {
      console.log('🚀 Odpowiedź z /calc/paid/cl:', d);
      
      if (d.dev_j) {
        console.log('✅ Otrzymano dev_j:', d.dev_j);
        setDevJ(d.dev_j);
        addDevJResult(volume, d.dev_j);
        setSelectedVolume(volume, undefined);
      }
      
      if (d.sigmas?.sigma) {
        console.log('✅ Otrzymano sigma (z API sigmas.sigma - to faktycznie sd):', d.sigmas.sigma);
        setSd(d.sigmas.sigma); // API zwraca sd jako "sigma"
      }
      
      if (d.sigmas?.sd) {
        console.log('✅ Otrzymano sd (z API sigmas.sd - to faktycznie sigma):', d.sigmas.sd);
        setSigma(d.sigmas.sd); // API zwraca sigma jako "sd"
        addSigmaResult(volume, d.sigmas.sd);
        setSelectedSigmaVolume(volume, undefined);
      }
    },
  });

  /* auto-start train_divide */
  useEffect(() => {
    console.log('[usePaidCL] 🔍 useEffect triggered:', {
      paidTriangleLength: paidTriangle?.length || 0,
      trainDevideDetLength: trainDevideDet?.length || 0,
      hasPaidTriangle: !!paidTriangle?.length,
      hasTrainDevide: !!trainDevideDet?.length,
      dataGenerationId: dataGenerationId,
      shouldTrigger: !!(paidTriangle?.length && !trainDevideDet?.length)
    });
    
    if (paidTriangle?.length && !trainDevideDet?.length) {
      console.log('[usePaidCL] 🚀 Triggering mTrainDivide.mutate()');
      mTrainDivide.mutate();
    } else {
      console.log('[usePaidCL] ❌ Warunki nie spełnione - nie triggeru ję train_divide');
    }
  }, [paidTriangle, trainDevideDet, dataGenerationId]); // Dodaj dataGenerationId do dependencies

  return {
    triangle      : paidTriangle,
    trainDevide   : trainDevideDet,
    weights       : selectedWeightsDet,
    selectedCells : selectedCellsDet,
    devJResults,
    sigmaResults,
    devJ,
    sigma,
    sd,
    selectedVolume,
    selectedSubIndex,
    setSelectedVolume,
    selectedSigmaVolume,
    selectedSigmaSubIndex,
    setSelectedSigmaVolume,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    toggleRowDet,

    runSigma   : () => mCL.mutate(),
    isLoading  : mTrainDivide.isPending || mCL.isPending,
  };
}