// features/Parametryzacja/MultPaid/Symulacje/ClSimulationPaidRefactored.tsx
'use client';

import { useState } from 'react';
import { useSimulationResultsStore } from '../../../../stores/simulationResultsStore';
import { useChainLadderResultsStore } from '../../../../stores/chainLadderResultsStore';
import { useTrainDevideStoreDet } from '../../../../stores/trainDevideStoreDeterministyczny';
import { useUserStore } from '../../../../app/_components/useUserStore';
import { useParamsymStore } from '../../../../stores/paramsymStore';
import { useDiscountRatesStore } from '../../../../stores/discountRatesStore';
import { useCombinedSDSummary } from '../hooks/useCombinedSDSummary';
import { useSelectedValuesSD } from '../hooks/useSelectedValuesSD';
import { useCLSimulationStore } from '../../../../stores/clSimulationStore';
import { CustomAlertDialog } from '@/components/CustomAlertDialog';
import { exportStatisticsToExcel } from '../../../../untils/exportToExcel';

// 🎯 IMPORTY REUŻYWALNYCH KOMPONENTÓW
import {
  SimulationLayout,
  SimulationControlPanel,
  SimulationStatisticsTable,
  type DataAvailabilityStatus,
  type SimulationParams
} from '../../../../shared/components/Symulacje';

import {
  useSimulationApi,
  type AlertState,
  type SimulationRequestData
} from '../../../../shared/hooks';

import {
  validateVectorLengths,
  checkDataAvailability,
  getCalculationOptions,
  prepareSelectedValueCL,
  prepareSelectedValueSigma,
  prepareCombinedSDSummary,
  processNetBruttoParams,
  processDiscountRates,
  parseQuantiles
} from '../../../../shared/utils';

export function ClSimulationPaid() {
  // State dla modali
  const [alertState, setAlertState] = useState<AlertState>({
    show: false,
    variant: 'success',
    title: '',
    message: ''
  });

  // API Hook
  const { executeSimulation, executeStatistics, isCalculating, isCalculatingStatistics } = useSimulationApi();

  // Stores
  const {
    simulationParams,
    kwantyle,
    statisticsResults,
    updateSimulationParam,
    setKwantyle,
    setStatisticsResults,
  } = useCLSimulationStore();

  const { 
    results: simulationResults, 
    setResults, 
    clearResults, 
  } = useSimulationResultsStore();

  // Oddzielnie pobierz wyniki deterministyczne (tylko do odczytu)
  const { results: chainLadderResults } = useChainLadderResultsStore();

  // 🔥 POPRAWKA: hasResults to metoda, nie właściwość
  const hasResults = simulationResults !== null;

  const { 
    paidTriangle, 
    selectedDevJIndexes, 
    selectedSigmaIndexes, 
    leftCountCL, 
    combinedDevJSummary, 
    combinedSigmaSummary, 
    devJ, 
    selectedWeightsDet,
    safeWeights, 
    setSafeWeights, 
    tailCountCL,
    selectedValuesCL,
    selectedValuesSigma,
    sd
  } = useTrainDevideStoreDet();

  const userId = useUserStore((s: any) => s.userId);
  const { combinedSDSummary, getAsNumbers: getSDAsNumbers, hasData: hasSDData } = useCombinedSDSummary();
  const { getAsNumbers: getSelectedValuesSDAsNumbers, hasData: hasSelectedValuesSD } = useSelectedValuesSD();
  
  const getParamsymTriangle = useParamsymStore((s) => s.paramsymTriangle);
  const getSelectedParamsymLine = useParamsymStore((s) => s.selectedParamsymLine);
  const getDiscountRatesTriangle = useDiscountRatesStore((s) => s.discountRatesTriangle);
  const getSelectedDiscountRateLine = useDiscountRatesStore((s) => s.selectedDiscountRateLine);

  // Sprawdzenie dostępności danych
  const dataAvailability = checkDataAvailability(
    paidTriangle || [], // 🔥 POPRAWKA: fallback dla undefined
    getDiscountRatesTriangle,
    getParamsymTriangle
  );

  const calculationOptions = getCalculationOptions(dataAvailability);

  // Przygotuj dane dla DataAvailabilityStatus
  const dataAvailabilityStatus: DataAvailabilityStatus[] = [
    {
      label: 'Trójkąt Paid',
      isAvailable: dataAvailability.paidTriangle,
      status: dataAvailability.paidTriangle ? 'Wczytany' : 'Brak danych'
    },
    {
      label: 'Stopy Dyskontowe',
      isAvailable: dataAvailability.discountRates,
      status: dataAvailability.discountRates ? 'Wczytany' : 'Brak danych'
    },
    {
      label: 'Netto/Brutto',
      isAvailable: dataAvailability.nettoBrutto,
      status: dataAvailability.nettoBrutto ? 'Wczytany' : 'Brak danych'
    }
  ];

  // Funkcje obsługi alertów
  const showAlert = (alert: AlertState) => {
    setAlertState(alert);
  };

  const hideAlert = () => {
    setAlertState(prev => ({ ...prev, show: false }));
  };

  // Główna funkcja wykonania obliczeń
  const handleExecuteCalculations = async () => {
    // Wyczyść stare wyniki
    clearResults();
    setStatisticsResults([]);
    
    if (!userId) {
      return;
    }

    // Sprawdź podstawowe wymagania
    if (!dataAvailability.paidTriangle) {
      showAlert({
        show: true,
        variant: 'error',
        title: 'Błąd danych',
        message: 'Wymagany trójkąt paid do wykonania obliczeń'
      });
      return;
    }

    // 🔥 POBIERZ ŚWIEŻE DANE ZE STORE
    const freshState = useTrainDevideStoreDet.getState();
    
    // Przygotuj wagi
    let calculatedSafeWeights: number[][];
    if (freshState.safeWeights && freshState.safeWeights.length > 0) {
      calculatedSafeWeights = freshState.safeWeights;
    } else {
      calculatedSafeWeights = freshState.selectedWeightsDet?.map((r) => r.map((c) => (c === 1 ? 1 : 0))) ?? [];
      setSafeWeights(calculatedSafeWeights);
    }

    // Przygotuj wektory z fallbackami
    const vectorSelectedValueCL = prepareSelectedValueCL(
      freshState.selectedValuesCL,
      combinedDevJSummary,
      devJ || [] // 🔥 POPRAWKA: fallback dla undefined
    );

    const vectorSelectedValueSigma = prepareSelectedValueSigma(
      freshState.selectedValuesSigma,
      combinedSigmaSummary,
      freshState.sigma || [] // 🔥 POPRAWKA: fallback dla undefined
    );

    const vectorCombinedSDSummary = prepareCombinedSDSummary(
      hasSelectedValuesSD ? getSelectedValuesSDAsNumbers() : [],
      freshState.combinedSDSummary || [], // 🔥 POPRAWKA: fallback dla undefined
      sd || [] // 🔥 POPRAWKA: fallback dla undefined
    );

    // Waliduj długości wektorów
    const validation = validateVectorLengths(
      vectorSelectedValueCL,
      vectorSelectedValueSigma,
      vectorCombinedSDSummary
    );

    if (!validation.isValid) {
      showAlert({
        show: true,
        variant: 'error',
        title: 'Błąd długości wektorów',
        message: validation.errorMessage || 'Błąd walidacji wektorów'
      });
      return;
    }

    // Przygotuj pozostałe dane
    const processedNetBrutto = processNetBruttoParams(
      getParamsymTriangle,
      getSelectedParamsymLine
    );

    const processedDiscountRates = processDiscountRates(
      getDiscountRatesTriangle,
      getSelectedDiscountRateLine
    );

    // Przygotuj request data
    const requestData: SimulationRequestData = {
      user_id: userId,
      paid_triangle: paidTriangle || [], // 🔥 POPRAWKA: fallback dla undefined
      weights: calculatedSafeWeights,
      cl_indexes: selectedDevJIndexes || [],
      sigma_indexes: selectedSigmaIndexes || [],
      left_count_cl: leftCountCL || 0,
      selected_value_cl: vectorSelectedValueCL,
      selected_value_sigma: vectorSelectedValueSigma,
      combined_sd_summary: vectorCombinedSDSummary,
      tail_count_cl: tailCountCL === "" || tailCountCL === null || tailCountCL === undefined 
        ? null 
        : Number(tailCountCL),
      calculation_options: calculationOptions,
      discount_rates: processedDiscountRates,
      netto_brutto: processedNetBrutto,
      ilosc_symulacji: simulationParams.iloscSymulacji,
      ziarno: simulationParams.ziarno,
      podzial_ziarna: simulationParams.podzialZiarna,
      skalowanie: simulationParams.skalowanie,
      kwantyle: parseQuantiles(kwantyle)
    };

    // Wykonaj symulację
    const results = await executeSimulation(
      requestData,
      '/calc/simulationClpaid',
      showAlert
    );

    if (results) {
      setResults(results);
      
      // Jeśli symulacja się udała, usuń stare statystyki
      setStatisticsResults([]);
    }
  };

  // Funkcja wykonania statystyk
  const handleExecuteStatistics = async () => {
    // Guard clause dla userId
    if (!userId) {
      showAlert({
        show: true,
        variant: 'error',
        title: 'Błąd użytkownika',
        message: 'Brak identyfikatora użytkownika'
      });
      return;
    }

    if (!simulationResults) {
      showAlert({
        show: true,
        variant: 'warning',
        title: 'Brak danych symulacji',
        message: 'Najpierw wykonaj "Wykonaj obliczenia", a następnie statystyki.'
      });
      return;
    }

    // Sprawdź czy wyniki są świeże (mają userId)
    if (!simulationResults.userId || simulationResults.userId !== userId) {
      showAlert({
        show: true,
        variant: 'warning',
        title: 'Nieświeże dane symulacji',
        message: 'Wyniki symulacji są przestarzałe. Wykonaj ponownie "Wykonaj obliczenia".'
      });
      return;
    }

    // 🎯 SPRAWDŹ czy wyniki deterministyczne są rzeczywiście obliczone
    const hasDeterministicResults = chainLadderResults && 
                                   chainLadderResults.userId === userId &&
                                   chainLadderResults.shouldShowResults === true &&
                                   Array.isArray(chainLadderResults.last_col) &&
                                   chainLadderResults.last_col.length > 0 &&
                                   chainLadderResults.last_col.some(val => val !== 0) &&
                                   typeof chainLadderResults.userId === 'string' &&
                                   typeof chainLadderResults.calculatedAt === 'string' &&
                                   Array.isArray(chainLadderResults.cum_trian) &&
                                   Array.isArray(chainLadderResults.ult_net_disc);

    // Używamy poprawnego typu StatisticsRequestData
    const statisticsData: import('../../../../shared/hooks').StatisticsRequestData = {
      user_id: userId, // userId jest już sprawdzony wyżej
      kwantyle: parseQuantiles(kwantyle),
      skalowanie: simulationParams.skalowanie,
      skalowanie2: simulationParams.skalowanie2,
      // Zamiast wysyłać dummy results, wyślij null - backend użyje zapisanych danych
      simulation_results: null,
      // 🎯 WYSYŁAJ tylko rzeczywiste wyniki deterministyczne
      deterministic_results: hasDeterministicResults ? {
        cum_trian: chainLadderResults.cum_trian as number[],
        last_col: chainLadderResults.last_col as number[],
        ult_net_disc: chainLadderResults.ult_net_disc as number[],
        userId: chainLadderResults.userId as string,
        calculatedAt: chainLadderResults.calculatedAt as string
      } : null
    };

    console.log('🚀 [WYKONAJ STATYSTYKI] Wysyłane dane:', statisticsData);

    const results = await executeStatistics(
      statisticsData,
      '/calc/statisticClpaid',
      showAlert
    );

    if (results) {
      setStatisticsResults(results);
    }
  };

  // Funkcja eksportu do Excel
  const handleExportStatistics = () => {
    if (statisticsResults.length === 0) {
      showAlert({
        show: true,
        variant: 'warning',
        title: 'Brak danych',
        message: 'Najpierw wykonaj statystyki, aby móc je wyeksportować do Excel.'
      });
      return;
    }

    try {
      exportStatisticsToExcel(
        statisticsResults,
        kwantyle,
        simulationParams.skalowanie,
        simulationParams
      );
      showAlert({
        show: true,
        variant: 'success',
        title: 'Eksport wykonany!',
        message: 'Statystyki zostały zapisane do pliku Excel.'
      });
    } catch (error) {
      console.error('Błąd podczas eksportu:', error);
      showAlert({
        show: true,
        variant: 'error',
        title: 'Błąd eksportu',
        message: 'Wystąpił błąd podczas zapisywania do Excel. Sprawdź konsolę przeglądarki.'
      });
    }
  };

  return (
    <>
      <SimulationLayout
        sidebar={
          <SimulationControlPanel
            simulationParams={simulationParams}
            kwantyle={kwantyle}
            isCalculating={isCalculating}
            isCalculatingStatistics={isCalculatingStatistics}
            hasResults={hasResults}
            statisticsResultsCount={statisticsResults.length}
            dataAvailability={dataAvailabilityStatus}
            onUpdateSimulationParam={updateSimulationParam}
            onSetKwantyle={setKwantyle}
            onExecuteCalculations={() => {
              handleExecuteCalculations();
            }}
            onExecuteStatistics={handleExecuteStatistics}
            onClearResults={clearResults}
            onClearStatistics={() => setStatisticsResults([])}
            onExportStatistics={handleExportStatistics}
          />
        }
      >
        <SimulationStatisticsTable
          statisticsResults={statisticsResults}
          kwantyle={kwantyle}
          skalowanie={simulationParams.skalowanie}
          skalowanie2={simulationParams.skalowanie2}
          title="📊 Wyniki Statystyk Chain Ladder"
          subtitle="Analiza statystyczna wyników symulacji metodą Chain Ladder"
        />
      </SimulationLayout>

      {/* Modal */}
      <CustomAlertDialog
        open={alertState.show}
        onOpenChange={hideAlert}
        variant={alertState.variant}
        title={alertState.title}
        message={alertState.message}
        buttonText="OK"
      />
    </>
  );
}