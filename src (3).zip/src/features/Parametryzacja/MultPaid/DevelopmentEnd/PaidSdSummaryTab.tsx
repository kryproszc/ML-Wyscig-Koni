/* ------------------------------------------------------------------ */
/*                       PaidSdSummaryTab.tsx                        */
/* ------------------------------------------------------------------ */
"use client"

import React from "react";
import { GenericSummaryTab } from '@/shared/components/DevelopmentEnd'
import { sdSummaryConfig } from './configs'

export default function PaidSdSummaryTab() {
  return <GenericSummaryTab config={sdSummaryConfig} />
}
