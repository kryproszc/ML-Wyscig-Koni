/* ------------------------------------------------------------------ */
/*                       PaidSigmaSummaryTab.tsx                     */
/* ------------------------------------------------------------------ */
"use client"

import React from "react";
import { GenericSummaryTab } from '@/shared/components/DevelopmentEnd'
import { sigmaSummaryConfig } from './configs'

export default function PaidSigmaSummaryTab() {
  return <GenericSummaryTab config={sigmaSummaryConfig} />
}
