/* ------------------------------------------------------------------ */
/*                        CL Summary Configuration                    */
/* ------------------------------------------------------------------ */

import type { SummaryConfig } from '@/shared/types/summaryConfig'

export const clSummaryConfig: SummaryConfig = {
  tableContext: 'CL',
  
  // Store selectors - leftCount
  leftCountSelector: (s) => s.leftCountCL,
  setLeftCountSelector: (s) => s.setLeftCountCL,
  
  // Store selectors - selectedCurve  
  selectedCurveSelector: (s) => s.selectedCurveSummary,
  setSelectedCurveSelector: (s) => s.setSelectedCurveSummary,
  
  // Store selectors - manualOverrides
  manualOverridesSelector: (s) => s.manualOverridesSummary,
  setManualOverridesSelector: (s) => s.setManualOverridesSummary,
  
  // Store selectors - sourceSwitches
  sourceSwitchesSelector: (s) => s.sourceSwitchesSummary,
  setSourceSwitchesSelector: (s) => s.setSourceSwitchesSummary,
  
  // Store selectors - dane bazowe
  baseDataSelector: (s) => s.devJPreview,
  simResultsSelector: (s) => s.simResults,
  
  // Store selectors - kombinowane dane
  setCombinedDataSelector: (s) => s.setCombinedDevJSummary,
  
  // Store selectors - pozostałe
  setRemainingHeadersSelector: (s) => s.setRemainingDevJHeaders,
  
  // Brak transformacji dla CL - dane używane bezpośrednio
  disabledCurves: [],
  debugLabel: undefined
}