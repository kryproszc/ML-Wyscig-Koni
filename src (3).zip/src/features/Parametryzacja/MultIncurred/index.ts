// Export głównych modułów MultIncurred
export * from './cl-coefficients';
export { IncurredTriangleView } from './triangle-view/IncurredTriangleView';

// Export calculation
export { DeterminMethodCLIncurred } from './calculation/determinMethodCLrj';