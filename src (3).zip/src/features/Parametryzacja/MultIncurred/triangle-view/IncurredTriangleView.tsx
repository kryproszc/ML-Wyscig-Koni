'use client';

import React, { useEffect } from 'react';
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { TriangleTableView } from '@/shared/components/TriangleTableView';

export function IncurredTriangleView() {
  // Store data
  const { incurredTriangle: triangle } = useTrainDevideStoreIncurred();
  
  // Labels from store
  const incurredRowLabels = useLabelsStore((s) => s.incurredRowLabels);
  const incurredColumnLabels = useLabelsStore((s) => s.incurredColumnLabels);
  const globalRowLabels = useLabelsStore((s) => s.globalRowLabels);
  const globalColumnLabels = useLabelsStore((s) => s.globalColumnLabels);
  const lastLoadedFile = useLabelsStore((s) => s.lastLoadedFile);

  // Debug logs
  useEffect(() => {
    if (triangle?.length) {
      console.log('[IncurredTriangleView] 🔍 Triangle data received:');
      console.log('  - Number of rows:', triangle.length);
      console.log('  - First row length:', triangle[0]?.length);
      console.log('  - First row:', triangle[0]);
      console.log('  - Max row length:', Math.max(...triangle.map((row) => row?.length || 0)));
    }
    console.log('[IncurredTriangleView] incurredRowLabels:', incurredRowLabels);
    console.log('[IncurredTriangleView] incurredColumnLabels:', incurredColumnLabels, 'length:', incurredColumnLabels.length);
    console.log('[IncurredTriangleView] globalRowLabels:', globalRowLabels);
    console.log('[IncurredTriangleView] globalColumnLabels:', globalColumnLabels, 'length:', globalColumnLabels.length);
    console.log('[IncurredTriangleView] lastLoadedFile:', lastLoadedFile);
  }, [triangle, incurredRowLabels, incurredColumnLabels, globalRowLabels, globalColumnLabels, lastLoadedFile]);

  return (
    <div className="p-6 text-white">
      <TriangleTableView
        title="Trójkąt Incurred"
        triangle={triangle}
        noDataMessage="Brak danych trójkąta Incurred. Przejdź do zakładki 'Wprowadź dane' aby załadować dane incurred."
        withNumericHeaders={true}
        rowLabels={incurredRowLabels}
        columnLabels={incurredColumnLabels}
        className="space-y-4"
      />
    </div>
  );
}