/* ------------------------------------------------------------------ */
/*                   SD Summary Configuration (Incurred)              */
/* ------------------------------------------------------------------ */

import type { SummaryConfig } from '@/shared/types/summaryConfig'
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred'

export const sdSummaryIncurredConfig: SummaryConfig = {
  tableContext: 'SD (Incurred)',
  
  // Store hook - używamy Incurred store
  useStore: useTrainDevideStoreIncurred,
  
  // Store selectors - leftCount
  leftCountSelector: (s) => s.leftCountSD,
  setLeftCountSelector: (s) => s.setLeftCountSD,
  
  // Store selectors - selectedCurve  
  selectedCurveSelector: (s) => s.selectedCurveSD,
  setSelectedCurveSelector: (s) => s.setSelectedCurveSD,
  
  // Store selectors - manualOverrides
  manualOverridesSelector: (s) => s.manualOverridesSD,
  setManualOverridesSelector: (s) => s.setManualOverridesSD,
  
  // Store selectors - sourceSwitches
  sourceSwitchesSelector: (s) => s.sourceSwitchesSD,
  setSourceSwitchesSelector: (s) => s.setSourceSwitchesSD,
  
  // Store selectors - dane bazowe
  baseDataSelector: (s) => s.sd,
  simResultsSelector: (s) => s.sePred,
  
  // Store selectors - kombinowane dane
  setCombinedDataSelector: (s) => s.setCombinedSDSummary,
  
  // Store selectors - pozostałe
  setRemainingHeadersSelector: (s) => s.setRemainingDevJHeaders,
  
  // Transformacja danych - pierwiastek dla SD
  transformBaseData: (sd, leftCount) => {
    if (!sd || !Array.isArray(sd)) return sd;
    
    return sd.map((value, index) => {
      // Pierwiastek z wartości na lewo od leftCount (Initial Selection)
      if (index < leftCount && typeof value === 'number' && Number.isFinite(value) && value >= 0) {
        return Math.sqrt(value);
      }
      return value; // Pozostaw bez zmian dla reszty
    });
  },
  
  // Transformacja simResults dla SD
  transformSimResults: (sePred) => {
    if (!sePred) return undefined
    
    // Format danych dla SimulationTable - używamy klucza "k: X" który jest rozpoznawany przez getCurveValue
    const sePreData = Object.fromEntries(
      sePred.map((value: number, index: number) => [`k: ${index + 1}`, value])
    )
    
    return { "se_pred": sePreData }
  },
  
  disabledCurves: [],
  debugLabel: 'SD (Incurred)'
}