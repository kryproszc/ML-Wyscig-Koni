/* ------------------------------------------------------------------ */
/*                    IncurredDevSummaryTab.tsx                       */
/* ------------------------------------------------------------------ */
"use client"

import React from "react";
import { GenericSummaryTab } from '@/shared/components/DevelopmentEnd'
import { clSummaryIncurredConfig } from './configs'

export default function IncurredDevSummaryTab() {
  return <GenericSummaryTab config={clSummaryIncurredConfig} />
}