/* ------------------------------------------------------------------ */
/*                   IncurredSigmaSummaryTab.tsx                      */
/* ------------------------------------------------------------------ */
"use client"

import React from "react";
import { GenericSummaryTab } from '@/shared/components/DevelopmentEnd'
import { sigmaSummaryIncurredConfig } from './configs'

export default function IncurredSigmaSummaryTab() {
  return <GenericSummaryTab config={sigmaSummaryIncurredConfig} />
}