/* ------------------------------------------------------------------ */
/*                     IncurredSdSummaryTab.tsx                       */
/* ------------------------------------------------------------------ */
"use client"

import React from "react";
import { GenericSummaryTab } from '@/shared/components/DevelopmentEnd'
import { sdSummaryIncurredConfig } from './configs'

export default function IncurredSdSummaryTab() {
  return <GenericSummaryTab config={sdSummaryIncurredConfig} />
}