'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny'; // 🆕 DODANY dla paidTriangle
import { useParamsymStore } from '@/stores/paramsymStore';
import { useDiscountRatesStore } from '@/stores/discountRatesStore';
import { useUserStore } from '@/app/_components/useUserStore';
import { useChainLadderResultsStore } from '@/stores/chainLadderResultsStore';
import { CustomAlertDialog } from '@/components/CustomAlertDialog';
import { 
  CalculationLayout, 
  DataStatusPanel, 
  ActionButtonsGroup, 
  SuccessModal,
  ResultsTable,
  EmptyState 
} from '@/shared/components/calculation';
import { useDataValidation } from '@/shared/hooks';
import { processSelectedRow } from '@/shared/utils';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? '';

export default function DeterminMethodCLIncurred() {
  // Store dla wyników Chain Ladder - zastępuje lokalny useState
  const { 
    results: calculationResults, 
    setResults, 
    clearResults, 
    hideResults,
    showResults,
    isCalculating, 
    setCalculating, 
    setError,
    hasResults 
  } = useChainLadderResultsStore();
  
  // Pobierz wyniki Chain Ladder z MultPaid (3 wektory obliczeń)
  const chainLadderResults = useChainLadderResultsStore((s) => s.results);

  // State dla success modalu
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  // State dla alertów (modalów błędów)
  const [alertState, setAlertState] = useState({
    show: false,
    variant: 'success' as 'success' | 'error' | 'warning',
    title: '',
    message: ''
  });

  // Funkcje pomocnicze dla alertów
  const showAlert = (state: { variant: 'success' | 'error' | 'warning'; title: string; message: string }) => {
    setAlertState(prev => ({ ...prev, ...state, show: true }));
  };

  const hideAlert = () => {
    setAlertState(prev => ({ ...prev, show: false }));
  };

  // 🔺 ZMIANA: Importy z RÓŻNYCH stores
  // 1️⃣ Z useTrainDevideStoreDet (MultPaid)
  const { paidTriangle } = useTrainDevideStoreDet(); // Trójkąt paid z MultPaid
  
  // 2️⃣ Z useTrainDevideStoreIncurred (MultIncurred)
  const { 
    incurredTriangle,           // Trójkąt incurred
    selectedDevJIndexes,        // Wybrane indeksy dla dev_j  
    selectedSigmaIndexes,       // Wybrane indeksy dla sigma
    leftCountCL,                // Liczba pozostałych współczynników
    combinedDevJSummary,        // Finalne wartości dev_j po FitCurve
    combinedSigmaSummary,       // Finalne wartości sigma po FitCurve
    devJ,                       // Oryginalne dane dev_j z API (Initial CL)
    // 3️⃣ r_j z PaidToIncurred
    combinedRJPaidToIncurredSummary, // r_j współczynniki
    rJPaidToIncurredPreview,     // r_j initial values
    rJPaidToIncurred            // r_j aktualne wartości
  } = useTrainDevideStoreIncurred();
  
  // 🎯 Pobierz selectedValues reaktywnie (rzeczywiste wartości z tabeli Selected Value)
  const selectedValuesCL = useTrainDevideStoreIncurred((s) => s.selectedValuesCL);
  const selectedValuesSigma = useTrainDevideStoreIncurred((s) => s.selectedValuesSigma);
  const selectedValuesRJPaidToIncurred = useTrainDevideStoreIncurred((s) => s.selectedValuesRJPaidToIncurred); // 🆕 DODANO
  
  // User ID
  const userId = useUserStore((s: any) => s.userId);

  // 💰 Wspólne parametry (identyczne jak w MultPaid)
  const getParamsymTriangle = useParamsymStore((s) => s.paramsymTriangle);
  const getSelectedParamsymLine = useParamsymStore((s) => s.selectedParamsymLine);
  const getDiscountRatesTriangle = useDiscountRatesStore((s) => s.discountRatesTriangle);
  const getSelectedDiscountRateLine = useDiscountRatesStore((s) => s.selectedDiscountRateLine);



  console.log('🔍 [DeterminMethodCLIncurred] Component rendered with data:', {
    // Z MultPaid store
    paidTriangle: !!paidTriangle?.length,
    // Z MultIncurred store
    incurredTriangle: !!incurredTriangle?.length,
    devJ: !!devJ?.length,
    selectedDevJIndexes: selectedDevJIndexes?.length || 0,
    selectedSigmaIndexes: selectedSigmaIndexes?.length || 0,
    selectedValuesCL: selectedValuesCL?.length || 0,
    selectedValuesSigma: selectedValuesSigma?.length || 0,
    selectedValuesRJPaidToIncurred: selectedValuesRJPaidToIncurred?.length || 0, // 🆕 DODANO
    // r_j z PaidToIncurred
    rJPaidToIncurred: !!rJPaidToIncurredPreview?.length || !!combinedRJPaidToIncurredSummary?.length
  });

  // 🔧 ZMIANA: Walidacja danych dla incurredTriangle
  const {
    isPaidTriangleLoaded: isIncurredTriangleLoaded,  // Zmiana nazwy dla czytelności
    isDiscountRatesLoaded, 
    isNettoBruttoLoaded,
    canSelectBrutto,
    canSelectBruttoDysk,
    canSelectNettoDysk
  } = useDataValidation(incurredTriangle, getDiscountRatesTriangle, getParamsymTriangle);

  console.log('🎯 [Validation Results - MultIncurred]', {
    canSelectBrutto,
    canSelectBruttoDysk,
    canSelectNettoDysk,
    incurredTriangleLoaded: !!isIncurredTriangleLoaded(),
    discountRatesLoaded: !!isDiscountRatesLoaded(),
    nettoBruttoLoaded: !!isNettoBruttoLoaded()
  });

  // 🔧 Wyczyść wyniki tylko gdy należą do innego użytkownika
  useEffect(() => {
    if (calculationResults && calculationResults.userId && userId) {
      if (calculationResults.userId !== userId) {
        console.log('🔄 [MultIncurred] Czyszczenie wyników innego użytkownika');
        clearResults();
      } else {
        console.log('✅ [MultIncurred] Zachowywanie wyników dla bieżącego użytkownika');
      }
    }
  }, [userId, calculationResults, clearResults]);

  // 🎯 Ukryj kolumny wyników TYLKO gdy rzeczywiście wczytano NOWE dane
  const previousDiscountRates = React.useRef(getDiscountRatesTriangle);
  const previousParamsym = React.useRef(getParamsymTriangle);
  const hasInitialized = React.useRef(false);
  
  const stableHideResults = useCallback(() => {
    hideResults();
  }, [hideResults]);
  
  useEffect(() => {
    // Pomiń pierwsze uruchomienie (inicjalizacja komponentu)
    if (!hasInitialized.current) {
      hasInitialized.current = true;
      previousDiscountRates.current = getDiscountRatesTriangle;
      previousParamsym.current = getParamsymTriangle;
      return;
    }

    // Sprawdź czy dane rzeczywiście się zmieniły
    const discountRatesChanged = previousDiscountRates.current !== getDiscountRatesTriangle;
    const paramsymChanged = previousParamsym.current !== getParamsymTriangle;
    
    if (calculationResults && 
        calculationResults.shouldShowResults && 
        calculationResults.userId === userId && 
        (discountRatesChanged || paramsymChanged)) {
      
      console.log('🚫 [MultIncurred] Ukrywam kolumny wyników - wykryto zmianę danych:', {
        discountRatesChanged,
        paramsymChanged
      });
      stableHideResults();
    }
    
    // Aktualizuj referencje
    previousDiscountRates.current = getDiscountRatesTriangle;
    previousParamsym.current = getParamsymTriangle;
  }, [getDiscountRatesTriangle, getParamsymTriangle, calculationResults?.shouldShowResults, calculationResults?.userId, userId, stableHideResults]);

  // 🚀 Funkcja wysyłania danych na backend - NA RAZIE PUSTA (kolejny krok)
  const handleExecuteCalculations = async () => {
    if (!userId) {
      console.error('❌ Brak userId - nie można wysłać danych');
      return;
    }

    // 🔄 Przetwarzanie danych za pomocą shared utils
    const processedNetBrutto = processSelectedRow(getParamsymTriangle, getSelectedParamsymLine);
    const processedDiscountRates = processSelectedRow(getDiscountRatesTriangle, getSelectedDiscountRateLine);

    // Sprawdź czy można wykonać obliczenia - wymagane dane podstawowe
    if (!Array.isArray(incurredTriangle) || incurredTriangle.length === 0) {
      console.error('❌ Brak trójkąta incurred - nie można wykonać obliczeń');
      showAlert({
        variant: 'error',
        title: 'Brak danych wejściowych',
        message: '❌ Wymagany trójkąt incurred do wykonania obliczeń.\n\n🔧 Rozwiązanie:\nWczytaj trójkąt incurred w pierwszej zakładce.'
      });
      return;
    }

    // 🔍 SZCZEGÓŁOWE LOGI DANYCH WEJŚCIOWYCH
    console.log('� === PAID TRIANGLE (z MultPaid) ===');
    console.log('📊 paidTriangle (pierwsze 5 wierszy):', paidTriangle?.slice(0, 5));
    console.log('📏 Wymiary paidTriangle:', {
      rows: paidTriangle?.length || 0,
      cols: paidTriangle?.[0]?.length || 0
    });
    
    console.log('🔺 === INCURRED TRIANGLE (z MultIncurred) ===');
    console.log('📊 incurredTriangle (pierwsze 5 wierszy):', incurredTriangle?.slice(0, 5));
    console.log('📏 Wymiary incurredTriangle:', {
      rows: incurredTriangle?.length || 0,
      cols: incurredTriangle?.[0]?.length || 0
    });

    // 🎯 === WSPÓŁCZYNNIKI CL (z MultIncurred) ===
    console.log('📊 === CL WSPÓŁCZYNNIKI ===');
    console.log('🔵 devJ (Initial Selection):', devJ);
    console.log('🔴 rJPaidToIncurred (Current Values):', rJPaidToIncurred);
    
    // 🔄 FALLBACK LOGIC - jeśli selected values są puste, użyj oryginalnych danych
    console.log('🔄 [FALLBACK LOGIC] Sprawdzanie selected values:', {
      selectedValuesCL: {
        length: selectedValuesCL?.length || 0,
        isEmpty: !selectedValuesCL || selectedValuesCL.length === 0,
        data: selectedValuesCL
      },
      selectedValuesRJPaidToIncurred: {
        length: selectedValuesRJPaidToIncurred?.length || 0,
        isEmpty: !selectedValuesRJPaidToIncurred || selectedValuesRJPaidToIncurred.length === 0,
        data: selectedValuesRJPaidToIncurred
      },
      fallbackData: {
        devJ: devJ?.length || 0,
        rJPaidToIncurred: rJPaidToIncurred?.length || 0
      }
    });
    
    // 🎯 PRZYGOTOWANIE DANYCH (kombinacja z różnych stores)
    const requestData = {
      // 🔵 WEKTORY OBLICZEŃ Z CHAIN LADDER RESULTS (MultIncurred z suffixami)
      last_col_incurred: Array.isArray(chainLadderResults?.last_col_incurred) ? chainLadderResults.last_col_incurred : [],
      ult_disc_incurred: Array.isArray(chainLadderResults?.ult_net_disc_incurred) ? chainLadderResults.ult_net_disc_incurred : [],
      
      user_id: userId,
      
      // 🔺 1. PAID TRIANGLE (z MultPaid)
      paid_triangle: Array.isArray(paidTriangle) ? paidTriangle : [],
      
      // 🔺 2. INCURRED TRIANGLE (z MultIncurred)
      incurred_triangle: Array.isArray(incurredTriangle) ? incurredTriangle : [],
      
      // 📊 3. WYBRANE INDEKSY DEV_J
      selected_dev_j_indexes: Array.isArray(selectedDevJIndexes) ? selectedDevJIndexes : [],
      
      // 🔵 6. ORYGINALNE DANE DEV_J Z API (Initial CL)
      dev_j: Array.isArray(devJ) ? devJ : [],
      
      // 🔄 7. SELECTED VALUES DEV_J (z fallback na dev_j jeśli puste)
      selected_values_dev_j: (Array.isArray(selectedValuesCL) && selectedValuesCL.length > 0) 
        ? selectedValuesCL 
        : (Array.isArray(devJ) ? devJ : []),
      

      // 🔄 10. r_j SELECTED VALUES (z fallback na rj_paid_to_incurred_current jeśli puste)
      selected_values_rj_paid_to_incurred: (Array.isArray(selectedValuesRJPaidToIncurred) && selectedValuesRJPaidToIncurred.length > 0) 
        ? selectedValuesRJPaidToIncurred 
        : (Array.isArray(rJPaidToIncurred) ? rJPaidToIncurred : []),
      
      // 🆕 11. dev_j AKTUALNE WARTOŚCI (z tabeli współczynników)
      dev_j_current: Array.isArray(devJ) ? devJ : [],
      
      // 🆕 12. r_j AKTUALNE WARTOŚCI (z tabeli współczynników PaidToIncurred)
      rj_paid_to_incurred_current: Array.isArray(rJPaidToIncurred) ? rJPaidToIncurred : [],
      
      // 💸 13. DISCOUNT RATES
      discount_rates: Object.keys(processedDiscountRates).length > 0
        ? processedDiscountRates
        : { "0": { "0": -1 } },
      
      // 💸 14. NETTO/BRUTTO
      netto_brutto: Object.keys(processedNetBrutto).length > 0
        ? processedNetBrutto
        : { "0": { "0": -1 } }
    };

    console.log('📦 CAŁE requestData (to co wysyłam na backend):', requestData);

    // 🎯 WALIDACJA DŁUGOŚCI WEKTORÓW WSPÓŁCZYNNIKÓW przed wysłaniem
    console.log('🔍 === WALIDACJA DEV_J vs RJ_PAID_TO_INCURRED ===');
    
    const devJIncurredData = requestData.selected_values_dev_j || [];  // selected_values_dev_j (z fallback)
    const rjPaidToIncurredData = requestData.rj_paid_to_incurred_current || [];  // rj_paid_to_incurred_current
    
    console.log(`   selected_values_dev_j (z fallback): ${devJIncurredData.length} elementów`);
    console.log(`   rj_paid_to_incurred_current: ${rjPaidToIncurredData.length} elementów`);
    
    // Sprawdź czy któryś z wektorów jest pusty
    if (devJIncurredData.length === 0) {
      console.log('❌ [WALIDACJA DEV_J vs RJ] selected_values_dev_j jest pusty');
      showAlert({
        variant: 'error',
        title: 'Błąd danych współczynników dev_j',
        message: 'Wektor selected_values_dev_j (incurred) jest pusty.\n\n🔧 Rozwiązanie:\nPrzejdź do zakładki "Współczynniki CL" → "CL" i wykonaj obliczenia, a następnie wybierz finalny wektor w tabeli wyników.'
      });
      return;
    }
    
    if (rjPaidToIncurredData.length === 0) {
      console.log('❌ [WALIDACJA DEV_J vs RJ] rj_paid_to_incurred_current jest pusty');
      showAlert({
        variant: 'error',
        title: 'Błąd danych współczynników r_j',
        message: 'Wektor rj_paid_to_incurred_current jest pusty.\n\n🔧 Rozwiązanie:\nPrzejdź do zakładki "Paid→Incurred" → "r_j" i wykonaj obliczenia, a następnie wybierz finalny wektor w tabeli wyników.'
      });
      return;
    }
    
    // Sprawdź czy selected_values_dev_j jest o 1 krótsze niż rj_paid_to_incurred_current
    const expectedDevJLength = rjPaidToIncurredData.length - 1;
    if (devJIncurredData.length !== expectedDevJLength) {
      console.log('❌ [WALIDACJA DEV_J vs RJ] Nieprawidłowe proporcje długości:');
      console.log(`   selected_values_dev_j: ${devJIncurredData.length} (oczekiwano: ${expectedDevJLength})`);
      console.log(`   rj_paid_to_incurred_current: ${rjPaidToIncurredData.length}`);
      showAlert({
        variant: 'error',
        title: 'Błąd zgodności długości wektorów współczynników',
        message: `❌ Nieprawidłowe długości wektorów współczynników:\n\n📊 Aktualne długości:\n• dev_j (incurred): ${devJIncurredData.length} elementów\n• r_j (paid→incurred): ${rjPaidToIncurredData.length} elementów\n\n✅ Wymagane:\n• dev_j powinien mieć ${expectedDevJLength} elementów\n• r_j powinien mieć ${rjPaidToIncurredData.length} elementów\n\n🔧 Rozwiązanie:\nSprawdź obliczenia w zakładkach "Współczynniki CL" i "Paid→Incurred" oraz upewnij się, że używasz danych z tego samego trójkąta.`
      });
      return;
    }
    
    console.log('✅ [WALIDACJA DEV_J vs RJ] Prawidłowe proporcje długości:');
    console.log(`   selected_values_dev_j: ${devJIncurredData.length} elementów`);
    console.log(`   rj_paid_to_incurred_current: ${rjPaidToIncurredData.length} elementów (dev_j + 1)`);
    console.log('🔍 === KONIEC WALIDACJI DEV_J vs RJ ===');

    console.log('🔍 [WEKTORY OBLICZEŃ Z MultIncurred] WSZYSTKIE 3 WEKTORY:');
    console.log('  - last_col_incurred:', chainLadderResults?.last_col_incurred || 'BRAK DANYCH');
    console.log('  - cum_trian_incurred:', chainLadderResults?.cum_trian_incurred || 'BRAK DANYCH');
    console.log('  - ult_net_disc_incurred:', chainLadderResults?.ult_net_disc_incurred || 'BRAK DANYCH');
    console.log('🔍 [CHAIN LADDER RESULTS STORE]:', chainLadderResults);    
    try {
      setCalculating(true);
      
      console.log('🚀 [MultIncurred] Wysyłanie requestu na backend...');
      const startTime = Date.now();
      
      // 🔥 Dodamy timeout 60 sekund
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 60000); // 60 sekund
      
      const response = await fetch(`${API_URL}/calc/execute_calculations_incurred`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestData),
        signal: controller.signal
      });

      clearTimeout(timeoutId);
      const endTime = Date.now();
      console.log(`⏱️ [MultIncurred] Request trwał: ${endTime - startTime}ms`);
      
      console.log('📡 [MultIncurred] Otrzymano odpowiedź z statusem:', response.status);

      if (!response.ok) {
        // 🔍 SZCZEGÓŁOWE LOGOWANIE BŁĘDÓW
        const errorText = await response.text();
        console.error('❌ [Backend Error Details]:', {
          status: response.status,
          statusText: response.statusText,
          errorBody: errorText,
          url: response.url
        });
        
        // Próbuj sparsować jako JSON jeśli możliwe
        let errorDetails = errorText;
        try {
          errorDetails = JSON.parse(errorText);
          console.error('🔍 Parsed error details:', errorDetails);
        } catch {
          console.error('🔍 Raw error response:', errorText);
        }
        
        throw new Error(`HTTP error! status: ${response.status} - ${errorDetails}`);
      }

      const result = await response.json();
      console.log('✅ [Backend Response] Otrzymano wyniki:', result);
      console.log('📊 [MultIncurred] Rozpoczęcie parsowania odpowiedzi...');

      // 🔍 DEBUG: Sprawdź strukturę odpowiedzi z backend
      console.log('🔍 [MultIncurred] Otrzymana struktura odpowiedzi:', JSON.stringify(result, null, 2));
      console.log('🔍 [MultIncurred] Czy result.vectors istnieje:', !!result.vectors);
      console.log('🔍 [MultIncurred] Klucze result.vectors:', result.vectors ? Object.keys(result.vectors) : 'N/A');

      // ✅ OBSŁUGA SUKCESU - backend MultIncurred zwraca dane w vectors z suffixami _incurred
      if (result.status === 'ok' && result.vectors && 
          (result.vectors.last_col_incurred !== undefined || 
           result.vectors.cum_trian_incurred !== undefined || 
           result.vectors.ult_net_disc_incurred !== undefined)) {
        
        console.log('🎉 Obliczenia Chain Ladder - MultIncurred zakończone pomyślnie!');
        
        // Zapisz wyniki do store - backend MultIncurred zwraca dane w result.vectors z suffixami
        setResults({
          // 🆕 Zachowaj istniejące wyniki MultPaid jeśli istnieją
          ...(calculationResults || {}),
          // 🆕 Dodaj wyniki MultIncurred z suffixem - dane z vectors
          last_col_incurred: Array.isArray(result.vectors.last_col_incurred) ? result.vectors.last_col_incurred : [],
          cum_trian_incurred: Array.isArray(result.vectors.cum_trian_incurred) ? result.vectors.cum_trian_incurred : [],
          ult_net_disc_incurred: Array.isArray(result.vectors.ult_net_disc_incurred) ? result.vectors.ult_net_disc_incurred : [],
          userId: userId, // Dodajemy ID użytkownika
          calculationType: 'incurred', // 🆕 Oznacz jako wyniki MultIncurred
          shouldShowResults: true
        });
        
        setShowSuccessModal(true);
        
      } else {
        console.log('🔍 [MultIncurred] Brak oczekiwanych danych w odpowiedzi:', {
          hasStatus: !!result.status,
          hasVectors: !!result.vectors,
          vectorsKeys: result.vectors ? Object.keys(result.vectors) : [],
          resultKeys: Object.keys(result)
        });
        const errorMsg = `❌ [MultIncurred] Brak oczekiwanych danych w odpowiedzi. Status: ${result.status}, Vectors: ${!!result.vectors}`;
        setError(errorMsg);
        showAlert({
          variant: 'error',
          title: 'Błąd odpowiedzi z serwera',
          message: 'Serwer nie zwrócił oczekiwanych danych obliczeń.\n\n🔧 Sprawdź:\n• Czy wszystkie dane wejściowe są poprawne\n• Logi w konsoli przeglądarki\n• Połączenie z serwerem'
        });
      }
      
    } catch (error: unknown) {
      console.error('❌ [Backend Error] Błąd podczas wysyłania danych:', error);
      
      if (error && typeof error === 'object' && 'name' in error && error.name === 'AbortError') {
        const errorMsg = '⏰ Timeout - obliczenia trwały za długo (ponad 60 sekund)';
        setError(errorMsg);
        showAlert({
          variant: 'error',
          title: 'Timeout obliczeń',
          message: 'Obliczenia trwały za długo i zostały przerwane.\n\n🔧 Spróbuj:\n• Zmniejszyć rozmiar danych wejściowych\n• Sprawdzić połączenie z serwerem\n• Skontaktować się z administratorem'
        });
      } else {
        const errorMessage = error instanceof Error ? error.message : String(error);
        setError('Błąd podczas wykonywania obliczeń: ' + errorMessage);
        showAlert({
          variant: 'error', 
          title: 'Błąd wykonywania obliczeń',
          message: `Wystąpił błąd podczas komunikacji z serwerem.\n\n❌ Szczegóły:\n${errorMessage}\n\n🔧 Sprawdź logi w konsoli przeglądarki dla więcej informacji.`
        });
      }
    } finally {
      setCalculating(false);
    }
  };

  // Konfiguracja kolumn dla ResultsTable
  const resultColumns = (calculationResults && calculationResults.calculationType === 'incurred') ? [
    {
      key: 'last_col_incurred',
      header: 'Last Column (Brutto) - Incurred',
      data: calculationResults?.last_col_incurred || [],
      show: canSelectBrutto
    },
    {
      key: 'cum_trian_incurred', 
      header: 'Cumulative Triangle (Brutto Dysk.) - Incurred',
      data: calculationResults?.cum_trian_incurred || [],
      show: canSelectBruttoDysk
    },
    {
      key: 'ult_net_disc_incurred',
      header: 'Ultimate Net Discounted (Netto Dysk.) - Incurred',
      data: calculationResults?.ult_net_disc_incurred || [],
      show: canSelectNettoDysk
    }
  ] : [];

  // Przygotuj dane dla komponentów
  const statusItems = [
    { label: 'Trójkąt Incurred', isLoaded: canSelectBrutto },
    { label: 'Stopy Dyskontowe', isLoaded: isDiscountRatesLoaded() },
    { label: 'Netto/Brutto', isLoaded: isNettoBruttoLoaded() }
  ];

  const actionButtons = [
    {
      label: isCalculating ? 'Obliczanie...' : 'Wykonaj obliczenia',
      onClick: handleExecuteCalculations,
      disabled: isCalculating || !canSelectBrutto,
      variant: 'primary' as const,
      icon: isCalculating ? '⏳' : '✅'
    },
    ...((calculationResults && calculationResults.shouldShowResults === false && calculationResults.calculationType === 'incurred') ? [{
      label: 'Pokaż wyniki',
      onClick: () => showResults(),
      variant: 'info' as const,
      icon: '👁️'
    }] : []),
    ...((calculationResults && calculationResults.calculationType === 'incurred') ? [{
      label: 'Wyczyść wyniki',
      onClick: () => clearResults(),
      variant: 'danger' as const,
      icon: '🗑️'
    }] : []),
    {
      label: 'Generuj raport',
      onClick: () => {},
      variant: 'secondary' as const,
      icon: '📊'
    }
  ];

  return (
    <>
      <CalculationLayout
        sidebar={
          <div className="space-y-6">
            <DataStatusPanel statusItems={statusItems} />
            <hr className="border-gray-600" />
            <ActionButtonsGroup buttons={actionButtons} />
          </div>
        }
      >
        <div className="space-y-6">
          {/* Wyniki z backendu - tabele */}
          {(calculationResults && calculationResults.calculationType === 'incurred') ? (
            <div className="w-full">
              <ResultsTable
                title="Wyniki Obliczeń Chain Ladder - MultIncurred"
                subtitle="Analiza trójkąta incurred metodą deterministyczną"
                columns={resultColumns}
                userId={userId}
                resultsUserId={calculationResults?.userId}
                shouldShowResults={calculationResults?.shouldShowResults}
              />
            </div>
          ) : (
            <EmptyState
              title="Rozpocznij obliczenia MultIncurred"
              description={canSelectBrutto ? (
                `Dane MultIncurred są gotowe do obliczeń. Kliknij "Wykonaj obliczenia", aby wygenerować wyniki analizy.${
                  canSelectBruttoDysk ? '<br/><strong class="text-blue-400">📊 Dostępne:</strong> Brutto + Brutto Dyskontowane' : ''
                }${
                  canSelectNettoDysk ? '<br/><strong class="text-green-400">📈 Dostępne:</strong> + Netto Dyskontowane' : ''
                }`
              ) : (
                'Wczytaj trójkąt incurred w pierwszej zakładce, aby rozpocząć obliczenia.'
              )}
            />
          )}
        </div>
      </CalculationLayout>
      
      {/* Success Modal */}
      <SuccessModal 
        isOpen={showSuccessModal}
        onClose={() => setShowSuccessModal(false)}
      />

      {/* Alert Modal */}
      <CustomAlertDialog
        open={alertState.show}
        onOpenChange={hideAlert}
        variant={alertState.variant}
        title={alertState.title}
        message={alertState.message}
        buttonText="OK"
      />
    </>
  );
}

export { DeterminMethodCLIncurred };