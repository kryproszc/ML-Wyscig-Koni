/* ---------------------------------------------------------------------- */
/*     src/features/Parametryzacja/MultIncurred/FitCurve/FitCurveIncurred.tsx     */
/* ---------------------------------------------------------------------- */
"use client";

import React from "react";
import { 
  FitCurvePageLayout, 
  DEV_J_INCURRED_CONFIG, 
  DEV_J_INCURRED_STORE_MAPPING,
  useFitCurveData
} from "@/shared";

/* ------------------------------------------------------------------ */
/*                              KONTENER                              */
/* ------------------------------------------------------------------ */
import { useTrainDevideStoreIncurred } from "@/stores/useTrainDevideStoreIncurred";

export default function FitCurveIncurred() {
  const fitCurveProps = useFitCurveData({
    config: DEV_J_INCURRED_CONFIG,
    storeMapping: DEV_J_INCURRED_STORE_MAPPING,
    useStore: useTrainDevideStoreIncurred
  });

  // Debug: sprawdź stan danych
  console.log('🔍 [FitCurveIncurred] Current data state:', {
    preview: fitCurveProps.data.preview?.length || 0,
    previewData: fitCurveProps.data.preview,
    selectedIndexes: fitCurveProps.data.selectedIndexes?.length || 0,
    currentVector: fitCurveProps.currentVector?.length || 0,
    currentVectorData: fitCurveProps.currentVector,
    thresholdValue: DEV_J_INCURRED_CONFIG.thresholdValue,
    areEqual: JSON.stringify(fitCurveProps.data.preview) === JSON.stringify(fitCurveProps.currentVector)
  });

  return (
    <FitCurvePageLayout
      config={DEV_J_INCURRED_CONFIG}
      {...fitCurveProps}
    />
  );
}