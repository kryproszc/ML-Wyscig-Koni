/* ---------------------------------------------------------------------- */
/*     src/features/Parametryzacja/MultIncurred/FitCurve/FitCurveSigmaIncurred.tsx     */
/* ---------------------------------------------------------------------- */
"use client";

import React, { useEffect, useRef } from "react";
import { useTrainDevideStoreIncurred } from "@/stores/useTrainDevideStoreIncurred";
import { 
  FitCurvePageLayout, 
  SIGMA_INCURRED_CONFIG, 
  SIGMA_INCURRED_STORE_MAPPING,
  useFitCurveData
} from "@/shared";


export default function FitCurveSigmaIncurred() {
  // Flaga śledząca czy użytkownik już ręcznie modyfikował selekcję
  const hasUserInteractedRef = useRef(false);
  // Dla synchronizacji tailCountSigma z tailCountCL
  const {
    tailCountCL,
    tailCountSigma,
    setTailCountSigma,
  } = useTrainDevideStoreIncurred();

  const fitCurveProps = useFitCurveData({
    config: SIGMA_INCURRED_CONFIG,
    storeMapping: SIGMA_INCURRED_STORE_MAPPING,
    useStore: useTrainDevideStoreIncurred
  });

  // Wykrywanie ręcznej interakcji użytkownika z selekcją
  const originalSetSelectedIndexes = fitCurveProps.actions.setSelectedIndexes;
  const wrappedSetSelectedIndexes = React.useCallback((indexes: number[]) => {
    hasUserInteractedRef.current = true;
    originalSetSelectedIndexes(indexes);
  }, [originalSetSelectedIndexes]);

  // Nadpisanie akcji setSelectedIndexes w fitCurveProps
  const enhancedFitCurveProps = {
    ...fitCurveProps,
    actions: {
      ...fitCurveProps.actions,
      setSelectedIndexes: wrappedSetSelectedIndexes
    }
  };

  // Debug logging
  console.log('🔍 FitCurveSigmaIncurred debug:', {
    tailCountCL,
    tailCountSigma,
    setTailCountSigma: typeof setTailCountSigma,
    fitCurvePropsData: fitCurveProps.data?.tailCount,
    fitCurvePropsActions: typeof fitCurveProps.actions?.setTailCount,
    preview: fitCurveProps.data.preview?.length || 0,
    selectedIndexes: fitCurveProps.data.selectedIndexes,
    thresholdValue: SIGMA_INCURRED_CONFIG.thresholdValue
  });

  // Synchronizacja tailCount z CL
  useEffect(() => {
    if (tailCountCL !== undefined && tailCountCL !== tailCountSigma) {
      console.log('🔄 Synchronizing tailCountSigma with tailCountCL (Incurred):', tailCountCL);
      setTailCountSigma(tailCountCL);
      // Reset flagi przy zmianie danych - pozwoli to na nowe automatyczne zaznaczenie
      hasUserInteractedRef.current = false;
    }
  }, [tailCountCL, tailCountSigma, setTailCountSigma]);

  // Automatyczne zaznaczanie wartości > 0 gdy dane są dostępne (tylko przy pierwszym ładowaniu)
  useEffect(() => {
    // Tylko gdy użytkownik jeszcze nie interagował z selekcją
    if (!hasUserInteractedRef.current && fitCurveProps.data.preview?.length && fitCurveProps.currentVector?.length) {
      // Oblicz które indeksy powinny być zaznaczone (wartości > 0)
      const expectedSelected = fitCurveProps.data.preview
        .map((v, i) => (v > SIGMA_INCURRED_CONFIG.thresholdValue ? i : -1))
        .filter((i) => i >= 0);
      
      // Sprawdź czy aktualnie zaznaczone indeksy są prawidłowe
      const currentSelected = fitCurveProps.data.selectedIndexes;
      const shouldUpdate = 
        expectedSelected.length > 0 && currentSelected.length === 0;
      
      if (shouldUpdate) {
        console.log('🎯 [FitCurveSigmaIncurred] Auto-selecting initial values > 0 for Sigma...');
        console.log('📊 Expected vs Current:', { expected: expectedSelected, current: currentSelected });
        console.log('✅ [FitCurveSigmaIncurred] Setting auto-selected indexes:', expectedSelected);
        // Używamy oryginalnej funkcji, żeby nie oznaczyć jako ręczną interakcję
        fitCurveProps.actions.setSelectedIndexes(expectedSelected);
      }
    }
  }, [
    fitCurveProps.data.preview, 
    fitCurveProps.data.selectedIndexes, 
    fitCurveProps.currentVector,
    fitCurveProps.actions.setSelectedIndexes
  ]);

  return (
    <FitCurvePageLayout
      config={SIGMA_INCURRED_CONFIG}
      {...enhancedFitCurveProps}
    />
  );
}