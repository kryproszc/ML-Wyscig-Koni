// features/Parametryzacja/MultIncurred/Symulacje/ClSimulationIncurred.tsx
'use client';

import { useState } from 'react';
import { CustomAlertDialog } from '@/components/CustomAlertDialog';
import { exportStatisticsToExcel } from '../../../../untils/exportToExcel';
import { useTrainDevideStoreDet } from '../../../../stores/trainDevideStoreDeterministyczny';
import { useTrainDevideStoreIncurred } from '../../../../stores/useTrainDevideStoreIncurred';
import { useSimulationResultsStore } from '../../../../stores/simulationResultsStore';
import { useCombinedSDSummary } from '../hooks/useCombinedSDSummary';
import { useSelectedValuesSD } from '../hooks/useSelectedValuesSD';
import { useParamsymStore } from '../../../../stores/paramsymStore';
import { useDiscountRatesStore } from '../../../../stores/discountRatesStore';
import { useChainLadderResultsStore } from '../../../../stores/chainLadderResultsStore';
import { useUserStore } from '../../../../app/_components/useUserStore';

// Import store dla symulacji incurred (podobny do useCLSimulationStore ale dla incurred)
import { useCLSimulationStore } from '../../../../stores/clSimulationStore';

// 🎯 IMPORTY REUŻYWALNYCH KOMPONENTÓW (dokładnie jak w ClSimulationPaid)
import {
  SimulationLayout,
  SimulationControlPanel,
  SimulationStatisticsTable,
  type DataAvailabilityStatus,
  type SimulationParams
} from '../../../../shared/components/Symulacje';

import {
  useSimulationApi,
  type AlertState,
  type SimulationRequestData
} from '../../../../shared/hooks';

import {
  validateVectorLengths,
  checkDataAvailability,
  getCalculationOptions,
  prepareSelectedValueCL,
  prepareSelectedValueSigma,
  prepareCombinedSDSummary,
  processNetBruttoParams,
  processDiscountRates,
  parseQuantiles
} from '../../../../shared/utils';

export function ClSimulationIncurred() {
  // State dla modali (jak w ClSimulationPaid)
  const [alertState, setAlertState] = useState<AlertState>({
    show: false,
    variant: 'success',
    title: '',
    message: ''
  });

  // API Hook
  const { executeSimulation, executeStatistics, isCalculating, isCalculatingStatistics } = useSimulationApi();

  // Stores dla symulacji incurred
  const {
    simulationParams,
    kwantyle,
    statisticsResults,
    updateSimulationParam,
    setKwantyle,
    setStatisticsResults,
  } = useCLSimulationStore();

  const { 
    results: simulationResults, 
    setResults, 
    clearResults, 
  } = useSimulationResultsStore();

  const hasResults = simulationResults !== null;

  // Prawdziwe dane ze store'ów - użyj właściwych store'ów jak w determinMethodCLrj.tsx
  const { paidTriangle } = useTrainDevideStoreDet(); // Paid z MultPaid store
  const { 
    incurredTriangle,
    selectedDevJIndexes,
    selectedSigmaIndexes,
    leftCountCL,
    tailCountCL,
    combinedDevJSummary,
    combinedSigmaSummary,
    devJ,
    selectedValuesCL,
    selectedValuesSigma,
    combinedRJPaidToIncurredSummary,
    rJPaidToIncurredPreview,
    selectedValuesRJPaidToIncurred,
    selectedValuesVarJPaidToIncurred,
    tailCountVarJPaidToIncurred,
    leftCountRJPaidToIncurred,
    selectedRJPaidToIncurredIndexes,
    selectedVarJPaidToIncurredIndexes,
    sd,
    combinedSDSummary,
    selectedValuesSD,
    safeWeights,  // 🎯 DODANE - wagi z MultIncurred
    selectedWeightsIncurred,  // 🎯 DODANE - wybrane wagi
    setSafeWeights,  // 🎯 DODANE - setter dla safeWeights
    
    // 🎯 DODANE - wagi PaidToIncurred dla weights_rj_incurred
    selectedWeightsPaidToIncurred,  // Wagi z PaidToIncurred (większa macierz)
    safeWeightsPaidToIncurred,  // Przetworzone wagi PaidToIncurred
    
    // 🎯 DODANE - dane PaidToIncurred dla wysylania
    trainPaidToIncurred,     // Główna tabela z endpointu /calc/paid_incurred/triangles
    resIJPaidToIncurred,     // Tabela res_i_j z PaidToIncurred
    lambdaJPaidToIncurred,   // Wartość lambda_j z PaidToIncurred
    
    // 🎯 DODANE - fallback data dla walidacji
    rJPaidToIncurred,        // r_j aktualne wartości (fallback dla selected_values_rj)
    varJPaidToIncurred,      // var_j aktualne wartości (fallback dla selected_values_varj)
  } = useTrainDevideStoreIncurred(); // Incurred z MultIncurred store
  
  const userId = useUserStore((s: any) => s.userId);
  
  // Oddzielnie pobierz wyniki deterministyczne (tylko do odczytu)
  const { results: chainLadderResults } = useChainLadderResultsStore();
  
  const { combinedSDSummary: combinedSDSummaryFromHook, getAsNumbers: getSDAsNumbers, hasData: hasSDData } = useCombinedSDSummary();
  const { getAsNumbers: getSelectedValuesSDAsNumbers, hasData: hasSelectedValuesSD } = useSelectedValuesSD();
  const getParamsymTriangle = useParamsymStore((s) => s.paramsymTriangle);
  const getSelectedParamsymLine = useParamsymStore((s) => s.selectedParamsymLine);
  const getDiscountRatesTriangle = useDiscountRatesStore((s) => s.discountRatesTriangle);
  const getSelectedDiscountRateLine = useDiscountRatesStore((s) => s.selectedDiscountRateLine);

  // Sprawdzenie dostępności danych dla Incurred
  const dataAvailability = checkDataAvailability(
    incurredTriangle || [], // Używamy incurred triangle
    getDiscountRatesTriangle,
    getParamsymTriangle
  );

  const calculationOptions = getCalculationOptions(dataAvailability);

  // Przygotuj dane dla DataAvailabilityStatus
  const dataAvailabilityStatus: DataAvailabilityStatus[] = [
    {
      label: 'Trójkąt Paid',
      isAvailable: Boolean(paidTriangle && paidTriangle.length > 0),
      status: (paidTriangle && paidTriangle.length > 0) ? 'Wczytany' : 'Brak danych'
    },
    {
      label: 'Trójkąt Incurred', 
      isAvailable: dataAvailability.paidTriangle, // Tu sprawdzamy incurred (funkcja checkDataAvailability sprawdza pierwszy parametr)
      status: dataAvailability.paidTriangle ? 'Wczytany' : 'Brak danych'
    },
    {
      label: 'Stopy Dyskontowe',
      isAvailable: dataAvailability.discountRates,
      status: dataAvailability.discountRates ? 'Wczytany' : 'Brak danych'
    },
    {
      label: 'Netto/Brutto',
      isAvailable: dataAvailability.nettoBrutto,
      status: dataAvailability.nettoBrutto ? 'Wczytany' : 'Brak danych'
    }
  ];

  // Funkcje pomocnicze
  const showAlert = (state: Partial<AlertState>) => {
    setAlertState(prev => ({ ...prev, ...state, show: true }));
  };

  const hideAlert = () => {
    setAlertState(prev => ({ ...prev, show: false }));
  };


  // Główna funkcja wykonania obliczeń
  const handleExecuteCalculations = async () => {
    // Wyczyść stare wyniki
    clearResults();
    setStatisticsResults([]);
    
    if (!userId) {
      return;
    }

    // Sprawdź podstawowe wymagania
    if (!dataAvailability.paidTriangle) { // Sprawdzamy incurred triangle
      showAlert({
        variant: 'error',
        title: 'Błąd danych',
        message: 'Wymagany trójkąt incurred do wykonania obliczeń'
      });
      return;
    }

    // Pobierz dane z incurred store
    const freshIncurredState = useTrainDevideStoreIncurred.getState();
    const freshDetState = useTrainDevideStoreDet.getState();
    
    // Przygotuj wagi dla Incurred (identycznie jak w ClSimulationPaid)
    let calculatedSafeWeights: number[][];
    if (safeWeights && safeWeights.length > 0) {
      calculatedSafeWeights = safeWeights;
    } else {
      calculatedSafeWeights = selectedWeightsIncurred?.map((r) => r.map((c) => (c === 1 ? 1 : 0))) ?? [];
      setSafeWeights(calculatedSafeWeights);
    }

    // Przygotuj wektory z fallbackami dla Incurred - UŻYJ DANYCH Z FINALTABLE
    const vectorSelectedValueCL = prepareSelectedValueCL(
      freshIncurredState.selectedValuesCL,  // Z FinalTable Selected Values 
      combinedDevJSummary,
      devJ || []
    );

    const vectorSelectedValueSigma = prepareSelectedValueSigma(
      freshIncurredState.selectedValuesSigma,  // Z FinalTable Selected Values
      combinedSigmaSummary,
      freshIncurredState.sigma || []
    );

    // 🎯 UŻYWAJ selectedValuesSD zamiast hook'ów - to są dane z FinalTable!
    const vectorCombinedSDSummary = prepareCombinedSDSummary(
      selectedValuesSD || [],  // 🎯 BEZPOŚREDNIO z store (FinalTable Selected Values)
      freshIncurredState.combinedSDSummary || [],
      sd || []
    );

    // Waliduj długości wektorów
    const validation = validateVectorLengths(
      vectorSelectedValueCL,
      vectorSelectedValueSigma,
      vectorCombinedSDSummary
    );

    if (!validation.isValid) {
      showAlert({
        variant: 'error',
        title: 'Błąd długości wektorów',
        message: validation.errorMessage || 'Błąd walidacji wektorów'
      });
      return;
    }

    // Przygotuj pozostałe dane
    const processedNetBrutto = processNetBruttoParams(
      getParamsymTriangle,
      getSelectedParamsymLine
    );

    const processedDiscountRates = processDiscountRates(
      getDiscountRatesTriangle,
      getSelectedDiscountRateLine
    );

    // 🔍 DEBUGGING: Sprawdź dane z FinalTable Selected Values
    console.log('🔍 [INCURRED STORE DATA] selectedValuesSD:', selectedValuesSD);
    console.log('🔍 [INCURRED STORE DATA] selectedValuesCL:', selectedValuesCL);
    console.log('🔍 [INCURRED STORE DATA] selectedValuesSigma:', selectedValuesSigma);
    console.log('🔍 [INCURRED STORE DATA] combinedSDSummary:', combinedSDSummary);
    console.log('🔍 [INCURRED STORE DATA] combinedDevJSummary:', combinedDevJSummary);
    console.log('🔍 [INCURRED STORE DATA] combinedSigmaSummary:', combinedSigmaSummary);
    
    // 🔍 DEBUGGING: Sprawdź co jest w chainLadderResults
    console.log('🔍 [chainLadderResults] PEŁNA STRUKTURA:', chainLadderResults);
    console.log('🔍 [chainLadderResults] KLUCZE:', chainLadderResults ? Object.keys(chainLadderResults) : 'NULL');
    console.log('🔍 [chainLadderResults._incurred] last_col_incurred:', chainLadderResults?.last_col_incurred);
    console.log('🔍 [chainLadderResults._incurred] cum_trian_incurred:', chainLadderResults?.cum_trian_incurred);
    console.log('🔍 [chainLadderResults._incurred] ult_net_disc_incurred:', chainLadderResults?.ult_net_disc_incurred);
    console.log('🔍 [chainLadderResults.metadata] calculationType:', chainLadderResults?.calculationType);
    console.log('🔍 [chainLadderResults.metadata] userId:', chainLadderResults?.userId);

    // 🎯 DEBUG - sprawdź rozmiary macierzy WAG przed utworzeniem requestData
    console.log('🔍 === SPRAWDZENIE ROZMIARÓW MACIERZY WAG ===');
    console.log('calculatedSafeWeights (MultIncurred):', calculatedSafeWeights?.length || 0, 'x', calculatedSafeWeights?.[0]?.length || 0);
    console.log('safeWeightsPaidToIncurred (PaidToIncurred):', safeWeightsPaidToIncurred?.length || 0, 'x', safeWeightsPaidToIncurred?.[0]?.length || 0);
    console.log('selectedWeightsPaidToIncurred (PaidToIncurred):', selectedWeightsPaidToIncurred?.length || 0, 'x', selectedWeightsPaidToIncurred?.[0]?.length || 0);
    
    // Wybierz właściwe wagi dla weights_rj_incurred
    const weightsRjIncurred = safeWeightsPaidToIncurred || selectedWeightsPaidToIncurred || calculatedSafeWeights;
    console.log('weightsRjIncurred (używane dla weights_rj_incurred):', weightsRjIncurred?.length || 0, 'x', weightsRjIncurred?.[0]?.length || 0);
    console.log('🔍 === KONIEC SPRAWDZENIA ===');

    // 🔍 WALIDACJA I FALLBACK SELECTED VALUES PRZED WYSŁANIEM
    console.log('🔍 === WALIDACJA SELECTED VALUES ===');
    
    // Funkcja sprawdzająca czy array jest pusty lub ma NaN/null/undefined
    const isEmptyOrInvalid = (arr: any[]): boolean => {
      if (!Array.isArray(arr) || arr.length === 0) return true;
      return arr.every(val => val == null || isNaN(val) || val === undefined || val === '');
    };

    // 1. Walidacja selected_values_rj_paid_to_incurred
    let finalSelectedValuesRJ = selectedValuesRJPaidToIncurred || [];
    if (isEmptyOrInvalid(finalSelectedValuesRJ)) {
      console.log('⚠️ selected_values_rj_paid_to_incurred jest puste/invalid, używam rJPaidToIncurred jako fallback');
      finalSelectedValuesRJ = freshIncurredState.rJPaidToIncurred || [];
    }
    console.log('🔵 Finalne selected_values_rj_paid_to_incurred:', finalSelectedValuesRJ?.length || 0, 'elementów');

    // 2. Walidacja selected_values_sd_incurred  
    let finalSelectedValuesSD = selectedValuesSD || [];
    if (isEmptyOrInvalid(finalSelectedValuesSD)) {
      console.log('⚠️ selected_values_sd_incurred jest puste/invalid, używam sd jako fallback');
      finalSelectedValuesSD = sd || [];
    }
    console.log('🔵 Finalne selected_values_sd_incurred:', finalSelectedValuesSD?.length || 0, 'elementów');

    // 3. Walidacja selected_values_varj_paid_to_incurred
    let finalSelectedValuesVarJ = selectedValuesVarJPaidToIncurred || [];
    if (isEmptyOrInvalid(finalSelectedValuesVarJ)) {
      console.log('⚠️ selected_values_varj_paid_to_incurred jest puste/invalid, używam varJPaidToIncurred jako fallback');
      finalSelectedValuesVarJ = freshIncurredState.varJPaidToIncurred || [];
    }
    console.log('🔵 Finalne selected_values_varj_paid_to_incurred:', finalSelectedValuesVarJ?.length || 0, 'elementów');

    // 4. Walidacja selected_value_sd_incurred (vectorCombinedSDSummary)
    let finalSelectedValueSD = vectorCombinedSDSummary;
    if (isEmptyOrInvalid(finalSelectedValueSD)) {
      console.log('⚠️ selected_value_sd_incurred jest puste/invalid, używam sd jako fallback');
      finalSelectedValueSD = sd || [];
    }
    console.log('🔵 Finalne selected_value_sd_incurred:', finalSelectedValueSD?.length || 0, 'elementów');
    console.log('🔍 === KONIEC WALIDACJI ===');

    // Przygotuj request data dla Incurred zgodnie z klasą SimulationClIncurredRequest
    const requestData: any = {
      // Wektory obliczeń z Chain Ladder Results (MultIncurred z suffixami)
      last_col_incurred: Array.isArray(chainLadderResults?.last_col_incurred) ? chainLadderResults.last_col_incurred : [],
      cum_trian_incurred: Array.isArray(chainLadderResults?.cum_trian_incurred) ? chainLadderResults.cum_trian_incurred : [],
      ult_net_disc_incurred: Array.isArray(chainLadderResults?.ult_net_disc_incurred) ? chainLadderResults.ult_net_disc_incurred : [],
      
      user_id_incurred: userId,
      
      // Parametry symulacji zgodnie z klasą backendu
      ilosc_symulacji_incurred: simulationParams.iloscSymulacji,
      ziarno_incurred: simulationParams.ziarno,
      skalowanie_incurred: simulationParams.skalowanie,
      skalowanie2_incurred: simulationParams.skalowanie2,
      kwantyle_incurred: parseQuantiles(kwantyle),
      
      // Trójkąty danych
      paid_triangle_incurred: paidTriangle || [], // Z MultPaid store
      incurred_triangle_incurred: incurredTriangle || [], // Z MultIncurred store
      
      // Wagi - DODANE
      weights_incurred: calculatedSafeWeights,  // 🎯 NOWE POLE - wagi z MultIncurred
      weights_rj_incurred: weightsRjIncurred,  // 🎯 POPRAWIONE - wagi z PaidToIncurred (większa macierz)
      
      // Opcje kalkulacji
      calculation_options_incurred: calculationOptions,
      
      // Podsumowania i współczynniki
      combined_sd_summary_incurred: vectorCombinedSDSummary,
      
      // Indeksy i selekcje - POPRAWIONE NAZWY zgodnie z backendem
      selected_dev_j_indexes_incurred: selectedDevJIndexes || [],
      selected_sigma_indexes_incurred: selectedSigmaIndexes || [],
      sigma_indexes_incurred: selectedSigmaIndexes || [], // Duplikacja dla kompatybilności
      left_count_cl_incurred: leftCountCL || 0,
      
      // Selected values - DODANE BRAKUJĄCE POLA
      selected_value_cl_incurred: vectorSelectedValueCL,  // 🎯 DODANE - dane z CL (Incurred) FinalTable 
      selected_value_sigma_incurred: vectorSelectedValueSigma,
      selected_value_sd_incurred: finalSelectedValueSD,  // 🎯 ZWALIDOWANE - z fallbackiem do sd_incurred
      selected_values_rj_paid_to_incurred: finalSelectedValuesRJ,  // 🎯 ZWALIDOWANE - z fallbackiem
      selected_values_varj_paid_to_incurred: finalSelectedValuesVarJ,  // 🎯 ZWALIDOWANE - z fallbackiem
      selected_rj_paid_to_incurred_indexes_incurred: selectedRJPaidToIncurredIndexes || [],  // 🎯 DODANE - indeksy zaznaczonych r_j
      selected_varj_paid_to_incurred_indexes_incurred: selectedVarJPaidToIncurredIndexes || [],
      
      // 🎯 DODANE - oryginalne dane z API (analogiczne do dev_j i rj_paid_to_incurred)
      sigma_incurred: freshIncurredState.sigma || [],  // Oryginalne dane sigma z API
      sd_incurred: sd || [],  // Oryginalne dane sd z API
      
      // Tail counts - POPRAWIONE NAZWY
      tail_count_cl_incurred: tailCountCL === "" || tailCountCL === null || tailCountCL === undefined 
        ? 0 
        : Number(tailCountCL),
      tail_count_rj_paid_to_incurred: leftCountRJPaidToIncurred || 0,
      tail_count_varj_paid_to_incurred_incurred: tailCountVarJPaidToIncurred || 0,
      
      // Stawki dyskontowe i netto/brutto
      discount_rates_incurred: processedDiscountRates,
      netto_brutto_incurred: processedNetBrutto,
      
      // 🎯 DODANE - dane PaidToIncurred
      train_paidtoincurred: trainPaidToIncurred || [],  // 🎯 NOWE POLE - główna tabela z endpointu /calc/paid_incurred/triangles
      res_i_j_paid_to_incurred: resIJPaidToIncurred || [],  // Tabela res_i_j z PaidToIncurred
      lambda_j_paid_to_incurred: lambdaJPaidToIncurred || null,  // Wartość lambda_j z PaidToIncurred
      
      // 🎯 DODANE - współczynniki var_j z tabeli PaidToIncurred  
      varj_paid_to_incurred_coefficients: freshIncurredState.varJPaidToIncurred || [],  // Współczynniki var_j z tabeli PaidToIncurred
      
      // Lambda jako ostatnie pole
      lambda: lambdaJPaidToIncurred || null,
    };

    // 🚀 PEŁNE LOGOWANIE requestData wysyłanego na backend
    console.log('🚀 [BACKEND REQUEST] PEŁNE requestData wysyłane na /calc/simulationClIncurred:');
    console.log(JSON.stringify(requestData, null, 2));

    // Wykonaj symulację
    const results = await executeSimulation(
      requestData,
      '/calc/simulationClIncurred',
      showAlert
    );

    if (results) {
      console.log('🔍 [SYMULACJA DEBUG] Wyniki z backendu przed zapisem:', results);
      console.log('🔍 [SYMULACJA DEBUG] results.userId:', results.userId);
      console.log('🔍 [SYMULACJA DEBUG] typeof results.userId:', typeof results.userId);
      console.log('🔍 [SYMULACJA DEBUG] aktualny userId:', userId);
      
      // 🎯 UPEWNIJ SIĘ ŻE userId JEST ZAPISANY W WYNIKACH
      const resultsWithUserId = {
        ...results,
        userId: userId,  // Wymuś ustawienie userId
        calculatedAt: new Date().toISOString() // Dodaj timestamp
      };
      
      console.log('🔍 [SYMULACJA DEBUG] Wyniki po dodaniu userId:', resultsWithUserId);
      
      setResults(resultsWithUserId);
      
      // Jeśli symulacja się udała, usuń stare statystyki
      setStatisticsResults([]);
    }
  };

  // Funkcja wykonania statystyk
  const handleExecuteStatistics = async () => {
    // Guard clause dla userId
    if (!userId) {
      showAlert({
        variant: 'error',
        title: 'Błąd użytkownika',
        message: 'Brak identyfikatora użytkownika'
      });
      return;
    }

    // 🔍 DEBUG - sprawdź stan danych
    console.log('🔍 [DEBUG STATYSTYKI] simulationResults:', simulationResults);
    console.log('🔍 [DEBUG STATYSTYKI] simulationResults?.userId:', simulationResults?.userId);
    console.log('🔍 [DEBUG STATYSTYKI] aktualny userId:', userId);
    console.log('🔍 [DEBUG STATYSTYKI] chainLadderResults?.userId:', chainLadderResults?.userId);

    if (!simulationResults) {
      console.log('❌ [WALIDACJA] Brak simulationResults - pokazuję alert');
      showAlert({
        variant: 'warning',
        title: 'Brak danych symulacji',
        message: 'Najpierw wykonaj "Wykonaj obliczenia", a następnie statystyki.'
      });
      return;
    }

    // Sprawdź czy wyniki są świeże (mają userId)
    console.log('🔍 [WALIDACJA] Sprawdzam świeżość danych...');
    console.log('🔍 [WALIDACJA] simulationResults.userId:', simulationResults.userId);
    console.log('🔍 [WALIDACJA] typeof simulationResults.userId:', typeof simulationResults.userId);
    console.log('🔍 [WALIDACJA] userId:', userId);
    console.log('🔍 [WALIDACJA] typeof userId:', typeof userId);
    console.log('🔍 [WALIDACJA] !simulationResults.userId:', !simulationResults.userId);
    console.log('🔍 [WALIDACJA] simulationResults.userId !== userId:', simulationResults.userId !== userId);
    
    if (!simulationResults.userId || simulationResults.userId !== userId) {
      console.log('❌ [WALIDACJA] Nieświeże dane - userId nie pasuje lub brak userId');
      showAlert({
        variant: 'warning',
        title: 'Nieświeże dane symulacji',
        message: 'Wyniki symulacji są przestarzałe. Wykonaj ponownie "Wykonaj obliczenia".'
      });
      return;
    }

    console.log('✅ [WALIDACJA] Dane są świeże - kontynuuję...');

    // Sprawdź czy wyniki deterministyczne są rzeczywiście obliczone
    const hasDeterministicResults = chainLadderResults && 
                                   chainLadderResults.userId === userId &&
                                   chainLadderResults.shouldShowResults === true &&
                                   Array.isArray(chainLadderResults.last_col_incurred) &&
                                   chainLadderResults.last_col_incurred.length > 0 &&
                                   chainLadderResults.last_col_incurred.some(val => val !== 0) &&
                                   typeof chainLadderResults.userId === 'string' &&
                                   typeof chainLadderResults.calculatedAt === 'string' &&
                                   Array.isArray(chainLadderResults.cum_trian_incurred) &&
                                   Array.isArray(chainLadderResults.ult_net_disc_incurred);

    // Używamy identycznej logiki jak w ClSimulationPaid - optimized approach + dodatkowe pola Incurred
    const statisticsData: any = {
      // Podstawowe pola jak w ClSimulationPaid
      user_id: userId, // userId jest już sprawdzony wyżej
      kwantyle: parseQuantiles(kwantyle),
      skalowanie: simulationParams.skalowanie,
      skalowanie2: simulationParams.skalowanie2,
      // Zamiast wysyłać dummy results, wyślij null - backend użyje zapisanych danych
      simulation_results: null,
      // 🎯 WYSYŁAJ tylko rzeczywiste wyniki deterministyczne dla Incurred
      deterministic_results: hasDeterministicResults ? {
        cum_trian: chainLadderResults.cum_trian_incurred as number[],
        last_col: chainLadderResults.last_col_incurred as number[],
        ult_net_disc: chainLadderResults.ult_net_disc_incurred as number[],
        userId: chainLadderResults.userId as string,
        calculatedAt: chainLadderResults.calculatedAt as string
      } : null,
      
      // 🎯 DODATKOWE POLA INCURRED - identyczne jak w symulacji
      last_col_incurred: Array.isArray(chainLadderResults?.last_col_incurred) ? chainLadderResults.last_col_incurred : [],
      cum_trian_incurred: Array.isArray(chainLadderResults?.cum_trian_incurred) ? chainLadderResults.cum_trian_incurred : [],
      ult_net_disc_incurred: Array.isArray(chainLadderResults?.ult_net_disc_incurred) ? chainLadderResults.ult_net_disc_incurred : [],
      user_id_incurred: userId,
      skalowanie_incurred: simulationParams.skalowanie,
      skalowanie2_incurred: simulationParams.skalowanie2,
      kwantyle_incurred: parseQuantiles(kwantyle),
    };

    console.log('🚀 [WYKONAJ STATYSTYKI INCURRED] Wysyłane dane:', statisticsData);
    
    // 🔍 DEBUG - sprawdź czy pola Incurred są załadowane
    console.log('🔍 [STATISTYKI DEBUG] last_col_incurred:', statisticsData.last_col_incurred?.length || 0, 'elementów');
    console.log('🔍 [STATISTYKI DEBUG] cum_trian_incurred:', statisticsData.cum_trian_incurred?.length || 0, 'elementów');
    console.log('🔍 [STATISTYKI DEBUG] ult_net_disc_incurred:', statisticsData.ult_net_disc_incurred?.length || 0, 'elementów');
    console.log('🔍 [STATISTYKI DEBUG] user_id_incurred:', statisticsData.user_id_incurred);
    console.log('🔍 [STATISTYKI DEBUG] skalowanie_incurred:', statisticsData.skalowanie_incurred);
    console.log('🔍 [STATISTYKI DEBUG] skalowanie2_incurred:', statisticsData.skalowanie2_incurred);
    console.log('🔍 [STATISTYKI DEBUG] kwantyle_incurred:', statisticsData.kwantyle_incurred);

    const results = await executeStatistics(
      statisticsData,
      '/calc/statisticClIncurred',
      showAlert
    );

    if (results) {
      setStatisticsResults(results);
    }
  };


  // Funkcja eksportu do Excel
  const handleExportStatistics = () => {
    if (statisticsResults.length === 0) {
      showAlert({
        variant: 'warning',
        title: 'Brak danych',
        message: 'Najpierw wykonaj statystyki, aby móc je wyeksportować do Excel.'
      });
      return;
    }

    try {
      exportStatisticsToExcel(
        statisticsResults,
        kwantyle,
        simulationParams.skalowanie,
        simulationParams
      );
      showAlert({
        variant: 'success',
        title: 'Eksport wykonany!',
        message: 'Statystyki zostały zapisane do pliku Excel.'
      });
    } catch (error) {
      console.error('Błąd podczas eksportu:', error);
      showAlert({
        variant: 'error',
        title: 'Błąd eksportu',
        message: 'Wystąpił błąd podczas zapisywania do Excel. Sprawdź konsolę przeglądarki.'
      });
    }
  };

  return (
    <>
      <SimulationLayout
        sidebar={
          <SimulationControlPanel
            simulationParams={simulationParams}
            kwantyle={kwantyle}
            isCalculating={isCalculating}
            isCalculatingStatistics={isCalculatingStatistics}
            hasResults={hasResults}
            statisticsResultsCount={statisticsResults.length}
            dataAvailability={dataAvailabilityStatus}
            onUpdateSimulationParam={updateSimulationParam}
            onSetKwantyle={setKwantyle}
            onExecuteCalculations={() => {
              handleExecuteCalculations();
            }}
            onExecuteStatistics={handleExecuteStatistics}
            onClearResults={clearResults}
            onClearStatistics={() => setStatisticsResults([])}
            onExportStatistics={handleExportStatistics}
          />
        }
      >
        <SimulationStatisticsTable
          statisticsResults={statisticsResults}
          kwantyle={kwantyle}
          skalowanie={simulationParams.skalowanie}
          skalowanie2={simulationParams.skalowanie2}
          title="📊 Wyniki Statystyk Chain Ladder Incurred"
          subtitle="Analiza statystyczna wyników symulacji metodą Chain Ladder z danymi Incurred"
        />
      </SimulationLayout>

      {/* Modal */}
      <CustomAlertDialog
        open={alertState.show}
        onOpenChange={hideAlert}
        variant={alertState.variant}
        title={alertState.title}
        message={alertState.message}
        buttonText="OK"
      />
    </>
  );
}