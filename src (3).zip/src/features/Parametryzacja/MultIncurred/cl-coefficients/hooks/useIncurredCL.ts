'use client';

import { useEffect } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useUserStore } from '@/app/_components/useUserStore';
import {
  useTrainDevideStoreIncurred,
} from '@/stores/useTrainDevideStoreIncurred';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export function useIncurredCL() {
  const userId = useUserStore((s) => s.userId);
  const store = useTrainDevideStoreIncurred();

  const {
    incurredTriangle,
    trainDevideIncurred,
    selectedWeightsIncurred,
    safeWeights,
    selectedCellsIncurred,
    volume,
    devJResults,
    sigmaResults,
    devJ,
    sigma,
    sd,
    setTrainDevideIncurred,
    setSafeWeights,
    setDevJ,
    setSigma,
    setSd,
    addDevJResult,
    addSigmaResult,
    resetSelectionIncurred,
    toggleRowIncurred,
    toggleCellIncurred,
    toggleWeightCellIncurred,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    setMinMaxHighlighting,
    selectedDevJVolume: selectedVolume,
    selectedDevJSubIndex: selectedSubIndex,
    setSelectedDevJVolume: setSelectedVolume,
    selectedSigmaVolume,
    selectedSigmaSubIndex,
    setSelectedSigmaVolume,
    // FitCurve preview setters dla automatycznego wybierania
    setDevJPreview,
    setSelectedDevJIndexes,
    setSigmaPreview,
    setSelectedSigmaIndexes,
  } = store;

  /* -------- mutation 1 -------- */
  const mTrainDivide = useMutation({
    mutationKey: ['trainDevideIncurred', volume],
    mutationFn: async () => {
      const triangle = (incurredTriangle ?? []);
      
      console.log('📤 [mTrainDivide] Wysyłam na backend:', {
        endpoint: `${API_URL}/calc/incurred/train_devide_incurred`,
        triangleRows: triangle.length,
        triangleCols: triangle[0]?.length || 0,
        firstRow: triangle[0],
        userId: userId,
        fullTriangle: triangle
      });
      
      const requestBody = { user_id: userId, incurred_data_det: triangle };
      console.log('📤 [mTrainDivide] Request body:', requestBody);
      
      const res = await fetch(`${API_URL}/calc/incurred/train_devide_incurred`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody),
      });
      return res.json() as Promise<{ train_devide?: number[][] }>;
    },
    onSuccess: (d) => {
      if (d.train_devide) {
        setTrainDevideIncurred(d.train_devide);
        // Ustaw wszystkie komórki jako zaznaczone domyślnie tylko jeśli weights nie istnieją
        if (!selectedWeightsIncurred) {
          resetSelectionIncurred();
        }
      }
    },
  });

  /* -------- mutation 2 -------- */
  const mCL = useMutation({
    mutationKey: ['clIncurred', volume],
    mutationFn: async () => {
      // Użyj oryginalnej macierzy z Excela (incurredTriangle) - usuń ostatni wiersz
      const processedTriangle = (incurredTriangle ?? []).slice(0, -1);

      // Buduj macierz wag na podstawie trainDevideIncurred (przetworzonej przez backend)
      const trainMatrix = (trainDevideIncurred ?? []).slice(0, -1);
      const safeWeights = trainMatrix.map((row, rowIndex) => 
        row.map((cell, colIndex) => {
          // Jeśli komórka ma NaN/null/undefined - waga = 0 (nie ma danych)
          if (cell === null || cell === undefined || isNaN(cell)) return 0;
          
          // Jeśli komórka ma liczbę - użyj wagi z selectedWeightsIncurred
          const originalWeight = selectedWeightsIncurred?.[rowIndex]?.[colIndex];
          return originalWeight === 1 ? 1 : 0;
        })
      );

      // 🔥 ZAPISZ DO STORE dla innych zakładek
      setSafeWeights(safeWeights);
      
      console.log('📋 === ORYGINALNA MACIERZ Z EXCELA (incurredTriangle) ===');
      incurredTriangle?.forEach((row, i) => {
        console.log(`Wiersz ${i}:`, row);
      });
      
      console.log('🔺 === MACIERZ TRAINDEVIDEINCURRED (z backendu) ===');
      trainDevideIncurred?.forEach((row, i) => {
        console.log(`Wiersz ${i}:`, row);
      });
      
      console.log('🟦 === NOWA MACIERZ WAGI (z incurredTriangle) ===');
      safeWeights.forEach((row, i) => {
        console.log(`Wiersz ${i}:`, row);
      });
      
      const requestBody = {
        user_id: userId,
        incurred_data_det: processedTriangle,
        weights: safeWeights,
      };
      
      console.log('📤 [mCL] Wysyłam na backend:', {
        endpoint: `${API_URL}/calc/incurred/cl`,
        processedTriangleRows: processedTriangle.length,
        processedTriangleCols: processedTriangle[0]?.length || 0,
        weightsRows: safeWeights.length,
        weightsCols: safeWeights[0]?.length || 0,
        userId: userId,
        requestBody
      });
      
      const res = await fetch(`${API_URL}/calc/incurred/cl`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody),
      });
      return res.json() as Promise<{ 
        message?: string; 
        dev_j?: number[]; 
        sigmas?: { 
          sd: number[]; 
          sigma: number[]; 
        };
      }>;
    },
    onSuccess: (d) => {
      console.log('🚀 Odpowiedź z /calc/incurred/cl:', d);
      
      if (d.dev_j) {
        console.log('✅ Otrzymano dev_j:', d.dev_j);
        setDevJ(d.dev_j);
        addDevJResult(volume, d.dev_j);
        setSelectedVolume(volume, undefined);
        
        // Automatycznie kopiuj do preview TYLKO jeśli preview jest puste (pierwsze obliczenia)
        if (!store.devJPreview || store.devJPreview.length === 0) {
          console.log('🎯 Pierwsze obliczenia - automatycznie ładuję do preview');
          setDevJPreview(d.dev_j);
          
          // Automatycznie wybierz odpowiednie indeksy tylko przy pierwszym załadowaniu
          const autoSelectedDevJ = d.dev_j
            .map((v, i) => (Math.abs(v - 1.0) > 0.0001 ? i : -1))
            .filter((i) => i >= 0);
          setSelectedDevJIndexes(autoSelectedDevJ);
          console.log('🎯 Auto-selected dev_j indexes (pierwsze obliczenia):', autoSelectedDevJ);
        } else {
          console.log('ℹ️ Preview już istnieje - nie aktualizuję automatycznie. Użyj "Zaktualizuj wektor"');
        }
        
        // WYŁĄCZONE: Automatyczne kopiowanie do preview - użytkownik musi kliknąć "Zaktualizuj wektor"
        // setDevJPreview(d.dev_j);
        
        // WYŁĄCZONE: Automatyczne wybieranie indeksów - użytkownik musi kliknąć "Zaktualizuj wektor"
        // const autoSelectedDevJ = d.dev_j
        //   .map((v, i) => (Math.abs(v - 1.0) > 0.0001 ? i : -1))
        //   .filter((i) => i >= 0);
        // setSelectedDevJIndexes(autoSelectedDevJ);
        // console.log('🎯 Auto-selected dev_j indexes (excluding values = 1.0):', autoSelectedDevJ);
      }
      
      if (d.sigmas?.sigma) {
        console.log('✅ Otrzymano sigma (z API sigmas.sigma - to faktycznie sd):', d.sigmas.sigma);
        setSd(d.sigmas.sigma); // API zwraca sd jako "sigma"
      }
      
      if (d.sigmas?.sd) {
        console.log('✅ Otrzymano sd (z API sigmas.sd - to faktycznie sigma):', d.sigmas.sd);
        setSigma(d.sigmas.sd); // API zwraca sigma jako "sd"
        addSigmaResult(volume, d.sigmas.sd);
        setSelectedSigmaVolume(volume, undefined);
        
        // Automatycznie kopiuj do preview TYLKO jeśli preview jest puste (pierwsze obliczenia)
        if (!store.sigmaPreview || store.sigmaPreview.length === 0) {
          console.log('🎯 Pierwsze obliczenia sigma - automatycznie ładuję do preview');
          setSigmaPreview(d.sigmas.sd);
          
          // Automatycznie wybierz odpowiednie indeksy tylko przy pierwszym załadowaniu
          const autoSelectedSigma = d.sigmas.sd
            .map((v, i) => (v > 0 ? i : -1))
            .filter((i) => i >= 0);
          setSelectedSigmaIndexes(autoSelectedSigma);
          console.log('🎯 Auto-selected sigma indexes (pierwsze obliczenia):', autoSelectedSigma);
        } else {
          console.log('ℹ️ Sigma preview już istnieje - nie aktualizuję automatycznie. Użyj "Zaktualizuj wektor"');
        }
        
        // WYŁĄCZONE: Automatyczne kopiowanie do preview - użytkownik musi kliknąć "Zaktualizuj wektor"
        // setSigmaPreview(d.sigmas.sd);
        
        // WYŁĄCZONE: Automatyczne wybieranie indeksów - użytkownik musi kliknąć "Zaktualizuj wektor"  
        // const autoSelectedSigma = d.sigmas.sd
        //   .map((v, i) => (v > 0 ? i : -1))
        //   .filter((i) => i >= 0);
        // setSelectedSigmaIndexes(autoSelectedSigma);
        // console.log('🎯 Auto-selected sigma indexes (values > 0):', autoSelectedSigma);
      }
    },
  });

  /* auto-start train_divide */
  useEffect(() => {
    console.log('[useIncurredCL] 🔍 useEffect triggered:', {
      incurredTriangleLength: incurredTriangle?.length || 0,
      trainDevideIncurredLength: trainDevideIncurred?.length || 0,
      hasIncurredTriangle: !!incurredTriangle?.length,
      hasTrainDevide: !!trainDevideIncurred?.length,
      shouldTrigger: !!(incurredTriangle?.length && !trainDevideIncurred?.length)
    });
    
    if (incurredTriangle?.length && !trainDevideIncurred?.length) {
      console.log('[useIncurredCL] 🚀 Triggering mTrainDivide.mutate()');
      mTrainDivide.mutate();
    } else {
      console.log('[useIncurredCL] ❌ Warunki nie spełnione - nie triggeruję train_divide');
    }
  }, [incurredTriangle, trainDevideIncurred]);

  return {
    triangle: incurredTriangle,
    trainDevide: trainDevideIncurred,
    weights: selectedWeightsIncurred,
    selectedCells: selectedCellsIncurred,
    devJResults,
    sigmaResults,
    devJ,
    sigma,
    sd,
    selectedVolume,
    selectedSubIndex,
    setSelectedVolume,
    selectedSigmaVolume,
    selectedSigmaSubIndex,
    setSelectedSigmaVolume,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    toggleRowDet: toggleRowIncurred,
    toggleCellDet: toggleCellIncurred,
    toggleWeightCellDet: toggleWeightCellIncurred,

    runSigma: () => mCL.mutate(),
    isLoading: mTrainDivide.isPending || mCL.isPending,
  };
}