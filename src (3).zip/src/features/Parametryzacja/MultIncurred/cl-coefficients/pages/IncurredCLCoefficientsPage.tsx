'use client';

import React, { useState } from 'react';
import { useIncurredCL } from '../hooks/useIncurredCL';
import SidebarPanelCLIncurred from '../components/SidebarPanelCLIncurred';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { useDisplaySettingsStore } from '@/stores/useDisplaySettingsStore';
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred';
import {
  CalculationPageLayout,
  type ResultRow,
} from '@/shared/components/calculation-tables';

export default function IncurredCLCoefficientsPage() {
  // Labels from store (JUŻ 1:1 z body — bez rogu)
  const incurredRowLabels = useLabelsStore((s) => s.incurredRowLabels);
  const incurredColumnLabels = useLabelsStore((s) => s.incurredColumnLabels);

  // Display settings for fullscreen
  const fullscreenMode = useDisplaySettingsStore((s) => s.fullscreenMode);
  const tableScale = useDisplaySettingsStore((s) => s.tableScale);
  const setFullscreenMode = useDisplaySettingsStore((s) => s.setFullscreenMode);
  const increaseScale = useDisplaySettingsStore((s) => s.increaseScale);
  const decreaseScale = useDisplaySettingsStore((s) => s.decreaseScale);

  // Stan dla animacji zamykania
  const [isClosing, setIsClosing] = useState(false);

  const {
    triangle,
    trainDevide,
    weights,
    selectedCells,
    devJ,
    sigma,
    sd,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    toggleRowDet,
    toggleWeightCellDet,
    runSigma,
    isLoading,
  } = useIncurredCL();

  // Dostęp do store dla decimalPlaces
  const store = useTrainDevideStoreIncurred();
  const { decimalPlaces, volume, setVolume } = store;

  // Funkcja do zamykania z animacją
  const handleCloseFullscreen = () => {
    setIsClosing(true);
    setTimeout(() => {
      setFullscreenMode(false);
      setIsClosing(false);
    }, 300);
  };

  // ---- Nagłówki kolumn dla tabeli współczynników ----
  const coeffHeaderLabels =
    incurredColumnLabels.length > 1
      ? incurredColumnLabels.slice(1, 1 + (trainDevide?.[0]?.length || 0))
      : Array.from({ length: trainDevide?.[0]?.length || 0 }, (_, i) => String(i + 2));

  // ---- Etykiety wierszy 1:1 (bez +1) ----
  const rowLabelAt = (i: number) => incurredRowLabels[i] ?? String(i + 1);

  // ---- Przygotowanie danych dla tabeli ----
  const tableData = trainDevide?.length ? [
    [''].concat(coeffHeaderLabels),
    ...trainDevide.map((row, i) => [
      rowLabelAt(i),
      ...row.map((c) => (c == null ? '' : c.toString())),
    ]),
  ] : [];

  // ---- Przygotowanie danych wyników ----
  console.log('🔍 [IncurredCLCoefficientsPage] Debug wyników:', {
    devJ,
    sigma,
    sd,
    devJLength: devJ?.length,
    devJVisible: !!devJ,
    devJHasValues: devJ && devJ.some(v => v != null)
  });

  const resultRows: ResultRow[] = [
    {
      label: 'dev_j',
      values: devJ || [],
      visible: !!devJ,
    },
    {
      label: 'sigma',
      values: sigma || [],
      visible: !!sigma,
    },
    {
      label: 'sd',
      values: sd || [],
      visible: true, // sd zawsze widoczny gdy tabela się wyświetla
    },
  ];

  return (
    <CalculationPageLayout
      title="Tabela współczynników rok do roku (Incurred)"
      loadingMessage={`⏳ Oczekiwanie na dane wejściowe incurredTriangle…`}
      noDataMessage="Brak wyników 😢"
      
      // Table data
      tableData={tableData}
      headerLabels={coeffHeaderLabels}
      rowLabels={incurredRowLabels}
      hasData={!!triangle?.length && !!trainDevide?.length}
      
      // Table interactions
      weights={weights}
      selectedCells={selectedCells}
      minMaxCells={minMaxCells}
      minCells={minCells}
      maxCells={maxCells}
      minMaxHighlighting={minMaxHighlighting}
      showRowToggle={true}
      onToggleRow={toggleRowDet}
      onToggleWeightCell={toggleWeightCellDet}
      
      // Results
      resultRows={resultRows}
      resultsTitle="Wyniki obliczeń"
      decimalPlaces={decimalPlaces}
      
      // Fullscreen
      fullscreenMode={fullscreenMode}
      isClosing={isClosing}
      onCloseFullscreen={handleCloseFullscreen}
      
      // Scale
      tableScale={tableScale}
      onIncreaseScale={increaseScale}
      onDecreaseScale={decreaseScale}
      
      // Volume and calculate (hidden in UI but required by layout)
      volume={volume}
      onVolumeChange={setVolume}
      onCalculate={runSigma}
      calculateLabel="Oblicz"
      
      // Sidebar
      sidebar={
        <SidebarPanelCLIncurred
          onCalculate={runSigma}
          className="w-64 shrink-0"
        />
      }
    />
  );
}