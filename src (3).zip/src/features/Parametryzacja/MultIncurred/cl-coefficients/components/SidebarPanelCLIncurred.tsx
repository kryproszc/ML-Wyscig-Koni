'use client';

import { useState } from 'react';
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred';
import { useDisplaySettingsStore } from '@/stores/useDisplaySettingsStore';
import Modal from '@/components/Modal';
import { exportDevJToExcel } from '@/untils/exportToExcel';
import { Button } from '@/components/ui/button';
import { Maximize2, Plus, Minus } from 'lucide-react';

type Props = {
  onCalculate: () => void;
  className?: string;
};

export default function SidebarPanelCLIncurred({ onCalculate, className }: Props) {
  const store = useTrainDevideStoreIncurred();
  const [resetOpen, setResetOpen] = useState(false);

  // Display settings for fullscreen and scale
  const fullscreenMode = useDisplaySettingsStore((s) => s.fullscreenMode);
  const tableScale = useDisplaySettingsStore((s) => s.tableScale);
  const setFullscreenMode = useDisplaySettingsStore((s) => s.setFullscreenMode);
  const increaseScale = useDisplaySettingsStore((s) => s.increaseScale);
  const decreaseScale = useDisplaySettingsStore((s) => s.decreaseScale);

  const {
    clearDevJResults,
    setFinalDevJ,
    clearAllDevFinalValues,
    clearSigmaResults,
    clearFitCurveData,
    clearDevSummaryData,
    finalDevJ,
    finalDevVector,
    devJResults,
    minMaxHighlighting,
    setMinMaxHighlighting,
    safeWeights,
    decimalPlaces = 6,
    setDecimalPlaces,
  } = store;

  const overrides: any[] = []; // można dodać obsługę overrides jeśli potrzeba

  const [isMissingFinalModalOpen, setIsMissingFinalModalOpen] = useState(false);
  
  const openMissingFinalModal = () => setIsMissingFinalModalOpen(true);
  const closeMissingFinalModal = () => setIsMissingFinalModalOpen(false);

  const handleExport = () => {
    if (!finalDevJ?.values?.length) {
      openMissingFinalModal();
      return;
    }
    // Adaptacja funkcji eksportu dla incurred - może wymagać modyfikacji
    exportDevJToExcel(devJResults, finalDevJ, finalDevVector, overrides);
  };

  const handleReset = () => {
    clearDevJResults();
    setFinalDevJ(undefined);
    clearAllDevFinalValues();
    clearSigmaResults();
    clearFitCurveData();
    clearDevSummaryData();
    // resetuj zaznaczenia w tabeli współczynników rok do roku
    store.resetSelectionIncurred();
  };

  const toggleMinMax = () => {
    setMinMaxHighlighting(!minMaxHighlighting);
  };

  // Komponent kontrolek rozmiaru - używany w panelu bocznym
  const ScaleControls = () => (
    <div className="flex items-center gap-2">
      <Button
        onClick={decreaseScale}
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
        disabled={tableScale <= 0.5}
      >
        <Minus className="w-4 h-4" />
      </Button>
      
      <span className="text-white text-sm min-w-[3rem] text-center">
        {Math.round(tableScale * 100)}%
      </span>
      
      <Button
        onClick={increaseScale}
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
        disabled={tableScale >= 2.0}
      >
        <Plus className="w-4 h-4" />
      </Button>
    </div>
  );

  return (
    <div className={`w-64 shrink-0 space-y-4 ${className ?? ''}`}>
      {/* Kontrolka zaokrąglania - na górze */}
      <div className="bg-gray-800 rounded-lg p-4">
        <label className="text-white text-sm font-medium mb-2 block">
          Miejsca po przecinku
        </label>
        <input
          type="number"
          min="0"
          max="10"
          value={decimalPlaces}
          onChange={(e) => setDecimalPlaces?.(Number(e.target.value))}
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
        <div className="text-xs text-gray-400 mt-1">
          Współczynniki będą zaokrąglone do {decimalPlaces} miejsc
        </div>
      </div>

      {/* Przyciski akcji */}
      <div className="space-y-3">
        <button
          onClick={onCalculate}
          className="w-full py-3 px-4 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors"
        >
          Oblicz
        </button>

        <button
          onClick={handleExport}
          className="w-full py-3 px-4 bg-amber-500 text-white rounded-lg font-medium hover:bg-amber-600 transition-colors"
        >
          Eksportuj do Excela
        </button>

        <button
          onClick={() => setResetOpen(true)}
          className="w-full py-3 px-4 bg-rose-500 text-white rounded-lg font-medium hover:bg-rose-600 transition-colors"
        >
          Reset współczynników
        </button>
      </div>

      {/* Modals */}
      <Modal
        isOpen={resetOpen}
        title="Usunięcie współczynników"
        message="Czy na pewno chcesz usunąć współczynniki CL i wektory dev_j? Ta operacja jest nieodwracalna."
        onCancel={() => setResetOpen(false)}
        onConfirm={() => {
          handleReset();
          setResetOpen(false);
        }}
      />

      <Modal
        isOpen={isMissingFinalModalOpen}
        title="Brak finalnego wektora"
        message="Najpierw wybierz finalny wektor dev_j."
        onConfirm={closeMissingFinalModal}
        onlyOk
      />

      {/* Min/Max Button */}
      <button
        onClick={toggleMinMax}
        className={`w-full py-3 px-4 rounded-lg font-medium transition-colors ${
          minMaxHighlighting
            ? 'bg-yellow-600 hover:bg-yellow-700 text-white'
            : 'bg-gray-600 hover:bg-gray-700 text-white'
        }`}
      >
        {minMaxHighlighting ? '🔍 Ukryj Min/Max' : '🔍 Pokaż Min/Max'}
      </button>

      {/* Ustawienia wyświetlania */}
      <div className="bg-gray-800 rounded-lg p-4">
        <div className="text-white text-lg font-medium mb-4">
          Ustawienia wyświetlania
        </div>
        
        <div className="space-y-4">
          <div>
            <label className="text-white text-sm font-medium mb-2 block">
              Rozmiar tabeli
            </label>
            <ScaleControls />
          </div>
          
          <Button
            onClick={() => setFullscreenMode(true)}
            variant="destructive"
            size="sm"
            className="w-full"
          >
            <Maximize2 className="w-4 h-4 mr-2" />
            Pełny ekran
          </Button>
        </div>
      </div>
    </div>
  );
}