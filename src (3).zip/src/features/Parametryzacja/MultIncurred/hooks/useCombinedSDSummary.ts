/**
 * Hook do obsługi zmiennej combinedSDSummary z store'a dla MultIncurred
 * Umożliwia łatwe pobieranie i manipulację wynikami SD Summary
 */

'use client';

import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';

export function useCombinedSDSummary() {
  // Pobierz dane ze store'a
  const combinedSDSummary = useTrainDevideStoreDet(s => s.combinedSDSummary);
  const setCombinedSDSummary = useTrainDevideStoreDet(s => s.setCombinedSDSummary);
  const clearCombinedSDSummary = useTrainDevideStoreDet(s => s.clearCombinedSDSummary);

  // Helper functions
  const hasData = Boolean(combinedSDSummary?.length);
  
  const getLength = () => combinedSDSummary?.length || 0;
  
  const getAsNumbers = (): number[] => {
    if (!combinedSDSummary) return [];
    return combinedSDSummary.map(val => 
      typeof val === 'string' ? parseFloat(val) || 0 : val
    );
  };
  
  const getAsStrings = (): string[] => {
    if (!combinedSDSummary) return [];
    return combinedSDSummary.map(val => String(val));
  };

  const getValue = (index: number): number | string | undefined => {
    return combinedSDSummary?.[index];
  };

  const getStats = () => {
    if (!hasData) return null;
    
    const numbers = getAsNumbers();
    const validNumbers = numbers.filter(n => !isNaN(n));
    
    if (validNumbers.length === 0) return null;
    
    return {
      count: validNumbers.length,
      sum: validNumbers.reduce((a, b) => a + b, 0),
      avg: validNumbers.reduce((a, b) => a + b, 0) / validNumbers.length,
      min: Math.min(...validNumbers),
      max: Math.max(...validNumbers),
    };
  };

  // Funkcja do eksportowania danych dla API
  const getForAPI = () => {
    return {
      combinedSDSummary: combinedSDSummary || [],
      length: getLength(),
      hasData,
      asNumbers: getAsNumbers(),
      asStrings: getAsStrings(),
    };
  };

  return {
    // Podstawowe dane
    combinedSDSummary,
    
    // Setters
    setCombinedSDSummary,
    clearCombinedSDSummary,
    
    // Helper functions
    hasData,
    getLength,
    getAsNumbers,
    getAsStrings,
    getValue,
    getStats,
    getForAPI,
  };
}