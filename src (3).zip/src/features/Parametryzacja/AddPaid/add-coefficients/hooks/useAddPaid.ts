'use client';

import { useEffect } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useUserStore } from '@/app/_components/useUserStore';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useAddCoefficientsStore } from '@/stores/addCoefficientsStore';
import { useExposureStore } from '@/stores/exposureStore';
import { useAddPaidStore } from '@/stores/addPaidStore';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export function useAddCL() {
  const userId = useUserStore((s) => s.userId);
  
  // Store z danymi paid triangle (z deterministic store) - GŁÓWNY STORE
  const paidStore = useTrainDevideStoreDet();
  
  // Store z wynikami i ustawieniami dla AddPaid coefficients  
  const store = useAddCoefficientsStore();
  
  // Store z danymi ekspozycji (z exposureStore)
  const exposureStore = useExposureStore();
  
  // Store z danymi FitCurve dla AddPaid
  const addPaidStore = useAddPaidStore();

  // UŻYWAJ VOLUME Z GŁÓWNEGO STORE (tak jak MultPaid)
  const { volume: mainVolume } = paidStore;
  
  const {
    trainDevideAdd,
    selectedWeightsAdd,
    selectedCellsAdd,
    devJResults,
    sigmaResults,
    devJ,
    sigma,
    sd,
    setTrainDevideAdd,
    setDevJ,
    setSigma,
    setSd,
    addDevJResult,
    addSigmaResult,
    resetSelectionAdd,
    toggleRowAdd,
    applyVolumeToWeights,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    setMinMaxHighlighting,
    selectedDevJVolume   : selectedVolume,
    selectedDevJSubIndex : selectedSubIndex,
    setSelectedDevJVolume: setSelectedVolume,
    selectedSigmaVolume,
    selectedSigmaSubIndex,
    setSelectedSigmaVolume,
  } = store;

  // Pobierz dane z paid store (to samo źródło co MultPaid)
  const paidTriangle = paidStore.paidTriangle;
  
  // Pobierz dane ekspozycji z exposure store
  const exposureTriangle = exposureStore.exposureTriangle;
  const selectedExposureLine = exposureStore.selectedExposureLine;
  const availableExposureLines = exposureStore.availableExposureLines;

  // Konwertuj exposureTriangle (format obiektu) do formatu array dla API
  const getExposureArray = () => {
    if (!exposureTriangle || Object.keys(exposureTriangle).length === 0) {
      console.log('🔍 [getExposureArray] No exposure data');
      return [];
    }
    
    if (selectedExposureLine === null) {
      console.log('🔍 [getExposureArray] No exposure line selected');
      return [];
    }
    
    // Znajdź wybraną linię w dostępnych liniach
    const selectedLine = availableExposureLines.find(line => line.index === selectedExposureLine);
    if (!selectedLine) {
      console.log('🔍 [getExposureArray] Selected line not found:', selectedExposureLine);
      return [];
    }
    
    console.log('🔍 [getExposureArray] Selected line:', selectedLine);
    console.log('🔍 [getExposureArray] Selected line values:', selectedLine.values);
    
    // Zwróć wartości z wybranej linii (już jest to array liczb z kolumn 1, 2, 3, ...)
    return selectedLine.values;
  };

  // Konwertuj paidTriangle do formatu array dla API AddPaid
  const getPaidArray = () => {
    if (!paidTriangle?.length) return [];
    
    console.log('🔍 [getPaidArray] Raw paidTriangle:', paidTriangle);
    console.log('🔍 [getPaidArray] Dimensions:', { 
      rows: paidTriangle.length, 
      cols: paidTriangle[0]?.length || 0 
    });
    
    // paidTriangle już jest w formacie array, więc tylko sprawdzamy czy jest poprawny
    const result = paidTriangle.map(row => 
      row.map(cell => (cell === null || cell === undefined) ? null : cell)
    );
    
    console.log('🔍 [getPaidArray] Final result:', result);
    return result;
  };

  /* -------- mutation 1: train_devide dla AddPaid -------- */
  const mTrainDivideAdd = useMutation({
    mutationKey: ['trainDivideAdd', mainVolume],
    mutationFn : async () => {
      const paidArray = getPaidArray();
      const exposureArray = getExposureArray();
      
      console.log('🔍 [useAddCL] Debug paid + exposure data:', {
        paidTriangle: paidTriangle,
        paidArray: paidArray,
        paidArrayLength: paidArray.length,
        paidArraySample: paidArray.slice(0, 3),
        exposureTriangle: exposureTriangle,
        exposureArray: exposureArray,
        exposureArrayLength: exposureArray.length
      });
      
      const res = await fetch(`${API_URL}/calc/add/train_devide_add`, {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ 
          user_id: userId, 
          add_data_det: paidArray,
          ekspozycja: exposureArray
        }),
      });
      return res.json() as Promise<{ train_devide?: number[][] }>;
    },
    onSuccess: (d) => {
      console.log('🎉 [train_devide_add] Success:', d);
      if (d.train_devide) {
        console.log('📊 Setting trainDevideAdd:', d.train_devide);
        setTrainDevideAdd(d.train_devide);
        
        console.log('🔧 Current selectedWeightsAdd:', selectedWeightsAdd);
        // Ustaw wszystkie komórki jako zaznaczone domyślnie tylko jeśli weights nie istnieją
        if (!selectedWeightsAdd) {
          console.log('🔄 Calling resetSelectionAdd()');
          resetSelectionAdd();
        } else {
          console.log('⚠️ selectedWeightsAdd already exists, not resetting');
        }
      }
    },
  });

  /* -------- mutation 2: CL dla AddPaid -------- */
  const mAddCL = useMutation({
    mutationKey: ['clAdd', mainVolume],
    mutationFn : async () => {
      const paidArray = getPaidArray();
      const exposureArray = getExposureArray();
      
      // 🔥 POPRAWIONE: Gdzie trainDevideAdd ma null, tam waga = 0 (niezależnie od zaznaczenia)
      const safeWeights = selectedWeightsAdd?.map((weightRow, rowIndex) => 
        weightRow.map((weight, colIndex) => {
          const trainValue = trainDevideAdd?.[rowIndex]?.[colIndex];
          // Jeśli w train_devide_add jest null/undefined - waga = 0
          if (trainValue === null || trainValue === undefined) {
            return 0;
          }
          // W przeciwnym razie używaj wagi z zaznaczenia
          return weight === 1 ? 1 : 0;
        })
      ) ?? [];
      
      console.log('🔥 SafeWeights (first 3 rows):', safeWeights.slice(0, 3).map(r => r.slice(0, 10)));
      
      const res = await fetch(`${API_URL}/calc/add/wspolczynniki_add`, {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({
          user_id      : userId,
          add_data_det: paidArray,
          ekspozycja   : exposureArray,
          weights      : safeWeights,
        }),
      });
      return res.json() as Promise<{ 
        message?: string; 
        LR_j?: number[]; 
        sigma_j?: number[]; 
        sd_j?: number[]; 
      }>;
    },
    onSuccess: (d) => {
      console.log('🚀 Odpowiedź z /calc/add/wspolczynniki_add:', d);
      
      if (d.LR_j) {
        console.log('✅ Otrzymano LR_j (ADD):', d.LR_j);
        setDevJ(d.LR_j);
        addDevJResult(mainVolume, d.LR_j);
        setSelectedVolume(mainVolume, undefined);
        
        // Zapisz do addPaidStore dla FitCurve
        addPaidStore.setAddJ(d.LR_j);
        console.log('✅ Zapisano LR_j do addPaidStore:', d.LR_j);
        console.log('🔍 AddPaidStore state after setAddJ:', addPaidStore.addJ);
      }
      
      if (d.sigma_j) {
        console.log('✅ Otrzymano sigma_j (ADD):', d.sigma_j);
        setSigma(d.sigma_j);
        addSigmaResult(mainVolume, d.sigma_j);
        setSelectedSigmaVolume(mainVolume, undefined);
        
        // Zapisz do addPaidStore dla FitCurve
        addPaidStore.setSigmaLR(d.sigma_j);
        console.log('✅ Zapisano sigma_j do addPaidStore:', d.sigma_j);
        console.log('🔍 AddPaidStore state after setSigmaLR:', addPaidStore.sigmaLR);
      }
      
      if (d.sd_j) {
        console.log('✅ Otrzymano sd_j (ADD):', d.sd_j);
        setSd(d.sd_j);
        
        // Zapisz do addPaidStore dla FitCurve
        addPaidStore.setSdLR(d.sd_j);
        console.log('✅ Zapisano sd_j do addPaidStore:', d.sd_j);
        console.log('🔍 AddPaidStore state after setSdLR:', addPaidStore.sdLR);
      }
    },
  });

  /* auto-start train_divide gdy mamy dane paid i wybraną linię exposure */
  useEffect(() => {
    console.log('[useAddCL] 🔍 useEffect triggered:', {
      paidTriangleLength: paidTriangle?.length || 0,
      paidTriangleData: paidTriangle?.slice(0, 2), // pierwsze 2 wiersze dla debug
      exposureTriangleKeys: Object.keys(exposureTriangle || {}),
      exposureTriangleLength: Object.keys(exposureTriangle || {}).length,
      selectedExposureLine,
      availableExposureLinesCount: availableExposureLines.length,
      trainDevideAddLength: trainDevideAdd?.length || 0,
      hasPaidTriangle: !!paidTriangle?.length,
      hasExposureTriangle: Object.keys(exposureTriangle || {}).length > 0,
      hasSelectedExposureLine: selectedExposureLine !== null,
      hasTrainDevide: !!trainDevideAdd?.length,
      shouldTrigger: !!(paidTriangle?.length && selectedExposureLine !== null && !trainDevideAdd?.length)
    });
    
    if (paidTriangle?.length && selectedExposureLine !== null && !trainDevideAdd?.length) {
      console.log('[useAddCL] 🚀 Triggering mTrainDivideAdd.mutate()');
      mTrainDivideAdd.mutate();
    } else {
      console.log('[useAddCL] ❌ Warunki nie spełnione - nie triggeruję train_divide_add');
      if (!paidTriangle?.length) console.log('  - Brak paidTriangle');
      if (Object.keys(exposureTriangle || {}).length === 0) console.log('  - Brak exposureTriangle');
      if (selectedExposureLine === null) console.log('  - Nie wybrano linii ekspozycji');
      if (trainDevideAdd?.length) console.log('  - trainDevideAdd już istnieje');
    }
  }, [paidTriangle, exposureTriangle, selectedExposureLine, trainDevideAdd]);

  /* Aplikuj volume do wag gdy volume lub trainDevideAdd się zmieni */
  useEffect(() => {
    console.log('[useAddCL] 🔧 Volume effect triggered:', {
      mainVolume,
      trainDevideAddLength: trainDevideAdd?.length || 0,
      selectedWeightsAddExists: !!selectedWeightsAdd
    });
    
    if (trainDevideAdd?.length && mainVolume > 0) {
      console.log('[useAddCL] 🎯 Applying volume to weights:', mainVolume);
      applyVolumeToWeights(mainVolume);
    }
  }, [mainVolume, trainDevideAdd]);

  return {
    triangle      : getPaidArray(), // Paid triangle jako array dla AddPaid
    paidTriangle  : paidTriangle,   // Raw paid triangle data
    trainDevide   : trainDevideAdd,
    weights       : selectedWeightsAdd,
    selectedCells : selectedCellsAdd,
    devJResults,
    sigmaResults,
    devJ,
    sigma,
    sd,
    selectedVolume,
    selectedSubIndex,
    setSelectedVolume,
    selectedSigmaVolume,
    selectedSigmaSubIndex,
    setSelectedSigmaVolume,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    toggleRowAdd,

    runSigma   : () => mAddCL.mutate(),
    isLoading  : mTrainDivideAdd.isPending || mAddCL.isPending,
  };
}