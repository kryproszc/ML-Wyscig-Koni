'use client';

import React, { useState, useMemo } from 'react';
import { useAddCL } from '../hooks/useAddPaid';
import SidebarPanelAdd from '../components/SidebarPanelAdd';
import { TableDataAdd } from '@/components/TableDataAdd';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { useAddCoefficientsStore } from '@/stores/addCoefficientsStore';
import { useDisplaySettingsPaidStore } from '@/stores/useDisplaySettingsPaidStore';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import CalculationPageLayout from '@/shared/components/calculation-tables/CalculationPageLayout';
import type { ResultRow } from '@/shared/components/calculation-tables/ResultsTable';

export default function AddPaidCoefficientsPage() {
  // Labels from store (JUŻ 1:1 z body — bez rogu)
  const detRowLabels = useLabelsStore((s) => s.detRowLabels);
  const detColumnLabels = useLabelsStore((s) => s.detColumnLabels);
  
  // AddPaid store (nie używamy już coeffHeaderLabelsAdd)
  const addStore = useAddCoefficientsStore();

  // Display settings for fullscreen
  const fullscreenMode = useDisplaySettingsPaidStore((s) => s.fullscreenMode);
  const tableScale = useDisplaySettingsPaidStore((s) => s.tableScale);
  const setFullscreenMode = useDisplaySettingsPaidStore((s) => s.setFullscreenMode);
  const increaseScale = useDisplaySettingsPaidStore((s) => s.increaseScale);
  const decreaseScale = useDisplaySettingsPaidStore((s) => s.decreaseScale);

  // Stan dla animacji zamykania
  const [isClosing, setIsClosing] = useState(false);

  const {
    triangle,
    trainDevide,
    weights,
    selectedCells,
    devJ,
    sigma,
    sd,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    toggleRowAdd,

    runSigma,
    isLoading,
  } = useAddCL();

  // Dostęp do volume i setVolume z GŁÓWNEGO store (tak jak MultPaid)
  const mainStore = useTrainDevideStoreDet();
  const { volume, setVolume, decimalPlaces } = mainStore;

  console.log('🔧 [AddPaidCoefficientsPage] Current volume from trainDevideStoreDet:', volume);

  // Funkcja do zamykania z animacją
  const handleCloseFullscreen = () => {
    setIsClosing(true);
    // Opóźnienie zamknięcia o czas trwania animacji
    setTimeout(() => {
      setFullscreenMode(false);
      setIsClosing(false);
    }, 300); // 300ms - szybsze zamykanie
  };

  if (!triangle?.length) {
    return (
      <div className="p-6 text-yellow-300">
        ⏳ Oczekiwanie na dane wejściowe:
        <ul className="mt-2 ml-4 list-disc">
          <li><code>paidTriangle</code> (Trójkąt paid)</li>
          <li><code>exposureTriangle</code> + wybór linii (Ekspozycja)</li>
        </ul>
      </div>
    );
  }

  // ---- Nagłówki kolumn dla tabeli współczynników (tak samo jak MultPaid) ----
  const coeffHeaderLabels =
    detColumnLabels.length > 1
      ? detColumnLabels.slice(1, 1 + (trainDevide?.[0]?.length || 0))
      : Array.from({ length: trainDevide?.[0]?.length || 0 }, (_, i) => String(i + 2));

  // Przygotowanie danych dla tabeli (tak jak w oryginalnym kodzie)
  const tableData = useMemo(() => {
    if (!trainDevide?.length) return [];
    
    return [
      [''].concat(coeffHeaderLabels),
      ...trainDevide.map((row, i) => [
        detRowLabels[i] || `Rok ${i + 1}`,
        ...row.map((c) => (c == null ? '' : c.toString())),
      ]),
    ];
  }, [trainDevide, coeffHeaderLabels, detRowLabels]);

  // Przygotowanie wierszy wyników
  const resultRows = useMemo((): ResultRow[] => {
    const rows: ResultRow[] = [];
    
    if (devJ) {
      rows.push({
        label: 'LR_j',
        values: devJ.map(val => val ?? null),
      });
    }
    
    if (sigma) {
      rows.push({
        label: 'sigma_j', 
        values: sigma.map(val => val ?? null),
      });
    }
    
    // sd_j zawsze dodajemy jeśli mamy dane
    if (devJ || sigma || sd) {
      rows.push({
        label: 'sd_j',
        values: sd ? sd.map(val => val ?? null) : coeffHeaderLabels.map(() => null),
      });
    }
    
    return rows;
  }, [devJ, sigma, sd, coeffHeaderLabels]);

  // Debug: wyświetl wartości w konsoli
  React.useEffect(() => {
    console.log('✅ === DEBUG: AddPaidCoefficientsPage.tsx (REFACTORED) ===');
    console.log('✅ detColumnLabels:', detColumnLabels);
    console.log('✅ coeffHeaderLabels (lokalna zmienna):', coeffHeaderLabels);
    console.log('✅ coeffHeaderLabels length:', coeffHeaderLabels.length);
    console.log('devJ:', devJ);
    console.log('devJ type:', typeof devJ, 'Array?', Array.isArray(devJ));
    console.log('devJ length:', devJ?.length);
    console.log('sigma:', sigma);
    console.log('sigma type:', typeof sigma, 'Array?', Array.isArray(sigma));
    console.log('sigma length:', sigma?.length);
    console.log('sd:', sd);
    console.log('sd type:', typeof sd, 'Array?', Array.isArray(sd));
    console.log('sd length:', sd?.length);
    console.log('decimalPlaces:', decimalPlaces);
    if (devJ && devJ.length > 0) {
      console.log('Pierwszy element devJ:', devJ[0], 'typu:', typeof devJ[0]);
    }
    if (sigma && sigma.length > 0) {
      console.log('Pierwszy element sigma:', sigma[0], 'typu:', typeof sigma[0]);
    }
    if (sd && sd.length > 0) {
      console.log('Pierwszy element sd:', sd[0], 'typu:', typeof sd[0]);
    }
    console.log('✅ ==========================================');
  }, [devJ, sigma, sd, coeffHeaderLabels, decimalPlaces, detColumnLabels]);

  return (
    <CalculationPageLayout
      title="Tabela współczynników rok do roku (AddPaid)"
      isLoading={isLoading}
      tableData={tableData}
      headerLabels={coeffHeaderLabels}
      rowLabels={detRowLabels}
      hasData={!!trainDevide?.length}
      weights={weights}
      selectedCells={selectedCells}
      minMaxCells={minMaxHighlighting ? minMaxCells : []}
      minCells={minMaxHighlighting ? minCells : []}
      maxCells={minMaxHighlighting ? maxCells : []}
      minMaxHighlighting={minMaxHighlighting}
      showRowToggle={true}
      onToggleRow={toggleRowAdd}
      tableComponent={TableDataAdd}
      resultRows={resultRows}
      resultsTitle="Wyniki obliczeń AddPaid"
      decimalPlaces={decimalPlaces}
      fullscreenMode={fullscreenMode}
      isClosing={isClosing}
      onCloseFullscreen={handleCloseFullscreen}
      tableScale={tableScale}
      onIncreaseScale={increaseScale}
      onDecreaseScale={decreaseScale}
      volume={volume}
      onVolumeChange={setVolume}
      onCalculate={runSigma}
      calculateLabel="Oblicz"
      sidebar={
        <SidebarPanelAdd
          onCalculate={runSigma}
          className="w-64 shrink-0"
        />
      }
    />
  );
}