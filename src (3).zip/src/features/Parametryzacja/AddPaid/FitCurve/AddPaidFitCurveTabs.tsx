'use client';

import { useState } from 'react';
import { SegmentedTabs } from '@/app/_components/DeterministicMethodsTab';
import FitCurveAddJ from '@/features/Parametryzacja/AddPaid/FitCurve/FitCurveAddJ';
import FitCurveSigmaLR from '@/features/Parametryzacja/AddPaid/FitCurve/FitCurveSigmaLR';

type Tab = 'AddJ' | 'SigmaLR';

/** Krok 3 — Dopasowanie krzywej AddPaid (AddJ/SigmaLR) */
export function AddPaidFitCurveTabs() {
  const [active, setActive] = useState<Tab>('AddJ');
  const tabs: Readonly<Tab[]> = ['AddJ', 'SigmaLR'];

  return (
    <div className="w-full">
      <SegmentedTabs<Tab>
        active={active}
        setActive={setActive}
        tabs={tabs}
        ariaLabel="Tryb dopasowania AddPaid"
      />

      <div className="mt-3">
        {active === 'AddJ' && <FitCurveAddJ />}
        {active === 'SigmaLR' && <FitCurveSigmaLR />}
      </div>
    </div>
  );
}