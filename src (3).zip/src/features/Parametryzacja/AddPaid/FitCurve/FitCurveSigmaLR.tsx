'use client';

import { FitCurvePageLayout } from '@/shared/components/fit-curve/FitCurvePageLayout';
import { SIGMA_LR_CONFIG } from '@/shared/components/fit-curve/configs';
import { SIGMA_LR_STORE_MAPPING } from '@/shared/components/fit-curve/storeMappings';
import { useFitCurveData } from '@/shared/hooks/useFitCurveData';
import { useAddPaidStore } from '@/stores/addPaidStore';

export default function FitCurveSigmaLR() {
  const fitCurveProps = useFitCurveData({
    config: SIGMA_LR_CONFIG,
    storeMapping: SIGMA_LR_STORE_MAPPING,
    useStore: useAddPaidStore
  });

  return (
    <FitCurvePageLayout
      config={SIGMA_LR_CONFIG}
      {...fitCurveProps}
    />
  );
}