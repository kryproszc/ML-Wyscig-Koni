'use client';

import { FitCurvePageLayout } from '@/shared/components/fit-curve/FitCurvePageLayout';
import { ADD_J_CONFIG } from '@/shared/components/fit-curve/configs';
import { ADD_J_STORE_MAPPING } from '@/shared/components/fit-curve/storeMappings';
import { useFitCurveData } from '@/shared/hooks/useFitCurveData';
import { useAddPaidStore } from '@/stores/addPaidStore';

export default function FitCurveAddJ() {
  const fitCurveProps = useFitCurveData({
    config: ADD_J_CONFIG,
    storeMapping: ADD_J_STORE_MAPPING,
    useStore: useAddPaidStore
  });

  return (
    <FitCurvePageLayout
      config={ADD_J_CONFIG}
      {...fitCurveProps}
    />
  );
}