'use client';

import React, { useEffect } from 'react';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { TriangleTableView } from '@/shared/components/TriangleTableView';

export function PaidTriangleView() {
  // Store data
  const { paidTriangle: triangle } = useTrainDevideStoreDet();
  
  // Labels from store
  const detRowLabels = useLabelsStore((s) => s.detRowLabels);
  const detColumnLabels = useLabelsStore((s) => s.detColumnLabels);
  const globalRowLabels = useLabelsStore((s) => s.globalRowLabels);
  const globalColumnLabels = useLabelsStore((s) => s.globalColumnLabels);
  const lastLoadedFile = useLabelsStore((s) => s.lastLoadedFile);

  // Debug logs (based on what I saw in compiled JS)
  useEffect(() => {
    if (triangle?.length) {
      console.log('[PaidTriangleView] 🔍 Triangle data received:');
      console.log('  - Number of rows:', triangle.length);
      console.log('  - First row length:', triangle[0]?.length);
      console.log('  - First row:', triangle[0]);
      console.log('  - Max row length:', Math.max(...triangle.map((row) => row?.length || 0)));
    }
    console.log('[PaidTriangleView] detRowLabels:', detRowLabels);
    console.log('[PaidTriangleView] detColumnLabels:', detColumnLabels, 'length:', detColumnLabels.length);
    console.log('[PaidTriangleView] globalRowLabels:', globalRowLabels);
    console.log('[PaidTriangleView] globalColumnLabels:', globalColumnLabels, 'length:', globalColumnLabels.length);
    console.log('[PaidTriangleView] lastLoadedFile:', lastLoadedFile);
  }, [triangle, detRowLabels, detColumnLabels, globalRowLabels, globalColumnLabels, lastLoadedFile]);

  return (
    <div className="p-6 text-white">
      <TriangleTableView
        title="Trójkąt Paid"
        triangle={triangle}
        noDataMessage="Brak danych trójkąta Paid. Przejdź do zakładki 'Wprowadź dane' aby załadować dane."
        withNumericHeaders={true}
        rowLabels={detRowLabels}
        columnLabels={detColumnLabels}
        className="space-y-4"
      />
    </div>
  );
}