'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useParamsymStore } from '@/stores/paramsymStore';
import { useDiscountRatesStore } from '@/stores/discountRatesStore';
import { useUserStore } from '@/app/_components/useUserStore';
import { useExposureStore } from '@/stores/exposureStore';
import { useAddPaidStore } from '@/stores/addPaidStore';
import { useAddPaidResultsStore } from '@/stores/addPaidResultsStore';
import { 
  CalculationLayout, 
  DataStatusPanel, 
  ActionButtonsGroup, 
  SuccessModal,
  ResultsTable,
  EmptyState 
} from '@/shared/components/calculation';
import { useDataValidation } from '@/shared/hooks';
import { processSelectedRow, processSelectedValues } from '@/shared/utils';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? '';

export default function DeterminMethodAddPaid() {
  // Store dla wyników AddPaid
  const { 
    results: calculationResults, 
    setResults, 
    clearResults, 
    hideResults,
    showResults,
    isCalculating, 
    setCalculating, 
    setError,
    hasResults,
    lastError
  } = useAddPaidResultsStore();

  // State dla success modalu
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  // Store'y z danymi
  const userId = useUserStore((s: any) => s.userId);
  
  // Dane podstawowe - paid triangle
  const { paidTriangle } = useTrainDevideStoreDet();
  
  // Dane ekspozycji
  const { 
    exposureTriangle, 
    selectedExposureLine, 
    availableExposureLines 
  } = useExposureStore();
  
  // Dane współczynników z AddPaid store
  const {
    // Indeksy
    selectedAddJIndexes,
    selectedSigmaLRIndexes,
    // Left count
    leftCountAddLR,
    // Selected values
    selectedValuesAddLR,
    selectedValuesAddSigma,
    // Summary data (na wypadek fallback)
    combinedAddLRSummary,
    combinedAddSigmaSummary,
    // Bazowe dane współczynników
    addJ,
    sigmaLR
  } = useAddPaidStore();

  // Pobierz funkcje dostępu do store (dla opcjonalnych danych)
  const getParamsymTriangle = useParamsymStore((s) => s.paramsymTriangle);
  const getSelectedParamsymLine = useParamsymStore((s) => s.selectedParamsymLine);
  const getDiscountRatesTriangle = useDiscountRatesStore((s) => s.discountRatesTriangle);
  const getSelectedDiscountRateLine = useDiscountRatesStore((s) => s.selectedDiscountRateLine);

  // Funkcja konwersji exposureTriangle do array (z useAddPaid.ts)
  const getExposureArray = useCallback(() => {
    if (!exposureTriangle || Object.keys(exposureTriangle).length === 0) {
      return [];
    }
    
    if (selectedExposureLine === null) {
      return [];
    }
    
    // Znajdź wybraną linię w dostępnych liniach
    const selectedLine = availableExposureLines.find(line => line.index === selectedExposureLine);
    if (!selectedLine) {
      return [];
    }
    
    return selectedLine.values;
  }, [exposureTriangle, selectedExposureLine, availableExposureLines]);

  // Walidacja danych za pomocą shared hook
  const {
    isPaidTriangleLoaded,
    isDiscountRatesLoaded, 
    isNettoBruttoLoaded,
    canSelectBrutto,
    canSelectBruttoDysk,
    canSelectNettoDysk
  } = useDataValidation(paidTriangle, getDiscountRatesTriangle, getParamsymTriangle);

  // Dodatkowa walidacja dla AddPaid
  const isExposureLoaded = useCallback(() => {
    return exposureTriangle && Object.keys(exposureTriangle).length > 0 && selectedExposureLine !== null;
  }, [exposureTriangle, selectedExposureLine]);

  const hasRequiredCoefficients = useCallback(() => {
    return (
      Array.isArray(selectedAddJIndexes) && selectedAddJIndexes.length > 0 &&
      Array.isArray(selectedSigmaLRIndexes) && selectedSigmaLRIndexes.length > 0 &&
      Array.isArray(selectedValuesAddLR) && selectedValuesAddLR.length > 0 &&
      Array.isArray(selectedValuesAddSigma) && selectedValuesAddSigma.length > 0
    );
  }, [selectedAddJIndexes, selectedSigmaLRIndexes, selectedValuesAddLR, selectedValuesAddSigma]);

  const canExecuteCalculations = useCallback(() => {
    return (
      Array.isArray(paidTriangle) && paidTriangle.length > 0 &&
      isExposureLoaded() &&
      hasRequiredCoefficients()
    );
  }, [paidTriangle, isExposureLoaded, hasRequiredCoefficients]);

  // Funkcja wysyłania danych do backend
  const handleExecuteCalculations = async () => {
    if (!userId) {
      console.error('❌ Brak userId - nie można wysłać danych');
      setError('Brak identyfikatora użytkownika');
      return;
    }

    if (!canExecuteCalculations()) {
      console.error('❌ Nie wszystkie wymagane dane są dostępne');
      setError('Nie wszystkie wymagane dane są dostępne do obliczeń');
      return;
    }

    try {
      setCalculating(true);
      setError(null);

      // Przygotuj dane ekspozycji
      const exposureArray = getExposureArray();

      // Przetwarzanie opcjonalnych danych za pomocą shared utils
      const processedNetBrutto = processSelectedRow(getParamsymTriangle, getSelectedParamsymLine);
      const processedDiscountRates = processSelectedRow(getDiscountRatesTriangle, getSelectedDiscountRateLine);

      // Przygotuj dane do wysyłki zgodnie z interfejsem ExecuteCalculationsRequestLR
      const requestData = {
        // ZAWSZE WYMAGANE
        user_id: userId,
        paid_triangle: Array.isArray(paidTriangle) ? paidTriangle.map(row => 
          row.map(cell => (cell === null || cell === undefined) ? null : cell)
        ) : [],
        ekspozycja: exposureArray,
        lr_indexes: Array.isArray(selectedAddJIndexes) ? selectedAddJIndexes : [],
        sigma_lr_indexes: Array.isArray(selectedSigmaLRIndexes) ? selectedSigmaLRIndexes : [],
        left_count_lr: typeof leftCountAddLR === 'number' ? leftCountAddLR : 0,
        
        // Przetwarzanie wybranych wartości za pomocą shared utils
        selected_value_lr: processSelectedValues(selectedValuesAddLR, combinedAddLRSummary, addJ as any[], 1.0),
        selected_value_sigma_lr: processSelectedValues(selectedValuesAddSigma, combinedAddSigmaSummary, sigmaLR as any[], 0.1),
        
        // Opcje obliczeń - automatycznie na podstawie dostępnych danych
        calculation_options: {
          brutto: canSelectBrutto,
          brutto_dysk: canSelectBruttoDysk,
          netto_dysk: canSelectNettoDysk
        },
        
        // OPCJONALNE - używamy przetworzone lub fallback
        discount_rates: Object.keys(processedDiscountRates).length > 0
          ? processedDiscountRates
          : {},
        netto_brutto: Object.keys(processedNetBrutto).length > 0
          ? processedNetBrutto
          : {}
      };

      console.log('📤 Wysyłanie requestData do /calc_lr/execute_calculations:', requestData);

      const response = await fetch(`${API_URL}/calc_lr/execute_calculations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData)
      });

      const result = await response.json();

      if (!response.ok) {
        console.error('❌ Backend error:', {
          status: response.status,
          statusText: response.statusText,
          details: result
        });
        console.error('❌ Full error details:', JSON.stringify(result, null, 2));
        const errorMsg = `Backend błąd ${response.status}: ${JSON.stringify(result, null, 2)}`;
        setError(errorMsg);
        return;
      }

      // ✅ OBSŁUGA SUKCESU - tak samo jak w MultPaid
      if (result.status === 'ok') {
        // Zapisz wyniki do store z informacją o użytkowniku - tak samo jak w MultPaid
        if (result.vectors) {
          setResults({
            last_col: Array.isArray(result.vectors.last_col) ? result.vectors.last_col : [],
            cum_trian: Array.isArray(result.vectors.cum_trian) ? result.vectors.cum_trian : [],
            ult_net_disc: Array.isArray(result.vectors.ult_net_disc) ? result.vectors.ult_net_disc : [],
            userId: userId // Dodajemy ID użytkownika
          });
        }
        
        // Wyświetl modal sukcesu
        setShowSuccessModal(true);
        
      } else {
        console.warn('⚠️ [handleExecuteCalculations] Nieoczekiwany status odpowiedzi:', result.status);
        const errorMsg = `⚠️ Nieoczekiwany status odpowiedzi: ${result.status}`;
        setError(errorMsg);
      }

    } catch (error) {
      console.error('❌ Błąd wysyłki:', error);
      const errorMsg = `❌ Błąd wysyłki: ${error}`;
      setError(errorMsg);
    } finally {
      setCalculating(false);
    }
  };

  // Konfiguracja kolumn dla ResultsTable - tak samo jak w MultPaid
  const resultColumns = calculationResults ? [
    {
      key: 'last_col',
      header: 'Last Column (Brutto)',
      data: calculationResults.last_col || [],
      show: canSelectBrutto
    },
    {
      key: 'cum_trian', 
      header: 'Cumulative Triangle (Brutto Dysk.)',
      data: calculationResults.cum_trian || [],
      show: canSelectBruttoDysk
    },
    {
      key: 'ult_net_disc',
      header: 'Ultimate Net Discounted (Netto Dysk.)',
      data: calculationResults.ult_net_disc || [],
      show: canSelectNettoDysk
    }
  ] : [];

  // Przygotuj dane dla komponentów UI
  const statusItems = [
    { label: 'Trójkąt Paid', isLoaded: !!isPaidTriangleLoaded() },
    { label: 'Ekspozycja', isLoaded: isExposureLoaded() },
    { label: 'Współczynniki LR', isLoaded: hasRequiredCoefficients() },
    { label: 'Stopy Dyskontowe', isLoaded: isDiscountRatesLoaded() },
    { label: 'Netto/Brutto', isLoaded: isNettoBruttoLoaded() }
  ];

  const actionButtons = [
    {
      label: isCalculating ? 'Obliczanie...' : 'Wykonaj obliczenia',
      onClick: handleExecuteCalculations,
      disabled: isCalculating || !canExecuteCalculations(),
      variant: 'primary' as const,
      icon: isCalculating ? '⏳' : '✅'
    },
    ...(calculationResults && calculationResults.shouldShowResults === false ? [{
      label: 'Pokaż wyniki',
      onClick: () => showResults(),
      variant: 'info' as const,
      icon: '👁️'
    }] : []),
    ...(calculationResults ? [{
      label: 'Wyczyść wyniki',
      onClick: () => clearResults(),
      variant: 'danger' as const,
      icon: '🗑️'
    }] : []),
    {
      label: 'Generuj raport',
      onClick: () => {},
      variant: 'secondary' as const,
      icon: '📊'
    }
  ];

  // 🔧 NAPRAWKA: Wyczyść wyniki tylko gdy należą do innego użytkownika - zachowaj wyniki przy przechodzeniu między zakładkami
  useEffect(() => {
    if (calculationResults && calculationResults.userId && userId) {
      if (calculationResults.userId !== userId) {
        clearResults();
      }
    }
  }, [userId, calculationResults, clearResults]);

  // 🎯 NAPRAWIONE: Ukryj kolumny wyników TYLKO gdy rzeczywiście wczytano NOWE dane (nie przy przechodzeniu między zakładkami)
  const previousDiscountRates = React.useRef(getDiscountRatesTriangle);
  const previousParamsym = React.useRef(getParamsymTriangle);
  const previousPaidTriangle = React.useRef(paidTriangle);
  const previousExposure = React.useRef(exposureTriangle);
  const hasInitialized = React.useRef(false);
  
  // Stabilna referencja do funkcji hideResults
  const stableHideResults = useCallback(() => {
    hideResults();
  }, [hideResults]);
  
  useEffect(() => {
    // Pomiń pierwsze uruchomienie (inicjalizacja komponentu)
    if (!hasInitialized.current) {
      hasInitialized.current = true;
      previousDiscountRates.current = getDiscountRatesTriangle;
      previousParamsym.current = getParamsymTriangle;
      previousPaidTriangle.current = paidTriangle;
      previousExposure.current = exposureTriangle;
      return;
    }

    // Sprawdź czy dane rzeczywiście się zmieniły (nie tylko re-render)
    const discountRatesChanged = previousDiscountRates.current !== getDiscountRatesTriangle;
    const paramsymChanged = previousParamsym.current !== getParamsymTriangle;
    const paidTriangleChanged = previousPaidTriangle.current !== paidTriangle;
    const exposureChanged = previousExposure.current !== exposureTriangle;
    
    // Ukryj wyniki tylko jeśli:
    // 1. Wyniki są aktualnie pokazywane
    // 2. Dane rzeczywiście się zmieniły (nowe wczytanie pliku)
    // 3. Wyniki należą do bieżącego użytkownika
    if (calculationResults && 
        calculationResults.shouldShowResults && 
        calculationResults.userId === userId && 
        (discountRatesChanged || paramsymChanged || paidTriangleChanged || exposureChanged)) {
      
      stableHideResults();
    }
    
    // Aktualizuj referencje
    previousDiscountRates.current = getDiscountRatesTriangle;
    previousParamsym.current = getParamsymTriangle;
    previousPaidTriangle.current = paidTriangle;
    previousExposure.current = exposureTriangle;
  }, [getDiscountRatesTriangle, getParamsymTriangle, paidTriangle, exposureTriangle, calculationResults?.shouldShowResults, calculationResults?.userId, userId, stableHideResults]);

  return (
    <>
      <CalculationLayout
        sidebar={
          <div className="space-y-6">
            <DataStatusPanel statusItems={statusItems} />
            <hr className="border-gray-600" />
            <ActionButtonsGroup buttons={actionButtons} />
            
            {/* Debug info */}
            {lastError && (
              <div className="mt-4 p-3 bg-red-900/20 border border-red-600 rounded text-red-300 text-sm">
                <strong>Błąd:</strong> {lastError}
              </div>
            )}
          </div>
        }
      >
        <div className="space-y-6">
          {/* Wyniki z backendu - tabele - tak samo jak w MultPaid */}
          {calculationResults ? (
            <div className="w-full">
              <ResultsTable
                title="Wyniki Obliczeń AddPaid LR"
                subtitle="Analiza trójkąta rozwoju szkód metodą AddPaid"
                columns={resultColumns}
                userId={userId}
                resultsUserId={calculationResults?.userId}
                shouldShowResults={calculationResults?.shouldShowResults}
              />
            </div>
          ) : (
            <EmptyState
              title="Rozpocznij obliczenia AddPaid"
              description={canExecuteCalculations() ? (
                `Dane są gotowe do obliczeń. Kliknij "Wykonaj obliczenia", aby wygenerować wyniki analizy AddPaid LR.${
                  canSelectBruttoDysk ? '<br/><strong class="text-blue-400">📊 Dostępne:</strong> Brutto + Brutto Dyskontowane' : ''
                }${
                  canSelectNettoDysk ? '<br/><strong class="text-green-400">📈 Dostępne:</strong> + Netto Dyskontowane' : ''
                }`
              ) : (
                !isPaidTriangleLoaded() ? 'Wczytaj trójkąt paid w pierwszej zakładce.' :
                !isExposureLoaded() ? 'Wczytaj dane ekspozycji w zakładce Ekspozycja.' :
                !hasRequiredCoefficients() ? 'Uzupełnij współczynniki LR i Sigma w poprzednich zakładkach.' :
                'Sprawdź czy wszystkie wymagane dane są dostępne.'
              )}
            />
          )}
        </div>
      </CalculationLayout>
      
      {/* Success Modal */}
      <SuccessModal 
        isOpen={showSuccessModal}
        onClose={() => setShowSuccessModal(false)}
      />
    </>
  );
}

export { DeterminMethodAddPaid };