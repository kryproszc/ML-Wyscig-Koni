/* ------------------------------------------------------------------ */
/*                       AddSigmaSummaryTab.tsx                      */
/* ------------------------------------------------------------------ */
"use client"

import React, { useMemo, useEffect } from "react";
import { useAddPaidStore } from '@/stores/addPaidStore'
import { useLabelsStore } from '@/stores/useLabelsStore'
import { DevSummaryLayout } from '@/shared/components/DevelopmentEnd'

export default function AddSigmaSummaryTab() {
  // Store selectors - używamy addPaidStore z polami Sigma
  const leftCount = useAddPaidStore(s => s.leftCountAddSigma)
  const setLeftCount = useAddPaidStore(s => s.setLeftCountAddSigma)
  const selectedCurve = useAddPaidStore(s => s.selectedCurveAddSigma)
  const setSelectedCurve = useAddPaidStore(s => s.setSelectedCurveAddSigma)
  const manualOverrides = useAddPaidStore(s => s.manualOverridesAddSigma)
  const setManualOverrides = useAddPaidStore(s => s.setManualOverridesAddSigma)
  const sourceSwitches = useAddPaidStore(s => s.sourceSwitchesAddSigma)
  const setSourceSwitches = useAddPaidStore(s => s.setSourceSwitchesAddSigma)
  const baseData = useAddPaidStore(s => s.sigmaLR) // Initial Selection - Sigma LR_j
  const rawSimResults = useAddPaidStore(s => s.simResultsSigmaLR) // Fitted curves Sigma
  const setCombinedData = useAddPaidStore(s => s.setCombinedAddSigmaSummary)

  // Debug log
  useEffect(() => {
    console.log('🚨 AddSigma Summary - selectedCurve:', selectedCurve)
  }, [selectedCurve])

  // Labels from store
  const rawDetColumnLabels = useLabelsStore(s => s.detColumnLabels)
  const detColumnLabels = useMemo(
    () => ["", ...rawDetColumnLabels],
    [rawDetColumnLabels]
  )

  console.log('AddSigma detColumnLabels:', detColumnLabels)

  return (
    <DevSummaryLayout
      leftCount={leftCount}
      setLeftCount={setLeftCount}
      selectedCurve={selectedCurve}
      setSelectedCurve={setSelectedCurve}
      manualOverrides={manualOverrides}
      setManualOverrides={setManualOverrides}
      sourceSwitches={sourceSwitches}
      setSourceSwitches={setSourceSwitches}
      devJPreview={baseData || undefined} // 🔧 Konwersja null → undefined
      simResults={rawSimResults || undefined} // 🔧 Konwersja null → undefined
      setCombinedDevJ={setCombinedData}
      columnLabels={detColumnLabels}
      onRemainingDevJHeaders={() => {}} // Dummy dla AddPaid
      disabledCurves={[]}
      tableContext='AddSigma'
    />
  )
}