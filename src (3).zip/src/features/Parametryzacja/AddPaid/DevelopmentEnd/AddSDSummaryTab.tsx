/* ------------------------------------------------------------------ */
/*                       AddSDSummaryTab.tsx                         */
/* ------------------------------------------------------------------ */
"use client"

import React, { useMemo } from "react";
import { useAddPaidStore } from '@/stores/addPaidStore'
import { useLabelsStore } from '@/stores/useLabelsStore'
import { DevSummaryLayout } from '@/shared/components/DevelopmentEnd'

export default function AddSDSummaryTab() {
  // Tymczasowo używamy bezpośrednio store + DevSummaryLayout
  // TODO: Naprawić GenericSummaryTab z useAddPaidStore
  
  const leftCount = useAddPaidStore(s => s.leftCountAddSD)
  const setLeftCount = useAddPaidStore(s => s.setLeftCountAddSD)
  const selectedCurve = useAddPaidStore(s => s.selectedCurveAddSD)
  const setSelectedCurve = useAddPaidStore(s => s.setSelectedCurveAddSD)
  const manualOverrides = useAddPaidStore(s => s.manualOverridesAddSD)
  const setManualOverrides = useAddPaidStore(s => s.setManualOverridesAddSD)
  const sourceSwitches = useAddPaidStore(s => s.sourceSwitchesAddSD)
  const setSourceSwitches = useAddPaidStore(s => s.setSourceSwitchesAddSD)
  const baseData = useAddPaidStore(s => s.sdLR)
  const rawSimResults = useAddPaidStore(s => s.simResultsSdLR)
  const setCombinedData = useAddPaidStore(s => s.setCombinedAddSDSummary)

  // Użyjemy tej samej logiki co MultPaid config
  const transformedBaseData = useMemo(() => {
    // Brak transformacji dla AddPaid SD - używaj oryginalnych wartości
    return baseData
  }, [baseData])

  const simResults = useMemo(() => {
    if (!rawSimResults || !Array.isArray(rawSimResults)) return undefined
    
    // Transformacja identyczna z addSdSummaryConfig
    const sdLRData = Object.fromEntries(
      rawSimResults.map((value: number, index: number) => [`k: ${index + 1}`, value])
    )
    
    return { "se_pred": sdLRData }
  }, [rawSimResults])

  const rawDetColumnLabels = useLabelsStore(s => s.detColumnLabels)
  const detColumnLabels = useMemo(() => ["", ...rawDetColumnLabels], [rawDetColumnLabels])

  return (
    <DevSummaryLayout
      leftCount={leftCount}
      setLeftCount={setLeftCount}
      selectedCurve={selectedCurve}
      setSelectedCurve={setSelectedCurve}
      manualOverrides={manualOverrides}
      setManualOverrides={setManualOverrides}
      sourceSwitches={sourceSwitches}
      setSourceSwitches={setSourceSwitches}
      devJPreview={transformedBaseData || undefined}
      simResults={simResults}
      setCombinedDevJ={setCombinedData}
      columnLabels={detColumnLabels}
      onRemainingDevJHeaders={() => {}}
      disabledCurves={[]}
      tableContext='AddSD'
    />
  )
}