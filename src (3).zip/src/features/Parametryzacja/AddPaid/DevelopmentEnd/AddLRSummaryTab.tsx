/* ------------------------------------------------------------------ */
/*                        AddLRSummaryTab.tsx                        */
/* ------------------------------------------------------------------ */
"use client"

import React, { useMemo, useEffect } from "react";
import { useAddPaidStore } from '@/stores/addPaidStore'
import { useLabelsStore } from '@/stores/useLabelsStore'
import { DevSummaryLayout } from '@/shared/components/DevelopmentEnd'

export default function AddLRSummaryTab() {
  // Store selectors - używamy addPaidStore bezpośrednio
  const leftCount = useAddPaidStore(s => s.leftCountAddLR)
  const setLeftCount = useAddPaidStore(s => s.setLeftCountAddLR)
  const selectedCurve = useAddPaidStore(s => s.selectedCurveAddLR)
  const setSelectedCurve = useAddPaidStore(s => s.setSelectedCurveAddLR)
  const manualOverrides = useAddPaidStore(s => s.manualOverridesAddLR)
  const setManualOverrides = useAddPaidStore(s => s.setManualOverridesAddLR)
  const sourceSwitches = useAddPaidStore(s => s.sourceSwitchesAddLR)
  const setSourceSwitches = useAddPaidStore(s => s.setSourceSwitchesAddLR)
  const baseData = useAddPaidStore(s => s.addJ) // Initial Selection - LR_j
  const rawSimResults = useAddPaidStore(s => s.simResultsAddJ) // Fitted curves
  const setCombinedData = useAddPaidStore(s => s.setCombinedAddLRSummary)

  // Debug log
  useEffect(() => {
    console.log('🚨 AddLR Summary - selectedCurve:', selectedCurve)
  }, [selectedCurve])

  // Labels from store
  const rawDetColumnLabels = useLabelsStore(s => s.detColumnLabels)
  const detColumnLabels = useMemo(
    () => ["", ...rawDetColumnLabels],
    [rawDetColumnLabels]
  )

  console.log('AddLR detColumnLabels:', detColumnLabels)

  return (
    <DevSummaryLayout
      leftCount={leftCount}
      setLeftCount={setLeftCount}
      selectedCurve={selectedCurve}
      setSelectedCurve={setSelectedCurve}
      manualOverrides={manualOverrides}
      setManualOverrides={setManualOverrides}
      sourceSwitches={sourceSwitches}
      setSourceSwitches={setSourceSwitches}
      devJPreview={baseData || undefined} // 🔧 Konwersja null → undefined
      simResults={rawSimResults || undefined} // 🔧 Konwersja null → undefined
      setCombinedDevJ={setCombinedData}
      columnLabels={detColumnLabels}
      onRemainingDevJHeaders={() => {}} // Dummy dla AddPaid
      disabledCurves={[]}
      tableContext='AddLR'
    />
  )
}