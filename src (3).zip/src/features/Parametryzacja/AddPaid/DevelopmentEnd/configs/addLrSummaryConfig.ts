/* ------------------------------------------------------------------ */
/*                      AddLR Summary Configuration                   */
/* ------------------------------------------------------------------ */

import type { SummaryConfig } from '@/shared/types/summaryConfig'
import { useAddPaidStore } from '@/stores/addPaidStore'

// Eksportujemy funkcję zamiast obiektu, żeby uniknąć problemów z re-render
export const createAddLrSummaryConfig = (): SummaryConfig => ({
  tableContext: 'AddLR',
  useStore: useAddPaidStore, // 🎯 Używaj AddPaid store
  
  // Store selectors - leftCount
  leftCountSelector: (s) => s.leftCountAddLR,
  setLeftCountSelector: (s) => s.setLeftCountAddLR,
  
  // Store selectors - selectedCurve  
  selectedCurveSelector: (s) => s.selectedCurveAddLR,
  setSelectedCurveSelector: (s) => s.setSelectedCurveAddLR,
  
  // Store selectors - manualOverrides
  manualOverridesSelector: (s) => s.manualOverridesAddLR,
  setManualOverridesSelector: (s) => s.setManualOverridesAddLR,
  
  // Store selectors - sourceSwitches
  sourceSwitchesSelector: (s) => s.sourceSwitchesAddLR,
  setSourceSwitchesSelector: (s) => s.setSourceSwitchesAddLR,
  
  // Store selectors - dane bazowe
  baseDataSelector: (s) => s.addJ, // Initial Selection - LR_j z coefficients
  simResultsSelector: (s) => s.simResultsAddJ, // Dopasowane krzywe z FitCurve
  
  // Store selectors - kombinowane dane
  setCombinedDataSelector: (s) => s.setCombinedAddLRSummary,
  
  // Store selectors - pozostałe (używamy dummy dla zgodności)
  setRemainingHeadersSelector: (s) => () => {}, // AddPaid nie używa tego pola
  
  // Brak transformacji dla AddLR - dane używane bezpośrednio
  disabledCurves: [],
  debugLabel: 'AddLR Summary'
})