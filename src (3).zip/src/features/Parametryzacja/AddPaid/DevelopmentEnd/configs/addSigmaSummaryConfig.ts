/* ------------------------------------------------------------------ */
/*                  AddPaid Sigma Summary Configuration               */
/* ------------------------------------------------------------------ */

import type { SummaryConfig } from '@/shared/types/summaryConfig'

export const addSigmaSummaryConfig: SummaryConfig = {
  tableContext: 'AddSigma',
  
  // Store selectors - leftCount
  leftCountSelector: (s) => s.leftCountAddSigma,
  setLeftCountSelector: (s) => s.setLeftCountAddSigma,
  
  // Store selectors - selectedCurve  
  selectedCurveSelector: (s) => s.selectedCurveAddSigma,
  setSelectedCurveSelector: (s) => s.setSelectedCurveAddSigma,
  
  // Store selectors - manualOverrides
  manualOverridesSelector: (s) => s.manualOverridesAddSigma,
  setManualOverridesSelector: (s) => s.setManualOverridesAddSigma,
  
  // Store selectors - sourceSwitches
  sourceSwitchesSelector: (s) => s.sourceSwitchesAddSigma,
  setSourceSwitchesSelector: (s) => s.setSourceSwitchesAddSigma,
  
  // Store selectors - dane bazowe
  baseDataSelector: (s) => s.sigmaLR,
  simResultsSelector: (s) => s.simResultsSigmaLR,
  
  // Store selectors - kombinowane dane
  setCombinedDataSelector: (s) => s.setCombinedAddSigmaSummary,
  
  // Store selectors - pozostałe (używamy dummy dla zgodności)
  setRemainingHeadersSelector: (s) => () => {}, // AddPaid nie używa tego pola
  
  // Brak transformacji dla AddSigma - dane używane bezpośrednio
  disabledCurves: [],
  debugLabel: 'AddSigma'
}