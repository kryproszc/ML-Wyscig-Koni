/* ------------------------------------------------------------------ */
/*                     AddPaid SD Summary Configuration               */
/* ------------------------------------------------------------------ */

import type { SummaryConfig } from '@/shared/types/summaryConfig'
import { useAddPaidStore } from '@/stores/addPaidStore'

export const addSdSummaryConfig: SummaryConfig = {
  tableContext: 'AddSD',
  useStore: useAddPaidStore,
  
  // Store selectors - leftCount
  leftCountSelector: (s) => s.leftCountAddSD,
  setLeftCountSelector: (s) => s.setLeftCountAddSD,
  
  // Store selectors - selectedCurve  
  selectedCurveSelector: (s) => s.selectedCurveAddSD,
  setSelectedCurveSelector: (s) => s.setSelectedCurveAddSD,
  
  // Store selectors - manualOverrides
  manualOverridesSelector: (s) => s.manualOverridesAddSD,
  setManualOverridesSelector: (s) => s.setManualOverridesAddSD,
  
  // Store selectors - sourceSwitches
  sourceSwitchesSelector: (s) => s.sourceSwitchesAddSD,
  setSourceSwitchesSelector: (s) => s.setSourceSwitchesAddSD,
  
  // Store selectors - dane bazowe
  baseDataSelector: (s) => s.sdLR,
  simResultsSelector: (s) => s.simResultsSdLR,
  
  // Store selectors - kombinowane dane
  setCombinedDataSelector: (s) => s.setCombinedAddSDSummary,
  
  // Store selectors - pozostałe (używamy dummy dla zgodności)
  setRemainingHeadersSelector: (s) => () => {}, // AddPaid nie używa tego pola
  
  // Brak transformacji dla AddPaid SD - używaj oryginalnych wartości sdLR
  // transformBaseData: undefined,
  
  // Transformacja simResults dla AddPaid SD
  transformSimResults: (simResultsSdLR) => {
    if (!simResultsSdLR) return undefined
    
    // Format danych dla SimulationTable - używamy klucza "k: X" który jest rozpoznawany przez getCurveValue
    const sdLRData = Object.fromEntries(
      simResultsSdLR.map((value: number, index: number) => [`k: ${index + 1}`, value])
    )
    
    return { "se_pred": sdLRData }
  },
  
  disabledCurves: [],
  debugLabel: 'AddSD'
}