// features/Parametryzacja/AddPaid/Symulacje/AddSimulationPaid.tsx
'use client';

import { useState } from 'react';
import { useTrainDevideStoreDet } from '../../../../stores/trainDevideStoreDeterministyczny';
import { useUserStore } from '../../../../app/_components/useUserStore';
import { useParamsymStore } from '../../../../stores/paramsymStore';
import { useDiscountRatesStore } from '../../../../stores/discountRatesStore';
import { useExposureStore } from '../../../../stores/exposureStore';
import { useAddPaidStore } from '../../../../stores/addPaidStore';
import { useAddCoefficientsStore } from '../../../../stores/addCoefficientsStore';
import { useAddSimulationStore } from '../../../../stores/addSimulationStore';
import { useAddPaidResultsStore } from '../../../../stores/addPaidResultsStore'; // ✅ DODANE: wyniki deterministyczne AddPaid
import { CustomAlertDialog } from '@/components/CustomAlertDialog';
import { exportStatisticsToExcel } from '../../../../untils/exportToExcel';

// 🎯 IMPORTY REUŻYWALNYCH KOMPONENTÓW
import {
  SimulationLayout,
  SimulationControlPanel,
  SimulationStatisticsTable,
  type DataAvailabilityStatus,
  type SimulationParams
} from '../../../../shared/components/Symulacje';

import {
  useSimulationApi,
  type AlertState,
  type SimulationRequestData
} from '../../../../shared/hooks';

import {
  validateVectorLengths,
  checkDataAvailability,
  getCalculationOptions,
  processNetBruttoParams,
  processDiscountRates,
  parseQuantiles,
  prepareSelectedValueSigma,
  prepareCombinedSDSummary
} from '../../../../shared/utils';

// Rozszerzone interface dla AddPaid
interface AddSimulationRequestData extends Omit<SimulationRequestData, 'selected_value_cl' | 'cl_indexes' | 'left_count_cl' | 'tail_count_cl'> {
  selected_value_lr: number[];  // zamiast selected_value_cl
  lr_indexes: number[];         // zamiast cl_indexes  
  left_count_lr: number;        // zamiast left_count_cl
  tail_count_lr: number | null; // zamiast tail_count_cl
  e_values: number[];           // exposure values - nowe dla AddPaid
  skalowanie2: number;          // 🆕 DODANE: drugie skalowanie
}

export function AddSimulationPaid() {
  // State dla modali
  const [alertState, setAlertState] = useState<AlertState>({
    show: false,
    variant: 'success',
    title: '',
    message: ''
  });

  // API Hook
  const { executeSimulation, executeStatistics, isCalculating, isCalculatingStatistics } = useSimulationApi();

  // Stores - AddPaid specific
  const {
    simulationParams,
    kwantyle,
    statisticsResults,
    simulationResults, // ✅ NOWE: wyniki symulacji z własnego store
    updateSimulationParam,
    setKwantyle,
    setStatisticsResults,
    setSimulationResults, // ✅ NOWE: akcja dla wyników symulacji
    clearSimulationResults, // ✅ NOWE: czyszczenie wyników symulacji
    hasSimulationResults, // ✅ NOWE: sprawdzenie czy są wyniki
  } = useAddSimulationStore();

  const hasResults = hasSimulationResults(); // ✅ UżYWAMY WŁASNEJ FUNKCJI
  // Oddzielnie pobierz wyniki deterministyczne AddPaid (tylko do odczytu)
  const { results: addPaidResults } = useAddPaidResultsStore();
  // Stores - Dane źródłowe (te same co w CL)
  const { paidTriangle } = useTrainDevideStoreDet();
  const userId = useUserStore((s: any) => s.userId);
  const getParamsymTriangle = useParamsymStore((s) => s.paramsymTriangle);
  const getSelectedParamsymLine = useParamsymStore((s) => s.selectedParamsymLine);
  const getDiscountRatesTriangle = useDiscountRatesStore((s) => s.discountRatesTriangle);
  const getSelectedDiscountRateLine = useDiscountRatesStore((s) => s.selectedDiscountRateLine);

  // Stores - AddPaid specific dane
  const { exposureTriangle, selectedExposureLine } = useExposureStore();
  const { 
    selectedValuesAddLR,
    selectedValuesAddSigma,
    selectedValuesAddSD, // ✅ DODANE: SD values
    combinedAddSDSummary,
    selectedAddJIndexes,
    leftCountAddLR,
    tailCountAddJ
  } = useAddPaidStore();
  const { selectedWeightsAdd, trainDevideAdd } = useAddCoefficientsStore();

  // Sprawdzenie dostępności danych - rozszerzone o exposure
  const dataAvailability = {
    ...checkDataAvailability(
      paidTriangle || [],
      getDiscountRatesTriangle,
      getParamsymTriangle
    ),
    exposure: exposureTriangle && Object.keys(exposureTriangle).length > 0
  };

  const calculationOptions = getCalculationOptions(dataAvailability);

  // Przygotuj dane dla DataAvailabilityStatus
  const dataAvailabilityStatus: DataAvailabilityStatus[] = [
    {
      label: 'Trójkąt Paid',
      isAvailable: dataAvailability.paidTriangle,
      status: dataAvailability.paidTriangle ? 'Wczytany' : 'Brak danych'
    },
    {
      label: 'Ekspozycja',
      isAvailable: dataAvailability.exposure,
      status: dataAvailability.exposure ? 'Wczytany' : 'Brak danych'
    },
    {
      label: 'Stopy Dyskontowe',
      isAvailable: dataAvailability.discountRates,
      status: dataAvailability.discountRates ? 'Wczytany' : 'Brak danych'
    },
    {
      label: 'Netto/Brutto',
      isAvailable: dataAvailability.nettoBrutto,
      status: dataAvailability.nettoBrutto ? 'Wczytany' : 'Brak danych'
    }
  ];

  // Funkcje obsługi alertów
  const showAlert = (alert: AlertState) => {
    setAlertState(alert);
  };

  const hideAlert = () => {
    setAlertState(prev => ({ ...prev, show: false }));
  };

  // Przygotuj exposure values
  const prepareExposureValues = (): number[] => {
    if (!exposureTriangle || selectedExposureLine === null) {
      console.log('🔍 Brak danych exposure, zwracam pustą tablicę');
      return [];
    }

    const selectedLine = exposureTriangle[selectedExposureLine];
    if (!selectedLine) {
      console.log('🔍 Nie znaleziono wybranej linii exposure, zwracam pustą tablicę');
      return [];
    }

    // Konwertuj wartości na liczby, zastąp null zerami
    const values = Object.values(selectedLine).map(val => 
      typeof val === 'number' ? val : 0
    );
    
    console.log('🔍 Przygotowane exposure values:', values);
    return values;
  };

  // Główna funkcja wykonania obliczeń AddPaid
  const handleExecuteCalculations = async () => {
    console.log('🎯 ROZPOCZĘCIE OBLICZEŃ AddPaid');
    console.log('🔍 UserId:', userId);
    console.log('🔍 DataAvailability:', dataAvailability);
    
    // Wyczyść stare wyniki
    clearSimulationResults(); // ✅ CZYSZCZENIE WYNIKÓW SYMULACJI
    setStatisticsResults([]);
    
    if (!userId) {
      console.log('❌ Brak userId');
      return;
    }

    // Sprawdź podstawowe wymagania
    if (!dataAvailability.paidTriangle) {
      console.log('❌ Brak trójkąta paid');
      showAlert({
        show: true,
        variant: 'error',
        title: 'Błąd danych',
        message: 'Wymagany trójkąt paid do wykonania obliczeń AddPaid'
      });
      return;
    }

    // Sprawdź exposure (wymagane dla AddPaid)
    if (!dataAvailability.exposure) {
      console.log('❌ Brak danych exposure');
      showAlert({
        show: true,
        variant: 'error',
        title: 'Błąd danych',
        message: 'Wymagane dane ekspozycji do wykonania obliczeń AddPaid'
      });
      return;
    }

    console.log('✅ Podstawowe walidacje przeszły');

    // Przygotuj dane specifyczne dla AddPaid
    const exposureValues = prepareExposureValues();

    // 🔥 Przygotuj safeWeights - IDENTYCZNIE JAK W COEFFICIENTS
    const safeWeights = selectedWeightsAdd?.map((weightRow, rowIndex) => 
      weightRow.map((weight, colIndex) => {
        const trainValue = trainDevideAdd?.[rowIndex]?.[colIndex];
        // Jeśli w train_devide_add jest null/undefined - waga = 0
        if (trainValue === null || trainValue === undefined) {
          return 0;
        }
        // W przeciwnym razie używaj wagi z zaznaczenia
        return weight === 1 ? 1 : 0;
      })
    ) ?? [];
    
    console.log('🔍 Dane AddPaid:');
    console.log('  - selectedValuesAddLR:', selectedValuesAddLR);
    console.log('  - selectedValuesAddSigma:', selectedValuesAddSigma);  
    console.log('  - selectedValuesAddSD:', selectedValuesAddSD);  // ✅ DODANE
    console.log('  - combinedAddSDSummary:', combinedAddSDSummary);
    console.log('  - selectedAddJIndexes:', selectedAddJIndexes);
    console.log('  - leftCountAddLR:', leftCountAddLR);
    console.log('  - tailCountAddJ:', tailCountAddJ);
    console.log('  - exposureValues:', exposureValues);
    console.log('  - safeWeights (first 3 rows):', safeWeights.slice(0, 3).map(r => r.slice(0, 10)));

    // Waliduj długości wektorów (AddPaid specific)
    if (selectedValuesAddLR.length === 0) {
      showAlert({
        show: true,
        variant: 'error', 
        title: 'Błąd danych AddLR',
        message: 'Brak danych selectedValuesAddLR. Sprawdź konfigurację w zakładce Parametryzacja AddPaid.'
      });
      return;
    }

    if (selectedValuesAddSigma.length === 0) {
      showAlert({
        show: true,
        variant: 'error',
        title: 'Błąd danych Sigma',
        message: 'Brak danych selectedValuesAddSigma. Sprawdź konfigurację w zakładce Parametryzacja AddPaid.'
      });
      return;
    }

    // Przygotuj wektory z funktions prepare (jak w CL)
    console.log('🔍 Przygotowuję wektory...');
    const vectorSelectedValueSigma = prepareSelectedValueSigma(
      selectedValuesAddSigma,
      combinedAddSDSummary,
      selectedValuesAddSigma // fallback na siebie
    );
    console.log('🔍 VectorSelectedValueSigma:', vectorSelectedValueSigma);

    const vectorCombinedSDSummary = prepareCombinedSDSummary(
      selectedValuesAddSD,    // ✅ POPRAWKA: SD values, nie Sigma!
      combinedAddSDSummary,   // fallback: mixed format
      selectedValuesAddSD     // fallback 2: SD values again
    );
    console.log('🔍 VectorCombinedSDSummary:', vectorCombinedSDSummary);

    // Przygotuj pozostałe dane (takie same jak CL)
    const processedNetBrutto = processNetBruttoParams(
      getParamsymTriangle,
      getSelectedParamsymLine
    );

    const processedDiscountRates = processDiscountRates(
      getDiscountRatesTriangle,
      getSelectedDiscountRateLine
    );

    // Przygotuj request data dla AddPaid
    const requestData: AddSimulationRequestData = {
      user_id: userId,
      paid_triangle: paidTriangle || [],
      weights: safeWeights, // ✅ UŻYWAMY SAFEWEIGHTS - tak jak w coefficients!
      lr_indexes: selectedAddJIndexes || [],           // LR indexes zamiast CL
      sigma_indexes: selectedAddJIndexes || [],         // Używamy tych samych indeksów
      left_count_lr: leftCountAddLR || 0,              // LR count zamiast CL
      selected_value_lr: selectedValuesAddLR,          // LR values zamiast CL
      selected_value_sigma: vectorSelectedValueSigma, // ✅ UŻYWAMY PRZYGOTOWANEGO
      combined_sd_summary: vectorCombinedSDSummary,   // ✅ UŻYWAMY PRZYGOTOWANEGO (NUMERIC!)
      tail_count_lr: tailCountAddJ || null,           // LR tail count
      e_values: exposureValues,                        // NOWE: exposure values
      calculation_options: calculationOptions,
      discount_rates: processedDiscountRates,
      netto_brutto: processedNetBrutto,
      ilosc_symulacji: simulationParams.iloscSymulacji,
      ziarno: simulationParams.ziarno,
      podzial_ziarna: simulationParams.podzialZiarna,
      skalowanie: simulationParams.skalowanie,
      skalowanie2: simulationParams.skalowanie2,
      kwantyle: parseQuantiles(kwantyle)
    };

    console.log('🔍 AddPaid RequestData:', requestData);

    // Wykonaj symulację AddPaid
    console.log('🔍 Wysyłam żądanie symulacji AddPaid...');
    const results = await executeSimulation(
      requestData as any, // Type cast dla kompatybilności z shared hook
      '/calc/simulationAddpaid', // Nowy endpoint
      showAlert
    );

    if (results) {
      console.log('✅ Zapisuję wyniki AddPaid SYMULACJI');
      setSimulationResults({ // ✅ UŻYWAMY SETSIMULATINRESULTS
        last_col: results.last_col || [],
        cum_trian: results.cum_trian || [],
        ult_net_disc: results.ult_net_disc || [],
        userId: userId,
        shouldShowResults: true
      });
      setStatisticsResults([]);
    } else {
      console.log('❌ Brak wyników AddPaid - symulacja nie powiodła się');
    }
    
    console.log('🏁 KONIEC FUNKCJI handleExecuteCalculations AddPaid');
  };

  // Funkcja wykonania statystyk AddPaid
  const handleExecuteStatistics = async () => {
    if (!userId) return;

    if (!simulationResults) { // ✅ SPRAWDZAMY WYNIKI SYMULACJI
      showAlert({
        show: true,
        variant: 'warning',
        title: 'Brak danych symulacji',
        message: 'Najpierw wykonaj "Wykonaj obliczenia AddPaid", a następnie statystyki.'
      });
      return;
    }

    // Sprawdź czy wyniki są świeże
    if (!simulationResults.userId || simulationResults.userId !== userId) { // ✅ SPRAWDZAMY USERID W SYMULACJI
      showAlert({
        show: true,
        variant: 'warning',
        title: 'Nieświeże dane symulacji',
        message: 'Wyniki symulacji AddPaid są przestarzałe. Wykonaj ponownie "Wykonaj obliczenia".'
      });
      return;
    }

    // 🎯 SPRAWDŹ czy wyniki deterministyczne AddPaid są rzeczywiście obliczone
    const hasAddPaidResults = addPaidResults && 
                              addPaidResults.userId === userId &&
                              addPaidResults.shouldShowResults === true &&
                              Array.isArray(addPaidResults.last_col) &&
                              addPaidResults.last_col.length > 0 &&
                              addPaidResults.last_col.some(val => val !== 0) &&
                              typeof addPaidResults.userId === 'string' &&
                              typeof addPaidResults.calculatedAt === 'string';

    const statisticsData = {
      user_id: userId,
      kwantyle: parseQuantiles(kwantyle),
      skalowanie: simulationParams.skalowanie,
      skalowanie2: simulationParams.skalowanie2,
      simulation_results: null, // Backend użyje zapisanych danych
      // 🎯 WYSYŁAJ wyniki deterministyczne AddPaid
      deterministic_results: hasAddPaidResults ? {
        cum_trian: addPaidResults.cum_trian,
        last_col: addPaidResults.last_col,
        ult_net_disc: addPaidResults.ult_net_disc,
        userId: addPaidResults.userId as string,
        calculatedAt: addPaidResults.calculatedAt as string
      } : null
    };

    console.log('🔍 AddPaid StatisticsData przed wysłaniem:', statisticsData);

    const results = await executeStatistics(
      statisticsData,
      '/calc/statisticAddpaid', // Nowy endpoint dla statystyk AddPaid
      showAlert
    );

    if (results) {
      // Konwertuj wyniki na format StatisticResult (z shared)
      const addResults: any[] = results.map(r => ({
        column: 0, // Używamy 0 jako placeholder dla number
        mean: r.mean || 0,
        std: r.std || 0,
        quantiles: r.quantiles || [],
        SCR: (r as any).SCR || 0,
        columnName: r.column || 'Unknown' // Dodatkowe pole z nazwą
      }));
      setStatisticsResults(addResults);
    }
  };

  // Funkcja eksportu do Excel (adaptacja dla AddPaid)
  const handleExportStatistics = () => {
    if (statisticsResults.length === 0) {
      showAlert({
        show: true,
        variant: 'warning',
        title: 'Brak danych',
        message: 'Najpierw wykonaj statystyki AddPaid, aby móc je wyeksportować do Excel.'
      });
      return;
    }

    try {
      exportStatisticsToExcel(
        statisticsResults,
        kwantyle,
        simulationParams.skalowanie,
        simulationParams as any // Type cast dla kompatybilności
      );
      showAlert({
        show: true,
        variant: 'success',
        title: 'Eksport wykonany!',
        message: 'Statystyki AddPaid zostały zapisane do pliku Excel.'
      });
    } catch (error) {
      console.error('Błąd podczas eksportu AddPaid:', error);
      showAlert({
        show: true,
        variant: 'error',
        title: 'Błąd eksportu',
        message: 'Wystąpił błąd podczas zapisywania do Excel. Sprawdź konsolę przeglądarki.'
      });
    }
  };

  // Adaptacja SimulationParams dla AddPaid
  const adaptedSimulationParams: SimulationParams = {
    iloscSymulacji: simulationParams.iloscSymulacji,
    ziarno: simulationParams.ziarno,
    podzialZiarna: simulationParams.podzialZiarna,
    skalowanie: simulationParams.skalowanie,
    skalowanie2: simulationParams.skalowanie2
  };

  return (
    <>
      <SimulationLayout
        sidebar={
          <SimulationControlPanel
            simulationParams={adaptedSimulationParams}
            kwantyle={kwantyle}
            isCalculating={isCalculating}
            isCalculatingStatistics={isCalculatingStatistics}
            hasResults={hasResults}
            statisticsResultsCount={statisticsResults.length}
            dataAvailability={dataAvailabilityStatus}
            onUpdateSimulationParam={(key, value) => updateSimulationParam(key as any, value)}
            onSetKwantyle={setKwantyle}
            onExecuteCalculations={handleExecuteCalculations}
            onExecuteStatistics={handleExecuteStatistics}
            onClearResults={clearSimulationResults} // ✅ CZYSZCZENIE WYNIKÓW SYMULACJI
            onClearStatistics={() => setStatisticsResults([])}
            onExportStatistics={handleExportStatistics}
          />
        }
      >
        <SimulationStatisticsTable
          statisticsResults={statisticsResults}
          kwantyle={kwantyle}
          skalowanie={simulationParams.skalowanie}
          skalowanie2={simulationParams.skalowanie2}
          title="📊 Wyniki Statystyk AddPaid"
          subtitle="Analiza statystyczna wyników symulacji metodą AddPaid Loss Ratio"
        />
      </SimulationLayout>

      {/* Modal */}
      <CustomAlertDialog
        open={alertState.show}
        onOpenChange={hideAlert}
        variant={alertState.variant}
        title={alertState.title}
        message={alertState.message}
        buttonText="OK"
      />
    </>
  );
}