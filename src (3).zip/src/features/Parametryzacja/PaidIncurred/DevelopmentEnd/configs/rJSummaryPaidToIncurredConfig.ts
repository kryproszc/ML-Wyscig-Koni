/* ------------------------------------------------------------------ */
/*             r_j Summary Configuration (PaidToIncurred)              */
/* ------------------------------------------------------------------ */

import type { SummaryConfig } from '@/shared/types/summaryConfig'
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred'

export const rJSummaryPaidToIncurredConfig: SummaryConfig = {
  tableContext: 'r_j (PaidToIncurred)',
  
  // Store hook - używamy Incurred store (który ma dane PaidToIncurred)
  useStore: useTrainDevideStoreIncurred,
  
  // Store selectors - leftCount
  leftCountSelector: (s) => s.leftCountRJPaidToIncurred,
  setLeftCountSelector: (s) => s.setLeftCountRJPaidToIncurred,
  
  // Store selectors - selectedCurve  
  selectedCurveSelector: (s) => s.selectedCurveRJPaidToIncurred,
  setSelectedCurveSelector: (s) => s.setSelectedCurveRJPaidToIncurred,
  
  // Store selectors - manualOverrides
  manualOverridesSelector: (s) => s.manualOverridesRJPaidToIncurred,
  setManualOverridesSelector: (s) => s.setManualOverridesRJPaidToIncurred,
  
  // Store selectors - sourceSwitches
  sourceSwitchesSelector: (s) => s.sourceSwitchesRJPaidToIncurred,
  setSourceSwitchesSelector: (s) => s.setSourceSwitchesRJPaidToIncurred,
  
  // Store selectors - dane bazowe
  baseDataSelector: (s) => s.rJPaidToIncurredPreview,
  simResultsSelector: (s) => s.simResultsRJPaidToIncurred,
  selectedValuesSelector: (s) => s.selectedValuesRJPaidToIncurred, // 🆕 DODANO Selected Values
  
  // Store selectors - kombinowane dane
  setCombinedDataSelector: (s) => s.setCombinedRJPaidToIncurredSummary,
  
  // Store selectors - pozostałe (nie ma remainingHeaders dla PaidIncurred)
  setRemainingHeadersSelector: (s) => s.setRemainingDevJHeaders, // Użyjemy tego samego
  
  // Brak transformacji dla r_j - dane używane bezpośrednio
  disabledCurves: [], // Wszystkie krzywe dostępne dla r_j
  debugLabel: 'PaidToIncurredRJSummaryTab - selectedCurve (r_j PaidToIncurred)'
}