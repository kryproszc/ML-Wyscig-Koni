/* ------------------------------------------------------------------ */
/*           var_j Summary Configuration (PaidToIncurred)              */
/* ------------------------------------------------------------------ */

import type { SummaryConfig } from '@/shared/types/summaryConfig'
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred'

export const varJSummaryPaidToIncurredConfig: SummaryConfig = {
  tableContext: 'var_j (PaidToIncurred)',
  
  // Store hook - używamy Incurred store (który ma dane PaidToIncurred)
  useStore: useTrainDevideStoreIncurred,
  
  // Store selectors - leftCount
  leftCountSelector: (s) => s.leftCountVarJPaidToIncurred,
  setLeftCountSelector: (s) => s.setLeftCountVarJPaidToIncurred,
  
  // Store selectors - selectedCurve  
  selectedCurveSelector: (s) => s.selectedCurveVarJPaidToIncurred,
  setSelectedCurveSelector: (s) => s.setSelectedCurveVarJPaidToIncurred,
  
  // Store selectors - manualOverrides
  manualOverridesSelector: (s) => s.manualOverridesVarJPaidToIncurred,
  setManualOverridesSelector: (s) => s.setManualOverridesVarJPaidToIncurred,
  
  // Store selectors - sourceSwitches
  sourceSwitchesSelector: (s) => s.sourceSwitchesVarJPaidToIncurred,
  setSourceSwitchesSelector: (s) => s.setSourceSwitchesVarJPaidToIncurred,
  
  // Store selectors - dane bazowe
  baseDataSelector: (s) => s.varJPaidToIncurredPreview,
  simResultsSelector: (s) => s.simResultsVarJPaidToIncurred,
  
  // Store selectors - kombinowane dane
  setCombinedDataSelector: (s) => s.setCombinedVarJPaidToIncurredSummary,
  
  // Store selectors - selected values (effectiveValues z FinalTable)
  selectedValuesSelector: (s) => s.selectedValuesVarJPaidToIncurred,
  setSelectedValuesSelector: (s) => s.setSelectedValuesVarJPaidToIncurred,
  
  // Store selectors - pozostałe (nie ma remainingHeaders dla PaidIncurred)
  setRemainingHeadersSelector: (s) => s.setRemainingDevJHeaders, // Użyjemy tego samego
  
  // Brak transformacji dla var_j - dane używane bezpośrednio
  disabledCurves: [], // Wszystkie krzywe dostępne dla var_j
  debugLabel: 'PaidToIncurredVarJSummaryTab - selectedCurve (var_j PaidToIncurred)'
}