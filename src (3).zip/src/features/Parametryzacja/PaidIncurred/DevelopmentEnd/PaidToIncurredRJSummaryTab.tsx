/* ------------------------------------------------------------------ */
/*               PaidToIncurredRJSummaryTab.tsx                        */
/* ------------------------------------------------------------------ */
"use client"

import React from "react";
import { GenericSummaryTab } from '@/shared/components/DevelopmentEnd'
import { rJSummaryPaidToIncurredConfig } from './configs'

export default function PaidToIncurredRJSummaryTab() {
  return <GenericSummaryTab config={rJSummaryPaidToIncurredConfig} />
}