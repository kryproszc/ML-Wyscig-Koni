/* ------------------------------------------------------------------ */
/*              PaidToIncurredVarJSummaryTab.tsx                       */
/* ------------------------------------------------------------------ */
"use client"

import React from "react";
import { GenericSummaryTab } from '@/shared/components/DevelopmentEnd'
import { varJSummaryPaidToIncurredConfig } from './configs'

export default function PaidToIncurredVarJSummaryTab() {
  return <GenericSummaryTab config={varJSummaryPaidToIncurredConfig} />
}