'use client';

import { useEffect } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useUserStore } from '@/app/_components/useUserStore';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export function usePaidToIncurred() {
  const userId = useUserStore((s) => s.userId);
  
  // Store dla danych paid
  const storePaid = useTrainDevideStoreDet();
  const paidTriangle = storePaid.paidTriangle;
  const paidTriangle_bez_inf = storePaid.paidTriangle_bez_inf;
  
  // Store dla danych incurred i PaidToIncurred
  const storeIncurred = useTrainDevideStoreIncurred();
  const {
    incurredTriangle,
    incurredTriangle_bez_inf,
    trainPaidToIncurred,
    selectedWeightsPaidToIncurred,
    safeWeightsPaidToIncurred,
    selectedCellsPaidToIncurred,
    volumePaidToIncurred,
    devJPaidToIncurred,
    sigmaPaidToIncurred,
    sdPaidToIncurred,
    rJPaidToIncurred,
    varJPaidToIncurred,
    resIJPaidToIncurred,
    lambdaJPaidToIncurred,
    minMaxHighlightingPaidToIncurred,
    minMaxCellsPaidToIncurred,
    minCellsPaidToIncurred,
    maxCellsPaidToIncurred,
    setTrainPaidToIncurred,
    setSafeWeightsPaidToIncurred,
    setDevJPaidToIncurred,
    setSigmaPaidToIncurred,
    setSdPaidToIncurred,
    setRJPaidToIncurred,
    setVarJPaidToIncurred,
    setResIJPaidToIncurred,
    setLambdaJPaidToIncurred,
    resetSelectionPaidToIncurred,
    toggleRowPaidToIncurred,
    toggleCellPaidToIncurred,
    toggleWeightCellPaidToIncurred,
    setMinMaxHighlightingPaidToIncurred,
    // Preview setters dla FitCurve
    setRJPaidToIncurredPreview,
    setVarJPaidToIncurredPreview,
    // Selected indexes setters dla automatycznego wybierania
    setSelectedRJPaidToIncurredIndexes,
    setSelectedVarJPaidToIncurredIndexes,
  } = storeIncurred;

  /* -------- mutation 1: Send triangles -------- */
  const mSendTriangles = useMutation({
    mutationKey: ['paidToIncurredTriangles'],
    mutationFn: async () => {
      const paid = paidTriangle_bez_inf ?? [];
      const incurred = incurredTriangle_bez_inf ?? [];
      
      console.log('📤 [mSendTriangles] Wysyłam na backend (BEZ INFLACJI):', {
        endpoint: `${API_URL}/calc/paid_incurred/triangles`,
        paidRows: paid.length,
        paidCols: paid[0]?.length || 0,
        incurredRows: incurred.length,
        incurredCols: incurred[0]?.length || 0,
        userId: userId
      });
      
      const requestBody = { 
        user_id: userId, 
        paid_data_det: paid,
        incurred_data_det: incurred
      };
      
      const res = await fetch(`${API_URL}/calc/paid_incurred/triangles`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody),
      });
      
      return res.json() as Promise<{ train_paidtoincurred?: number[][] }>;
    },
    onSuccess: (d) => {
      console.log('✅ [mSendTriangles] Odpowiedź z backendu:', d);
      if (d.train_paidtoincurred) {
        setTrainPaidToIncurred(d.train_paidtoincurred);
        // Ustaw wagi automatycznie - 0 dla pustych komórek, 1 dla prawidłowych
        if (!selectedWeightsPaidToIncurred) {
          console.log('🎯 Automatyczne ustawianie wag po otrzymaniu train_paidtoincurred');
          resetSelectionPaidToIncurred();
        }
      }
    },
  });

  /* -------- mutation 2: Calculate final PaidToIncurred -------- */
  const mCalculatePaidToIncurred = useMutation({
    mutationKey: ['calculatePaidToIncurred'],
    mutationFn: async () => {
      console.log('🚀 === ROZPOCZYNAM OBLICZENIA PAID TO INCURRED ===');
      console.log('📊 Stan aktualnych wag z UI (selectedWeightsPaidToIncurred):');
      if (selectedWeightsPaidToIncurred) {
        selectedWeightsPaidToIncurred.forEach((row, i) => {
          console.log(`Wiersz ${i}:`, row);
        });
        console.log('🔢 Statystyki wag z UI:', {
          rows: selectedWeightsPaidToIncurred.length,
          cols: selectedWeightsPaidToIncurred[0]?.length || 0,
          totalCells: selectedWeightsPaidToIncurred.flat().length,
          selectedCells: selectedWeightsPaidToIncurred.flat().filter(w => w === 1).length,
          unselectedCells: selectedWeightsPaidToIncurred.flat().filter(w => w === 0).length,
        });
      } else {
        console.log('❌ Brak selectedWeightsPaidToIncurred');
      }
      console.log('🚀 === KONTYNUUJĘ OBLICZENIA ===');
      
      // WYSYŁAMY PEŁNE DANE BEZ INFLACJI
      const paid = (paidTriangle_bez_inf ?? []);
      const incurred = (incurredTriangle_bez_inf ?? []);
      
      // Buduj macierz wag na podstawie trainPaidToIncurred  
      // Używamy pełnych danych żeby zachować zgodność wymiarów
      const trainMatrix = (trainPaidToIncurred ?? []);
      const safeWeights = trainMatrix.map((row, rowIndex) => 
        row.map((cell, colIndex) => {
          // Jeśli komórka ma NaN/null/undefined - waga = 0 (nie ma danych)
          if (cell === null || cell === undefined || isNaN(cell)) return 0;
          
          // Jeśli komórka ma liczbę - użyj wagi z selectedWeightsPaidToIncurred
          const originalWeight = selectedWeightsPaidToIncurred?.[rowIndex]?.[colIndex];
          return originalWeight === 1 ? 1 : 0;
        })
      );

      // Zapisz do store
      setSafeWeightsPaidToIncurred(safeWeights);
      
      const requestBody = {
        user_id: userId,
        paid_data_det: paid,
        incurred_data_det: incurred,
        weights: safeWeights,
        weights_rj_incurred: safeWeights,  // 🎯 DODANE - wagi dla rj PaidToIncurred (identyczne z podstawowymi wagami)
      };
      
      console.log('📤 [mCalculatePaidToIncurred] Wysyłam na backend (BEZ INFLACJI):', {
        endpoint: `${API_URL}/calc/paid_incurred/calculate`,
        paidRows: paid.length,
        paidCols: paid[0]?.length || 0,
        incurredRows: incurred.length,
        incurredCols: incurred[0]?.length || 0,
        weightsRows: safeWeights.length,
        weightsCols: safeWeights[0]?.length || 0,
        userId: userId
      });
      
      // ===== SZCZEGÓŁOWE LOGI DANYCH =====
      console.log('🔍 === SZCZEGÓŁY WYSYŁANYCH DANYCH (BEZ INFLACJI) ===');
      console.log('📊 Paid Triangle bez inflacji (pierwsze 3 wiersze):', paid.slice(0, 3));
      console.log('📊 Incurred Triangle bez inflacji (pierwsze 3 wiersze):', incurred.slice(0, 3));
      console.log('⚖️ Weights Matrix (kompletna):', safeWeights);
      console.log('⚖️ Weights RJ Incurred Matrix (kompletna):', safeWeights); // 🎯 DODANE - log dla weights_rj_incurred
      console.log('⚖️ Selected Weights (z UI):', selectedWeightsPaidToIncurred);
      console.log('🔢 Statystyki wag:', {
        totalWeights: safeWeights.flat().length,
        selectedWeights: safeWeights.flat().filter(w => w === 1).length,
        unselectedWeights: safeWeights.flat().filter(w => w === 0).length,
        percentage: Math.round((safeWeights.flat().filter(w => w === 1).length / safeWeights.flat().length) * 100) + '%'
      });
      console.log('🎯 Statystyki weights_rj_incurred (identyczne):', {
        totalWeights: safeWeights.flat().length,
        selectedWeights: safeWeights.flat().filter(w => w === 1).length,
        percentage: Math.round((safeWeights.flat().filter(w => w === 1).length / safeWeights.flat().length) * 100) + '%'
      }); // 🎯 DODANE - statystyki dla weights_rj_incurred
      console.log('📝 Request Body (kompletny):', requestBody);
      console.log('🔍 === KONIEC SZCZEGÓŁÓW ===');
      
      const res = await fetch(`${API_URL}/calc/paid_incurred/calculate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody),
      });
      
      return res.json() as Promise<{ 
        message?: string; 
        r_j?: number[];
        var_j?: number[];
        res_i_j?: number[][];
        lambda_j?: number;
      }>;
    },
    onSuccess: (d) => {
      console.log('🚀 Odpowiedź z /calc/paid_incurred/calculate:', d);
      
      if (d.r_j) {
        console.log('✅ Otrzymano r_j:', d.r_j);
        setRJPaidToIncurred(d.r_j);
        
        // Automatycznie kopiuj do preview TYLKO jeśli preview jest puste (pierwsze obliczenia)
        if (!storeIncurred.rJPaidToIncurredPreview || storeIncurred.rJPaidToIncurredPreview.length === 0) {
          console.log('🎯 Pierwsze obliczenia r_j - automatycznie ładuję do preview');
          setRJPaidToIncurredPreview(d.r_j);
        } else {
          console.log('🔄 r_j preview już istnieje - pomijam automatyczne ładowanie');
        }
        
        // Automatycznie wybierz odpowiednie indeksy dla r_j PaidToIncurred (wykluczając wartości równe 1.0)
        const autoSelectedRJ = d.r_j
          .map((v, i) => (Math.abs(v - 1.0) > 0.0001 ? i : -1))
          .filter((i) => i >= 0);
        setSelectedRJPaidToIncurredIndexes(autoSelectedRJ);
        console.log('🎯 Auto-selected r_j PaidToIncurred indexes (excluding values = 1.0):', autoSelectedRJ);
      }
      
      if (d.var_j) {
        console.log('✅ Otrzymano var_j:', d.var_j);
        setVarJPaidToIncurred(d.var_j);
        
        // Automatycznie kopiuj do preview TYLKO jeśli preview jest puste (pierwsze obliczenia)
        if (!storeIncurred.varJPaidToIncurredPreview || storeIncurred.varJPaidToIncurredPreview.length === 0) {
          console.log('🎯 Pierwsze obliczenia var_j - automatycznie ładuję do preview');
          setVarJPaidToIncurredPreview(d.var_j);
        } else {
          console.log('🔄 var_j preview już istnieje - pomijam automatyczne ładowanie');
        }
        
        // Automatycznie wybierz odpowiednie indeksy dla var_j PaidToIncurred (wartości > 0)
        const autoSelectedVarJ = d.var_j
          .map((v, i) => (v > 0 ? i : -1))
          .filter((i) => i >= 0);
        setSelectedVarJPaidToIncurredIndexes(autoSelectedVarJ);
        console.log('🎯 Auto-selected var_j PaidToIncurred indexes (values > 0):', autoSelectedVarJ);
      }
      
      if (d.res_i_j) {
        console.log('✅ Otrzymano res_i_j (matrix):', d.res_i_j);
        setResIJPaidToIncurred(d.res_i_j);
      }
      
      if (d.lambda_j) {
        console.log('✅ Otrzymano lambda_j:', d.lambda_j);
        setLambdaJPaidToIncurred(d.lambda_j);
      }
    },
  });

  /* auto-start triangles sending */
  useEffect(() => {
    console.log('[usePaidToIncurred] 🔍 useEffect triggered:', {
      hasPaidTriangle_bez_inf: !!paidTriangle_bez_inf?.length,
      hasIncurredTriangle_bez_inf: !!incurredTriangle_bez_inf?.length,
      hasTrainPaidToIncurred: !!trainPaidToIncurred?.length,
      shouldTrigger: !!(paidTriangle_bez_inf?.length && incurredTriangle_bez_inf?.length && !trainPaidToIncurred?.length)
    });
    
    if (paidTriangle_bez_inf?.length && incurredTriangle_bez_inf?.length && !trainPaidToIncurred?.length) {
      console.log('[usePaidToIncurred] 🚀 Triggering mSendTriangles.mutate() z danymi bez inflacji');
      mSendTriangles.mutate();
    }
  }, [paidTriangle_bez_inf, incurredTriangle_bez_inf, trainPaidToIncurred]);

  return {
    paidTriangle,
    incurredTriangle,
    triangle: trainPaidToIncurred,
    trainDevide: trainPaidToIncurred,
    weights: selectedWeightsPaidToIncurred,
    selectedCells: selectedCellsPaidToIncurred,
    devJ: devJPaidToIncurred,
    sigma: sigmaPaidToIncurred,
    sd: sdPaidToIncurred,
    rJ: rJPaidToIncurred,
    varJ: varJPaidToIncurred,
    resIJ: resIJPaidToIncurred,
    lambdaJ: lambdaJPaidToIncurred,
    minMaxHighlighting: minMaxHighlightingPaidToIncurred,
    minMaxCells: minMaxCellsPaidToIncurred,
    minCells: minCellsPaidToIncurred,
    maxCells: maxCellsPaidToIncurred,
    
    // Toggle functions
    toggleRowDet: toggleRowPaidToIncurred,
    toggleCellDet: toggleCellPaidToIncurred,
    toggleWeightCellDet: toggleWeightCellPaidToIncurred,
    
    // Calculations
    runSigma: () => mCalculatePaidToIncurred.mutate(),
    isLoading: mSendTriangles.isPending || mCalculatePaidToIncurred.isPending,
  };
}