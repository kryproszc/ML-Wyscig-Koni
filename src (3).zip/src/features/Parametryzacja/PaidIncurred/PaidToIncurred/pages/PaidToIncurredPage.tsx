'use client';

import React, { useState } from 'react';
import { usePaidToIncurred } from '../hooks/usePaidToIncurred';
import SidebarPanelPaidToIncurred from '../components/SidebarPanelPaidToIncurred';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { useDisplaySettingsStore } from '@/stores/useDisplaySettingsStore';
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import {
  CalculationPageLayout,
  type ResultRow,
} from '@/shared/components/calculation-tables';

export default function PaidToIncurredPage() {
  // Labels from store - używamy incurred labels dla kompatybilności
  const incurredRowLabels = useLabelsStore((s) => s.incurredRowLabels);
  const incurredColumnLabels = useLabelsStore((s) => s.incurredColumnLabels);

  // Display settings for fullscreen
  const fullscreenMode = useDisplaySettingsStore((s) => s.fullscreenMode);
  const tableScale = useDisplaySettingsStore((s) => s.tableScale);
  const setFullscreenMode = useDisplaySettingsStore((s) => s.setFullscreenMode);
  const increaseScale = useDisplaySettingsStore((s) => s.increaseScale);
  const decreaseScale = useDisplaySettingsStore((s) => s.decreaseScale);

  // Stan dla animacji zamykania
  const [isClosing, setIsClosing] = useState(false);

  const {
    paidTriangle,
    incurredTriangle,
    triangle,
    trainDevide,
    weights,
    selectedCells,
    devJ,
    sigma,
    sd,
    rJ,
    varJ,
    resIJ: resIJResults,
    lambdaJ: lambdaJResult,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    toggleRowDet,
    toggleWeightCellDet,
    runSigma,
    isLoading,
  } = usePaidToIncurred();

  // Dostęp do store dla decimalPlaces i danych bez inflacji
  const store = useTrainDevideStoreIncurred();
  const { 
    decimalPlaces, 
    volumePaidToIncurred: volume, 
    setVolumePaidToIncurred: setVolume,
    incurredTriangle_bez_inf 
  } = store;
  
  // Dostęp do paid bez inflacji
  const paidStore = useTrainDevideStoreDet();
  const paidTriangle_bez_inf = paidStore.paidTriangle_bez_inf;
  
  // === DEBUG STORE ===
  console.log('💾 === DEBUG STORE ===');
  console.log('trainPaidToIncurred w store:', store.trainPaidToIncurred?.length ? `${store.trainPaidToIncurred.length}x${store.trainPaidToIncurred[0]?.length}` : 'BRAK');
  console.log('rJPaidToIncurred w store:', store.rJPaidToIncurred?.length ? store.rJPaidToIncurred.slice(0, 3) : 'BRAK');
  console.log('varJPaidToIncurred w store:', store.varJPaidToIncurred?.length ? store.varJPaidToIncurred.slice(0, 3) : 'BRAK');
  console.log('lambdaJPaidToIncurred w store:', store.lambdaJPaidToIncurred);
  console.log('devJPaidToIncurred w store:', store.devJPaidToIncurred?.length ? store.devJPaidToIncurred.slice(0, 3) : 'BRAK');
  console.log('💾 === KONIEC DEBUG STORE ===');

  // Funkcja do zamykania z animacją
  const handleCloseFullscreen = () => {
    setIsClosing(true);
    setTimeout(() => {
      setFullscreenMode(false);
      setIsClosing(false);
    }, 300);
  };

  // ---- Nagłówki kolumn dla tabeli współczynników ----
  const coeffHeaderLabels =
    incurredColumnLabels.length > 1
      ? incurredColumnLabels.slice(1, 1 + (trainDevide?.[0]?.length || 0))
      : Array.from({ length: trainDevide?.[0]?.length || 0 }, (_, i) => String(i + 2));

  // ---- Etykiety wierszy 1:1 (bez +1) ----
  const rowLabelAt = (i: number) => incurredRowLabels[i] ?? String(i + 1);

  // ---- Przygotowanie danych dla tabeli ----
  const tableData = trainDevide?.length ? [
    ['Cały wiersz'].concat(coeffHeaderLabels),
    ...trainDevide.map((row, i) => [
      rowLabelAt(i),
      ...row.map((c) => (c == null ? '' : c.toString())),
    ]),
  ] : [];

  // ---- Przygotowanie danych wyników ----
  const resultRows: ResultRow[] = [
    {
      label: 'r_j',
      values: rJ || [],
      visible: !!rJ?.length,
    },
    {
      label: 'var_j',
      values: varJ || [],
      visible: !!varJ?.length,
    },
    {
      label: 'lambda_j',
      values: lambdaJResult ? [lambdaJResult] : [],
      visible: !!lambdaJResult,
    },
  ];

  // Sprawdź czy mamy potrzebne dane do wyświetlenia tabeli - używamy danych bez inflacji
  const hasData = !!paidTriangle_bez_inf?.length && !!incurredTriangle_bez_inf?.length && !!trainDevide?.length;

  // === DEBUG LOGS ===
  console.log('🔍 === PaidToIncurredPage DEBUG ===');
  console.log('📊 paidTriangle (z inflacją):', !!paidTriangle?.length ? `${paidTriangle.length}x${paidTriangle[0]?.length}` : 'BRAK');
  console.log('📊 paidTriangle_bez_inf:', !!paidTriangle_bez_inf?.length ? `${paidTriangle_bez_inf.length}x${paidTriangle_bez_inf[0]?.length}` : 'BRAK');
  console.log('📊 incurredTriangle (z inflacją):', !!incurredTriangle?.length ? `${incurredTriangle.length}x${incurredTriangle[0]?.length}` : 'BRAK');
  console.log('📊 incurredTriangle_bez_inf:', !!incurredTriangle_bez_inf?.length ? `${incurredTriangle_bez_inf.length}x${incurredTriangle_bez_inf[0]?.length}` : 'BRAK');
  console.log('📊 trainDevide (z /calc/paid_incurred/triangles):', !!trainDevide?.length ? `${trainDevide.length}x${trainDevide[0]?.length}` : 'BRAK');
  console.log('📊 hasData:', hasData);
  console.log('📊 isLoading:', isLoading);
  console.log('📊 tableData.length:', tableData.length);
  console.log('📊 coeffHeaderLabels:', coeffHeaderLabels);
  
  // === DEBUG WYNIKÓW ===
  console.log('🎯 === DEBUG WYNIKÓW PaidToIncurred ===');
  console.log('rJ (type, length, first 3):', typeof rJ, rJ?.length, rJ?.slice(0, 3));
  console.log('varJ (type, length, first 3):', typeof varJ, varJ?.length, varJ?.slice(0, 3));
  console.log('lambdaJ (type, value):', typeof lambdaJResult, lambdaJResult);
  console.log('resIJ (type, rows, first row):', typeof resIJResults, resIJResults?.length, resIJResults?.[0]);
  console.log('devJ (type, length, first 3):', typeof devJ, devJ?.length, devJ?.slice(0, 3));
  console.log('sigma (type, length, first 3):', typeof sigma, sigma?.length, sigma?.slice(0, 3));
  console.log('sd (type, length, first 3):', typeof sd, sd?.length, sd?.slice(0, 3));
  console.log('🎯 === KONIEC DEBUG WYNIKÓW ===');
  
  // === WYŚWIETL TABELĘ W KONSOLI ===
  if (tableData.length > 0) {
    console.log('📋 === TABELA WSPÓŁCZYNNIKÓW PAID TO INCURRED ===');
    tableData.forEach((row, index) => {
      if (index === 0) {
        console.log(`NAGŁÓWEK:`, row);
      } else {
        console.log(`Wiersz ${index - 1}:`, row);
      }
    });
    console.log('📋 === KONIEC TABELI ===');
  } else {
    console.log('❌ Tabela jest pusta');
  }
  
  // === WYŚWIETL WYNIKI ===
  if (resultRows.some(r => r.visible)) {
    console.log('🎯 === WYNIKI OBLICZEŃ ===');
    resultRows.forEach(row => {
      if (row.visible) {
        console.log(`${row.label}:`, row.values);
      }
    });
    console.log('🎯 === KONIEC WYNIKÓW ===');
  } else {
    console.log('❌ Brak wyników do wyświetlenia');
  }
  
  console.log('🔍 === END DEBUG ===');

  // Utwórz sidebar osobno, żeby uniknąć problemów z TypeScript
  const sidebarElement = (
    <SidebarPanelPaidToIncurred
      onCalculate={runSigma}
      className="w-64 shrink-0"
    />
  );

  return (
    <CalculationPageLayout
      title="Tabela współczynników PaidToIncurred"
      loadingMessage={`⏳ Oczekiwanie na dane wejściowe paid i incurred…`}
      noDataMessage="Brak danych paid/incurred 😢"
      
      // Table data
      tableData={tableData}
      headerLabels={coeffHeaderLabels}
      rowLabels={incurredRowLabels}
      hasData={hasData}
      
      // Table interactions
      weights={weights}
      selectedCells={selectedCells}
      minMaxCells={minMaxCells}
      minCells={minCells}
      maxCells={maxCells}
      minMaxHighlighting={minMaxHighlighting}
      showRowToggle={true}
      onToggleRow={toggleRowDet}
      onToggleWeightCell={toggleWeightCellDet}
      
      // Results
      resultRows={resultRows}
      resultsTitle="Wyniki obliczeń PaidToIncurred"
      decimalPlaces={decimalPlaces}
      
      // Fullscreen
      fullscreenMode={fullscreenMode}
      isClosing={isClosing}
      onCloseFullscreen={handleCloseFullscreen}
      
      // Scale
      tableScale={tableScale}
      onIncreaseScale={increaseScale}
      onDecreaseScale={decreaseScale}
      
      // Volume and calculate (hidden in UI but required by layout)
      volume={volume}
      onVolumeChange={setVolume}
      onCalculate={runSigma}
      calculateLabel="Oblicz PaidToIncurred"
      
      // Sidebar
      sidebar={sidebarElement}
    />
  );
}