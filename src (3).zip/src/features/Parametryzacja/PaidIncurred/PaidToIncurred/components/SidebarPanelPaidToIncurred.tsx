'use client';

import { useState } from 'react';
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred';
import { useDisplaySettingsStore } from '@/stores/useDisplaySettingsStore';
import Modal from '@/components/Modal';
import { Button } from '@/components/ui/button';
import { Maximize2, Plus, Minus } from 'lucide-react';

type Props = {
  onCalculate: () => void;
  className?: string;
};

export default function SidebarPanelPaidToIncurred({ onCalculate, className }: Props) {
  const store = useTrainDevideStoreIncurred();
  const [resetOpen, setResetOpen] = useState(false);

  // Display settings for fullscreen and scale
  const fullscreenMode = useDisplaySettingsStore((s) => s.fullscreenMode);
  const tableScale = useDisplaySettingsStore((s) => s.tableScale);
  const setFullscreenMode = useDisplaySettingsStore((s) => s.setFullscreenMode);
  const increaseScale = useDisplaySettingsStore((s) => s.increaseScale);
  const decreaseScale = useDisplaySettingsStore((s) => s.decreaseScale);

  const {
    trainPaidToIncurred,
    selectedWeightsPaidToIncurred,
    devJPaidToIncurred,
    sigmaPaidToIncurred,
    sdPaidToIncurred,
    minMaxHighlightingPaidToIncurred,
    setMinMaxHighlightingPaidToIncurred,
    resetSelectionPaidToIncurred,
    decimalPlaces = 6,
    setDecimalPlaces,
  } = store;

  const [isMissingDataModalOpen, setIsMissingDataModalOpen] = useState(false);
  
  const openMissingDataModal = () => setIsMissingDataModalOpen(true);
  const closeMissingDataModal = () => setIsMissingDataModalOpen(false);

  const handleExport = () => {
    if (!devJPaidToIncurred?.length) {
      openMissingDataModal();
      return;
    }
    
    // TODO: Implementuj eksport dla PaidToIncurred
    console.log('Export PaidToIncurred data:', {
      devJ: devJPaidToIncurred,
      sigma: sigmaPaidToIncurred,
      sd: sdPaidToIncurred
    });
  };

  const handleReset = () => {
    // Reset selection in table
    resetSelectionPaidToIncurred();
    
    // TODO: Dodaj clearowanie wyników PaidToIncurred jeśli będzie potrzebne
    console.log('Reset PaidToIncurred selection');
  };

  const toggleMinMax = () => {
    setMinMaxHighlightingPaidToIncurred(!minMaxHighlightingPaidToIncurred);
  };

  // Komponent kontrolek rozmiaru
  const ScaleControls = () => (
    <div className="flex items-center gap-2">
      <Button
        onClick={decreaseScale}
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
        disabled={tableScale <= 0.5}
      >
        <Minus className="w-4 h-4" />
      </Button>
      
      <span className="text-white text-sm min-w-[3rem] text-center">
        {Math.round(tableScale * 100)}%
      </span>
      
      <Button
        onClick={increaseScale}
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
        disabled={tableScale >= 2.0}
      >
        <Plus className="w-4 h-4" />
      </Button>
    </div>
  );

  return (
    <div className={`w-64 shrink-0 space-y-4 ${className ?? ''}`}>
      {/* Kontrolka zaokrąglania - na górze */}
      <div className="bg-gray-800 rounded-lg p-4">
        <label className="text-white text-sm font-medium mb-2 block">
          Miejsca po przecinku
        </label>
        <input
          type="number"
          min="0"
          max="10"
          value={decimalPlaces}
          onChange={(e) => setDecimalPlaces?.(Number(e.target.value))}
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
        <div className="text-xs text-gray-400 mt-1">
          Współczynniki będą zaokrąglone do {decimalPlaces} miejsc
        </div>
      </div>

      {/* Przyciski akcji */}
      <div className="space-y-3">
        <button
          onClick={onCalculate}
          className="w-full py-3 px-4 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors"
          disabled={!trainPaidToIncurred}
        >
          Oblicz PaidToIncurred
        </button>

        <button
          onClick={handleExport}
          className="w-full py-3 px-4 bg-amber-500 text-white rounded-lg font-medium hover:bg-amber-600 transition-colors"
          disabled={!devJPaidToIncurred}
        >
          Eksportuj do Excela
        </button>

        <button
          onClick={() => setResetOpen(true)}
          className="w-full py-3 px-4 bg-rose-500 text-white rounded-lg font-medium hover:bg-rose-600 transition-colors"
        >
          Reset zaznaczenia
        </button>
      </div>

      {/* Min/Max Button */}
      <button
        onClick={toggleMinMax}
        className={`w-full py-3 px-4 rounded-lg font-medium transition-colors ${
          minMaxHighlightingPaidToIncurred
            ? 'bg-yellow-600 hover:bg-yellow-700 text-white'
            : 'bg-gray-600 hover:bg-gray-700 text-white'
        }`}
      >
        {minMaxHighlightingPaidToIncurred ? '🔍 Ukryj Min/Max' : '🔍 Pokaż Min/Max'}
      </button>

      {/* Ustawienia wyświetlania */}
      <div className="bg-gray-800 rounded-lg p-4">
        <div className="text-white text-lg font-medium mb-4">
          Ustawienia wyświetlania
        </div>
        
        <div className="space-y-4">
          <div>
            <label className="text-white text-sm font-medium mb-2 block">
              Rozmiar tabeli
            </label>
            <ScaleControls />
          </div>
          
          <Button
            onClick={() => setFullscreenMode(true)}
            variant="destructive"
            size="sm"
            className="w-full"
          >
            <Maximize2 className="w-4 h-4 mr-2" />
            Pełny ekran
          </Button>
        </div>
      </div>

      {/* Modals */}
      <Modal
        isOpen={resetOpen}
        title="Reset zaznaczenia"
        message="Czy na pewno chcesz zresetować zaznaczenie komórek w tabeli? Wszystkie komórki zostaną zaznaczone."
        onCancel={() => setResetOpen(false)}
        onConfirm={() => {
          handleReset();
          setResetOpen(false);
        }}
      />

      <Modal
        isOpen={isMissingDataModalOpen}
        title="Brak danych do eksportu"
        message="Najpierw oblicz współczynniki PaidToIncurred."
        onConfirm={closeMissingDataModal}
        onlyOk
      />
    </div>
  );
}