/* ---------------------------------------------------------------------- */
/*     src/features/Parametryzacja/PaidIncurred/FitCurve/FitCurveRJPaidToIncurred.tsx     */
/* ---------------------------------------------------------------------- */
"use client";

import React, { useEffect } from "react";
import { 
  FitCurvePageLayout, 
  useFitCurveData,
  R_J_PAID_TO_INCURRED_CONFIG,
  R_J_PAID_TO_INCURRED_STORE_MAPPING
} from "@/shared";

/* ------------------------------------------------------------------ */
/*                              KONTENER                              */
/* ------------------------------------------------------------------ */
import { useTrainDevideStoreIncurred } from "@/stores/useTrainDevideStoreIncurred";

export default function FitCurveRJPaidToIncurred() {
  const { 
    rJPaidToIncurred, 
    simResultsRJPaidToIncurred, 
    setSimResultsRJPaidToIncurred,
    clearPaidToIncurredFitCurveData 
  } = useTrainDevideStoreIncurred();
  
  const fitCurveProps = useFitCurveData({
    config: R_J_PAID_TO_INCURRED_CONFIG,
    storeMapping: R_J_PAID_TO_INCURRED_STORE_MAPPING,
    useStore: useTrainDevideStoreIncurred
  });

  // Debug: sprawdź stan danych preview vs currentVector
  console.log('🔍 [FitCurveRJPaidToIncurred] Current data state:', {
    preview: fitCurveProps.data.preview?.length || 0,
    previewData: fitCurveProps.data.preview,
    currentVector: fitCurveProps.currentVector?.length || 0,
    currentVectorData: fitCurveProps.currentVector,
    disableAutoLoading: R_J_PAID_TO_INCURRED_CONFIG.disableAutoLoading,
    areEqual: JSON.stringify(fitCurveProps.data.preview) === JSON.stringify(fitCurveProps.currentVector)
  });

  // Usunięto automatyczne czyszczenie - dane zachowują się między zakładkami r_j/var_j
  // Czyszczenie nastąpi tylko gdy użytkownik opuści całą sekcję PaidIncurred

  return (
    <FitCurvePageLayout
      config={R_J_PAID_TO_INCURRED_CONFIG}
      {...fitCurveProps}
    />
  );
}