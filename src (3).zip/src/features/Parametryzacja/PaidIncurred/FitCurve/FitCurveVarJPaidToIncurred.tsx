/* ---------------------------------------------------------------------- */
/*     src/features/Parametryzacja/PaidIncurred/FitCurve/FitCurveVarJPaidToIncurred.tsx     */
/* ---------------------------------------------------------------------- */
"use client";

import React, { useEffect, useRef } from "react";
import { useTrainDevideStoreIncurred } from "@/stores/useTrainDevideStoreIncurred";
import { 
  FitCurvePageLayout, 
  useFitCurveData,
  VAR_J_PAID_TO_INCURRED_CONFIG,
  VAR_J_PAID_TO_INCURRED_STORE_MAPPING
} from "@/shared";

/* ------------------------------------------------------------------ */
/*                              KONTENER                              */
/* ------------------------------------------------------------------ */

export default function FitCurveVarJPaidToIncurred() {
  // Flaga śledząca czy użytkownik już ręcznie modyfikował selekcję
  const hasUserInteractedRef = useRef(false);
  
  // Dla synchronizacji tailCount między r_j i var_j
  const {
    tailCountRJPaidToIncurred,
    tailCountVarJPaidToIncurred,
    setTailCountVarJPaidToIncurred,
    rJPaidToIncurred,
    varJPaidToIncurred,
    clearPaidToIncurredFitCurveData
  } = useTrainDevideStoreIncurred();

  const fitCurveProps = useFitCurveData({
    config: VAR_J_PAID_TO_INCURRED_CONFIG,
    storeMapping: VAR_J_PAID_TO_INCURRED_STORE_MAPPING,
    useStore: useTrainDevideStoreIncurred
  });

  // Wykrywanie ręcznej interakcji użytkownika z selekcją
  const originalSetSelectedIndexes = fitCurveProps.actions.setSelectedIndexes;
  const wrappedSetSelectedIndexes = React.useCallback((indexes: number[]) => {
    hasUserInteractedRef.current = true;
    originalSetSelectedIndexes(indexes);
  }, [originalSetSelectedIndexes]);

  // Nadpisanie akcji setSelectedIndexes w fitCurveProps
  const enhancedFitCurveProps = {
    ...fitCurveProps,
    actions: {
      ...fitCurveProps.actions,
      setSelectedIndexes: wrappedSetSelectedIndexes
    }
  };

  // Usunięto automatyczne czyszczenie - dane zachowują się między zakładkami r_j/var_j
  // Czyszczenie nastąpi tylko gdy użytkownik opuści całą sekcję PaidIncurred

  // Debug logging
  console.log('🔍 FitCurveVarJPaidToIncurred debug:', {
    tailCountRJPaidToIncurred,
    tailCountVarJPaidToIncurred,
    rJPaidToIncurred,
    varJPaidToIncurred,
    fitCurvePropsData: fitCurveProps.data,
    preview: fitCurveProps.data.preview?.length || 0,
    selectedIndexes: fitCurveProps.data.selectedIndexes,
    thresholdValue: VAR_J_PAID_TO_INCURRED_CONFIG.thresholdValue
  });

  // Synchronizacja tailCountVarJPaidToIncurred z tailCountRJPaidToIncurred
  useEffect(() => {
    if (tailCountRJPaidToIncurred !== undefined && tailCountRJPaidToIncurred !== tailCountVarJPaidToIncurred) {
      console.log('🔄 Synchronizing tailCountVarJPaidToIncurred with tailCountRJPaidToIncurred:', tailCountRJPaidToIncurred);
      setTailCountVarJPaidToIncurred(tailCountRJPaidToIncurred);
      // Reset flagi przy zmianie danych - pozwoli to na nowe automatyczne zaznaczenie
      hasUserInteractedRef.current = false;
    }
  }, [tailCountRJPaidToIncurred, tailCountVarJPaidToIncurred, setTailCountVarJPaidToIncurred]);

  // Automatyczne zaznaczanie wartości > 0 gdy dane są dostępne (tylko przy pierwszym ładowaniu)
  useEffect(() => {
    // Tylko gdy użytkownik jeszcze nie interagował z selekcją
    if (!hasUserInteractedRef.current && fitCurveProps.data.preview?.length && fitCurveProps.currentVector?.length) {
      // Oblicz które indeksy powinny być zaznaczone (wartości > 0)
      const expectedSelected = fitCurveProps.data.preview
        .map((v, i) => (v > VAR_J_PAID_TO_INCURRED_CONFIG.thresholdValue ? i : -1))
        .filter((i) => i >= 0);
      
      // Sprawdź czy aktualnie zaznaczone indeksy są prawidłowe
      const currentSelected = fitCurveProps.data.selectedIndexes;
      const shouldUpdate = 
        expectedSelected.length > 0 && currentSelected.length === 0;
      
      if (shouldUpdate) {
        console.log('🎯 [FitCurveVarJPaidToIncurred] Auto-selecting initial values > 0 for VarJ...');
        console.log('📊 Expected vs Current:', { expected: expectedSelected, current: currentSelected });
        console.log('✅ [FitCurveVarJPaidToIncurred] Setting auto-selected indexes:', expectedSelected);
        // Używamy oryginalnej funkcji, żeby nie oznaczyć jako ręczną interakcję
        fitCurveProps.actions.setSelectedIndexes(expectedSelected);
      }
    }
  }, [
    fitCurveProps.data.preview, 
    fitCurveProps.data.selectedIndexes, 
    fitCurveProps.currentVector,
    fitCurveProps.actions.setSelectedIndexes
  ]);

  return (
    <FitCurvePageLayout
      config={VAR_J_PAID_TO_INCURRED_CONFIG}
      {...enhancedFitCurveProps}
    />
  );
}