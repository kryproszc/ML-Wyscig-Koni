// features/Parametryzacja/Test/TestTab.tsx
'use client';

import { useState, useEffect } from 'react';
import { useTrainDevideStoreDet } from '../../../stores/trainDevideStoreDeterministyczny';
import { useUserStore } from '../../../app/_components/useUserStore';
import { useParamsymStore } from '../../../stores/paramsymStore';
import { useDiscountRatesStore } from '../../../stores/discountRatesStore';
import { useExposureStore } from '../../../stores/exposureStore';
import { useAddPaidStore } from '../../../stores/addPaidStore';
import { useAddCoefficientsStore } from '../../../stores/addCoefficientsStore';
import { useAddSimulationStore } from '../../../stores/addSimulationStore';
import { useCLSimulationStore } from '../../../stores/clSimulationStore';
import { useSimulationResultsStore } from '../../../stores/simulationResultsStore';
import { useChainLadderResultsStore } from '../../../stores/chainLadderResultsStore';
import { useAddPaidResultsStore } from '../../../stores/addPaidResultsStore';
import { CustomAlertDialog } from '@/components/CustomAlertDialog';
import { useCombinedSDSummary } from '../MultPaid/hooks/useCombinedSDSummary';
import { useSelectedValuesSD } from '../MultPaid/hooks/useSelectedValuesSD';

import {
  prepareSelectedValueCL,
  prepareSelectedValueSigma,
  prepareCombinedSDSummary,
  processNetBruttoParams,
  processDiscountRates,
  parseQuantiles,
  checkDataAvailability,
  getCalculationOptions,
  validateVectorLengths
} from '../../../shared/utils';

interface AlertState {
  show: boolean;
  variant: 'success' | 'error' | 'warning';
  title: string;
  message: string;
}

interface TestData {
  chainLadderData: any;
  addPaidData: any;
  simulationResults: {
    clResults: any;
    addResults: any;
  };
  deterministicResults: {
    clDeterministic: any;
    addDeterministic: any;
  };
}

export function TestTab() {
  const [alertState, setAlertState] = useState<AlertState>({
    show: false,
    variant: 'success',
    title: '',
    message: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  // Funkcja wymuszenia odświeżenia danych
  const refreshData = () => {
    console.log('🔄 Odświeżam dane ze store\'ów...');
    setRefreshKey(prev => prev + 1);
  };

  // Automatyczne odświeżenie co 1 sekundę (opcjonalnie)
  useEffect(() => {
    const interval = setInterval(() => {
      setRefreshKey(prev => prev + 1);
    }, 1000);
    
    return () => clearInterval(interval);
  }, []);

  // Stores dla Chain Ladder - ŚWIEŻE DANE
  const trainDevideStoreState = useTrainDevideStoreDet();
  const {
    paidTriangle,
    selectedDevJIndexes,
    selectedSigmaIndexes,
    leftCountCL,
    combinedDevJSummary,
    combinedSigmaSummary,
    devJ,
    safeWeights,
    tailCountCL,
    selectedValuesCL,
    selectedValuesSigma,
    sd
  } = trainDevideStoreState;

  const { simulationParams: clSimulationParams, kwantyle: clKwantyle } = useCLSimulationStore();
  const { results: clSimulationResults } = useSimulationResultsStore();
  const { results: clDeterministicResults } = useChainLadderResultsStore();

  // Stores dla AddPaid - DOKŁADNIE JAK W ORYGINALE
  const { exposureTriangle, selectedExposureLine } = useExposureStore();
  const { 
    selectedValuesAddLR,
    selectedValuesAddSigma,
    selectedValuesAddSD, // ✅ DODANE: SD values
    combinedAddSDSummary,
    selectedAddJIndexes,
    leftCountAddLR,
    tailCountAddJ
  } = useAddPaidStore();
  const { selectedWeightsAdd, trainDevideAdd } = useAddCoefficientsStore();

  // Common stores
  const userId = useUserStore((s: any) => s.userId);
  const getParamsymTriangle = useParamsymStore((s) => s.paramsymTriangle);
  const getSelectedParamsymLine = useParamsymStore((s) => s.selectedParamsymLine);
  const getDiscountRatesTriangle = useDiscountRatesStore((s) => s.discountRatesTriangle);
  const getSelectedDiscountRateLine = useDiscountRatesStore((s) => s.selectedDiscountRateLine);

  // Hooks dla SD - DOKŁADNIE JAK W ClSimulationPaid
  const { combinedSDSummary, getAsNumbers: getSDAsNumbers, hasData: hasSDData } = useCombinedSDSummary();
  const { getAsNumbers: getSelectedValuesSDAsNumbers, hasData: hasSelectedValuesSD } = useSelectedValuesSD();

  // Dodaj pozostałe stores na końcu
  const { 
    simulationParams: addSimulationParams, 
    kwantyle: addKwantyle,
    simulationResults: addSimulationResults
  } = useAddSimulationStore();
  const { results: addDeterministicResults } = useAddPaidResultsStore();

  const showAlert = (alert: AlertState) => {
    setAlertState(alert);
  };

  const hideAlert = () => {
    setAlertState(prev => ({ ...prev, show: false }));
  };

  // Przygotowanie danych Exposure dla AddPaid
  const prepareExposureValues = (): number[] => {
    if (!exposureTriangle || selectedExposureLine === null) {
      return [];
    }

    const selectedLine = exposureTriangle[selectedExposureLine];
    if (!selectedLine) {
      return [];
    }

    return Object.values(selectedLine).map(val => 
      typeof val === 'number' ? val : 0
    );
  };

  // Przygotowanie danych Chain Ladder - DOKŁADNIE JAK W ORYGINALE + ŚWIEŻE DANE
  const prepareChainLadderData = () => {
    console.log('🔄 Przygotowuję Chain Ladder Data - pobieranie świeżych danych...');
    
    // 🔥 POBIERZ NAJŚWIEŻSZE DANE ZE STORE - tak jak w oryginale
    const freshState = useTrainDevideStoreDet.getState();
    console.log('🔍 Fresh State Train Devide:', {
      selectedValuesCL: freshState.selectedValuesCL?.length,
      selectedValuesSigma: freshState.selectedValuesSigma?.length,
      safeWeights: freshState.safeWeights?.length,
      combinedSDSummary: freshState.combinedSDSummary?.length
    });
    
    const dataAvailability = checkDataAvailability(
      freshState.paidTriangle || [],
      getDiscountRatesTriangle,
      getParamsymTriangle
    );

    const calculationOptions = getCalculationOptions(dataAvailability);
    
    // Przygotuj wagi - dokładnie jak w ClSimulationPaid
    let calculatedSafeWeights: number[][];
    if (freshState.safeWeights && freshState.safeWeights.length > 0) {
      calculatedSafeWeights = freshState.safeWeights;
    } else {
      calculatedSafeWeights = freshState.selectedWeightsDet?.map((r) => r.map((c) => (c === 1 ? 1 : 0))) ?? [];
    }

    // Przygotuj wektory z fallbackami - dokładnie jak w oryginale
    const vectorSelectedValueCL = prepareSelectedValueCL(
      freshState.selectedValuesCL,
      freshState.combinedDevJSummary,
      freshState.devJ || []
    );

    const vectorSelectedValueSigma = prepareSelectedValueSigma(
      freshState.selectedValuesSigma,
      freshState.combinedSigmaSummary,
      freshState.sigma || []
    );

    const vectorCombinedSDSummary = prepareCombinedSDSummary(
      (() => {
        try {
          return hasSelectedValuesSD ? getSelectedValuesSDAsNumbers() : [];
        } catch (e) {
          console.warn('Błąd getSelectedValuesSDAsNumbers:', e);
          return [];
        }
      })(),
      freshState.combinedSDSummary || [],
      freshState.sd || []
    );

    const processedNetBrutto = processNetBruttoParams(
      getParamsymTriangle,
      getSelectedParamsymLine
    );

    const processedDiscountRates = processDiscountRates(
      getDiscountRatesTriangle,
      getSelectedDiscountRateLine
    );

    // DOKŁADNY REQUEST DATA JAK W ClSimulationPaid
    const requestData = {
      user_id: userId,
      paid_triangle: freshState.paidTriangle || [],
      weights: calculatedSafeWeights,
      cl_indexes: freshState.selectedDevJIndexes || [],
      sigma_indexes: freshState.selectedSigmaIndexes || [],
      left_count_cl: freshState.leftCountCL || 0,
      selected_value_cl: vectorSelectedValueCL,
      selected_value_sigma: vectorSelectedValueSigma,
      combined_sd_summary: vectorCombinedSDSummary,
      tail_count_cl: freshState.tailCountCL === "" || freshState.tailCountCL === null || freshState.tailCountCL === undefined 
        ? null 
        : Number(freshState.tailCountCL),
      calculation_options: calculationOptions,
      discount_rates: processedDiscountRates,
      netto_brutto: processedNetBrutto,
      ilosc_symulacji: clSimulationParams.iloscSymulacji,
      ziarno: clSimulationParams.ziarno,
      podzial_ziarna: clSimulationParams.podzialZiarna,
      skalowanie: clSimulationParams.skalowanie,
      kwantyle: parseQuantiles(clKwantyle)
    };
    
    console.log('✅ Chain Ladder Request Data przygotowane:', requestData);
    return requestData;
  };

  // Przygotowanie danych AddPaid - DOKŁADNIE JAK W ORYGINALE + ŚWIEŻE DANE
  const prepareAddPaidData = () => {
    console.log('🔄 Przygotowuję AddPaid Data - pobieranie świeżych danych...');
    
    // 🔥 POBIERZ NAJŚWIEŻSZE DANE ZE STORE AddPaid
    const freshAddPaidState = useAddPaidStore.getState();
    const freshAddCoefficientsState = useAddCoefficientsStore.getState();
    const freshExposureState = useExposureStore.getState();
    const freshTrainDevideState = useTrainDevideStoreDet.getState();
    
    console.log('🔍 Fresh AddPaid State:', {
      selectedValuesAddLR: freshAddPaidState.selectedValuesAddLR?.length,
      selectedValuesAddSigma: freshAddPaidState.selectedValuesAddSigma?.length,
      selectedValuesAddSD: freshAddPaidState.selectedValuesAddSD?.length,
      selectedAddJIndexes: freshAddPaidState.selectedAddJIndexes?.length,
      selectedWeightsAdd: freshAddCoefficientsState.selectedWeightsAdd?.length
    });
    
    const dataAvailability = checkDataAvailability(
      freshTrainDevideState.paidTriangle || [],
      getDiscountRatesTriangle,
      getParamsymTriangle
    );

    const calculationOptions = getCalculationOptions(dataAvailability);

    // Exposure values z fresh state
    const exposureValues = (() => {
      if (!freshExposureState.exposureTriangle || freshExposureState.selectedExposureLine === null) {
        return [];
      }
      const selectedLine = freshExposureState.exposureTriangle[freshExposureState.selectedExposureLine];
      if (!selectedLine) return [];
      return Object.values(selectedLine).map(val => typeof val === 'number' ? val : 0);
    })();

    // 🔥 Przygotuj safeWeights - IDENTYCZNIE JAK W COEFFICIENTS (z AddSimulationPaid)
    const safeWeights = freshAddCoefficientsState.selectedWeightsAdd?.map((weightRow, rowIndex) => 
      weightRow.map((weight, colIndex) => {
        const trainValue = freshAddCoefficientsState.trainDevideAdd?.[rowIndex]?.[colIndex];
        // Jeśli w train_devide_add jest null/undefined - waga = 0
        if (trainValue === null || trainValue === undefined) {
          return 0;
        }
        // W przeciwnym razie używaj wagi z zaznaczenia
        return weight === 1 ? 1 : 0;
      })
    ) ?? [];

    // Przygotuj wektory dla AddPaid - dokładnie jak w oryginale z fresh data
    const vectorSelectedValueSigma = prepareSelectedValueSigma(
      freshAddPaidState.selectedValuesAddSigma,
      freshAddPaidState.combinedAddSDSummary,
      freshAddPaidState.selectedValuesAddSigma // fallback na siebie
    );

    const vectorCombinedSDSummary = prepareCombinedSDSummary(
      freshAddPaidState.selectedValuesAddSD,    // ✅ POPRAWKA: SD values, nie Sigma!
      freshAddPaidState.combinedAddSDSummary,   // fallback: mixed format
      freshAddPaidState.selectedValuesAddSD     // fallback 2: SD values again
    );

    const processedNetBrutto = processNetBruttoParams(
      getParamsymTriangle,
      getSelectedParamsymLine
    );

    const processedDiscountRates = processDiscountRates(
      getDiscountRatesTriangle,
      getSelectedDiscountRateLine
    );

    // DOKŁADNY REQUEST DATA JAK W AddSimulationPaid
    const requestData = {
      user_id: userId,
      paid_triangle: freshTrainDevideState.paidTriangle || [],
      weights: safeWeights, // ✅ UŻYWAMY SAFEWEIGHTS - tak jak w coefficients!
      lr_indexes: freshAddPaidState.selectedAddJIndexes || [],           // LR indexes zamiast CL
      sigma_indexes: freshAddPaidState.selectedAddJIndexes || [],         // Używamy tych samych indeksów
      left_count_lr: freshAddPaidState.leftCountAddLR || 0,              // LR count zamiast CL
      selected_value_lr: freshAddPaidState.selectedValuesAddLR,          // LR values zamiast CL
      selected_value_sigma: vectorSelectedValueSigma, // ✅ UŻYWAMY PRZYGOTOWANEGO
      combined_sd_summary: vectorCombinedSDSummary,   // ✅ UŻYWAMY PRZYGOTOWANEGO (NUMERIC!)
      tail_count_lr: freshAddPaidState.tailCountAddJ || null,           // LR tail count
      e_values: exposureValues,                        // NOWE: exposure values
      calculation_options: calculationOptions,
      discount_rates: processedDiscountRates,
      netto_brutto: processedNetBrutto,
      ilosc_symulacji: addSimulationParams.iloscSymulacji,
      ziarno: addSimulationParams.ziarno,
      podzial_ziarna: addSimulationParams.podzialZiarna,
      skalowanie: addSimulationParams.skalowanie,
      skalowanie2: addSimulationParams.skalowanie2,    // 🆕 DODANE: drugie skalowanie
      kwantyle: parseQuantiles(addKwantyle)
    };
    
    console.log('✅ AddPaid Request Data przygotowane:', requestData);
    return requestData;
  };

  // Główna funkcja wysyłania danych
  const handleSendData = async () => {
    if (!userId) {
      showAlert({
        show: true,
        variant: 'error',
        title: 'Błąd użytkownika',
        message: 'Brak identyfikatora użytkownika'
      });
      return;
    }

    setIsLoading(true);

    try {
      // Przygotuj wszystkie dane
      const chainLadderData = prepareChainLadderData();
      const addPaidData = prepareAddPaidData();

      // Przygotuj dane w formacie dla backendu
      const testData = {
        // WSPÓLNE DANE
        user_id: userId,
        paid_triangle: chainLadderData.paid_triangle,
        calculation_options: chainLadderData.calculation_options,
        discount_rates: chainLadderData.discount_rates,
        netto_brutto: chainLadderData.netto_brutto,
        
        // CHAIN LADDER DANE
        cl_weights: chainLadderData.weights,
        cl_indexes: chainLadderData.cl_indexes,
        cl_sigma_indexes: chainLadderData.sigma_indexes,
        cl_left_count: chainLadderData.left_count_cl,
        cl_tail_count: chainLadderData.tail_count_cl,
        cl_selected_value_cl: chainLadderData.selected_value_cl,
        cl_selected_value_sigma: chainLadderData.selected_value_sigma,
        cl_combined_sd_summary: chainLadderData.combined_sd_summary,
        cl_ilosc_symulacji: chainLadderData.ilosc_symulacji,
        cl_ziarno: chainLadderData.ziarno,
        cl_podzial_ziarna: chainLadderData.podzial_ziarna,
        cl_skalowanie: chainLadderData.skalowanie,
        cl_kwantyle: chainLadderData.kwantyle,
        
        // ADDPAID DANE
        add_weights: addPaidData.weights,
        add_lr_indexes: addPaidData.lr_indexes,
        add_sigma_indexes: addPaidData.sigma_indexes,
        add_left_count_lr: addPaidData.left_count_lr,
        add_tail_count_lr: addPaidData.tail_count_lr,
        add_selected_value_lr: addPaidData.selected_value_lr,
        add_selected_value_sigma: addPaidData.selected_value_sigma,
        add_combined_sd_summary: addPaidData.combined_sd_summary,
        add_e_values: addPaidData.e_values,
        add_ilosc_symulacji: addPaidData.ilosc_symulacji,
        add_ziarno: addPaidData.ziarno,
        add_podzial_ziarna: addPaidData.podzial_ziarna,
        add_skalowanie: addPaidData.skalowanie,
        add_skalowanie2: addPaidData.skalowanie2,
        add_kwantyle: addPaidData.kwantyle,
        
        // WYNIKI (opcjonalne)
        cl_simulation_results: clSimulationResults ? {
          last_col: clSimulationResults.last_col || [],
          cum_trian: clSimulationResults.cum_trian || [],
          ult_net_disc: clSimulationResults.ult_net_disc || []
        } : null,
        add_simulation_results: addSimulationResults ? {
          last_col: addSimulationResults.last_col || [],
          cum_trian: addSimulationResults.cum_trian || [],
          ult_net_disc: addSimulationResults.ult_net_disc || []
        } : null,
        cl_deterministic_results: clDeterministicResults ? {
          cum_trian: clDeterministicResults.cum_trian,
          last_col: clDeterministicResults.last_col,
          ult_net_disc: clDeterministicResults.ult_net_disc,
          userId: clDeterministicResults.userId,
          calculatedAt: clDeterministicResults.calculatedAt
        } : null,
        add_deterministic_results: addDeterministicResults ? {
          cum_trian: addDeterministicResults.cum_trian,
          last_col: addDeterministicResults.last_col,
          ult_net_disc: addDeterministicResults.ult_net_disc,
          userId: addDeterministicResults.userId,
          calculatedAt: addDeterministicResults.calculatedAt
        } : null
      };

      console.log('🎯 Wysyłam dane na backend:', testData);

      // WYSYŁANIE NA BACKEND
      const response = await fetch('http://localhost:8000/test/all-data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(testData)
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      console.log('✅ Odpowiedź z backendu:', result);

      showAlert({
        show: true,
        variant: 'success',
        title: 'Dane wysłane!',
        message: `Wszystkie dane zostały wysłane na backend. Status: ${result.status}`
      });

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Nieznany błąd';
      console.error('❌ Błąd podczas wysyłania danych:', error);
      showAlert({
        show: true,
        variant: 'error',
        title: 'Błąd wysyłania',
        message: `Wystąpił błąd podczas wysyłania danych na backend: ${errorMessage}`
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-6 bg-[#0f172a] min-h-screen text-white">
      <div className="max-w-4xl mx-auto">
        <div className="bg-gradient-to-r from-[#1e293b] to-[#334155] p-8 rounded-xl shadow-2xl">
          <h1 className="text-3xl font-bold mb-6 text-center bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
            🧪 Test - Wysyłanie Danych
          </h1>
          
          <div className="bg-[#0f172a] p-6 rounded-lg mb-6 border border-slate-600">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold text-blue-400">📊 Status Danych</h2>
              <button
                onClick={refreshData}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm transition-colors"
              >
                🔄 Odśwież Dane
              </button>
            </div>
            
            <div className="mb-4 text-sm text-gray-400">
              Ostatnie odświeżenie: {refreshKey} | Auto-odświeżanie co 1s
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="bg-slate-800 p-4 rounded-lg">
                <h3 className="font-semibold text-green-400 mb-2">Chain Ladder Request Data</h3>
                <ul className="text-sm space-y-1">
                  <li>✅ Trójkąt Paid: {paidTriangle ? 'Dostępny' : 'Brak'}</li>
                  <li>✅ CL Indexes: {selectedDevJIndexes?.length || 0} indeksów</li>
                  <li>✅ Sigma Indexes: {selectedSigmaIndexes?.length || 0} indeksów</li>
                  <li>✅ Left Count CL: {leftCountCL || 0}</li>
                  <li>✅ Tail Count CL: {tailCountCL || 'null'}</li>
                  <li>✅ Selected Values CL: {selectedValuesCL?.length || 0} wartości</li>
                  <li>✅ Selected Values Sigma: {selectedValuesSigma?.length || 0} wartości</li>
                  <li>✅ SD Summary: {(() => {
                    try {
                      return hasSelectedValuesSD ? (getSelectedValuesSDAsNumbers()?.length || 0) : 0;
                    } catch (e) {
                      return 0;
                    }
                  })()} wartości</li>
                  <li>✅ Wagi (SafeWeights): {safeWeights?.length || 0} wierszy</li>
                  <li>✅ Symulacje: {clSimulationParams.iloscSymulacji}</li>
                  <li>✅ Skalowanie: {clSimulationParams.skalowanie}</li>
                  <li>✅ Kwantyle: {clKwantyle}</li>
                </ul>
              </div>
              
              <div className="bg-slate-800 p-4 rounded-lg">
                <h3 className="font-semibold text-purple-400 mb-2">AddPaid Request Data</h3>
                <ul className="text-sm space-y-1">
                  <li>✅ Trójkąt Paid: {paidTriangle ? 'Dostępny' : 'Brak'}</li>
                  <li>✅ Exposure: {exposureTriangle ? 'Dostępny' : 'Brak'}</li>
                  <li>✅ LR Indexes: {selectedAddJIndexes?.length || 0} indeksów</li>
                  <li>✅ Left Count LR: {leftCountAddLR || 0}</li>
                  <li>✅ Tail Count LR: {tailCountAddJ || 'null'}</li>
                  <li>✅ Selected Values LR: {selectedValuesAddLR?.length || 0} wartości</li>
                  <li>✅ Selected Values Sigma: {selectedValuesAddSigma?.length || 0} wartości</li>
                  <li>✅ Selected Values SD: {selectedValuesAddSD?.length || 0} wartości</li>
                  <li>✅ Combined SD Summary: {combinedAddSDSummary?.length || 0} wartości</li>
                  <li>✅ Wagi Add: {selectedWeightsAdd?.length || 0} wierszy</li>
                  <li>✅ Symulacje: {addSimulationParams.iloscSymulacji}</li>
                  <li>✅ Skalowanie: {addSimulationParams.skalowanie}</li>
                  <li>✅ Skalowanie2: {addSimulationParams.skalowanie2}</li>
                  <li>✅ Kwantyle: {addKwantyle}</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="text-center">
            <button
              onClick={handleSendData}
              disabled={isLoading || !userId}
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 
                         disabled:from-gray-500 disabled:to-gray-600 disabled:cursor-not-allowed
                         text-white font-bold py-4 px-8 rounded-lg transition-all duration-200 
                         shadow-lg hover:shadow-xl transform hover:scale-105 text-lg"
            >
              {isLoading ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Wysyłanie...
                </span>
              ) : (
                '🚀 Wyślij Wszystkie Dane'
              )}
            </button>
            
            <p className="text-gray-400 text-sm mt-4">
              Kliknij przycisk aby wysłać wszystkie dane z Chain Ladder i AddPaid.<br/>
              Wyniki będą wyświetlone w konsoli przeglądarki.
            </p>
          </div>
        </div>
      </div>

      {/* Modal */}
      <CustomAlertDialog
        open={alertState.show}
        onOpenChange={hideAlert}
        variant={alertState.variant}
        title={alertState.title}
        message={alertState.message}
        buttonText="OK"
      />
    </div>
  );
}