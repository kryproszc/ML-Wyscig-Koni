// src/lib/resetAllStores.ts

import { useTableStore } from "@/stores/tableStore";
import { useTrainDevideStore } from '@/stores/trainDevideStore';
import { useInputSettingsStore } from "@/stores/inputSettingsStore";
import { useCLSimulationStore } from "@/stores/clSimulationStore";
import { useInflacjaStore } from "@/stores/inflacjaStore";
import { useExposureStore } from "@/stores/exposureStore";
import { useParamsymStore } from "@/stores/paramsymStore";
import { useDiscountRatesStore } from "@/stores/discountRatesStore";
import { useTrainDevideStoreDet } from "@/stores/trainDevideStoreDeterministyczny";
import { useTrainDevideStoreIncurred } from "@/stores/useTrainDevideStoreIncurred";
import { useIncurredTableStore } from "@/stores/useIncurredTableStore";

export function resetAllStores() {
  // Stare store'y
  useTableStore.getState().resetData();
  useTrainDevideStore.getState().reset();
  useInputSettingsStore.getState().reset();
  useCLSimulationStore.getState().resetStore();
  
  // Store'y wprowadzania danych
  useInflacjaStore.getState().resetData();
  useExposureStore.getState().resetData();
  useParamsymStore.getState().resetData();
  useDiscountRatesStore.getState().resetData();
  useTrainDevideStoreDet.getState().resetPaidTriangle();
  
  // Nowe store'y dla danych incurred
  useTrainDevideStoreIncurred.getState().resetIncurredTriangle();
  useIncurredTableStore.getState().resetData();
  
  // Wyczyść localStorage i sessionStorage
  if (typeof window !== 'undefined') {
    // Wyczyść wszystkie klucze związane z aplikacją, ale zachowaj aktualne ustawienia
    const keysToRemove = Object.keys(localStorage).filter(key => 
      key.includes('inflacja') || 
      key.includes('exposure') || 
      key.includes('paramsym') || 
      key.includes('discount') ||
      key.includes('chain-ladder') ||
      // Usuń stare klucze triangle, ale zachowaj aktualne
      (key.includes('triangle') && !key.includes('ca_triangle_type'))
    );
    keysToRemove.forEach(key => localStorage.removeItem(key));
    
    // Wyczyść sessionStorage
    const sessionKeysToRemove = Object.keys(sessionStorage).filter(key => 
      key.includes('inflacja') || 
      key.includes('exposure') || 
      key.includes('paramsym') || 
      key.includes('discount') ||
      key.includes('chain-ladder') ||
      // Usuń stare klucze triangle, ale zachowaj aktualne
      (key.includes('triangle') && !key.includes('ca_triangle_type'))
    );
    sessionKeysToRemove.forEach(key => sessionStorage.removeItem(key));
  }
}
