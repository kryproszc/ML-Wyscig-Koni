// src/utils/dataValidation.ts

/**
 * Opcje konfiguracji walidacji danych
 */
export interface ValidationOptions {
  /** Czy wyświetlać szczegółowe logi w konsoli */
  enableLogging?: boolean;
  /** Czy sprawdzać strukturę trójkąta */
  validateTriangleStructure?: boolean;
  /** Czy sprawdzać puste komórki w środku danych */
  checkEmptyCells?: boolean;
  /** Czy sprawdzać czy wszystkie wartości są numeryczne */
  checkNumericValues?: boolean;
  /** Minimalna liczba wierszy (domyślnie 2) */
  minRows?: number;
  /** Minimalna liczba kolumn w pierwszym wierszu (domyślnie 2) */
  minColumns?: number;
}

/**
 * Wynik walidacji
 */
export interface ValidationResult {
  isValid: boolean;
  reason?: string;
}

/**
 * Uniwersalna funkcja walidacji danych - zawiera wszystkie możliwości
 */
export function validateDataValues(
  data: any[][], 
  options: ValidationOptions = {}
): ValidationResult {
  const {
    enableLogging = false,
    validateTriangleStructure = false,
    checkEmptyCells = true,
    checkNumericValues = true,
    minRows = 2,
    minColumns = 2
  } = options;

  if (enableLogging) {
    console.log("🔍 Sprawdzam dane:", data);
    console.log("⚙️ Opcje walidacji:", options);
  }

  // 1. Podstawowe sprawdzenie formatu
  if (!Array.isArray(data) || data.length < minRows) {
    const reason = `Brak danych lub za mało wierszy (minimum ${minRows})`;
    if (enableLogging) console.warn(`❌ ${reason}`);
    return { isValid: false, reason };
  }

  const firstRow = data[0];
  if (!Array.isArray(firstRow) || firstRow.length < minColumns) {
    const reason = `Pierwszy wiersz ma za mało kolumn (minimum ${minColumns})`;
    if (enableLogging) console.warn(`❌ ${reason}`);
    return { isValid: false, reason };
  }

  // 2. Walidacja struktury trójkąta (jeśli włączona)
  if (validateTriangleStructure) {
    const triangleResult = validateTriangleFormat(data, enableLogging);
    if (!triangleResult.isValid) {
      return triangleResult;
    }
  }

  // 3. Sprawdzanie pustych komórek i wartości numerycznych
  if (checkEmptyCells || checkNumericValues) {
    for (let rowIdx = 1; rowIdx < data.length; rowIdx++) { // Pomijamy nagłówek (pierwszy wiersz)
      const row = data[rowIdx]!;

      // Policz puste komórki na końcu
      let emptyCount = 0;
      for (let colIdx = row.length - 1; colIdx >= 0; colIdx--) {
        if (row[colIdx] === "" || row[colIdx] === null || row[colIdx] === undefined) {
          emptyCount++;
        } else {
          break;
        }
      }

      const dataPart = row.slice(1, row.length - emptyCount); // Pomijamy pierwszą kolumnę (nazwy wierszy) i puste na końcu

      for (const [cellIdx, cell] of dataPart.entries()) {
        const actualColIdx = cellIdx + 1; // Przesunięcie indeksu kolumny o 1 (bo pomijamy pierwszą kolumnę)
        if (enableLogging) {
          console.log(`Row ${rowIdx}, Cell ${actualColIdx}:`, cell, `Type: ${typeof cell}`);
        }

        // Sprawdź puste komórki w środku danych
        if (checkEmptyCells && (cell === "" || cell === null || cell === undefined)) {
          const reason = `Dane mają braki`;
          if (enableLogging) console.warn(`❌ ${reason} - pusta komórka w wierszu ${rowIdx}, kolumna ${actualColIdx}`);
          return { isValid: false, reason };
        }

        // Sprawdź czy wartości są numeryczne
        if (checkNumericValues) {
          const numericValue = typeof cell === 'number' ? cell : Number(cell);
          if (isNaN(numericValue)) {
            const reason = `Dane posiadają wartość inną niż liczbową`;
            if (enableLogging) console.warn(`❌ ${reason} - wartość "${cell}" w wierszu ${rowIdx}, kolumna ${actualColIdx}`);
            return { isValid: false, reason };
          }
        }
      }
    }
  }

  if (enableLogging) {
    console.log("✅ Walidacja zakończona pomyślnie");
  }

  return { isValid: true };
}

/**
 * Funkcja sprawdzająca strukturę trójkąta
 */
function validateTriangleFormat(data: any[][], enableLogging: boolean): ValidationResult {
  let prevCount = Infinity;
  let firstCount = Infinity;
  let isEnd = false;

  for (let i = 0; i < data.length; i++) {
    const row = data[i];
    // Dla wiersza nagłówka (i === 0) liczymy wszystkie kolumny
    // Dla wierszy danych (i > 0) pomijamy pierwszą kolumnę (nazwy wierszy)
    const values = i === 0 ? countNonEmptyCells(row) : countNonEmptyDataCells(row);

    if (values === 0) {
      isEnd = true;
      continue;
    } else if (isEnd) {
      const reason = `Wiersz ${i + 1} zawiera dane po pustym wierszu - nieprawidłowa struktura trójkąta`;
      if (enableLogging) console.warn(`❌ ${reason}`);
      return { isValid: false, reason };
    }

    if (i === 0) {
      firstCount = values;
      prevCount = values;
      continue;
    }

    if (i === 1 && values !== firstCount - 1) { // Porównujemy dane z nagłówkiem (pomijając pierwszą kolumnę w obu)
      const reason = `Wiersz 2 ma inną długość danych (${values}) niż nagłówek (${firstCount - 1})`;
      if (enableLogging) console.warn(`❌ ${reason}`);
      return { isValid: false, reason };
    }

    if (values > prevCount) {
      const reason = `Wiersz ${i + 1} ma więcej danych (${values}) niż poprzedni (${prevCount}) - nieprawidłowa struktura trójkąta`;
      if (enableLogging) console.warn(`❌ ${reason}`);
      return { isValid: false, reason };
    }

    prevCount = values;
  }

  if (prevCount < 2) {
    const reason = `Za mało danych w ostatnim wierszu (${prevCount}, minimum 2)`;
    if (enableLogging) console.warn(`❌ ${reason}`);
    return { isValid: false, reason };
  }

  if (enableLogging) {
    console.log("✅ Struktura trójkąta jest prawidłowa");
  }

  return { isValid: true };
}

/**
 * Pomocnicza funkcja do liczenia niepustych komórek w wierszu
 */
function countNonEmptyCells(row: any[] | undefined): number {
  if (!row) return 0;
  
  let lastNonEmptyIndex = -1;
  for (let i = 0; i < row.length; i++) {
    if (row[i] !== null && row[i] !== undefined && row[i] !== '') {
      lastNonEmptyIndex = i;
    }
  }
  
  return lastNonEmptyIndex + 1;
}

/**
 * Pomocnicza funkcja do liczenia niepustych komórek w wierszu, pomijając pierwszą kolumnę (nazwy wierszy)
 */
function countNonEmptyDataCells(row: any[] | undefined): number {
  if (!row || row.length <= 1) return 0;
  
  let lastNonEmptyIndex = -1; // -1 oznacza że nie znaleźliśmy żadnych danych
  for (let i = 1; i < row.length; i++) { // Zaczynamy od indeksu 1 (pomijamy pierwszą kolumnę)
    if (row[i] !== null && row[i] !== undefined && row[i] !== '') {
      lastNonEmptyIndex = i;
    }
  }
  
  // Jeśli lastNonEmptyIndex = -1, to brak danych (zwróć 0)
  // Jeśli lastNonEmptyIndex = 1, to jedna komórka danych (zwróć 1) 
  // Jeśli lastNonEmptyIndex = 2, to dwie komórki danych (zwróć 2)
  return lastNonEmptyIndex === -1 ? 0 : lastNonEmptyIndex;
}

/**
 * Predefiniowane konfiguracje dla różnych przypadków użycia
 */
export const ValidationPresets = {
  /** Podstawowa walidacja - tylko puste komórki i wartości numeryczne */
  basic: (): ValidationOptions => ({
    enableLogging: false,
    validateTriangleStructure: false,
    checkEmptyCells: true,
    checkNumericValues: true,
  }),

  /** Walidacja dla danych Paid - ze sprawdzaniem struktury trójkąta */
  paid: (): ValidationOptions => ({
    enableLogging: true, // 🔍 Włączamy logi do debugowania
    validateTriangleStructure: false, // 🚫 Tymczasowo wyłączamy walidację struktury trójkąta
    checkEmptyCells: true,
    checkNumericValues: true,
    minRows: 2,
    minColumns: 2,
  }),

  /** Walidacja dla danych Incurred - prostsza */
  incurred: (): ValidationOptions => ({
    enableLogging: false,
    validateTriangleStructure: false,
    checkEmptyCells: true,
    checkNumericValues: true,
    minRows: 2,
    minColumns: 1,
  }),

  /** Walidacja z debugowaniem - włączone logi */
  debug: (): ValidationOptions => ({
    enableLogging: true,
    validateTriangleStructure: true,
    checkEmptyCells: true,
    checkNumericValues: true,
  }),

  /** Tylko sprawdzenie struktury bez sprawdzania wartości */
  structureOnly: (): ValidationOptions => ({
    enableLogging: false,
    validateTriangleStructure: true,
    checkEmptyCells: false,
    checkNumericValues: false,
  }),
} as const;
