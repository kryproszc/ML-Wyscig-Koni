/**
 * Utylita do czyszczenia danych aplikacji przy zamknięciu karty/okna przeglądarki
 */
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred';

export function setupDataClearOnExit() {
  if (typeof window === 'undefined') return;

  const handleBeforeUnload = () => {
    // Wyczyść dane FitCurve PaidToIncurred z store
    try {
      const { clearPaidToIncurredFitCurveData } = useTrainDevideStoreIncurred.getState();
      clearPaidToIncurredFitCurveData();
      console.log('🧹 Dane PaidToIncurred FitCurve zostały wyczyszczone');
    } catch (error) {
      console.warn('⚠️ Błąd podczas czyszczenia danych PaidToIncurred:', error);
    }
    
    // Opcjonalnie: wyczyść wszystkie dane z sessionStorage
    // (to i tak się dzieje automatycznie przy zamknięciu karty)
    try {
      // Lista kluczy aplikacji które chcemy wyczyścić
      const appKeys = [
        'train-devide-det',
        'calculation-options-storage',
        'display-settings-paid',
        'add-coefficients-store',
        'addpaid-store',
        'paramsym-store',
        'chain-ladder-results-storage',
        'cl-simulation-store'
      ];

      // Dodatkowo wyczyść wszystkie klucze localStorage które mogły zostać zapisane
      const allLocalStorageKeys = Object.keys(localStorage);
      const appLocalStorageKeys = allLocalStorageKeys.filter(key => 
        key.includes('inflacja') || 
        key.includes('exposure') || 
        key.includes('paramsym') || 
        key.includes('discount') ||
        key.includes('chain-ladder') ||
        key.includes('triangle') ||
        key.includes('simulation')
      );
      
      appLocalStorageKeys.forEach(key => {
        localStorage.removeItem(key);
      });

      appKeys.forEach(key => {
        sessionStorage.removeItem(key);
      });

      console.log('🧹 Dane aplikacji zostały wyczyszczone przy zamknięciu');
    } catch (error) {
      console.warn('⚠️ Błąd podczas czyszczenia danych:', error);
    }
  };

  // Dodaj listener na zamknięcie karty/okna
  window.addEventListener('beforeunload', handleBeforeUnload);

  // Zwróć funkcję do usunięcia listenera (cleanup)
  return () => {
    window.removeEventListener('beforeunload', handleBeforeUnload);
  };
}