'use client';

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import { setupDataClearOnExit } from '@/utils/clearDataOnExit';

export function Providers({ children }: { children: ReactNode }) {
  const [client] = useState(() => new QueryClient());

  useEffect(() => {
    // Wyczyść stare dane z localStorage przy uruchomieniu aplikacji
    // (przypadek gdy aplikacja jest uruchamiana po zamknięciu przeglądarki)
    if (typeof window !== 'undefined') {
      const localStorageKeys = Object.keys(localStorage);
      const appKeys = localStorageKeys.filter(key => 
        key.includes('inflacja') || 
        key.includes('exposure') || 
        key.includes('paramsym') || 
        key.includes('discount') ||
        key.includes('chain-ladder') ||
        key.includes('simulation') ||
        // Usuń stare klucze triangle, ale zachowaj aktualne
        (key.includes('triangle') && !key.includes('ca_triangle_type'))
      );
      
      appKeys.forEach(key => {
        localStorage.removeItem(key);
      });
      
      console.log('🧹 Wyczyszczono stare dane z localStorage przy uruchomieniu aplikacji (zachowano ca_triangle_type)');
    }

    // Skonfiguruj czyszczenie danych przy zamknięciu aplikacji
    const cleanup = setupDataClearOnExit();
    
    // Cleanup function
    return cleanup;
  }, []);

  return (
    <QueryClientProvider client={client}>
      {children}
    </QueryClientProvider>
  );
}
