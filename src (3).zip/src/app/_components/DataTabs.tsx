'use client';

import { InputDataTabDet } from '@/features/data-input';
import { cn } from "@/lib/utils";

export function DataTabs() {
  return (
    <div className="flex flex-col gap-6">
      {/* Nagłówek */}
      <div className="text-white text-lg font-medium border-b border-gray-700 pb-2">
        Trójkąt danych paid
      </div>

      <div>
        <InputDataTabDet />
      </div>
    </div>
  );
}
