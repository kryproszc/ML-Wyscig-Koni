'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as XLSX from 'xlsx';
import { useState, useEffect } from 'react';
import { useExposureStore } from '@/stores/exposureStore';
import { useInflacjaStore } from '@/stores/inflacjaStore';
import { useUserStore } from '@/app/_components/useUserStore';
import { inflationApiService } from '@/services/inflationApi';
import { z } from 'zod';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardFooter,
} from '@/components/ui/card';
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { VisuallyHidden } from '@/components/ui/visually-hidden';
import { ExposureLineSelector } from '@/components/ExposureLineSelector';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const schema = z.object({
  rowStart: z.coerce.number().min(1),
  rowEnd: z.coerce.number().min(1),
  colStart: z.coerce.number().min(1),
  colEnd: z.coerce.number().min(1),
  file: z.any(),
});
type FormField = z.infer<typeof schema>;

// --- KONWERSJA LICZB Z POLSKIM FORMATOWANIEM ---
function parsePolishNumber(value: any): number | null {
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : null;
  }
  
  if (value == null || value === '') {
    return null;
  }
  
  let str = String(value).trim();
  
  // Usuń spacje (mogą być separatorami tysięcy)
  str = str.replace(/\s/g, '');
  
  // Jeśli string zawiera przecinek i nie zawiera kropki, 
  // to prawdopodobnie przecinek to separator dziesiętny
  if (str.includes(',') && !str.includes('.')) {
    str = str.replace(',', '.');
  }
  // Jeśli zawiera i przecinek i kropkę, to prawdopodobnie:
  // - kropka = separator tysięcy, przecinek = separator dziesiętny (np. 1.234,56)
  else if (str.includes(',') && str.includes('.')) {
    // Sprawdź pozycje - jeśli kropka jest przed przecinkiem, to kropka = tysiące
    const lastDotIndex = str.lastIndexOf('.');
    const lastCommaIndex = str.lastIndexOf(',');
    
    if (lastDotIndex < lastCommaIndex) {
      // Format: 1.234,56 (kropka=tysiące, przecinek=dziesiętne)
      str = str.replace(/\./g, '').replace(',', '.');
    }
    // Inaczej zostaw jak jest, może to być format amerykański
  }
  
  const num = Number(str);
  return Number.isFinite(num) ? num : null;
}

// --- KONWERSJA EXPOSURE TRIANGLE DO FORMATU MATRIX ---
function convertExposureToMatrix(exposureData: { [rowIndex: number]: { [colIndex: number]: number | null } }): (number | null)[][] {
  const matrix: (number | null)[][] = [];
  const rowIndices = Object.keys(exposureData).map(Number).sort((a, b) => a - b);
  
  for (const rowIndex of rowIndices) {
    const row = exposureData[rowIndex];
    if (!row) continue; // Sprawdź czy wiersz istnieje
    
    const colIndices = Object.keys(row).map(Number).sort((a, b) => a - b);
    const matrixRow: (number | null)[] = [];
    
    for (const colIndex of colIndices) {
      matrixRow.push(row[colIndex] ?? null); // Zabezpiecz przed undefined
    }
    matrix.push(matrixRow);
  }
  
  return matrix;
}

export function ExposureTab() {
  const {
    exposureTriangle,
    originalExposureTriangle,
    selectedSheetName,
    uploadedFileName,
    decimalPlaces,
    selectedExposureLine,
    inflationResult,
    setExposureTriangle,
    setOriginalExposureTriangle,
    setSelectedSheetName,
    setUploadedFileName,
    setSelectedExposureLine,
    setInflationResult,
    resetData
  } = useExposureStore();

  // Store'y dla inflacji
  const { inflacjaTriangle, selectedInflacjaLine, availableInflacjaLines } = useInflacjaStore();
  const userId = useUserStore((s) => s.userId);

  // Stan lokalny formularza
  const [workbook, setWorkbook] = useState<XLSX.WorkBook | null>(null);
  const [sheetNames, setSheetNames] = useState<string[]>([]);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [showErrorDialog, setShowErrorDialog] = useState(false);
  const [previewData, setPreviewData] = useState<{ [rowIndex: number]: { [colIndex: number]: number | null } }>({});
  const [isDataLoaded, setIsDataLoaded] = useState(false); // Nowy stan dla kontroli etapów
  // Używamy selectedExposureLine z store zamiast lokalnego stanu
  const selectedLineForSubmit = selectedExposureLine;

  const { register, handleSubmit, setValue, watch, formState: { errors } } = useForm<FormField>({
    resolver: zodResolver(schema),
    defaultValues: {
      rowStart: 1,
      rowEnd: 11,
      colStart: 1,
      colEnd: 11,
    }
  });

  const file = watch('file');

  // Załaduj podgląd przy inicjalizacji jeśli mamy już dane w store
  useEffect(() => {
    if (Object.keys(exposureTriangle).length > 0) {
      setPreviewData(exposureTriangle);
      setIsDataLoaded(true); // Jeśli są dane w store, oznacz jako załadowane
    }
  }, [exposureTriangle]);

  // Funkcja ładowania pliku
  const handleFileLoad = () => {
    if (!file || file.length === 0) return;

    const selectedFile = file[0];
    const reader = new FileReader();

    reader.onload = (e) => {
      const data = new Uint8Array(e.target?.result as ArrayBuffer);
      const wb = XLSX.read(data, { type: 'array' });
      setWorkbook(wb);
      setSheetNames(wb.SheetNames);
      setSelectedSheetName(wb.SheetNames[0] || '');
      setUploadedFileName(selectedFile.name);
      
      // Resetuj stan załadowania danych
      setIsDataLoaded(false);
      setPreviewData({});
      setInflationResult(null); // Reset wyniku inflacji
    };

    reader.readAsArrayBuffer(selectedFile);
  };

  // Funkcja wczytywania danych (Etap 1)
  const handleLoadData = () => {
    if (!workbook || !selectedSheetName) return;

    const worksheet = workbook.Sheets[selectedSheetName];
    if (!worksheet) return;

    try {
      // Użyj wartości z formularza
      const formData = watch();
      const rangeString = XLSX.utils.encode_range({
        s: { r: (formData.rowStart || 1) - 1, c: (formData.colStart || 1) - 1 },
        e: { r: (formData.rowEnd || 11) - 1, c: (formData.colEnd || 11) - 1 }
      });

      const rawData = XLSX.utils.sheet_to_json(worksheet, {
        range: rangeString,
        header: 1,
        defval: null
      }) as any[][];

      // Przetwórz dane na format trójkąta dla podglądu
      const triangleData: { [rowIndex: number]: { [colIndex: number]: number | null } } = {};
      
      for (let i = 0; i < rawData.length; i++) {
        const row = rawData[i];
        if (!row) continue;
        
        triangleData[i] = {};
        
        for (let j = 0; j < row.length; j++) {
          const value = row[j];
          if (value !== null && value !== undefined && value !== '') {
            const parsedValue = parsePolishNumber(value);
            triangleData[i]![j] = parsedValue !== null ? parsedValue : value; // Zachowaj string label jeśli nie da się sparsować
          } else {
            triangleData[i]![j] = null;
          }
        }
      }

      setPreviewData(triangleData);
      setIsDataLoaded(true); // Oznacz dane jako załadowane
    } catch (error) {
      console.error('Błąd podczas wczytywania danych:', error);
      setShowErrorDialog(true);
    }
  };

  // Funkcja automatycznego wykrywania zakresu
  const handleAutoRange = () => {
    if (!workbook || !selectedSheetName) return;

    const worksheet = workbook.Sheets[selectedSheetName];
    if (!worksheet) return;

    const range = XLSX.utils.decode_range(worksheet['!ref'] || 'A1:A1');
    setValue('rowStart', range.s.r + 1);
    setValue('rowEnd', range.e.r + 1);
    setValue('colStart', range.s.c + 1);
    setValue('colEnd', range.e.c + 1);
  };

  // Funkcja przetwarzania danych
  const onSubmit = (data: FormField) => {
    if (!workbook || !selectedSheetName) return;

    const worksheet = workbook.Sheets[selectedSheetName];
    if (!worksheet) return;

    try {
      // Pobierz dane z zakresu
      const rangeString = XLSX.utils.encode_range({
        s: { r: data.rowStart - 1, c: data.colStart - 1 },
        e: { r: data.rowEnd - 1, c: data.colEnd - 1 }
      });

      const rawData = XLSX.utils.sheet_to_json(worksheet, {
        range: rangeString,
        header: 1,
        defval: null
      }) as any[][];

      // Przetwórz dane na format trójkąta
      const triangleData: { [rowIndex: number]: { [colIndex: number]: number | null } } = {};
      
      // Przetwarzamy wszystkie dane bez pomijania nagłówków
      for (let i = 0; i < rawData.length; i++) {
        const row = rawData[i];
        if (!row) continue;
        
        triangleData[i] = {};
        
        for (let j = 0; j < row.length; j++) {
          const value = row[j];
          if (value !== null && value !== undefined && value !== '') {
            const parsedValue = parsePolishNumber(value);
            triangleData[i]![j] = parsedValue;
          } else {
            triangleData[i]![j] = null;
          }
        }
      }

      setExposureTriangle(triangleData);
      // Zapisz też oryginalne dane (bez inflacji)
      setOriginalExposureTriangle(triangleData);
      // Zapisz też wybraną linię ekspozycji
      if (selectedLineForSubmit !== null) {
        setSelectedExposureLine(selectedLineForSubmit);
      }
      setShowSuccessDialog(true);
    } catch (error) {
      console.error('Błąd podczas przetwarzania danych:', error);
      setShowErrorDialog(true);
    }
  };

  // Funkcja nakładania inflacji
  const handleApplyInflation = async () => {
    console.log('🔥 [ExposureTab] handleApplyInflation - rozpoczynam...');
    
    // Sprawdzenie czy są dane exposure
    if (!exposureTriangle || Object.keys(exposureTriangle).length === 0) {
      console.error('❌ Brak danych exposure');
      alert('Najpierw wczytaj dane exposure.');
      return;
    }

    // Sprawdzenie czy jest wybrany wektor exposure
    if (selectedExposureLine === null) {
      console.error('❌ Nie wybrano wektora exposure');
      alert('Wybierz wiersz jako wektor ekspozycji.');
      return;
    }

    // Sprawdzenie czy są dane inflacji
    if (selectedInflacjaLine === null || !userId) {
      console.error('❌ Brak danych inflacji lub user ID');
      alert('Brak danych inflacji lub user ID.');
      return;
    }

    // Znalezienie wybranej linii inflacji
    const inflationLine = availableInflacjaLines.find(line => line.index === selectedInflacjaLine);
    if (!inflationLine) {
      console.error('❌ Nie znaleziono wybranej linii inflacji');
      alert('Nie znaleziono wybranej linii inflacji');
      return;
    }

    try {
      // 🔥 WAŻNE: Używamy ORYGINALNYCH danych exposure (bez inflacji) do obliczeń
      const selectedRow = originalExposureTriangle[selectedExposureLine];
      if (!selectedRow) {
        console.error('❌ Nie znaleziono wybranego wiersza w oryginalnych danych exposure');
        alert('Błąd: nie znaleziono wybranego wiersza w oryginalnych danych exposure.');
        return;
      }

      console.log('🔍 [ExposureTab] Oryginalny selectedRow (bez inflacji):', selectedRow);
      
      // Pokaż wszystkie kolumny przed filtrowaniem
      const allColKeys = Object.keys(selectedRow).map(Number).sort((a, b) => a - b);
      console.log('🔍 [ExposureTab] Wszystkie kolumny przed filtrowaniem:', allColKeys);
      
      // Pokaż kolumny po filtrowaniu (bez kolumny 0)
      const filteredColKeys = allColKeys.filter(colIndex => colIndex !== 0);
      console.log('🔍 [ExposureTab] Kolumny po filtrowaniu (bez kolumny 0):', filteredColKeys);

      // Konwersja wiersza na tablicę liczb (POMIJAMY KOLUMNĘ 0 - ETYKIETĘ)
      const exposureVector: (number | null)[] = Object.keys(selectedRow)
        .map(Number)
        .sort((a, b) => a - b)
        .filter(colIndex => colIndex !== 0) // ← POMIJAMY KOLUMNĘ 0 (etykiety)
        .map(colIndex => selectedRow[colIndex] ?? null);
        
      console.log('🔍 [ExposureTab] Finalny exposureVector (bez kolumny 0):', exposureVector);
      console.log('🔍 [ExposureTab] Długość exposureVector:', exposureVector.length);

      // Przygotowanie requestu dla backendu
      const inflationRequest = {
        user_id: userId,
        inflationVector: inflationLine.values,
        exposureVector: exposureVector
      };

      console.log('📊 [ExposureTab] Request do backendu - podstawowe info:', {
        userId: inflationRequest.user_id,
        inflationVectorLength: inflationLine.values.length,
        exposureVectorLength: exposureVector.length,
        selectedExposureLine: selectedExposureLine
      });

      console.log('🚀 [ExposureTab] DOKŁADNY REQUEST WYSYŁANY NA BACKEND /calc/exposure/inflation:', {
        user_id: inflationRequest.user_id,
        inflationVector: inflationRequest.inflationVector,
        exposureVector: inflationRequest.exposureVector
      });

      // Wywołanie API endpointu
      const response = await fetch('http://localhost:8000/calc/exposure/inflation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(inflationRequest),
      });
      
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error(`Endpoint nie istnieje (404). Sprawdź czy backend ma zaimplementowany endpoint /calc/exposure/inflation`);
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const result = await response.json();
      
      console.log('✅ [ExposureTab] Odpowiedź z backendu:', result);
      
      // Zapisz wynik inflacji do stanu lokalnego - sprawdź różne możliwe nazwy pól
      let adjustedVector = null;
      if (result.adjustedExposure) {
        adjustedVector = result.adjustedExposure;
      } else if (result.adjustedExposureVector) {
        adjustedVector = result.adjustedExposureVector;
      } else if (result.adjusted_exposure_vector) {
        adjustedVector = result.adjusted_exposure_vector;
      } else if (result.result) {
        adjustedVector = result.result;
      } else if (result.adjustedVector) {
        adjustedVector = result.adjustedVector;
      }
      
      console.log('📊 [ExposureTab] Znaleziony skorygowany wektor:', adjustedVector);
      
      if (adjustedVector) {
        setInflationResult(adjustedVector);
        
        // 🔥 NADPISZ WYBRANY WIERSZ W EXPOSURE TRIANGLE SKORYGOWANYMI WARTOŚCIAMI
        const updatedTriangle = { ...exposureTriangle };
        const updatedRow = { ...updatedTriangle[selectedExposureLine] };
        
        console.log('🔍 [ExposureTab] Przed nadpisaniem - updatedRow:', updatedRow);
        console.log('🔍 [ExposureTab] AdjustedVector ma elementów:', adjustedVector.length);
        
        // Zachowaj etykietę z kolumny 0, ale nadpisz pozostałe kolumny skorygowanymi wartościami
        // TYLKO dla kolumn 1 do 1+adjustedVector.length
        const startCol = 1; // Zaczynamy od kolumny 1 (pomijamy kolumnę 0 z etykietą)
        
        // Wyczyść wszystkie stare kolumny oprócz etykiety
        const colKeys = Object.keys(updatedRow).map(Number).sort((a, b) => a - b);
        colKeys.forEach(colIndex => {
          if (colIndex !== 0) { // Nie usuwaj etykiety
            delete updatedRow[colIndex];
          }
        });
        
        // Wstaw nowe wartości rozpoczynając od kolumny 1
        for (let i = 0; i < adjustedVector.length; i++) {
          updatedRow[startCol + i] = adjustedVector[i];
        }
        
        updatedTriangle[selectedExposureLine] = updatedRow;
        setExposureTriangle(updatedTriangle);
        
        console.log('🔍 [ExposureTab] Po nadpisaniu - updatedRow:', updatedRow);
        console.log('🔄 [ExposureTab] Nadpisano exposure triangle skorygowanymi wartościami:', updatedTriangle[selectedExposureLine]);
        
        alert('Inflacja została pomyślnie nałożona na exposure! Skorygowane wartości zostały zapisane.');
      } else {
        console.warn('⚠️ [ExposureTab] Nie znaleziono skorygowanego wektora w odpowiedzi:', Object.keys(result));
        
        // 🔧 TYMCZASOWY MOCK DO DEBUGOWANIA - pokaż przykładową tabelę
        const mockResult = exposureVector.map((value, index) => 
          value !== null ? value * (1.05 + index * 0.01) : null
        );
        setInflationResult(mockResult);
        console.log('🔧 [DEBUG] Używam mock wynik:', mockResult);
        
        alert('Backend nie zwrócił wyniku, ale pokazuję mock tabelę do debugowania.');
      }
      
    } catch (error) {
      console.error('❌ [ExposureTab] Błąd podczas przygotowywania requestu:', error);
      const errorMessage = error instanceof Error ? error.message : 'Nieznany błąd';
      alert(`Błąd podczas nakładania inflacji: ${errorMessage}`);
    }
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Nagłówek */}
      <div className="text-white text-lg font-medium border-b border-gray-700 pb-2">
        Ekspozycja
      </div>

      <div>
        {/* ---------- FORMULARZ ---------- */}
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="p-4 border rounded flex flex-col gap-4"
        >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="bg-blue-500 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold">1</span>
              Etap 1: Wprowadź trójkąt danych ekspozycji
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* --- Plik --- */}
            <div className="flex items-center gap-4">
              <input
                type="file"
                accept=".xlsx,.xls"
                className="border p-2 rounded-lg"
                {...register('file')}
              />
              <Button
                type="button"
                onClick={handleFileLoad}
                disabled={!file || file.length === 0}
                className="bg-blue-500 text-white"
              >
                Załaduj plik
              </Button>
              {uploadedFileName && (
                <span className="text-sm text-green-400 ml-2">
                  Wczytano: <strong>{uploadedFileName}</strong>
                </span>
              )}
            </div>

            {/* --- Arkusz --- */}
            <div>
              <Label>Wybór arkusza</Label>
              <Select
                value={selectedSheetName}
                onValueChange={(newSheetName) => {
                  setSelectedSheetName(newSheetName);
                  // Reset danych przy zmianie arkusza
                  setIsDataLoaded(false);
                  setPreviewData({});
                  setSelectedExposureLine(null);
                }}
                disabled={!workbook}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Wybierz arkusz..." />
                </SelectTrigger>
                <SelectContent>
                  {sheetNames.map((name) => (
                    <SelectItem key={name} value={name}>
                      {name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <CardHeader>
              <CardTitle>Podaj zakres danych, które chcesz wczytać.</CardTitle>
            </CardHeader>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Wiersz początkowy</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('rowStart')}
                />
              </div>
              <div>
                <Label>Wiersz końcowy</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('rowEnd')}
                />
              </div>
              <div>
                <Label>Kolumna początkowa</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('colStart')}
                />
              </div>
              <div>
                <Label>Kolumna końcowa</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('colEnd')}
                />
              </div>
            </div>

            <div className="flex gap-4">
              <Button
                type="button"
                onClick={handleAutoRange}
                variant="outline"
                disabled={!workbook}
                className="bg-gray-500 text-white"
              >
                Wykryj zakres automatycznie
              </Button>
              
              <Button
                type="button"
                onClick={handleLoadData}
                disabled={!workbook || !selectedSheetName}
                className="bg-green-500 text-white"
              >
                Wczytaj dane
              </Button>
            </div>

            {/* ---------- PODGLĄD I WYBÓR LINII (ETAP 2) ---------- */}
            {isDataLoaded && Object.keys(previewData).length > 0 && (
              <div className="mt-6 space-y-4 border-t pt-6">
                <h4 className="text-lg font-semibold text-green-600 flex items-center gap-2">
                  <span className="bg-green-500 text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold">2</span>
                  ✅ Etap 2: Wybierz wektor ekspozycji
                </h4>
                
                {/* Selektor linii */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">
                    Wybierz wiersz z tabeli, który chcesz użyć jako wektor ekspozycji:
                  </Label>
                  <ExposureLineSelector
                    exposureData={previewData}
                    selectedLine={selectedLineForSubmit}
                    onLineChange={setSelectedExposureLine}
                    showPreview={false}
                    className=""
                  />
                  <p className="text-xs text-gray-500">
                    Ten wiersz zostanie przekazany do dalszej analizy AddPaid.
                  </p>
                </div>

                {/* Podgląd tabeli */}
                <div className="max-h-96 overflow-auto border rounded">
                  <table className="w-full text-sm">
                    <tbody>
                      {Object.entries(previewData).map(([rowIndex, rowData]) => (
                        <tr key={rowIndex} className={parseInt(rowIndex) === selectedLineForSubmit ? 'bg-green-200 text-black font-bold' : 'hover:bg-gray-50'}>
                          {Object.entries(rowData).map(([colIndex, value]) => (
                            <td key={colIndex} className="border px-2 py-1 text-center">
                              {value !== null ? value : ''}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                
                {/* Przycisk przejścia do analizy */}
                <div className="flex justify-center">
                  <Button
                    type="submit"
                    className="bg-blue-600 text-white px-8 py-3 text-lg"
                    disabled={selectedLineForSubmit === null}
                  >
                    🚀 Przejdź do analizy
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter>
            <Button
              type="button"
              onClick={handleApplyInflation}
              className="bg-orange-500 text-white hover:bg-orange-600 w-full"
              disabled={Object.keys(exposureTriangle).length === 0 || selectedInflacjaLine === null || selectedExposureLine === null}
            >
              🔥 Nałóż inflację na exposure
            </Button>
          </CardFooter>
        </Card>

        {/* ---------- WYNIKI INFLACJI ---------- */}
        {inflationResult && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="text-blue-600 flex items-center gap-2">
                🔥 Wynik nałożenia inflacji na exposure
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-auto border rounded bg-gray-800">
                <table className="w-full text-sm text-white">
                  <thead>
                    <tr className="bg-gray-700">
                      <th className="border border-gray-600 px-2 py-1 text-center font-bold">#</th>
                      {inflationResult.map((_, index) => (
                        <th key={index} className="border border-gray-600 px-2 py-1 text-center font-bold">
                          {index + 1}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border border-gray-600 px-2 py-1 text-center font-bold bg-gray-700">
                        1
                      </td>
                      {inflationResult.map((value, index) => (
                        <td key={index} className="border border-gray-600 px-2 py-1 text-center bg-gray-600">
                          {value !== null ? value.toFixed(2) : ''}
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}
      </form>

      {/* ---------- ALERTY ---------- */}
      {/* Sukces (zielony) */}
      <AlertDialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center">
            <VisuallyHidden>
              <AlertDialogTitle>Powiadomienie</AlertDialogTitle>
            </VisuallyHidden>
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-green-100 mb-4">
              <svg
                className="w-6 h-6 text-green-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M5 13l4 4L19 7"
                />
              </svg>
            </div>
            <AlertDialogDescription className="text-center text-green-600 font-medium">
              Dane ekspozycji zostały pomyślnie wczytane i przetworzone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>OK</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Błąd (czerwony) */}
      <AlertDialog open={showErrorDialog} onOpenChange={setShowErrorDialog}>
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center">
            <VisuallyHidden>
              <AlertDialogTitle>Błąd danych</AlertDialogTitle>
            </VisuallyHidden>
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-red-100 mb-4">
              <svg
                className="w-6 h-6 text-red-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </div>
            <AlertDialogDescription className="text-center text-red-600 font-medium">
              Wystąpił błąd podczas przetwarzania danych ekspozycji. Sprawdź format pliku!
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Zamknij</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      </div>
    </div>
  );
}