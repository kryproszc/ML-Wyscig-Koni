'use client';

import { useState } from "react";
import DeterministicMethodsTab from "./DeterministicMethodsTab";
import { ExposureTab } from "./ExposureTab";
import { NetBruttoTab } from "./NetBruttoTab";
import { DiscountRatesTab } from "./DiscountRatesTab";
import { Folder, Calculator, Home, BarChart, ChevronDown, ChevronRight } from "lucide-react";
import { DataTabs } from "./DataTabs";
import { DataTabsIncurred } from "./DataTabsIncurred";

// ✅ importy dla różnych metod symulacji
import { ClSimulationPaid } from "../../features/Parametryzacja/MultPaid/Symulacje/ClSimulationPaid";
import { AddSimulationPaid } from "../../features/Parametryzacja/AddPaid/Symulacje/AddSimulationPaid";
import { ClSimulationIncurred } from "@/features/Parametryzacja/MultIncurred/Symulacje/ClSimulationIncurred";

// ✅ NOWY import (plik Inflacja.tsc w tym samym katalogu co NetBruttoTab)
//    Uwaga: TypeScript rozwiąże rozszerzenie – ścieżka bez .tsc/.tsx
import { InflacjaTab } from "./Inflacja";
import { TestTab } from "../../features/Parametryzacja/Test/TestTab";

export function HomeTabs() {
  const [selectedTab, setSelectedTab] =
    useState<"start" | "input" | "deterministic" | "simulation">("start");

  const [isParametrizationExpanded, setIsParametrizationExpanded] = useState(false);
  const [isInputExpanded, setIsInputExpanded] = useState(false);
  const [isSimulationExpanded, setIsSimulationExpanded] = useState(false);

  const [selectedMethod, setSelectedMethod] = useState<"paid" | "incurred" | "other1" | "other2">("paid");

  // ✅ rozszerzony typ o "incurred"
  const [selectedInputType, setSelectedInputType] =
    useState<"inflacja" | "paid" | "incurred" | "exposure" | "netbrutto" | "discountrates">("paid");

  const [selectedSimMethod, setSelectedSimMethod] =
    useState<"bootstrap" | "addpaid" | "incurred" | "test">("bootstrap");

  const renderContent = () => {
    switch (selectedTab) {
      case "start":
        return <StartPage />;
      case "input":
        // ✅ obsługa nowej zakładki
        if (selectedInputType === "inflacja") return <InflacjaTab />;
        if (selectedInputType === "incurred") return <DataTabsIncurred />;
        if (selectedInputType === "exposure") return <ExposureTab />;
        if (selectedInputType === "netbrutto") return <NetBruttoTab />;
        if (selectedInputType === "discountrates") return <DiscountRatesTab />;
        return <DataTabs />;
      case "deterministic":
        return <DeterministicMethodsTab selectedMethod={selectedMethod} />;
      case "simulation":
        if (selectedSimMethod === "bootstrap") return <ClSimulationPaid />;
        if (selectedSimMethod === "addpaid") return <AddSimulationPaid />;
        if (selectedSimMethod === "incurred") return <ClSimulationIncurred />;
        if (selectedSimMethod === "test") return <TestTab />;
        return <ClSimulationPaid />; // domyślnie ClSimulationPaid
      default:
        return null;
    }
  };

  return (
    <div className="flex min-h-screen bg-[#0f172a]">
      {/* Sidebar */}
      <aside className="w-64 bg-[#1e293b] text-gray-100 flex flex-col py-6 px-4 border-r border-gray-700 sticky top-0 h-screen">
        {/* Logo / nagłówek */}
        <div className="flex flex-col justify-center items-center mb-8">
          <h1 className="text-2xl font-extrabold tracking-wider text-blue-400">UPZ</h1>
          <p className="text-xs text-gray-400 mt-1 text-center leading-tight">
            Uniwersytet Pomocy<br />Zagubionym
          </p>
        </div>

        <nav className="flex flex-col gap-2">
          <SidebarItem
            icon={<Home size={20} />}
            label="Start"
            isActive={selectedTab === "start"}
            onClick={() => setSelectedTab("start")}
          />

          {/* Wprowadź dane */}
          <div>
            <SidebarItem
              icon={<Folder size={20} />}
              label="Wprowadź dane"
              isActive={selectedTab === "input"}
              onClick={() => {
                setIsInputExpanded(!isInputExpanded);
                if (!isInputExpanded) setSelectedTab("input");
              }}
              expandIcon={isInputExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
              isExpandable
            />

            {isInputExpanded && (
              <div className="ml-6 border-l border-slate-600">
                {/* ✅ NOWA pozycja – przed „Trójkąt paid” */}
                <SidebarSubItem
                  label="Inflacja"
                  isActive={selectedTab === "input" && selectedInputType === "inflacja"}
                  onClick={() => { setSelectedTab("input"); setSelectedInputType("inflacja"); }}
                />
                <SidebarSubItem
                  label="Trójkąt paid"
                  isActive={selectedTab === "input" && selectedInputType === "paid"}
                  onClick={() => { setSelectedTab("input"); setSelectedInputType("paid"); }}
                />
                <SidebarSubItem
                  label="Trójkąt incurred"
                  isActive={selectedTab === "input" && selectedInputType === "incurred"}
                  onClick={() => { setSelectedTab("input"); setSelectedInputType("incurred"); }}
                />
                <SidebarSubItem
                  label="Ekspozycja"
                  isActive={selectedTab === "input" && selectedInputType === "exposure"}
                  onClick={() => { setSelectedTab("input"); setSelectedInputType("exposure"); }}
                />
                <SidebarSubItem
                  label="Netto/brutto"
                  isActive={selectedTab === "input" && selectedInputType === "netbrutto"}
                  onClick={() => { setSelectedTab("input"); setSelectedInputType("netbrutto"); }}
                />
                <SidebarSubItem
                  label="Stopy dyskontowe"
                  isActive={selectedTab === "input" && selectedInputType === "discountrates"}
                  onClick={() => { setSelectedTab("input"); setSelectedInputType("discountrates"); }}
                />
              </div>
            )}
          </div>

          {/* Parametryzacja */}
          <div>
            <SidebarItem
              icon={<Calculator size={20} />}
              label="Parametryzacja"
              isActive={selectedTab === "deterministic"}
              onClick={() => {
                setIsParametrizationExpanded(!isParametrizationExpanded);
                if (!isParametrizationExpanded) setSelectedTab("deterministic");
              }}
              expandIcon={
                isParametrizationExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />
              }
              isExpandable
            />

            {isParametrizationExpanded && (
              <div className="ml-6 border-l border-slate-600">
                <SidebarSubItem
                  label="MultPaid"
                  isActive={selectedTab === "deterministic" && selectedMethod === "paid"}
                  onClick={() => { setSelectedTab("deterministic"); setSelectedMethod("paid"); }}
                />
                <SidebarSubItem
                  label="MultIncurred"
                  isActive={selectedTab === "deterministic" && selectedMethod === "incurred"}
                  onClick={() => { setSelectedTab("deterministic"); setSelectedMethod("incurred"); }}
                />
                <SidebarSubItem
                  label="AddPaid"
                  isActive={selectedTab === "deterministic" && selectedMethod === "other1"}
                  onClick={() => { setSelectedTab("deterministic"); setSelectedMethod("other1"); }}
                />
                <SidebarSubItem
                  label="Paid/Incurred"
                  isActive={selectedTab === "deterministic" && selectedMethod === "other2"}
                  onClick={() => { setSelectedTab("deterministic"); setSelectedMethod("other2"); }}
                />
              </div>
            )}
          </div>

          {/* Symulacje */}
          <div>
            <SidebarItem
              icon={<BarChart size={20} />}
              label="Symulacje"
              isActive={selectedTab === "simulation"}
              onClick={() => {
                setIsSimulationExpanded(!isSimulationExpanded);
                if (!isSimulationExpanded) setSelectedTab("simulation");
              }}
              expandIcon={
                isSimulationExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />
              }
              isExpandable
            />

            {isSimulationExpanded && (
              <div className="ml-6 border-l border-slate-600">
                <SidebarSubItem
                  label="Chain Ladder Simulation"
                  isActive={selectedTab === "simulation" && selectedSimMethod === "bootstrap"}
                  onClick={() => { setSelectedTab("simulation"); setSelectedSimMethod("bootstrap"); }}
                />
                <SidebarSubItem
                  label="AddPaid Simulation"
                  isActive={selectedTab === "simulation" && selectedSimMethod === "addpaid"}
                  onClick={() => { setSelectedTab("simulation"); setSelectedSimMethod("addpaid"); }}
                />
                <SidebarSubItem
                  label="Chain Ladder Incurred"
                  isActive={selectedTab === "simulation" && selectedSimMethod === "incurred"}
                  onClick={() => { setSelectedTab("simulation"); setSelectedSimMethod("incurred"); }}
                />
                <SidebarSubItem
                  label="Test"
                  isActive={selectedTab === "simulation" && selectedSimMethod === "test"}
                  onClick={() => { setSelectedTab("simulation"); setSelectedSimMethod("test"); }}
                />
              </div>
            )}
          </div>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 bg-[#0f172a] p-8 overflow-auto">
        {renderContent()}
      </main>
    </div>
  );
}

function SidebarItem({
  icon,
  label,
  isActive,
  onClick,
  expandIcon,
  isExpandable,
}: {
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
  expandIcon?: React.ReactNode;
  isExpandable?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-3 p-3 rounded-lg transition-all text-left w-full
        ${isActive ? "bg-gray-700 text-blue-400 font-semibold shadow-inner" : "hover:bg-gray-700 hover:text-blue-300"}`}
    >
      {icon}
      <span className="text-base flex-1">{label}</span>
      {isExpandable && expandIcon}
    </button>
  );
}

function SidebarSubItem({
  label,
  isActive,
  onClick,
}: {
  label: string;
  isActive: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-3 p-2 pl-4 rounded-lg transition-all text-left w-full text-sm ml-2
        ${isActive ? "bg-gray-600 text-blue-300 font-medium" : "hover:bg-gray-600 hover:text-blue-200 text-gray-300"}`}
    >
      <span className="w-2 h-2 bg-gray-500 rounded-full"></span>
      <span>{label}</span>
    </button>
  );
}

function StartPage() {
  return (
    <div className="flex flex-col items-center justify-center h-full text-gray-100 animate-fade-in">
      <div className="bg-gradient-to-b from-[#0f172a] to-[#1e293b] p-12 rounded-xl shadow-2xl flex flex-col items-center w-full max-w-4xl">
        <img
          src="/Grafika_powitalna.png"
          alt="Grafika powitalna"
          className="w-full max-w-2xl mb-4 rounded-lg shadow-lg"
        />
        <p className="text-xs text-gray-500 mb-10">
          Źródło:{" "}
          <a
            href="https://www.insurtechexpress.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="underline hover:text-gray-400"
          >
            www.insurtechexpress.com
          </a>
        </p>
        <h1 className="text-5xl font-bold mb-6 text-center">Witaj w aplikacji!</h1>
        <p className="text-xl text-gray-400 text-center max-w-2xl">
          Aplikacja do analizy rezerw ubezpieczeniowych metodą Chain-Ladder (Paid).
          Wprowadź dane i przeprowadź analizę współczynników rozwoju.
        </p>
      </div>
    </div>
  );
}
