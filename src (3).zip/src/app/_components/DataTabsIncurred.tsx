'use client';

import { InputDataTabIncurred } from '@/features/data-input';
import { cn } from "@/lib/utils";

export function DataTabsIncurred() {
  return (
    <div className="flex flex-col gap-6">
      {/* Nagłówek */}
      <div className="text-white text-lg font-medium border-b border-gray-700 pb-2">
        Trójkąt danych incurred
      </div>

      <div>
        <InputDataTabIncurred />
      </div>
    </div>
  );
}