'use client';

import React, { useState, useEffect } from 'react';
import { useTableStore } from '@/stores/tableStore';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred';

// ——— widoki Paid ———
import { PaidTriangleView } from '@/features/Parametryzacja/MultPaid/triangle-view/PaidTriangleView';
import PaidCLCoefficientsPage from '@/features/Parametryzacja/MultPaid/cl-coefficients/pages/PaidCLCoefficientsPage';
import DevJSelectorPaid from '@/features/Parametryzacja/MultPaid/FitCurve/FitCurvePaid';
import DevJSigmaPaid from '@/features/Parametryzacja/MultPaid/FitCurve/FitCurveSigma';

// ——— widoki MultIncurred ———
import { IncurredTriangleView } from '@/features/Parametryzacja/MultIncurred/triangle-view/IncurredTriangleView';
import IncurredCLCoefficientsPage from '@/features/Parametryzacja/MultIncurred/cl-coefficients/pages/IncurredCLCoefficientsPage';
import FitCurveIncurred from '@/features/Parametryzacja/MultIncurred/FitCurve/FitCurveIncurred';
import FitCurveSigmaIncurred from '@/features/Parametryzacja/MultIncurred/FitCurve/FitCurveSigmaIncurred';

// ——— widoki Paid – krok 4 (podsumowania/wybór) ———
import PaidDevSummaryTab from '@/features/Parametryzacja/MultPaid/DevelopmentEnd/PaidDevSummaryTab';
import PaidSigmaSummaryTab from '@/features/Parametryzacja/MultPaid/DevelopmentEnd/PaidSigmaSummaryTab';
import PaidSdSummaryTab from '@/features/Parametryzacja/MultPaid/DevelopmentEnd/PaidSdSummaryTab';

// ——— widoki MultIncurred – krok 4 (podsumowania/wybór) ———
import { IncurredDevSummaryTab, IncurredSigmaSummaryTab, IncurredSdSummaryTab } from '@/features/Parametryzacja/MultIncurred/DevelopmentEnd';

// ——— widoki PaidIncurred ———
import { PaidToIncurredPage } from '@/features/Parametryzacja/PaidIncurred';
import FitCurveRJPaidToIncurred from '@/features/Parametryzacja/PaidIncurred/FitCurve/FitCurveRJPaidToIncurred';
import FitCurveVarJPaidToIncurred from '@/features/Parametryzacja/PaidIncurred/FitCurve/FitCurveVarJPaidToIncurred';

// ——— widoki PaidIncurred – krok 3 (podsumowania/wybór) ———
import { PaidToIncurredRJSummaryTab, PaidToIncurredVarJSummaryTab } from '@/features/Parametryzacja/PaidIncurred/DevelopmentEnd';

// ——— widoki AddPaid ———
import { PaidTriangleView as AddPaidTriangleView } from '@/features/Parametryzacja/AddPaid/triangle-view/PaidTriangleView';
import AddPaidCoefficientsPage from '@/features/Parametryzacja/AddPaid/add-coefficients/pages/AddPaidCoefficientsPage';
import { AddPaidFitCurveTabs } from '@/features/Parametryzacja/AddPaid/FitCurve/AddPaidFitCurveTabs';

// ——— widoki AddPaid – krok 4 (podsumowania/wybór) ———
import AddLRSummaryTab from '@/features/Parametryzacja/AddPaid/DevelopmentEnd/AddLRSummaryTab';
import AddSigmaSummaryTab from '@/features/Parametryzacja/AddPaid/DevelopmentEnd/AddSigmaSummaryTab';
import AddSDSummaryTab from '@/features/Parametryzacja/AddPaid/DevelopmentEnd/AddSDSummaryTab';

// ——— widoki Wyniki ———
import DeterminMethodCL from '@/features/Parametryzacja/MultPaid/calculation/determinMethodCL';
import DeterminMethodCLIncurred from '@/features/Parametryzacja/MultIncurred/calculation/determinMethodCLrj';
import DeterminMethodAddPaid from '@/features/Parametryzacja/AddPaid/calculation/determinMethodAddPaid';

// ——— stałe zakładek ———
const STEP_TABS = [
  'Trójkąt',
  'Współczynniki CL',
  'Dopasowanie krzywej CL',
  'Wybór krzywej CL',
  'Wyniki',
] as const;

const STEP_TABS_PAID_INCURRED = [
  'Paid to Incurred',
  'Dopasowanie krzywej Paid to incurred',
  'Wybór krzywej Paid to incurred',
] as const;

const STEP_TABS_ADDPAID = [
  'Trójkąt',
  'Współczynniki Add',
  'Dopasowanie krzywej Add',
  'Wybór krzywej Add',
  'Wyniki',
] as const;

const METHOD_TABS: { id: 'paid' | 'incurred' | 'other1' | 'other2'; label: string }[] = [
  { id: 'paid', label: 'Metoda Paid' },
  { id: 'incurred', label: 'Metoda Incurred' },
  // { id: 'other1', label: 'Metoda Druga' },
  // { id: 'other2', label: 'Metoda Trzecia' },
];

type MethodType = 'paid' | 'incurred' | 'other1' | 'other2';

type Props = {
  selectedMethod: MethodType;
};

// >>> ZAKTUALIZOWANE - dodano LR dla AddPaid i r_j/var_j dla PaidIncurred
type Tab = 'CL' | 'Sigma' | 'SD' | 'LR' | 'r_j' | 'var_j';

// ——— Segmented tabs (dynamiczne) ———
export function SegmentedTabs<T extends string>({
  active,
  setActive,
  tabs,
  ariaLabel,
}: {
  active: T;
  setActive: (t: T) => void;
  tabs: readonly T[];
  ariaLabel: string;
}) {
  const idx = tabs.indexOf(active);
  const BTN_W = 48;
  const GAP = 8;
  const PAD = 4;

  return (
    <div
      role="radiogroup"
      aria-label={ariaLabel}
      className="relative inline-flex items-center rounded-xl border border-slate-700 bg-slate-900 p-1 shadow-sm"
    >
      {/* pigułka pod aktywnym przyciskiem */}
      <span
        aria-hidden
        className="absolute top-1 bottom-1 rounded-lg bg-[#0f172a] shadow-inner transition-[left,width] duration-300 ease-out"
        style={{
          left: PAD + Math.max(0, idx) * (BTN_W + GAP),
          width: BTN_W,
        }}
      />
      <div className="relative z-10 flex gap-2">
        {tabs.map((t) => {
          const isActive = active === t;
          return (
            <button
              key={String(t)}
              role="radio"
              aria-checked={isActive}
              onClick={() => setActive(t)}
              className={[
                'relative px-3 py-1.5 text-xs md:text-sm rounded-lg transition-colors',
                'focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/60',
                isActive ? 'text-white' : 'text-blue-200 hover:text-white',
              ].join(' ')}
            >
              {t}
            </button>
          );
        })}
      </div>
    </div>
  );
}

/** Krok 3 — Dopasowanie krzywej (CL/Sigma) */
export function PaidFitCurveTabs() {
  const [active, setActive] = useState<Tab>('CL');
  const tabs: Readonly<Tab[]> = ['CL', 'Sigma'];

  return (
    <div className="w-full">
      <SegmentedTabs<Tab>
        active={active}
        setActive={setActive}
        tabs={tabs}
        ariaLabel="Tryb dopasowania"
      />

      <div className="mt-3">
        {active === 'CL' && <DevJSelectorPaid />}
        {active === 'Sigma' && <DevJSigmaPaid />}
      </div>
    </div>
  );
}

/** Krok 4 — Wybór krzywej (CL/Sigma/SD Summary) */
export function PaidSummaryTabs() {
  const [active, setActive] = useState<Tab>('CL');
  const tabs: Readonly<Tab[]> = ['CL', 'Sigma', 'SD'];

  return (
    <div className="w-full">
      <SegmentedTabs<Tab>
        active={active}
        setActive={setActive}
        tabs={tabs}
        ariaLabel="Wybór krzywej"
      />

      <div className="mt-3">
        {active === 'CL' && <PaidDevSummaryTab />}
        {active === 'Sigma' && <PaidSigmaSummaryTab />}
        {active === 'SD' && <PaidSdSummaryTab />}
      </div>
    </div>
  );
}

/** Krok 4 — Wybór krzywej AddPaid (LR/Sigma/SD Summary) */
export function AddSummaryTabs() {
  const [active, setActive] = useState<Tab>('LR'); // 🎯 PRAWIDŁOWO: LR zamiast CL
  const tabs: Readonly<Tab[]> = ['LR', 'Sigma', 'SD']; // 🎯 PRAWIDŁOWO: LR dla AddPaid

  return (
    <div className="w-full">
      <SegmentedTabs<Tab>
        active={active}
        setActive={setActive}
        tabs={tabs}
        ariaLabel="Wybór krzywej Add"
      />

      <div className="mt-3">
        {active === 'LR' && <AddLRSummaryTab />}
        {active === 'Sigma' && <AddSigmaSummaryTab />}
        {active === 'SD' && <AddSDSummaryTab />}
      </div>
    </div>
  );
}

/** Krok 3 — Dopasowanie krzywej (CL/Sigma) - Incurred */
export function IncurredFitCurveTabs() {
  const [active, setActive] = useState<Tab>('CL');
  const tabs: Readonly<Tab[]> = ['CL', 'Sigma'];

  return (
    <div className="w-full">
      <SegmentedTabs<Tab>
        active={active}
        setActive={setActive}
        tabs={tabs}
        ariaLabel="Tryb dopasowania krzywej Incurred"
      />

      <div className="mt-3">
        {active === 'CL' && <FitCurveIncurred />}
        {active === 'Sigma' && <FitCurveSigmaIncurred />}
      </div>
    </div>
  );
}

/** Krok 4 — Wybór krzywej (CL/Sigma/SD Summary) - Incurred */
export function IncurredSummaryTabs() {
  const [active, setActive] = useState<Tab>('CL');
  const tabs: Readonly<Tab[]> = ['CL', 'Sigma', 'SD'];

  return (
    <div className="w-full">
      <SegmentedTabs<Tab>
        active={active}
        setActive={setActive}
        tabs={tabs}
        ariaLabel="Wybór krzywej Incurred"
      />

      <div className="mt-3">
        {active === 'CL' && <IncurredDevSummaryTab />}
        {active === 'Sigma' && <IncurredSigmaSummaryTab />}
        {active === 'SD' && <IncurredSdSummaryTab />}
      </div>
    </div>
  );
}

/** Krok 2 — Dopasowanie krzywej (r_j/var_j) - PaidIncurred */
export function PaidIncurredFitCurveTabs() {
  const [active, setActive] = useState<Tab>('r_j');
  const tabs: Readonly<Tab[]> = ['r_j', 'var_j'];

  return (
    <div className="w-full">
      <SegmentedTabs<Tab>
        active={active}
        setActive={setActive}
        tabs={tabs}
        ariaLabel="Tryb dopasowania krzywej PaidIncurred"
      />

      <div className="mt-3">
        {active === 'r_j' && <FitCurveRJPaidToIncurred />}
        {active === 'var_j' && <FitCurveVarJPaidToIncurred />}
      </div>
    </div>
  );
}

/** Krok 3 — Wybór krzywej (r_j/var_j Summary) - PaidIncurred */
export function PaidIncurredSummaryTabs() {
  const [active, setActive] = useState<Tab>('r_j');
  const tabs: Readonly<Tab[]> = ['r_j', 'var_j'];

  return (
    <div className="w-full">
      <SegmentedTabs<Tab>
        active={active}
        setActive={setActive}
        tabs={tabs}
        ariaLabel="Wybór krzywej PaidIncurred"
      />

      <div className="mt-3">
        {active === 'r_j' && <PaidToIncurredRJSummaryTab />}
        {active === 'var_j' && <PaidToIncurredVarJSummaryTab />}
      </div>
    </div>
  );
}

// ——— Główna karta metod deterministycznych ———
export default function DeterministicMethodsTab({ selectedMethod }: Props) {
  // Osobne stany kroków dla każdej metody
  const [paidStep, setPaidStep] = useState(0);
  const [incurredStep, setIncurredStep] = useState(0);
  const [addPaidStep, setAddPaidStep] = useState(0);
  const [other2Step, setOther2Step] = useState(0);

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { clData } = useTableStore();
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { finalDevJ } = useTrainDevideStoreDet();
  
  // Hook do czyszczenia danych PaidIncurred - USUNIĘTE - powodowało utratę danych przy nawigacji
  // const { clearPaidToIncurredFitCurveData } = useTrainDevideStoreIncurred();
  // const previousMethodRef = useRef<MethodType | null>(null);

  // // Wyczyść dane PaidIncurred gdy użytkownik wychodzi z tej sekcji - WYŁĄCZONE
  // useEffect(() => {
  //   // Sprawdzaj czy użytkownik wyszedł z metody 'other2' (PaidIncurred)
  //   if (previousMethodRef.current === 'other2' && selectedMethod !== 'other2') {
  //     console.log('🧹 Czyszczenie danych PaidIncurred - użytkownik opuścił sekcję');
  //     clearPaidToIncurredFitCurveData();
  //   }
  //   
  //   // Zapisz obecną metodę dla następnej iteracji
  //   previousMethodRef.current = selectedMethod;
  // }, [selectedMethod, clearPaidToIncurredFitCurveData]);

  const getCurrentStep = () => {
    switch (selectedMethod) {
      case 'paid':
        return paidStep;
      case 'incurred':
        return incurredStep;
      case 'other1':
        return addPaidStep;
      case 'other2':
        return other2Step;
      default:
        return 0;
    }
  };

  const setCurrentStep = (newStep: number) => {
    switch (selectedMethod) {
      case 'paid':
        setPaidStep(newStep);
        break;
      case 'incurred':
        setIncurredStep(newStep);
        break;
      case 'other1':
        setAddPaidStep(newStep);
        break;
      case 'other2':
        setOther2Step(newStep);
        break;
    }
  };

  const currentStep = getCurrentStep();

  const getCurrentStepTabs = () => {
    switch (selectedMethod) {
      case 'other1':
        return STEP_TABS_ADDPAID;
      case 'other2':
        return STEP_TABS_PAID_INCURRED;
      default:
        return STEP_TABS;
    }
  };

  const currentStepTabs = getCurrentStepTabs();

  return (
    <div className="w-full text-white">
      {/* ──────────────────  Pod-zakładki kroków  ────────────────── */}
      <div className="flex w-full rounded overflow-hidden border border-slate-700 bg-[#1e293b] mb-4">
        {currentStepTabs.map((label, index) => (
          <button
            key={index}
            onClick={() => setCurrentStep(index)}
            className={`flex-1 px-3 py-2 text-sm text-center transition-all ${
              currentStep === index
                ? 'bg-[#0f172a] text-white border-r border-slate-700 border-b-4 border-b-blue-400 font-medium'
                : 'hover:bg-slate-700 text-blue-200 border-r border-slate-700'
            }`}
          >
            {index + 1}. {label}
          </button>
        ))}
      </div>

      {/* ──────────────────  Treść kroków  ────────────────── */}
      {selectedMethod === 'paid' && (
        <>
          {currentStep === 0 && <PaidTriangleView />}
          {currentStep === 1 && <PaidCLCoefficientsPage />}

          {/* Krok 3 — Dopasowanie krzywej (CL/Sigma) */}
          {currentStep === 2 && <PaidFitCurveTabs />}

          {/* Krok 4 — Wybór krzywej (CL/Sigma/SD) */}
          {currentStep === 3 && <PaidSummaryTabs />}

          {/* Krok 5 — Wyniki */}
          {currentStep === 4 && <DeterminMethodCL />}
        </>
      )}

      {selectedMethod === 'incurred' && (
        <>
          {currentStep === 0 && <IncurredTriangleView />}
          {currentStep === 1 && <IncurredCLCoefficientsPage />}
          
          {/* Krok 3 — Dopasowanie krzywej (CL/Sigma) */}
          {currentStep === 2 && <IncurredFitCurveTabs />}
          
          {/* Krok 4 — Wybór krzywej (CL/Sigma/SD) */}
          {currentStep === 3 && <IncurredSummaryTabs />}
          
          {/* Krok 5 — Wyniki */}
          {currentStep === 4 && <DeterminMethodCLIncurred />}
        </>
      )}

      {selectedMethod === 'other1' && (
        <>
          {currentStep === 0 && <AddPaidTriangleView />}
          {currentStep === 1 && <AddPaidCoefficientsPage />}
          {currentStep === 2 && <AddPaidFitCurveTabs />}
          {currentStep === 3 && <AddSummaryTabs />}
          {currentStep === 4 && <DeterminMethodAddPaid />}
        </>
      )}

      {selectedMethod === 'other2' && (
        <>
          {currentStep === 0 && <PaidToIncurredPage />}
          {currentStep === 1 && <PaidIncurredFitCurveTabs />}
          {currentStep === 2 && <PaidIncurredSummaryTabs />}
        </>
      )}

      {/* ──────────────────  Pasek informacyjny  ────────────────── */}
      {currentStep > 1 && (
        <div className="p-4">
          <p>
            Metoda:{' '}
            <strong>{METHOD_TABS.find((t) => t.id === selectedMethod)?.label}</strong>, krok:{' '}
            <strong>{currentStepTabs[currentStep]}</strong>
          </p>
        </div>
      )}
    </div>
  );
}
