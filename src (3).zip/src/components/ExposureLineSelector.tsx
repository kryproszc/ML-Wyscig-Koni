'use client';

import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface Props {
  exposureData: { [rowIndex: number]: { [colIndex: number]: number | string | null } };
  selectedLine: number | null;
  onLineChange: (lineIndex: number | null) => void;
  showPreview?: boolean;
  className?: string;
}

export function ExposureLineSelector({ 
  exposureData, 
  selectedLine, 
  onLineChange, 
  showPreview = true,
  className = "" 
}: Props) {

  // Przygotuj dostępne linie z bieżących danych
  const generateAvailableLines = (data: { [rowIndex: number]: { [colIndex: number]: number | string | null } }) => {
    const lines: { index: number; label: string; values: (number | string | null)[] }[] = [];
    
    Object.keys(data).forEach(rowIndexStr => {
      const rowIndex = parseInt(rowIndexStr);
      const row = data[rowIndex];
      if (!row) return;
      
      // Pobierz label z pierwszej kolumny (kolumna 0)
      const labelValue = row[0];
      const label = labelValue !== null && labelValue !== undefined ? String(labelValue) : `Wiersz ${rowIndex + 1}`;
      
      // Pobierz wartości ze WSZYSTKICH kolumn OPRÓCZ kolumny 0 (etykiety)
      const values: (number | string | null)[] = [];
      const colKeys = Object.keys(row).map(Number).sort((a, b) => a - b);
      for (const colIndex of colKeys) {
        if (colIndex !== 0) { // Pomijamy TYLKO kolumnę 0 (etykiety), bierzemy wszystkie inne
          values.push(row[colIndex] ?? null);
        }
      }
      
      // Dodaj linię tylko jeśli ma jakieś wartości
      if (values.some(v => v !== null)) {
        lines.push({
          index: rowIndex,
          label,
          values
        });
      }
    });
    
    return lines;
  };

  const availableLines = generateAvailableLines(exposureData);

  if (availableLines.length === 0) {
    return null; // Nie pokazuj nic jeśli brak danych
  }

  return (
    <div className={className}>
      <div className="space-y-4">
        <div>
          <Label htmlFor="exposure-line-select">
            Wybierz linię ekspozycji (z pierwszej kolumny):
          </Label>
          <Select
            value={selectedLine?.toString() || ''}
            onValueChange={(value) => onLineChange(value ? parseInt(value) : null)}
          >
            <SelectTrigger id="exposure-line-select">
              <SelectValue placeholder="Wybierz linię..." />
            </SelectTrigger>
            <SelectContent>
              {availableLines.map((line) => (
                <SelectItem key={line.index} value={line.index.toString()}>
                  {line.label} ({line.values.filter(v => v !== null).length} wartości)
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Podgląd wybranych wartości */}
        {showPreview && selectedLine !== null && (
          <div className="mt-4">
            <Label>Podgląd wybranych wartości ekspozycji:</Label>
            <div className="bg-gray-100 p-3 rounded-md text-sm font-mono max-h-20 overflow-y-auto">
              {(() => {
                const selectedLineData = availableLines.find(l => l.index === selectedLine);
                return selectedLineData?.values.map((value, index) => (
                  <span key={index} className="mr-2">
                    {value !== null ? value.toString() : 'null'}
                  </span>
                )) || 'Brak danych';
              })()}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Te wartości zostaną wysłane jako ekspozycja do backend API.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}