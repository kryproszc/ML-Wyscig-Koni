'use client';

import React from 'react';
import ScaleControls from './ScaleControls';
import CoefficientTable from './CoefficientTable';
import ResultsTable from './ResultsTable';
import FullscreenOverlay from './FullscreenOverlay';

interface ResultRow {
  label: string;
  values: (number | null | undefined)[];
  visible?: boolean;
}

interface Props {
  // Page title and loading state
  title: string;
  isLoading?: boolean;
  loadingMessage?: string;
  noDataMessage?: string;

  // Main table data
  tableData: (string | number)[][];
  headerLabels: string[];
  rowLabels: string[];
  hasData: boolean;

  // Table interactions
  weights?: number[][];
  selectedCells?: [number, number][];
  minMaxCells?: [number, number][];
  minCells?: [number, number][];
  maxCells?: [number, number][];
  minMaxHighlighting?: boolean;
  showRowToggle?: boolean;
  onToggleRow?: (rowIndex: number) => void;
  onToggleWeightCell?: (r: number, c: number) => void;

  // Custom table component
  tableComponent?: React.ComponentType<any>;

  // Results table
  resultRows?: ResultRow[];
  resultsTitle?: string;
  decimalPlaces?: number;

  // Fullscreen
  fullscreenMode: boolean;
  isClosing: boolean;
  onCloseFullscreen: () => void;

  // Scale controls
  tableScale: number;
  onIncreaseScale: () => void;
  onDecreaseScale: () => void;

  // Volume and calculate
  volume: number;
  onVolumeChange: (volume: number) => void;
  onCalculate: () => void;
  calculateLabel?: string;

  // Sidebar
  sidebar: React.ReactNode;

  className?: string;
}

export default function CalculationPageLayout({
  title,
  isLoading = false,
  loadingMessage = "Oczekiwanie na dane...",
  noDataMessage = "Brak wyników 😢",
  tableData,
  headerLabels,
  rowLabels,
  hasData,
  weights,
  selectedCells,
  minMaxCells = [],
  minCells = [],
  maxCells = [],
  minMaxHighlighting = false,
  showRowToggle = true,
  onToggleRow,
  onToggleWeightCell,
  tableComponent,
  resultRows = [],
  resultsTitle,
  decimalPlaces = 6,
  fullscreenMode,
  isClosing,
  onCloseFullscreen,
  tableScale,
  onIncreaseScale,
  onDecreaseScale,
  volume,
  onVolumeChange,
  onCalculate,
  calculateLabel = "Oblicz",
  sidebar,
  className = "",
}: Props) {
  // Zawartość tabeli do wyświetlenia w obu trybach
  const TableContent = ({ fullscreen = false }: { fullscreen?: boolean }) => (
    <div 
      style={{ 
        transform: `scale(${tableScale})`, 
        transformOrigin: 'top left',
        width: `${100 / tableScale}%`,
        height: `${100 / tableScale}%`
      }}
    >
      {tableComponent ? (
        React.createElement(tableComponent, {
          data: tableData,
          headerLabels,
          rowLabels,
          weights,
          selectedCells,
          minMaxCells,
          minCells,
          maxCells,
          minMaxHighlighting,
          showRowToggle,
          onToggleRow,
          onToggleWeightCell,
          tableScale: 1, // Reset to 1 since scaling is handled by parent div
        })
      ) : (
        <CoefficientTable
          data={tableData}
          headerLabels={headerLabels}
          rowLabels={rowLabels}
          weights={weights}
          selectedCells={selectedCells}
          minMaxCells={minMaxCells}
          minCells={minCells}
          maxCells={maxCells}
          minMaxHighlighting={minMaxHighlighting}
          showRowToggle={showRowToggle}
          onToggleRow={onToggleRow}
          onToggleWeightCell={onToggleWeightCell}
          tableScale={1} // Reset to 1 since scaling is handled by parent div
        />
      )}

      {resultRows.length > 0 && (
        <ResultsTable
          title={resultsTitle}
          headerLabels={headerLabels}
          rows={resultRows}
          decimalPlaces={decimalPlaces}
          fullscreenMode={fullscreen}
          className="-mt-8"
        />
      )}
    </div>
  );

  if (!hasData) {
    return (
      <div className={`p-6 text-yellow-300 ${className}`}>
        ⏳ {loadingMessage}
      </div>
    );
  }

  return (
    <>
      {/* Normalny widok z panelem bocznym */}
      <div className={`flex gap-6 p-6 text-white ${className}`}>
        {/* Panel boczny */}
        {sidebar}

        {/* Główna część - elastyczna, minimalna szerokość 0 */}
        <div className="flex-1 min-w-0">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-xl font-bold">{title}</h2>
            
            {/* Kontrolki skalowania w nagłówku */}
            <div className="flex items-center gap-2">
              <span className="text-white text-sm">Skala:</span>
              <ScaleControls
                tableScale={tableScale}
                onIncreaseScale={onIncreaseScale}
                onDecreaseScale={onDecreaseScale}
                disabled={isLoading}
              />
            </div>
          </div>

          {hasData ? (
            <TableContent />
          ) : (
            <p className="text-yellow-400">{noDataMessage}</p>
          )}
        </div>
      </div>

      {/* Overlay pełnoekranowy */}
      <FullscreenOverlay
        isOpen={fullscreenMode}
        isClosing={isClosing}
        title={title}
        onClose={onCloseFullscreen}
        volume={volume}
        onVolumeChange={onVolumeChange}
        onCalculate={onCalculate}
        isLoading={isLoading}
        calculateLabel={calculateLabel}
        tableScale={tableScale}
        onIncreaseScale={onIncreaseScale}
        onDecreaseScale={onDecreaseScale}
      >
        {hasData ? <TableContent fullscreen={true} /> : <p className="text-yellow-400">{noDataMessage}</p>}
      </FullscreenOverlay>
    </>
  );
}