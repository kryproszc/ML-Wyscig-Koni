'use client';

import { Button } from '@/components/ui/button';
import { Plus, Minus } from 'lucide-react';

interface Props {
  tableScale: number;
  onIncreaseScale: () => void;
  onDecreaseScale: () => void;
  disabled?: boolean;
  className?: string;
}

export default function ScaleControls({
  tableScale,
  onIncreaseScale,
  onDecreaseScale,
  disabled = false,
  className = '',
}: Props) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <Button
        onClick={onDecreaseScale}
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
        disabled={disabled || tableScale <= 0.5}
      >
        <Minus className="w-4 h-4" />
      </Button>
      
      <span className="text-white text-sm min-w-[3rem] text-center">
        {Math.round(tableScale * 100)}%
      </span>
      
      <Button
        onClick={onIncreaseScale}
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
        disabled={disabled || tableScale >= 2.0}
      >
        <Plus className="w-4 h-4" />
      </Button>
    </div>
  );
}