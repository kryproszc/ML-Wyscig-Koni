import React from 'react';

// Shared calculation table components
export { default as CalculationPageLayout } from './CalculationPageLayout';
export { default as CalculationSidebar } from './CalculationSidebar';
export { default as CoefficientTable } from './CoefficientTable';
export { default as ResultsTable } from './ResultsTable';
export { default as ScaleControls } from './ScaleControls';
export { default as FullscreenOverlay } from './FullscreenOverlay';

// Types
export interface ResultRow {
  label: string;
  values: (number | null | undefined)[];
  visible?: boolean;
}

export interface SidebarSection {
  id: string;
  title: string;
  content: React.ReactNode;
}