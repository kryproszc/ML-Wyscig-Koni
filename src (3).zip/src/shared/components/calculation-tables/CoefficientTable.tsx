'use client';

import React from 'react';
import { TableDataDet } from '@/components/TableDataDet';

interface Props {
  data: (string | number)[][];
  headerLabels: string[];
  rowLabels: string[];
  weights?: number[][];
  selectedCells?: [number, number][];
  minMaxCells?: [number, number][];
  minCells?: [number, number][];
  maxCells?: [number, number][];
  minMaxHighlighting?: boolean;
  showRowToggle?: boolean;
  onToggleRow?: (rowIndex: number) => void;
  onToggleWeightCell?: (r: number, c: number) => void;
  tableScale?: number;
  className?: string;
}

export default function CoefficientTable({
  data,
  headerLabels,
  rowLabels,
  weights,
  selectedCells,
  minMaxCells = [],
  minCells = [],
  maxCells = [],
  minMaxHighlighting = false,
  showRowToggle = true,
  onToggleRow,
  onToggleWeightCell,
  tableScale = 1,
  className = "",
}: Props) {
  // Use data directly as it's already prepared
  const tableData = data;

  return (
    <div className={className}>
      <TableDataDet
        data={tableData}
        weights={weights}
        selectedCells={selectedCells}
        minMaxCells={minMaxHighlighting ? minMaxCells : []}
        minCells={minMaxHighlighting ? minCells : []}
        maxCells={minMaxHighlighting ? maxCells : []}
        showRowToggle={showRowToggle}
        onToggleRow={onToggleRow}
        onToggleWeightCell={onToggleWeightCell}
      />
    </div>
  );
}