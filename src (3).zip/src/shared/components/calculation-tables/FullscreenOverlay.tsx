'use client';

import React from 'react';
import { Button } from '@/components/ui/button';
import { Minimize2 } from 'lucide-react';
import ScaleControls from './ScaleControls';

interface Props {
  isOpen: boolean;
  isClosing: boolean;
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  
  // Volume controls
  volume: number;
  onVolumeChange: (volume: number) => void;
  
  // Calculate button
  onCalculate: () => void;
  isLoading: boolean;
  calculateLabel?: string;
  
  // Scale controls
  tableScale: number;
  onIncreaseScale: () => void;
  onDecreaseScale: () => void;
}

export default function FullscreenOverlay({
  isOpen,
  isClosing,
  title,
  onClose,
  children,
  volume,
  onVolumeChange,
  onCalculate,
  isLoading,
  calculateLabel = "Oblicz",
  tableScale,
  onIncreaseScale,
  onDecreaseScale,
}: Props) {
  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-gray-900 z-50 flex flex-col transition-all duration-300 ease-out"
      style={{
        animation: isClosing ? 'fadeOut 0.2s ease-in forwards' : 'fadeIn 0.3s ease-out'
      }}
    >
      {/* Górny pasek z przyciskiem zamknięcia */}
      <div 
        className="bg-gray-800 p-4 flex justify-between items-center border-b border-gray-700 transition-all duration-300 ease-out"
        style={{
          animation: isClosing 
            ? 'slideOutToTop 0.25s ease-in forwards' 
            : 'slideInFromTop 0.4s ease-out 0.1s both'
        }}
      >
        <h2 className="text-white text-lg font-medium">{title} - Widok pełnoekranowy</h2>
        
        <div className="flex items-center gap-4">
          {/* Kontrolki volume i oblicz */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <label className="text-white text-sm font-medium">Volume:</label>
              <input
                type="number"
                min="1"
                value={volume}
                onChange={(e) => onVolumeChange(Number(e.target.value))}
                className="w-16 px-2 py-1 bg-gray-700 border border-gray-600 rounded text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            
            <Button
              onClick={onCalculate}
              disabled={isLoading}
              variant="default"
              size="sm"
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {isLoading ? 'Obliczanie...' : calculateLabel}
            </Button>
          </div>
          
          {/* Kontrolki skalowania w trybie fullscreen */}
          <div className="flex items-center gap-2">
            <span className="text-white text-sm font-medium">Skala:</span>
            <ScaleControls
              tableScale={tableScale}
              onIncreaseScale={onIncreaseScale}
              onDecreaseScale={onDecreaseScale}
              disabled={isLoading}
            />
          </div>
          
          <Button
            onClick={onClose}
            variant="outline"
            size="sm"
            className="text-white border-gray-600 hover:bg-gray-700"
          >
            <Minimize2 className="w-4 h-4 mr-2" />
            Zamknij pełny ekran
          </Button>
        </div>
      </div>
      
      {/* Zawartość zajmująca całą dostępną przestrzeń */}
      <div 
        className="flex-1 p-6 overflow-auto bg-gray-900 transition-all duration-500 ease-out"
        style={{
          animation: isClosing 
            ? 'zoomOut 0.3s ease-in forwards'
            : 'zoomIn 0.5s ease-out 0.2s both'
        }}
      >
        {children}
      </div>
      
      {/* Style animacji - otwieranie i zamykanie */}
      <style jsx>{`
        /* Animacje otwierania */
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
        
        @keyframes slideInFromTop {
          from {
            transform: translateY(-20px);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }
        
        @keyframes zoomIn {
          from {
            transform: scale(0.95);
            opacity: 0;
          }
          to {
            transform: scale(1);
            opacity: 1;
          }
        }
        
        /* Animacje zamykania */
        @keyframes fadeOut {
          from {
            opacity: 1;
          }
          to {
            opacity: 0;
          }
        }
        
        @keyframes slideOutToTop {
          from {
            transform: translateY(0);
            opacity: 1;
          }
          to {
            transform: translateY(-20px);
            opacity: 0;
          }
        }
        
        @keyframes zoomOut {
          from {
            transform: scale(1);
            opacity: 1;
          }
          to {
            transform: scale(0.95);
            opacity: 0;
          }
        }
      `}</style>
    </div>
  );
}