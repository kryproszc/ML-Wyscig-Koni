'use client';

import React from 'react';

export interface ResultRow {
  label: string;
  values: (number | null | undefined)[];
  visible?: boolean;
}

interface Props {
  title?: string;
  headerLabels: string[];
  rows: ResultRow[];
  decimalPlaces: number;
  className?: string;
  fullscreenMode?: boolean;
}

export default function ResultsTable({
  title = "Wyniki obliczeń",
  headerLabels,
  rows,
  decimalPlaces,
  className = "",
  fullscreenMode = false,
}: Props) {
  console.log('📋 [ResultsTable] Otrzymane dane:', {
    title,
    rows: rows.map(r => ({
      label: r.label,
      values: r.values,
      valuesLength: r.values?.length,
      visible: r.visible,
      hasValues: r.values && r.values.some(v => v != null)
    })),
    headerLabels
  });

  // Pokaż tylko wiersze które są widoczne lub mają dane
  const visibleRows = rows.filter(row => 
    row.visible !== false && (row.values && row.values.some(v => v != null))
  );

  console.log('👁️ [ResultsTable] Widoczne wiersze:', visibleRows.map(r => r.label));

  if (visibleRows.length === 0) {
    return null;
  }

  const titleColor = "text-white";

  return (
    <div className={`mt-2 ${className}`}>
      <h3 className={`font-bold mb-2 ${titleColor}`}>{title}</h3>
      <table className="table-auto border-collapse border border-gray-700 text-white w-full">
        <thead>
          <tr>
            <th className="border border-gray-600 px-3 py-1 bg-slate-800 text-white">Typ</th>
            {headerLabels.map((label, i) => (
              <th key={i} className="border border-gray-600 px-3 py-1 bg-slate-800 text-center text-white">
                {label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {visibleRows.map((row, rowIndex) => (
            <tr key={row.label}>
              <td className="border border-gray-600 px-3 py-1 bg-slate-800 font-medium text-white">
                {row.label}
              </td>
              {row.values ? (
                <>
                  {row.values.map((value, i) => (
                    <td key={i} className="border border-gray-600 px-3 py-1 text-center font-mono bg-slate-900 text-white">
                      {value != null ? value.toFixed(decimalPlaces) : '-'}
                    </td>
                  ))}
                  {/* Wypełnij brakujące kolumny */}
                  {Array.from({ length: Math.max(0, headerLabels.length - row.values.length) }).map((_, i) => (
                    <td key={`empty-${row.label}-${i}`} className="border border-gray-600 px-3 py-1 text-center bg-slate-900 text-white">
                      -
                    </td>
                  ))}
                </>
              ) : (
                headerLabels.map((_, i) => (
                  <td key={i} className="border border-gray-600 px-3 py-1 text-center bg-slate-900 text-white">
                    -
                  </td>
                ))
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}