'use client';

import React from 'react';
import ScaleControls from './ScaleControls';

interface SidebarSection {
  id: string;
  title: string;
  content: React.ReactNode;
}

interface Props {
  // Volume controls
  volume: number;
  onVolumeChange: (volume: number) => void;
  
  // Action buttons
  onCalculate: () => void;
  onExport?: () => void;
  onReset?: () => void;
  isLoading?: boolean;
  calculateLabel?: string;
  
  // Scale controls
  tableScale: number;
  onIncreaseScale: () => void;
  onDecreaseScale: () => void;
  onFullscreen?: () => void;
  
  // Custom sections
  customSections?: SidebarSection[];
  
  // Modal states
  isResetModalOpen?: boolean;
  setResetModalOpen?: (open: boolean) => void;
  isMissingFinalModalOpen?: boolean;
  closeMissingFinalModal?: () => void;
  
  className?: string;
}

export default function CalculationSidebar({
  volume,
  onVolumeChange,
  onCalculate,
  onExport,
  onReset,
  isLoading = false,
  calculateLabel = "Oblicz",
  tableScale,
  onIncreaseScale,
  onDecreaseScale,
  onFullscreen,
  customSections = [],
  isResetModalOpen,
  setResetModalOpen,
  isMissingFinalModalOpen,
  closeMissingFinalModal,
  className = "",
}: Props) {
  return (
    <div className={`w-64 shrink-0 space-y-4 ${className}`}>
      {/* Custom sections pierwsza (np. miejsca po przecinku) */}
      {customSections.map((section) => (
        <div key={section.id} className="bg-gray-800 rounded-lg p-4">
          <div className="text-white text-sm font-medium mb-2 block">
            {section.title}
          </div>
          {section.content}
        </div>
      ))}

      {/* Panel Volume/Calculate/Export/Reset */}
      <div className="bg-gray-800 rounded-lg p-4 space-y-4">
        {/* Volume */}
        <div>
          <label className="text-white text-sm font-medium mb-2 block">
            Volume
          </label>
          <input
            type="number"
            min="1"
            value={volume}
            onChange={(e) => onVolumeChange(Number(e.target.value))}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        {/* Action buttons */}
        <div className="space-y-2">
          <button
            onClick={onCalculate}
            disabled={isLoading}
            className="w-full py-3 px-4 rounded-lg font-medium transition-colors bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white"
          >
            {isLoading ? 'Obliczanie...' : calculateLabel}
          </button>

          {onExport && (
            <button
              onClick={onExport}
              className="w-full py-3 px-4 rounded-lg font-medium transition-colors bg-green-600 hover:bg-green-700 text-white"
            >
              📊 Eksportuj do Excela
            </button>
          )}

          {onReset && (
            <button
              onClick={onReset}
              className="w-full py-3 px-4 rounded-lg font-medium transition-colors bg-red-600 hover:bg-red-700 text-white"
            >
              🔄 Reset współczynników
            </button>
          )}
        </div>
      </div>

      {/* Ustawienia wyświetlania */}
      <div className="bg-gray-800 rounded-lg p-4">
        <div className="text-white text-lg font-medium mb-4">
          Ustawienia wyświetlania
        </div>
        
        <div className="space-y-4">
          <div>
            <label className="text-white text-sm font-medium mb-2 block">
              Rozmiar tabeli
            </label>
            <ScaleControls
              tableScale={tableScale}
              onIncreaseScale={onIncreaseScale}
              onDecreaseScale={onDecreaseScale}
              disabled={isLoading}
            />
          </div>
          
          {onFullscreen && (
            <button
              onClick={onFullscreen}
              className="w-full py-2 px-4 rounded-lg font-medium transition-colors bg-red-600 hover:bg-red-700 text-white text-sm flex items-center justify-center gap-2"
            >
              <span>📺</span>
              Pełny ekran
            </button>
          )}
        </div>
      </div>
    </div>
  );
}