'use client';

import React from 'react';
import { formatPolishNumber } from '@/shared/utils';

interface ResultColumn {
  key: string;
  header: string;
  data: number[];
  show: boolean;
}

interface ResultsTableProps {
  title: string;
  subtitle?: string;
  columns: ResultColumn[];
  userId?: string | null;
  resultsUserId?: string | null;
  shouldShowResults?: boolean;
  className?: string;
}

const formatNumber = (value: number) => formatPolishNumber(value, 2);

export function ResultsTable({ 
  title, 
  subtitle, 
  columns, 
  userId, 
  resultsUserId, 
  shouldShowResults = true,
  className = ""
}: ResultsTableProps) {
  
  // Sprawdź czy wszystkie dane istnieją
  const hasAnyData = columns.some(col => col.data && col.data.length > 0);
  
  if (!hasAnyData) {
    return (
      <div className="bg-slate-800 rounded-lg border border-slate-600 p-8">
        <h3 className="text-2xl font-bold text-white mb-4">Wyniki Obliczeń</h3>
        <p className="text-gray-400">Brak kompletnych danych do wyświetlenia</p>
      </div>
    );
  }

  // Znajdź maksymalną długość
  const maxLength = Math.max(...columns.map(col => col.data?.length || 0));

  // Sprawdź które kolumny mają prawidłowe dane
  const columnsWithValidData = columns.map(col => ({
    ...col,
    hasValidData: col.data && col.data.length > 0 && col.data.some(val => 
      typeof val === 'number' && Number.isFinite(val)
    )
  }));

  // Sprawdź czy wyniki są ważne (dla użytkownika)
  const resultsAreValid = (!userId || !resultsUserId || resultsUserId === userId) && shouldShowResults;

  // Określ które kolumny pokazać
  const visibleColumns = columnsWithValidData.filter(col => 
    col.hasValidData && col.show && resultsAreValid
  );

  // Debug info
  console.log('🔍 Wyświetlane kolumny:', 
    Object.fromEntries(visibleColumns.map(col => [col.header, '✅']))
  );
  console.log('📊 Walidacja wyników:', {
    resultsUserId,
    currentUserId: userId,
    shouldShowResults,
    resultsAreValid
  });

  return (
    <div className={`bg-slate-800 rounded-lg border border-slate-600 overflow-hidden ${className}`}>
      {/* Nagłówek tabeli */}
      <div className="bg-gradient-to-r from-slate-700 to-slate-600 px-8 py-6">
        <h2 className="text-2xl font-bold text-white">{title}</h2>
        {subtitle && <p className="text-slate-300 mt-2">{subtitle}</p>}
      </div>

      {/* Tabela */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-slate-700 border-b border-slate-600">
            <tr>
              <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider border-r border-slate-600">
                Okres
              </th>
              {visibleColumns.map((col, index) => (
                <th key={col.key} className={`px-6 py-4 text-center text-xs font-semibold text-slate-300 uppercase tracking-wider ${
                  index < visibleColumns.length - 1 ? 'border-r border-slate-600' : ''
                }`}>
                  {col.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-slate-800 divide-y divide-slate-600">
            {Array.from({ length: maxLength }, (_, index) => (
              <tr key={index} className="hover:bg-slate-700 transition-colors duration-150 ease-in-out">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white border-r border-slate-600">
                  {index + 1}
                </td>
                {visibleColumns.map((col, colIndex) => (
                  <td key={col.key} className={`px-6 py-4 whitespace-nowrap text-sm text-slate-200 text-center font-mono ${
                    colIndex < visibleColumns.length - 1 ? 'border-r border-slate-600' : ''
                  }`}>
                    {col.data[index] !== undefined 
                      ? (typeof col.data[index] === 'number' 
                          ? formatNumber(col.data[index])
                          : String(col.data[index]))
                      : '-'
                    }
                  </td>
                ))}
              </tr>
            ))}
            
            {/* Wiersz z sumą */}
            <tr className="bg-slate-600 border-t-2 border-slate-500">
              <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-white border-r border-slate-500">
                SUMA
              </td>
              {visibleColumns.map((col, colIndex) => {
                const sum = col.data
                  .filter(val => typeof val === 'number')
                  .reduce((sum, val) => sum + val, 0);
                
                return (
                  <td key={col.key} className={`px-6 py-4 whitespace-nowrap text-sm font-bold text-white text-center font-mono ${
                    colIndex < visibleColumns.length - 1 ? 'border-r border-slate-500' : ''
                  }`}>
                    {formatNumber(sum)}
                  </td>
                );
              })}
            </tr>
          </tbody>
        </table>
      </div>

      {/* Stopka tabeli */}
      <div className="bg-slate-700 px-8 py-4 border-t border-slate-600">
        <div className="flex justify-between items-center text-sm text-slate-300">
          <span>Łącznie {maxLength} okresów</span>
        </div>
      </div>
    </div>
  );
}