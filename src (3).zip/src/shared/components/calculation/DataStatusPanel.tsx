'use client';

import React from 'react';
import { DataStatusItem } from './DataStatusItem';

interface DataStatusPanelProps {
  title?: string;
  subtitle?: string;
  statusItems: Array<{
    label: string;
    isLoaded: boolean;
  }>;
  className?: string;
}

export function DataStatusPanel({ 
  title = "📊 Status Danych",
  subtitle = "Dostępne dane do obliczeń",
  statusItems,
  className = ""
}: DataStatusPanelProps) {
  return (
    <div className={`space-y-6 ${className}`}>
      {/* Nagłówek Panel */}
      <div>
        <h2 className="text-xl font-bold text-white mb-4">{title}</h2>
        <p className="text-sm text-gray-400">{subtitle}</p>
      </div>

      {/* Status danych */}
      <div className="space-y-3">
        {statusItems.map((item, index) => (
          <DataStatusItem
            key={index}
            label={item.label}
            isLoaded={item.isLoaded}
          />
        ))}
      </div>
    </div>
  );
}