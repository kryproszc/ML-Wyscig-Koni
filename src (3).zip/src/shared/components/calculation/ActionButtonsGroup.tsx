'use client';

import React from 'react';

interface ActionButton {
  label: string;
  onClick: () => void;
  disabled?: boolean;
  variant?: 'primary' | 'secondary' | 'danger' | 'info';
  icon?: string;
}

interface ActionButtonsGroupProps {
  buttons: ActionButton[];
  className?: string;
}

const getButtonStyles = (variant: ActionButton['variant'], disabled?: boolean) => {
  if (disabled) {
    return 'bg-gray-600 cursor-not-allowed text-white';
  }
  
  switch (variant) {
    case 'primary':
      return 'bg-green-600 hover:bg-green-700 text-white';
    case 'secondary':
      return 'bg-gray-600 hover:bg-gray-700 text-white';
    case 'danger':
      return 'bg-red-600 hover:bg-red-700 text-white';
    case 'info':
      return 'bg-blue-600 hover:bg-blue-700 text-white';
    default:
      return 'bg-gray-600 hover:bg-gray-700 text-white';
  }
};

export function ActionButtonsGroup({ buttons, className = "" }: ActionButtonsGroupProps) {
  return (
    <div className={`space-y-3 pt-4 ${className}`}>
      {buttons.map((button, index) => (
        <button
          key={index}
          onClick={button.onClick}
          disabled={button.disabled}
          className={`w-full py-3 px-4 rounded-lg transition-colors font-medium ${getButtonStyles(button.variant, button.disabled)}`}
        >
          {button.icon && `${button.icon} `}{button.label}
        </button>
      ))}
    </div>
  );
}