'use client';

import React from 'react';

interface SuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  message?: string;
  buttonText?: string;
}

export function SuccessModal({ 
  isOpen, 
  onClose, 
  title = "Obliczenia zakończone pomyślnie!",
  message,
  buttonText = "OK"
}: SuccessModalProps) {
  if (!isOpen) return null;

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-slate-900 bg-opacity-20 flex items-center justify-center z-50"
      onClick={handleBackdropClick}
    >
      <div className="bg-slate-800 rounded-lg border border-slate-600 p-8 max-w-md w-full mx-4 transform transition-all animate-in fade-in zoom-in duration-300">
        {/* Ikona sukcesu */}
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center">
            <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
            </svg>
          </div>
        </div>

        {/* Tytuł */}
        <h2 className="text-2xl font-bold text-white text-center mb-4">
          {title}
        </h2>

        {/* Opcjonalna wiadomość */}
        {message && (
          <p className="text-gray-300 text-center mb-6">
            {message}
          </p>
        )}

        {/* Przycisk zamknięcia */}
        <button
          onClick={onClose}
          className="w-full bg-green-600 hover:bg-green-700 text-white py-3 px-6 rounded-lg font-medium transition-colors"
        >
          {buttonText}
        </button>
      </div>
    </div>
  );
}