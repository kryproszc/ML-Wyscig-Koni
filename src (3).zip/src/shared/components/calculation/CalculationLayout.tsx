'use client';

import React from 'react';

interface CalculationLayoutProps {
  sidebar: React.ReactNode;
  children: React.ReactNode;
  sidebarWidth?: string;
  className?: string;
}

export function CalculationLayout({ 
  sidebar, 
  children, 
  sidebarWidth = "w-80",
  className = ""
}: CalculationLayoutProps) {
  return (
    <div className={`flex h-full min-h-screen bg-[#0f172a] ${className}`}>
      {/* Sidebar Panel */}
      <aside className={`${sidebarWidth} bg-[#1e293b] border-r border-gray-700 p-6 sticky top-0 h-screen overflow-y-auto`}>
        {sidebar}
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-8 bg-[#0f172a] min-h-screen">
        <div className="w-full max-w-none">
          {children}
        </div>
      </main>
    </div>
  );
}