'use client';

import React from 'react';

interface DataStatusItemProps {
  label: string;
  isLoaded: boolean;
  className?: string;
}

export function DataStatusItem({ label, isLoaded, className = "" }: DataStatusItemProps) {
  return (
    <div className={`flex items-center gap-3 p-3 rounded-lg bg-slate-800 ${className}`}>
      <div className={`w-3 h-3 rounded-full ${isLoaded ? 'bg-green-500' : 'bg-red-500'}`}></div>
      <div className="flex-1">
        <div className="text-sm font-medium text-white">{label}</div>
        <div className="text-xs text-gray-400">
          {isLoaded ? '✅ Wczytane' : '❌ Brak danych'}
        </div>
      </div>
    </div>
  );
}