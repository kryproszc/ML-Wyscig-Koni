'use client';

import React from 'react';

interface EmptyStateProps {
  title: string;
  description: string;
  icon?: React.ReactNode;
  actionButton?: {
    label: string;
    onClick: () => void;
    disabled?: boolean;
  };
  className?: string;
}

const DefaultIcon = () => (
  <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
  </svg>
);

export function EmptyState({ 
  title, 
  description, 
  icon,
  actionButton,
  className = ""
}: EmptyStateProps) {
  return (
    <div className={`bg-slate-800 rounded-lg border border-slate-700 p-12 text-center ${className}`}>
      <div className="max-w-md mx-auto">
        <div className="w-16 h-16 bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-4">
          {icon || <DefaultIcon />}
        </div>
        
        <h2 className="text-2xl font-semibold text-white mb-4">{title}</h2>
        
        <div className="text-gray-400 mb-6" dangerouslySetInnerHTML={{ __html: description }} />
        
        {actionButton && (
          <button
            onClick={actionButton.onClick}
            disabled={actionButton.disabled}
            className={`px-6 py-3 rounded-lg font-medium transition-colors ${
              actionButton.disabled 
                ? 'bg-gray-600 cursor-not-allowed text-gray-400' 
                : 'bg-blue-600 hover:bg-blue-700 text-white'
            }`}
          >
            {actionButton.label}
          </button>
        )}
      </div>
    </div>
  );
}