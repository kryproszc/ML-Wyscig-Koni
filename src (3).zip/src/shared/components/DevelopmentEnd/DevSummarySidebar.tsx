/* ------------------------------------------------------------------ */
/*                         DevSummarySidebar                         */
/* ------------------------------------------------------------------ */

import React from 'react'

interface DevSummarySidebarProps {
  leftCount: number
  setLeftCount: (count: number) => void
}

export function DevSummarySidebar({ leftCount, setLeftCount }: DevSummarySidebarProps) {
  const handleLeftCountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value)
    if (!Number.isNaN(val) && val >= 0) setLeftCount(val)
  }

  return (
    <aside className="w-64 shrink-0 bg-gray-900 border-r border-gray-800 p-6 flex flex-col gap-6">
      <h3 className="text-lg font-semibold">Ustawienia</h3>
      <label className="flex flex-col gap-2 text-sm font-medium">
        <span>Ilość pozostawionych</span>
        <input
          type="number"
          min={0}
          value={leftCount}
          onChange={handleLeftCountChange}
          className="bg-gray-600 border border-gray-500 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-600/60"
        />
      </label>
    </aside>
  )
}
