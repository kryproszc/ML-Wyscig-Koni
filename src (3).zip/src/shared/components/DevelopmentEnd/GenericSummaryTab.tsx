/* ------------------------------------------------------------------ */
/*                        GenericSummaryTab                           */
/* ------------------------------------------------------------------ */
"use client"

import React, { useMemo, useEffect } from "react";
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny'
import { useLabelsStore } from '@/stores/useLabelsStore'
import { DevSummaryLayout } from './DevSummaryLayout'
import type { SummaryConfig } from '@/shared/types/summaryConfig'

interface GenericSummaryTabProps {
  config: SummaryConfig
}

export function GenericSummaryTab({ config }: GenericSummaryTabProps) {
  // Wybierz store hook z konfiguracji lub domyślny
  const storeHook = config.useStore || useTrainDevideStoreDet
  
  // Store selectors - używamy konfiguracji do wybrania odpowiednich selektorów
  const leftCount = storeHook(config.leftCountSelector)
  const setLeftCount = storeHook(config.setLeftCountSelector)
  const selectedCurve = storeHook(config.selectedCurveSelector)
  const setSelectedCurve = storeHook(config.setSelectedCurveSelector)
  const manualOverrides = storeHook(config.manualOverridesSelector)
  const setManualOverrides = storeHook(config.setManualOverridesSelector)
  const sourceSwitches = storeHook(config.sourceSwitchesSelector)
  const setSourceSwitches = storeHook(config.setSourceSwitchesSelector)
  const baseData = storeHook(config.baseDataSelector)
  const rawSimResults = storeHook(config.simResultsSelector)
  const selectedValues = config.selectedValuesSelector ? storeHook(config.selectedValuesSelector) : undefined
  const setCombinedData = storeHook(config.setCombinedDataSelector)
  const setRemainingHeaders = storeHook(config.setRemainingHeadersSelector)

  // Debug log z konfiguracją
  useEffect(() => {
    if (config.debugLabel) {
      console.log(`🚨 ${config.debugLabel} - selectedCurve:`, selectedCurve)
    }
  }, [selectedCurve, config.debugLabel])

  // Transformacja danych bazowych (np. pierwiastek dla SD)
  const transformedBaseData = useMemo(() => {
    if (config.transformBaseData) {
      return config.transformBaseData(baseData, leftCount)
    }
    return baseData
  }, [baseData, leftCount, config.transformBaseData])

  // Transformacja wyników symulacji
  const simResults = useMemo(() => {
    if (config.transformSimResults && rawSimResults) {
      return config.transformSimResults(rawSimResults)
    }
    return rawSimResults
  }, [rawSimResults, config.transformSimResults])

  // Labels from store
  const rawDetColumnLabels = useLabelsStore(s => s.detColumnLabels)
  const detColumnLabels = useMemo(
    () => ["", ...rawDetColumnLabels],
    [rawDetColumnLabels]
  )

  console.log(`${config.tableContext} detColumnLabels:`, detColumnLabels)
  console.log(`${config.tableContext} selected_value_cl:`, selectedValues)

  return (
    <DevSummaryLayout
      leftCount={leftCount}
      setLeftCount={setLeftCount}
      selectedCurve={selectedCurve}
      setSelectedCurve={setSelectedCurve}
      manualOverrides={manualOverrides}
      setManualOverrides={setManualOverrides}
      sourceSwitches={sourceSwitches}
      setSourceSwitches={setSourceSwitches}
      devJPreview={transformedBaseData}
      simResults={simResults}
      setCombinedDevJ={setCombinedData}
      columnLabels={detColumnLabels}
      onRemainingDevJHeaders={setRemainingHeaders}
      disabledCurves={config.disabledCurves || []}
      tableContext={config.tableContext}
      storeHook={storeHook} // 🆕 Przekaż store hook
    />
  )
}