/* ------------------------------------------------------------------ */
/*                           FinalTable                               */
/* ------------------------------------------------------------------ */

import React, { useCallback, useEffect, useMemo } from 'react'
import type { FinalTableProps } from '@/shared/types/developmentEnd'
import { useDevSummaryEditing } from '@/shared/hooks/useDevSummaryEditing'
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny'
import { useAddPaidStore } from '@/stores/addPaidStore'

type SimResults = Record<string, Record<string, number>>

export function FinalTable({
  combinedDevJ,
  maxLen,
  leftCount,
  columnLabels,
  manualOverrides,
  setManualOverrides,
  sourceSwitches,
  setSourceSwitches,
  selectedCurve,            // string | null
  devJPreview,              // <-- dodane dla oryginalnych wartości Initial Selection
  simResults,               // <-- przekaż z DevSummaryLayout
  onHeadersGenerated,
  onManualEdit,             // <-- nowy callback
  tableContext = 'CL',      // 🆕 DEFAULT to CL
  setCombinedDevJ,          // 🔧 DODANE: Setter dla combinedSigmaSummary/combinedCL
  storeHook                 // 🆕 Store hook dla dynamic store access
}: FinalTableProps & { simResults?: SimResults }) {
  const {
    editingIndex,
    editValue,
    setEditValue,
    startEditing,
    stopEditing, // eslint-disable-line @typescript-eslint/no-unused-vars
    saveEdit,
    clearManualOverride
  } = useDevSummaryEditing()

  // 🎯 Hooks do store - używaj storeHook jeśli dostępny, inaczej domyślny
  const defaultStore = useTrainDevideStoreDet
  const activeStore = storeHook || defaultStore
  
  // 🎯 Hooks do store - różne settery w zależności od kontekstu
  // MultPaid selectors
  const setSelectedValuesCL = activeStore(s => s.setSelectedValuesCL)
  const setSelectedValuesSigma = activeStore(s => s.setSelectedValuesSigma || useTrainDevideStoreDet(state => state.setSelectedValuesSigma))
  const setSelectedValuesSD = activeStore(s => s.setSelectedValuesSD || useTrainDevideStoreDet(state => state.setSelectedValuesSD))
  const setSelectedValuesRJPaidToIncurred = activeStore(s => s.setSelectedValuesRJPaidToIncurred) // 🆕 DODANO r_j PaidToIncurred
  const setSelectedValuesVarJPaidToIncurred = activeStore(s => s.setSelectedValuesVarJPaidToIncurred) // 🆕 DODANO var_j PaidToIncurred
  
  // AddPaid selectors
  const setSelectedValuesAddLR = useAddPaidStore(s => s.setSelectedValuesAddLR)
  const setSelectedValuesAddSigma = useAddPaidStore(s => s.setSelectedValuesAddSigma)
  const setSelectedValuesAddSD = useAddPaidStore(s => s.setSelectedValuesAddSD)

  const curveShort = (name?: string | null): string => {
    if (!name) return ''
    if (name === 'Initial Selection') return '' // nigdy nie prefiksujemy Initial
    switch (name) {
      case 'Exponential': return 'E'
      case 'Weibull': return 'W'
      case 'Power': return 'P'
      case 'Inverse Power': return 'IP'
      default: return name.charAt(0)
    }
  }

  const approxEqual = (a: number, b: number) => {
    if (!Number.isFinite(a) || !Number.isFinite(b)) return false
    if (a.toFixed(6) === b.toFixed(6)) return true
    return Math.abs(a - b) <= 1e-9 * Math.max(1, Math.abs(a), Math.abs(b))
  }

  // ---- helpers dla manualOverrides ----
  const pickOverrideNumber = (ov: unknown): number | undefined => {
    if (ov == null) return undefined
    if (typeof ov === 'number') return Number.isFinite(ov) ? ov : undefined
    if (typeof ov === 'string') {
      const s = ov.trim()
      if (s === '') return undefined
      const n = Number(s)
      return Number.isFinite(n) ? n : undefined
    }
    if (typeof ov === 'object' && 'value' in (ov as any)) {
      const raw = (ov as any).value
      if (typeof raw === 'number') return Number.isFinite(raw) ? raw : undefined
      if (typeof raw === 'string') {
        const s = raw.trim()
        if (s === '') return undefined
        const n = Number(s)
        return Number.isFinite(n) ? n : undefined
      }
    }
    return undefined
  }

  const pickOverrideCurve = (ov: unknown): string | undefined => {
    if (ov && typeof ov === 'object' && 'curve' in (ov as any)) {
      const c = (ov as any).curve
      if (typeof c === 'string' && c.trim() !== '') return c
    }
    return undefined
  }

// Pobierz wartość z danej krzywej dla kolumny idx (dp: idx+1 / k: idx+1 / plain)
const getCurveValue = useCallback((idx: number, curve?: string | null): number | undefined => {
  if (!curve) return undefined

  // Initial Selection = wartości bazowe BEZPOŚREDNIO z devJPreview!
  if (curve === 'Initial Selection') {
    const originalValue = devJPreview?.[idx]
    return originalValue !== undefined && Number.isFinite(originalValue) ? originalValue : undefined
  }

  // spróbuj kilku wariantów klucza kolumny
  const n = idx + 1
  const candidates = [
    `k: ${n}`,      // format z tabeli dopasowanych krzywych - PIERWSZEŃSTWO
    `dp: ${n}`,     // wcześniejszy format
    `${n}`,         // czysty numer jako string
  ]

  const row = simResults?.[curve]
  if (!row) return undefined

  for (const key of candidates) {
    const v = row[key as keyof typeof row]
    if (Number.isFinite(v)) return v as number
  }
  return undefined
}, [devJPreview, simResults])

// Oblicz efektywną długość tabeli - gdy nie ma krzywej, ogranicz do devJPreview
const effectiveMaxLen = useMemo(() => {
  if (!selectedCurve && devJPreview?.length) {
    return devJPreview.length
  }
  return maxLen
}, [selectedCurve, devJPreview, maxLen])

const effectiveValues = useMemo(
  () => {
    return Array.from({ length: effectiveMaxLen }, (_, i) => {
      const switchedCurve = sourceSwitches?.[i]?.curve
      const overrideCurve = pickOverrideCurve(manualOverrides?.[i])
      const manualValue = pickOverrideNumber(manualOverrides?.[i])
      const isInLeftPart = i < leftCount

      // PRIORYTET 1: Jeśli jest switchedCurve (kliknięto w tabeli krzywych)
      if (switchedCurve) {
        if (switchedCurve === 'Initial Selection') {
          // User explicite wybrał Initial Selection - użyj oryginalnych wartości z devJPreview!
          const originalValue = devJPreview?.[i]
          return originalValue !== undefined && Number.isFinite(originalValue) ? originalValue : NaN
        } else {
          // → ZAWSZE używamy krzywej, ignorujemy ręczne nadpisania
          const fromSwitched = getCurveValue(i, switchedCurve)
          if (fromSwitched !== undefined) return fromSwitched
        }
      }

      // PRIORYTET 2: Ręczna wartość liczbowa (w tym curve: "manual") - MA PRIORYTET NAD KRZYWYMI
      if (manualValue !== undefined && (overrideCurve === 'manual' || !overrideCurve)) {
        return manualValue
      }

      // PRIORYTET 3: Override krzywej z manualOverrides (ale nie manual)
      if (overrideCurve && overrideCurve !== 'manual' && !switchedCurve) {
        const fromOverride = getCurveValue(i, overrideCurve)
        if (fromOverride !== undefined) return fromOverride
      }

      // PRIORYTET 4: Jeśli NIE MA wybranej krzywej (selectedCurve jest null), 
      // zawsze używaj Initial Selection dla WSZYSTKICH kolumn
      if (!selectedCurve) {
        const originalValue = devJPreview?.[i]
        if (originalValue !== undefined && Number.isFinite(originalValue)) {
          return originalValue
        }
      }

      // PRIORYTET 5: Dla prawej części (>= leftCount) - zawsze globalna krzywa (gdy jest wybrana)
      if (!isInLeftPart && selectedCurve) {
        const fromGlobal = getCurveValue(i, selectedCurve)
        if (fromGlobal !== undefined) {
          return fromGlobal
        }
      }

      // PRIORYTET 6: Initial Selection jest DOMYŚLNE dla lewej części
      // Używaj Initial Selection, chyba że user explicite wybrał krzywą
      const hasNoSourceSwitch = !(i in (sourceSwitches || {}))
      const hasInitialSelectionSwitch = sourceSwitches?.[i]?.curve === 'Initial Selection'
      
      // Dla lewej części - Initial Selection ma priorytet (domyślne zachowanie)
      if (isInLeftPart && (hasNoSourceSwitch || hasInitialSelectionSwitch)) {
        const originalValue = devJPreview?.[i]
        if (originalValue !== undefined && Number.isFinite(originalValue)) {
          return originalValue
        }
      }

      // PRIORYTET 7: Globalna krzywa dla lewej części - tylko gdy brak Initial Selection
      if (isInLeftPart && selectedCurve && !hasNoSourceSwitch && !hasInitialSelectionSwitch && !manualValue) {
        const fromGlobal = getCurveValue(i, selectedCurve)
        if (fromGlobal !== undefined) return fromGlobal
      }
      
      // Ostateczny fallback - combinedDevJ
      const base = Number(combinedDevJ[i])
      return Number.isFinite(base) ? base : NaN
    })
  },
  [effectiveMaxLen, sourceSwitches, manualOverrides, combinedDevJ, getCurveValue, selectedCurve, leftCount, devJPreview]
)


  const findSourceCurve = useCallback((idx: number, value: number): string | null => {
    if (!simResults) return null
    const dpKey = `dp: ${idx + 1}`
    for (const [curve, dpMap] of Object.entries(simResults)) {
      const v = dpMap?.[dpKey]
      if (Number.isFinite(v) && approxEqual(v as number, value)) return curve
    }
    return null
  }, [simResults])

  const getInitialSelectionIndex = (idx: number): number | undefined => {
    const raw = columnLabels[idx + 2]
    const n = Number(raw)
    return Number.isFinite(n) ? n : undefined
  }

  // Wykryj krzywą dla nagłówka
  const detectPrefCurve = useCallback(
    (idx: number): string => {
      const switched = sourceSwitches?.[idx]?.curve
      const ovCurve  = pickOverrideCurve(manualOverrides?.[idx])
      const manualValue = pickOverrideNumber(manualOverrides?.[idx])
      const isInLeftPart = idx < leftCount
      
      // PRIORYTET 1: switchedCurve (kliknięto w tabeli) - ZAWSZE ma najwyższy priorytet
      if (switched) {
        // Jeśli user explicite wybrał Initial Selection, nie pokazuj prefiksu
        if (switched === 'Initial Selection') return ''
        return switched
      }

      // PRIORYTET 2: ręczne nadpisanie (curve: "manual")
      if (ovCurve === 'manual' && manualValue !== undefined) return 'D'

      // PRIORYTET 3: override krzywej (ale tylko jeśli nie ma switched i nie jest manual)
      if (ovCurve && ovCurve !== 'manual' && !switched) return ovCurve

      // PRIORYTET 4: Jeśli nie ma wybranej krzywej (selectedCurve === null), zawsze Initial Selection
      if (!selectedCurve) return ''

      // PRIORYTET 5: selectedCurve (globalna) tylko dla prawej części lub gdy nie ma wpisu w sourceSwitches
      if (!isInLeftPart && selectedCurve) return selectedCurve
      if (isInLeftPart && selectedCurve && !(idx in (sourceSwitches || {}))) return selectedCurve

      // PRIORYTET 6: wykryj krzywą na podstawie wartości
      const detected =
        Number.isFinite(effectiveValues[idx])
          ? findSourceCurve(idx, Number(effectiveValues[idx]))
          : null

      return detected ?? ''
    },
    [sourceSwitches, manualOverrides, effectiveValues, findSourceCurve, selectedCurve, leftCount]
  )

  // --------- Nagłówki ----------
  const generatedHeaders = useMemo(() => {
    const headers: string[] = []

    for (let idx = 0; idx < effectiveMaxLen; idx++) {
      const globalK = idx + 1
      const baseLabel: string = (columnLabels[idx + 2] ?? `j=${idx}`) as string

      const switchedCurve = sourceSwitches[idx]?.curve
      const overrideCurve = pickOverrideCurve(manualOverrides?.[idx])

      // czy user zmienił tę kolumnę?
      const hasUserChange =
        Boolean(switchedCurve) ||
        pickOverrideNumber(manualOverrides?.[idx]) !== undefined ||
        overrideCurve !== undefined

      // domyślny indeks k:<...>
      const initialIdx = getInitialSelectionIndex(idx)
      const kIndex = !hasUserChange && idx < leftCount && initialIdx !== undefined
        ? initialIdx
        : globalK

      const isLeft = idx < leftCount
      const prefCurve = isLeft && !hasUserChange ? '' : detectPrefCurve(idx)
      const pref = curveShort(prefCurve ?? '')

      const label =
        pref
          ? `${pref}:k:${kIndex}`
          : (isLeft ? baseLabel : `k:${kIndex}`)

      headers.push(label)
    }

    return headers
  }, [
    effectiveMaxLen,
    leftCount,
    columnLabels,
    sourceSwitches,
    manualOverrides,
    effectiveValues,
    selectedCurve,
    detectPrefCurve
  ])

  useEffect(() => {
    onHeadersGenerated?.(generatedHeaders)
  }, [generatedHeaders, onHeadersGenerated])

  // 🎯 ZAPISUJ effectiveValues do odpowiedniego store w zależności od kontekstu
  useEffect(() => {
    const validValues = effectiveValues
      .map(val => typeof val === 'number' && Number.isFinite(val) ? val : NaN)
      .filter(val => !isNaN(val))
    
    if (validValues.length > 0) {
      // 🎯 WYBIERZ WŁAŚCIWY SETTER W ZALEŻNOŚCI OD KONTEKSTU
      if (tableContext === 'Sigma' || tableContext === 'Sigma (Incurred)') {
        setSelectedValuesSigma(validValues)
        if (setCombinedDevJ) {
          setCombinedDevJ(validValues)
        }
      } else if (tableContext === 'SD' || tableContext === 'SD (Incurred)') {
        // 🎯 KONTEKST SD - zapisz do selectedValuesSD i combinedSDSummary
        setSelectedValuesSD(validValues)
        if (setCombinedDevJ) {
          setCombinedDevJ(validValues)
        }
        console.log('📊 Tabela współczynników Selected Value')
        console.log('Selected Value\t' + effectiveValues.join('\t'))
      } else if (tableContext === 'AddLR') {
        // 🎯 KONTEKST AddLR - zapisz do AddPaid store
        setSelectedValuesAddLR(validValues)
        if (setCombinedDevJ) {
          setCombinedDevJ(validValues)
        }
        console.log('📊 Tabela współczynników Selected Value (AddLR)')
        console.log('Selected Value\t' + effectiveValues.join('\t'))
      } else if (tableContext === 'AddSigma') {
        // 🎯 KONTEKST AddSigma - zapisz do AddPaid store
        setSelectedValuesAddSigma(validValues)
        if (setCombinedDevJ) {
          setCombinedDevJ(validValues)
        }
        console.log('📊 Tabela współczynników Selected Value (AddSigma)')
        console.log('Selected Value\t' + effectiveValues.join('\t'))
      } else if (tableContext === 'AddSD') {
        // 🎯 KONTEKST AddSD - zapisz do AddPaid store
        setSelectedValuesAddSD(validValues)
        if (setCombinedDevJ) {
          setCombinedDevJ(validValues)
        }
        console.log('📊 Tabela współczynników Selected Value (AddSD)')
        console.log('Selected Value\t' + effectiveValues.join('\t'))
      } else if (tableContext === 'r_j (PaidToIncurred)') {
        // 🎯 KONTEKST r_j PaidToIncurred - zapisz do selectedValuesRJPaidToIncurred
        setSelectedValuesRJPaidToIncurred(validValues)
        if (setCombinedDevJ) {
          setCombinedDevJ(validValues)
        }
        console.log('📊 Tabela współczynników Selected Value (r_j PaidToIncurred)')
        console.log('Selected Value\t' + effectiveValues.join('\t'))
      } else if (tableContext === 'var_j (PaidToIncurred)') {
        // 🎯 KONTEKST var_j PaidToIncurred - zapisz do selectedValuesVarJPaidToIncurred
        setSelectedValuesVarJPaidToIncurred(validValues)
        if (setCombinedDevJ) {
          setCombinedDevJ(validValues)
        }
        console.log('📊 Tabela współczynników Selected Value (var_j PaidToIncurred)')
        console.log('Selected Value\t' + effectiveValues.join('\t'))
      } else if (tableContext?.startsWith('CL')) {
        // 🎯 KONTEKST CL (domyślny) - obsługuje 'CL' i 'CL (Incurred)'
        setSelectedValuesCL(validValues)
        if (setCombinedDevJ) {
          setCombinedDevJ(validValues)
        }
      }
    }
  }, [effectiveValues, setSelectedValuesCL, setSelectedValuesSigma, setSelectedValuesSD, setSelectedValuesRJPaidToIncurred, setSelectedValuesVarJPaidToIncurred, setSelectedValuesAddLR, setSelectedValuesAddSigma, setSelectedValuesAddSD, tableContext, setCombinedDevJ])

  // Wyczyść ręczne nadpisania gdy użytkownik wybierze krzywą lokalnie
  useEffect(() => {
    Object.entries(sourceSwitches).forEach(([indexStr, switchData]) => {
      const index = parseInt(indexStr, 10)
      const override = manualOverrides[index]
      if (override && (override.curve === 'manual' || override.curve !== switchData.curve)) {
        clearManualOverride(index, manualOverrides, setManualOverrides)
      }
    })
  }, [sourceSwitches])

  // Wyczyść ręczne nadpisania gdy zmieni się globalna krzywa
  useEffect(() => {
    if (selectedCurve) {
      Object.entries(manualOverrides).forEach(([indexStr, override]) => {
        const index = parseInt(indexStr, 10)
        const hasLocalChoice = sourceSwitches[index]?.curve || pickOverrideCurve(override)
        // Wyczyść ręczne wartości gdy nie ma lokalnego wyboru
        if (!hasLocalChoice && override.curve === 'manual') {
          clearManualOverride(index, manualOverrides, setManualOverrides)
        }
      })
    }
  }, [selectedCurve])

  const handleCellClick = (idx: number, val: number | string) => {
    if (typeof val === 'string') return
    startEditing(idx, val.toString())
  }

  const handleBlur = () => {
    if (editingIndex !== null) {
      const num = parseFloat(editValue)
      if (!Number.isNaN(num)) {
        // Wywołaj callback - obsłużenie w DevSummaryLayout
        onManualEdit?.(editingIndex)
        
        // KLUCZOWE: Usuń wpis z sourceSwitches gdy użytkownik ręcznie edytuje
        // aby ręczna wartość miała priorytet nad krzywą
        if (sourceSwitches[editingIndex]) {
          const newSwitches = { ...sourceSwitches }
          delete newSwitches[editingIndex]
          setSourceSwitches(newSwitches)
        }
      }
      saveEdit(editingIndex, manualOverrides, setManualOverrides)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === 'Escape') {
      (e.target as HTMLInputElement).blur()
    }
  }

  return (
    <section>
      <h2 className="text-xl font-bold mb-4 text-center">Tabela współczynników Selected Value</h2>
      <div className="relative w-full max-w-full overflow-x-auto rounded-xl">
        <table className="min-w-max border-collapse bg-gray-900 rounded-xl shadow-md text-sm">
          <thead>
            <tr>
              <th className="border border-gray-700 px-3 py-2 bg-gray-800">-</th>
              {generatedHeaders.map((label, idx) => (
                <th key={idx} className="border border-gray-700 px-3 py-2 bg-gray-800">
                  {label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border border-gray-700 px-3 py-2 bg-gray-800">Selected Value</td>
              {effectiveValues.map((val, idx) => {
                const isEditing = editingIndex === idx
                return (
                  <td
                    key={idx}
                    className={`border border-gray-700 text-center px-3 py-2 ${
                      isEditing ? 'bg-blue-900/50' : 'hover:bg-gray-700/40 cursor-pointer'
                    }`}
                    onClick={() => handleCellClick(idx, val)}
                    title="Kliknij, aby edytować wartość ręcznie"
                  >
                    {isEditing ? (
                      <input
                        type="number"
                        step="any"
                        autoFocus
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        onBlur={handleBlur}
                        onKeyDown={handleKeyDown}
                        className="w-full px-2 py-1 rounded bg-white text-black border border-blue-400 text-sm text-center shadow"
                      />
                    ) : (
                      typeof val === 'number' ? val.toString() : val
                    )}
                  </td>
                )
              })}
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  )
}
