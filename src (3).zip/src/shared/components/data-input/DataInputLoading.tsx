import { Loader2 } from 'lucide-react';

interface DataInputLoadingProps {
  isLoading: boolean;
  progress: number;
}

export function DataInputLoading({ isLoading, progress }: DataInputLoadingProps) {
  if (!isLoading) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-[#1e1e2f] rounded-lg p-8 flex flex-col items-center w-80">
        <Loader2 className="animate-spin h-10 w-10 text-white mb-6" />
        <div className="w-full bg-gray-700 rounded-full h-4 mb-4 overflow-hidden">
          <div
            className="bg-gray-300 h-full transition-all duration-300 ease-in-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="text-white text-sm font-medium">
          {progress === 50 ? 'Nakładanie inflacji na backend...' : `Ładowanie… ${progress}%`}
        </div>
      </div>
    </div>
  );
}