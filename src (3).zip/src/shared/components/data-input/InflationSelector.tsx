import { Label } from '@/components/ui/label';
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardFooter,
} from '@/components/ui/card';

interface InflationSelectorProps {
  hasInflationData: boolean;
  useInflation: boolean;
  onInflationChange: (use: boolean) => void;
}

export function InflationSelector({ 
  hasInflationData, 
  useInflation, 
  onInflationChange 
}: InflationSelectorProps) {
  return (
    <div className="space-y-3">
      <CardHeader>
        <CardTitle>Uwzględnianie inflacji</CardTitle>
      </CardHeader>
      <div className="flex flex-col space-y-2">
        <label className={`flex items-center space-x-2 cursor-pointer ${!hasInflationData ? 'opacity-50 cursor-not-allowed' : ''}`}>
          <input
            type="radio"
            name="inflation"
            checked={useInflation === true}
            onChange={() => hasInflationData && onInflationChange(true)}
            disabled={!hasInflationData}
            className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 focus:ring-blue-500"
          />
          <span className="text-sm text-gray-300">
            ✓ Uwzględnij współczynniki inflacji w obliczeniach
          </span>
        </label>
        <label className={`flex items-center space-x-2 cursor-pointer ${!hasInflationData ? 'opacity-50 cursor-not-allowed' : ''}`}>
          <input
            type="radio"
            name="inflation"
            checked={useInflation === false}
            onChange={() => hasInflationData && onInflationChange(false)}
            disabled={!hasInflationData}
            className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 focus:ring-blue-500"
          />
          <span className="text-sm text-gray-300">
            ✗ Nie uwzględniaj współczynników inflacji w obliczeniach
          </span>
        </label>
      </div>
      
      {!hasInflationData && (
        <div className="text-xs text-gray-400 p-2 bg-gray-100 rounded border">
          ❌ Dane inflacji są niedostępne - możesz włączyć uwzględnianie inflacji
        </div>
      )}
    </div>
  );
}