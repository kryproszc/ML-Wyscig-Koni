// Komponenty
export { InflationSelector } from './InflationSelector';
export { DataInputDialogs } from './DataInputDialogs';
export { DataInputLoading } from './DataInputLoading';
export { FileUploadSection, RangeInputSection } from './FileAndRangeSection';
export { DataConfigurationSection } from './DataConfigurationSection';

// Utilities
export { parsePolishNumber } from './utils/parsePolishNumber';
export { 
  isMostlyNonNumeric, 
  looksLikeYears, 
  looksLikeDevPeriods 
} from './utils/autoDetection';