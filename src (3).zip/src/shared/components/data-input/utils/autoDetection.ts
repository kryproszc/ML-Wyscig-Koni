/**
 * Funkcje pomocnicze do auto-detekcji nagłówków w danych Excel
 */

export function isMostlyNonNumeric(arr: any[], threshold = 0.7): boolean {
  const vals = arr.filter(v => v !== null && v !== undefined && v !== '');
  if (vals.length === 0) return false;
  let nonNum = 0;
  for (const v of vals) {
    if (typeof v !== 'number' && !Number.isFinite(Number(v))) nonNum++;
  }
  return nonNum / vals.length >= threshold;
}

export function looksLikeYears(arr: any[], threshold = 0.7): boolean {
  const vals = arr.filter(v => v !== null && v !== undefined && v !== '');
  if (vals.length === 0) return false;
  const years = vals.filter(v => {
    const n = Number(v);
    return Number.isFinite(n) && n >= 1900 && n <= 2100;
  }).length;
  return years / vals.length >= threshold;
}

export function looksLikeDevPeriods(arr: any[], threshold = 0.7): boolean {
  const nums = arr
    .map(v => Number(v))
    .filter(n => Number.isFinite(n) && n >= 0 && n <= 500);
  if (nums.length === 0) return false;

  let nonDecreasing = 0;
  for (let i = 1; i < nums.length; i++) {
    const curr = nums[i]!;     // <- wiemy, że istnieje
    const prev = nums[i - 1]!; // <- też istnieje
    if (curr >= prev) nonDecreasing++;
  }
  return (nonDecreasing / Math.max(1, nums.length - 1)) >= threshold;
}