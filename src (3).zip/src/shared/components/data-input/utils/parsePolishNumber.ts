/**
 * Konwersja liczb z polskim formatowaniem na number|null
 * Obsługuje: przecinki jako separatory dziesiętne, spacje jako separatory tysięcy
 */
export function parsePolishNumber(value: any): number | null {
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : null;
  }
  
  if (value == null || value === '') {
    return null;
  }
  
  let str = String(value).trim();
  
  // Usuń spacje (mogą być separatorami tysięcy)
  str = str.replace(/\s/g, '');
  
  // Jeśli string zawiera przecinek i nie zawiera kropki, 
  // to prawdopodobnie przecinek to separator dziesiętny
  if (str.includes(',') && !str.includes('.')) {
    str = str.replace(',', '.');
  }
  // Jeśli zawiera i przecinek i kropkę, to prawdopodobnie:
  // - kropka = separator tysięcy, przecinek = separator dziesiętny (np. 1.234,56)
  else if (str.includes(',') && str.includes('.')) {
    // Sprawdź pozycje - jeśli kropka jest przed przecinkiem, to kropka = tysiące
    const lastDotIndex = str.lastIndexOf('.');
    const lastCommaIndex = str.lastIndexOf(',');
    
    if (lastDotIndex < lastCommaIndex) {
      // Format: 1.234,56 (kropka=tysiące, przecinek=dziesiętne)
      str = str.replace(/\./g, '').replace(',', '.');
    }
    // Inaczej zostaw jak jest, może to być format amerykański
  }
  
  const num = Number(str);
  return Number.isFinite(num) ? num : null;
}