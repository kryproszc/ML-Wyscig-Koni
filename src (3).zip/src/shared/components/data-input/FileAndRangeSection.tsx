import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface FileUploadSectionProps {
  file: FileList | undefined;
  uploadedFileName: string | null | undefined;
  onFileChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onFileLoad: () => void;
  isLoading?: boolean;
}

export function FileUploadSection({ 
  file, 
  uploadedFileName, 
  onFileChange, 
  onFileLoad,
  isLoading = false
}: FileUploadSectionProps) {
  return (
    <div className="flex items-center gap-4">
      <input
        type="file"
        accept=".xlsx,.xls"
        className="border p-2 rounded-lg"
        onChange={onFileChange}
      />
      <Button
        type="button"
        onClick={onFileLoad}
        disabled={!file || file.length === 0 || isLoading}
        className="bg-blue-500 text-white"
      >
        Załaduj plik
      </Button>
      {uploadedFileName && (
        <span className="text-sm text-green-400 ml-2">
          Wczytano: <strong>{uploadedFileName}</strong>
        </span>
      )}
    </div>
  );
}

interface RangeInputSectionProps {
  isDisabled: boolean;
  rowStart: number;
  rowEnd: number;
  colStart: number;
  colEnd: number;
  onRowStartChange: (value: number) => void;
  onRowEndChange: (value: number) => void;
  onColStartChange: (value: number) => void;
  onColEndChange: (value: number) => void;
  onAutoRange: () => void;
}

export function RangeInputSection({
  isDisabled,
  rowStart,
  rowEnd,
  colStart,
  colEnd,
  onRowStartChange,
  onRowEndChange,
  onColStartChange,
  onColEndChange,
  onAutoRange,
}: RangeInputSectionProps) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Wiersz początkowy</Label>
          <Input
            type="number"
            disabled={isDisabled}
            value={rowStart}
            onChange={(e) => onRowStartChange(Number(e.target.value))}
          />
        </div>
        <div>
          <Label>Wiersz końcowy</Label>
          <Input
            type="number"
            disabled={isDisabled}
            value={rowEnd}
            onChange={(e) => onRowEndChange(Number(e.target.value))}
          />
        </div>
        <div>
          <Label>Kolumna początkowa</Label>
          <Input
            type="number"
            disabled={isDisabled}
            value={colStart}
            onChange={(e) => onColStartChange(Number(e.target.value))}
          />
        </div>
        <div>
          <Label>Kolumna końcowa</Label>
          <Input
            type="number"
            disabled={isDisabled}
            value={colEnd}
            onChange={(e) => onColEndChange(Number(e.target.value))}
          />
        </div>
      </div>

      <Button
        type="button"
        onClick={onAutoRange}
        variant="outline"
        disabled={isDisabled}
        className="bg-blue-500 text-white"
      >
        Wykryj zakres automatycznie
      </Button>
    </div>
  );
}