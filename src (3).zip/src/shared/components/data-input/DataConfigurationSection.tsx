import { HeadersSelector } from '@/components/HeadersSelector';
import { DataTypeSelector, type DataType } from '@/components/DataTypeSelector';
import { InflationSelector } from './InflationSelector';

interface DataConfigurationSectionProps {
  hasHeaders: boolean;
  onHeadersChange: (hasHeaders: boolean) => void;
  dataType: DataType;
  onDataTypeChange: (dataType: DataType) => void;
  hasInflationData: boolean;
  useInflation: boolean;
  onInflationChange: (useInflation: boolean) => void;
}

export function DataConfigurationSection({
  hasHeaders,
  onHeadersChange,
  dataType,
  onDataTypeChange,
  hasInflationData,
  useInflation,
  onInflationChange,
}: DataConfigurationSectionProps) {
  return (
    <div className="space-y-4">
      {/* --- Czy dane zawierają podpisy --- */}
      <HeadersSelector 
        hasHeaders={hasHeaders} 
        onHeadersChange={onHeadersChange} 
      />

      {/* --- Typ danych --- */}
      <DataTypeSelector
        dataType={dataType}
        onDataTypeChange={onDataTypeChange}
      />

      {/* --- Uwzględnianie inflacji --- */}
      <InflationSelector
        hasInflationData={hasInflationData}
        useInflation={useInflation}
        onInflationChange={onInflationChange}
      />
    </div>
  );
}