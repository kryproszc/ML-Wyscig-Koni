'use client';

import React from 'react';
import { GenericTable } from '@/shared/ui';

interface VectorSelectionTableProps {
  preview: number[] | null;
  selectedIndexes: number[];
  config: {
    displayName: string;
    thresholdValue: number;
    thresholdMessage: string;
    dataType: string;
  };
  columnLabels: string[];
  onToggleIndex: (index: number) => void;
  relatedDataInfo?: {
    labels: string[];
    lengths: number[];
  };
}

export function VectorSelectionTable({
  preview,
  selectedIndexes,
  config,
  columnLabels,
  onToggleIndex,
  relatedDataInfo
}: VectorSelectionTableProps) {
  if (!preview) return null;

  // Przygotuj kolumny tabeli
  const baseLabels = columnLabels.length > 2 
    ? columnLabels.slice(2, preview.length + 2) 
    : preview.map((_, i) => i.toString());
  
  const vectorCols = ["–", ...baseLabels];

  const renderVector = (_: number, col: number) => {
    if (col === 0) return "0";

    const idx = col - 1;
    const raw = preview[idx];
    if (raw === undefined) return "–";

    let selectable = raw > config.thresholdValue;
    
    // Dla r_j wykluczamy wartości równe dokładnie 1.0
    if (config.dataType === 'rJ' && Math.abs(raw - 1.0) < 0.0001) {
      selectable = false;
    }
    
    const selected = selectedIndexes.includes(idx);

    return (
      <span
        onClick={() => onToggleIndex(idx)}
        className={
          selectable
            ? selected
              ? "bg-green-300 text-black font-semibold cursor-pointer px-2 block"
              : "hover:bg-gray-700 cursor-pointer px-2 block"
            : "text-gray-500 cursor-not-allowed px-2 block"
        }
      >
        {raw.toFixed(6)}
      </span>
    );
  };

  return (
    <div>
      <p className="text-sm text-gray-300 mb-2 text-center">
        {config.thresholdMessage}
      </p>
      <GenericTable
        cols={vectorCols}
        rows={1}
        stickyFirstCol
        renderCell={renderVector}
      />
      <p className="text-sm text-gray-400 mt-2 text-center">
        Wybrane: {selectedIndexes.length} współczynników {config.displayName}
        {relatedDataInfo && relatedDataInfo.lengths.some(l => l > 0) && (
          <span className="block text-green-400 text-xs mt-1">
            + dane {relatedDataInfo.labels.map((label, i) => 
              `${label}(${relatedDataInfo.lengths[i] || 0})`
            ).join(', ')} będą wysłane razem
          </span>
        )}
      </p>
    </div>
  );
}