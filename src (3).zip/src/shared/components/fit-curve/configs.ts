// Konfiguracje dla różnych typów FitCurve
import type { FitCurveConfig } from './types';

export const DEV_J_CONFIG: FitCurveConfig = {
  dataType: 'devJ',
  apiEndpoint: '/calc/paid/selected_dev_j',
  thresholdValue: 1,
  dataKey: 'selected_dev_j',
  
  displayName: 'Dev J',
  tableTitle: 'Tabela współczynników Initial Selection',
  resultsTableTitle: 'Tabela współczynników z dopasowanych krzywych',
  r2TableTitle: 'Tabela R² dla dopasowanych krzywych',
  chartTitle: 'Wykres dopasowanych krzywych oraz wektora współczynników Initial Selection',
  
  selectedCurves: ['Initial Selection', 'Exponential_weighted'],
  initialSelectionColor: 'text-blue-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Współczynniki CL" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości > 1, aby wybrać je do dopasowania krzywych'
};

export const SIGMA_CONFIG: FitCurveConfig = {
  dataType: 'sigma',
  apiEndpoint: '/calc/sigma/selected_sigma',
  thresholdValue: 0,
  dataKey: 'selected_sigma',
  
  displayName: 'Sigma',
  tableTitle: 'Tabela współczynników Sigma',
  resultsTableTitle: 'Tabela współczynników Sigma z dopasowanych krzywych',
  r2TableTitle: 'Tabela R² dla dopasowanych krzywych Sigma',
  chartTitle: 'Wykres dopasowanych krzywych Sigma oraz wektora współczynników Initial Selection',
  
  selectedCurves: ['Initial Selection', 'Sigma_weighted'],
  initialSelectionColor: 'text-red-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych sigma z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Współczynniki Sigma" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora Sigma',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor Sigma?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości > 0, aby wybrać je do dopasowania krzywych'
};

// Łatwo dodać nowe konfiguracje:
export const SD_CONFIG: FitCurveConfig = {
  dataType: 'sd',
  apiEndpoint: '/calc/sd/selected_sd',
  thresholdValue: 0,
  dataKey: 'selected_sd',
  
  displayName: 'SD',
  tableTitle: 'Tabela współczynników SD',
  resultsTableTitle: 'Tabela współczynników SD z dopasowanych krzywych',
  r2TableTitle: 'Tabela R² dla dopasowanych krzywych SD',
  chartTitle: 'Wykres dopasowanych krzywych SD oraz wektora współczynników Initial Selection',
  
  selectedCurves: ['Initial Selection', 'SD_weighted'],
  initialSelectionColor: 'text-green-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych SD z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Współczynniki SD" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora SD',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor Sigma?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości > 0, aby wybrać je do dopasowania krzywych'
};

export const ADD_J_CONFIG: FitCurveConfig = {
  dataType: 'addJ',
  apiEndpoint: '/calc/add/selected_add_j',
  thresholdValue: 0,
  dataKey: 'selected_add_j',
  
  displayName: 'Add J',
  tableTitle: 'Tabela współczynników Add J',
  resultsTableTitle: 'Tabela współczynników Add J z dopasowanych krzywych',
  r2TableTitle: 'Tabela R² dla dopasowanych krzywych Add J',
  chartTitle: 'Wykres dopasowanych krzywych Add J oraz wektora współczynników Initial Selection',
  
  selectedCurves: ['Initial Selection', 'AddJ_weighted'],
  initialSelectionColor: 'text-green-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych Add J z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Współczynniki Add J" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora Add J',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor Add J?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości > 0, aby wybrać je do dopasowania krzywych'
};

export const SIGMA_LR_CONFIG: FitCurveConfig = {
  dataType: 'sigmaLR',
  apiEndpoint: '/calc/add/selected_sigma_LR',
  thresholdValue: 0,
  dataKey: 'selected_sigma_l_r',
  
  displayName: 'Sigma LR',
  tableTitle: 'Tabela współczynników Sigma LR',
  resultsTableTitle: 'Tabela współczynników Sigma LR z dopasowanych krzywych',
  r2TableTitle: 'Tabela R² dla dopasowanych krzywych Sigma LR',
  chartTitle: 'Wykres dopasowanych krzywych Sigma LR oraz wektora współczynników Initial Selection',
  
  selectedCurves: ['Initial Selection', 'Sigma_weighted'],
  initialSelectionColor: 'text-orange-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych Sigma LR z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Współczynniki Sigma LR" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora Sigma LR',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor Sigma LR?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości > 0, aby wybrać je do dopasowania krzywych'
};

// Incurred configurations
export const DEV_J_INCURRED_CONFIG: FitCurveConfig = {
  dataType: 'devJ',
  apiEndpoint: '/calc/incurred/selected_dev_j',
  thresholdValue: 1,
  dataKey: 'selected_dev_j',
  disableAutoLoading: true, // Wyłącz automatyczne ładowanie - tylko na żądanie przez "Zaktualizuj wektor"
  
  displayName: 'Dev J (Incurred)',
  tableTitle: 'Tabela współczynników Initial Selection (Incurred)',
  resultsTableTitle: 'Tabela współczynników z dopasowanych krzywych (Incurred)',
  r2TableTitle: 'Tabela R² dla dopasowanych krzywych (Incurred)',
  chartTitle: 'Wykres dopasowanych krzywych oraz wektora współczynników Initial Selection (Incurred)',
  
  selectedCurves: ['Initial Selection', 'Exponential_weighted'],
  initialSelectionColor: 'text-cyan-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Współczynniki CL" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora (Incurred)',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości > 1, aby wybrać je do dopasowania krzywych'
};

export const SIGMA_INCURRED_CONFIG: FitCurveConfig = {
  dataType: 'sigma',
  apiEndpoint: '/calc/incurred/selected_sigma',
  thresholdValue: 0,
  dataKey: 'selected_sigma',
  
  displayName: 'Sigma (Incurred)',
  tableTitle: 'Tabela współczynników Sigma (Incurred)',
  resultsTableTitle: 'Tabela współczynników Sigma z dopasowanych krzywych (Incurred)',
  r2TableTitle: 'Tabela R² dla dopasowanych krzywych Sigma (Incurred)',
  chartTitle: 'Wykres dopasowanych krzywych Sigma oraz wektora współczynników Initial Selection (Incurred)',
  
  selectedCurves: ['Initial Selection', 'Sigma_weighted'],
  initialSelectionColor: 'text-emerald-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych sigma z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Współczynniki Sigma" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora Sigma (Incurred)',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor Sigma?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości > 0, aby wybrać je do dopasowania krzywych'
};

// PaidIncurred configurations
export const R_J_PAID_TO_INCURRED_CONFIG: FitCurveConfig = {
  dataType: 'rJ',
  apiEndpoint: '/calc/paid_incurred/fit_curve_rj',
  thresholdValue: -0.001,
  dataKey: 'r_j',
  disableAutoLoading: true, // Wyłącz automatyczne ładowanie - użytkownik musi ręcznie kliknąć "Zaktualizuj wektor"
  
  displayName: 'r_j (PaidToIncurred)',
  tableTitle: 'Tabela współczynników r_j (PaidToIncurred)',
  resultsTableTitle: 'Tabela współczynników r_j z dopasowanych krzywych (PaidToIncurred)',
  r2TableTitle: 'Tabela R² dla dopasowanych krzywych r_j (PaidToIncurred)',
  chartTitle: 'Wykres dopasowanych krzywych r_j oraz wektora współczynników Initial Selection (PaidToIncurred)',
  
  selectedCurves: ['Initial Selection'], // Będzie rozszerzane dynamicznie o wszystkie krzywe z API
  initialSelectionColor: 'text-violet-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych r_j z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Paid to Incurred" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora r_j (PaidToIncurred)',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor r_j?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości ≠ 1, aby wybrać je do dopasowania krzywych (wartości równe 1 są automatycznie wyłączone)'
};

export const VAR_J_PAID_TO_INCURRED_CONFIG: FitCurveConfig = {
  dataType: 'varJ',
  apiEndpoint: '/calc/paid_incurred/fit_curve_varj',
  thresholdValue: 0,
  dataKey: 'var_j',
  disableAutoLoading: true, // Wyłącz automatyczne ładowanie - użytkownik musi ręcznie kliknąć "Zaktualizuj wektor"
  
  displayName: 'var_j (PaidToIncurred)',
  tableTitle: 'Tabela współczynników var_j (PaidToIncurred)',
  resultsTableTitle: 'Tabela współczynników var_j z dopasowanych krzywych (PaidToIncurred)',
  r2TableTitle: 'Tabela R² dla dopasowanych krzywych var_j (PaidToIncurred)',
  chartTitle: 'Wykres dopasowanych krzywych var_j oraz wektora współczynników Initial Selection (PaidToIncurred)',
  
  selectedCurves: ['Initial Selection', 'VarJ_weighted'],
  initialSelectionColor: 'text-rose-400',
  primaryCurveColor: 'text-purple-400',
  
  loadingMessage: 'Ładowanie danych var_j z poprzedniej zakładki...',
  noDataMessage: 'Jeśli dane nie ładują się automatycznie, przejdź do zakładki "Paid to Incurred" i oblicz współczynniki',
  modalTitle: 'Aktualizacja wektora var_j (PaidToIncurred)',
  modalMessage: 'Czy na pewno chcesz zaktualizować wektor var_j?\nObliczenia w kolejnych zakładkach zostaną utracone.',
  
  thresholdMessage: 'Kliknij na wartości > 0, aby wybrać je do dopasowania krzywych'
};

// Export all configs for easy access
export const FIT_CURVE_CONFIGS = {
  devJ: DEV_J_CONFIG,
  sigma: SIGMA_CONFIG,
  sd: SD_CONFIG,
  addJ: ADD_J_CONFIG,
  sigmaLR: SIGMA_LR_CONFIG,
  devJIncurred: DEV_J_INCURRED_CONFIG,
  sigmaIncurred: SIGMA_INCURRED_CONFIG,
  rJPaidToIncurred: R_J_PAID_TO_INCURRED_CONFIG,
  varJPaidToIncurred: VAR_J_PAID_TO_INCURRED_CONFIG,
} as const;