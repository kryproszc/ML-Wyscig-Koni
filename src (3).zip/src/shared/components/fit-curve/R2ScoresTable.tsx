'use client';

import React from 'react';
import { GenericTable } from '@/shared/ui';

interface R2ScoresTableProps {
  r2Scores: Record<string, number>;
  title: string;
}

export function R2ScoresTable({ r2Scores, title }: R2ScoresTableProps) {
  return (
    <section>
      <h2 className="text-xl font-bold mb-4 text-center">
        {title}
      </h2>

      <GenericTable
        cols={["Krzywa", "R²"]}
        rows={Object.keys(r2Scores).length}
        stickyFirstCol
        renderCell={(row, col) => {
          /* 1️⃣ bezpiecznie wyciągamy parę [curve, r2] */
          const sorted = Object.entries(r2Scores).sort((a, b) => b[1] - a[1]);
          const pair = sorted[row];
          
          if (!pair) return null;
          const [curve, r2] = pair;

          /* 2️⃣ zwracamy właściwą komórkę */
          return col === 0 ? (
            <strong>{curve}</strong>
          ) : (
            r2.toFixed(6)
          );
        }}
      />
    </section>
  );
}