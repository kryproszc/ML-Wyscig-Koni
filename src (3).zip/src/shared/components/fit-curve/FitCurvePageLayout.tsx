'use client';

import React, { useState, useEffect } from 'react';
import { ControlPanel, SimulationChart, Modal } from '@/shared/ui';
import { VectorSelectionTable } from './VectorSelectionTable';
import { SimulationResultsTable } from './SimulationResultsTable';
import { R2ScoresTable } from './R2ScoresTable';
import { DpRangeControls } from './DpRangeControls';
import { ChartInfoSection } from './ChartInfoSection';
import type { FitCurveConfig, FitCurveData, FitCurveActions } from './types';

interface FitCurvePageLayoutProps {
  config: FitCurveConfig;
  data: FitCurveData;
  actions: FitCurveActions;
  detColumnLabels: string[];
  currentVector: number[];
  userId: string;
  forceRefreshData: () => void;
  buildRequestData: (validIndexes: number[]) => any;
  processApiResponse: (response: any) => void;
  relatedDataInfo?: {
    labels: string[];
    lengths: number[];
  };
}

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? '';

export function FitCurvePageLayout({
  config,
  data,
  actions,
  detColumnLabels,
  currentVector,
  userId,
  forceRefreshData,
  buildRequestData,
  processApiResponse,
  relatedDataInfo
}: FitCurvePageLayoutProps) {
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [dpRange, setDpRange] = useState<[number, number]>([1, 13]);

  // Auto-update dp range when simulation results change
  useEffect(() => {
    if (!data.simResults) return;
    const firstCurve = Object.values(data.simResults)[0] ?? {};
    const dps = Object.keys(firstCurve)
      .map((k) => parseInt(k.replace("dp: ", ""), 10))
      .filter((n) => !isNaN(n));
    if (dps.length) setDpRange([Math.min(...dps), Math.max(...dps)]);
  }, [data.simResults]);

  const openUpdateModal = () => {
    if (!currentVector.length) {
      console.log(`❌ No current${config.displayName}Vector data available`);
      return;
    }
    
    console.log(`✅ Setting ${config.dataType}PreviewCandidate to:`, currentVector);
    actions.setPreviewCandidate(currentVector);
    setConfirmOpen(true);
  };

  const confirmUpdate = () => {
    console.log(`✅ confirmUpdate ${config.dataType} - candidate data:`, data.previewCandidate);
    setConfirmOpen(false);
    if (!data.previewCandidate) {
      console.log(`❌ No ${config.dataType}PreviewCandidate`);
      return;
    }

    console.log(`🔄 Setting ${config.dataType}Preview to:`, data.previewCandidate);
    actions.setPreview(data.previewCandidate);

    const autoSelected = data.previewCandidate
      .map((v, i) => {
        if (v <= config.thresholdValue) return -1;
        // Dla r_j wykluczamy wartości równe dokładnie 1.0
        if (config.dataType === 'rJ' && Math.abs(v - 1.0) < 0.0001) return -1;
        return i;
      })
      .filter((i) => i >= 0);
    
    console.log(`🎯 Auto-selecting ${config.dataType} indexes:`, autoSelected);
    actions.setSelectedIndexes(autoSelected);

    actions.clearSimResults();
    actions.clearR2Scores();
  };

  const toggleIndex = (idx: number) => {
    if (!data.preview || data.preview[idx]! <= config.thresholdValue) return;
    // Dla r_j wykluczamy wartości równe dokładnie 1.0
    if (config.dataType === 'rJ' && Math.abs(data.preview[idx]! - 1.0) < 0.0001) return;
    const next = data.selectedIndexes.includes(idx)
      ? data.selectedIndexes.filter((i) => i !== idx)
      : [...data.selectedIndexes, idx];
    actions.setSelectedIndexes(next);
  };

  const handleSend = () => {
    // Jeśli preview jest null (np. dla PaidToIncurred z disableAutoLoading), załaduj dane najpierw
    if (!data.preview && currentVector?.length) {
      console.log(`🔄 Loading ${config.dataType} preview data on first "Dopasuj krzywe" click:`, currentVector);
      actions.setPreview(currentVector);
      
      // Automatycznie wybierz właściwe indeksy
      let autoSelected: number[];
      if (config.dataType === 'rJ' && config.thresholdValue < 0) {
        // Dla r_j PaidToIncurred: wybierz wszystkie OPRÓCZ tych równych 1.0
        autoSelected = currentVector
          .map((v, i) => (Math.abs(v - 1.0) > 0.0001 ? i : -1))
          .filter((i) => i >= 0);
        console.log(`✅ PaidToIncurred r_j - excluded values equal to 1.0, selected indexes:`, autoSelected);
      } else {
        // Standardowa logika
        autoSelected = currentVector
          .map((v, i) => (v > config.thresholdValue ? i : -1))
          .filter((i) => i >= 0);
      }
      
      actions.setSelectedIndexes(autoSelected);
      console.log(`🎯 Auto-selecting ${config.dataType} indexes on first load:`, autoSelected);
      
      // Po załadowaniu danych, nie kontynuuj jeszcze - niech użytkownik zobaczy tabelę i wybierze
      // Na kolejne kliknięcie "Dopasuj krzywe" już będzie normalny flow
      return;
    }
    
    if (!data.preview || !userId || !data.selectedIndexes.length) return;

    const valid = data.selectedIndexes
      .filter((i) => {
        const value = data.preview![i]!;
        if (value <= config.thresholdValue) return false;
        // Dla r_j wykluczamy wartości równe dokładnie 1.0
        if (config.dataType === 'rJ' && Math.abs(value - 1.0) < 0.0001) return false;
        return true;
      })
      .sort((a, b) => a - b);

    // Sprawdź czy mamy wystarczającą ilość punktów do dopasowania
    if (valid.length < 2) {
      console.log('❌ Za mało punktów do dopasowania krzywych. Potrzeba minimum 2 punktów, masz:', valid.length);
      alert('Wybierz co najmniej 2 współczynniki do dopasowania krzywych');
      return;
    }

    const requestData = buildRequestData(valid);

    console.log(`🚀 Sending complete ${config.dataType} data to backend:`, requestData);

    fetch(`${API_URL}${config.apiEndpoint}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(requestData),
    })
      .then((r) => {
        if (!r.ok) {
          throw new Error(`HTTP error! status: ${r.status}`);
        }
        return r.json();
      })
      .then((response) => {
        console.log(`✅ Complete ${config.dataType} response from backend:`, response);
        processApiResponse(response);
      })
      .catch((e) => {
        console.error(`❌ Błąd wysyłki ${config.dataType}:`, e);
        alert(`Błąd podczas dopasowywania krzywych: ${e.message}`);
      });
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 p-6 text-white overflow-x-hidden">
      {/* PANEL STEROWANIA */}
      <ControlPanel
        currentVectorLength={currentVector.length}
        tailCount={data.tailCount}
        onTailChange={actions.setTailCount}
        onUpdateVector={openUpdateModal}
        onSend={handleSend}
        disableSend={!data.selectedIndexes.length}
      />

      {/* PRAWA KOLUMNA */}
      <main className="flex-1 flex flex-col gap-8 overflow-hidden">
        {/* 1. Wektor Selection */}
        <section>
          <h2 className="text-xl font-bold mb-4 text-center">
            {config.tableTitle}
          </h2>
          
          {/* Debug info */}
          <div className="text-xs text-gray-500 mb-2 text-center">
            Debug: {config.dataType}Preview={data.preview?.length || 0}, current{config.displayName}Vector={currentVector?.length || 0}
            {relatedDataInfo && relatedDataInfo.lengths.map((length, i) => 
              `, ${relatedDataInfo.labels[i]}=${length || 0}`
            )}
          </div>
          
          {data.preview ? (
            <VectorSelectionTable
              preview={data.preview}
              selectedIndexes={data.selectedIndexes}
              config={config}
              columnLabels={detColumnLabels}
              onToggleIndex={toggleIndex}
              relatedDataInfo={relatedDataInfo}
            />
          ) : (
            <div className="text-center">
              <p className="text-yellow-400 mb-2">
                {config.loadingMessage}
              </p>
              <p className="text-sm text-gray-400 mb-4">
                {config.noDataMessage}
              </p>
              <button
                onClick={forceRefreshData}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors"
              >
                🔄 Odśwież dane {config.dataType} ręcznie
              </button>
            </div>
          )}
        </section>

        {/* 2. Simulation Results Table */}
        {data.simResults && (
          <SimulationResultsTable
            simResults={data.simResults}
            title={config.resultsTableTitle}
          />
        )}

        {/* 3. R² Table */}
        {data.r2Scores && (
          <R2ScoresTable
            r2Scores={data.r2Scores}
            title={config.r2TableTitle}
          />
        )}

        {/* 4. Chart Controls and Info */}
        <DpRangeControls
          dpRange={dpRange}
          onRangeChange={setDpRange}
          title={config.chartTitle}
        />

        <ChartInfoSection config={config} />

        {/* 5. Chart */}
        <SimulationChart
          simResults={data.simResults ?? null}
          devJ={data.preview || undefined}
          dpRange={dpRange}
          selectedCurves={(() => {
            // Dynamicznie rozszerz selectedCurves o wszystkie dostępne krzywe z simResults
            const baseCurves = config.selectedCurves;
            if (data.simResults) {
              const availableCurves = Object.keys(data.simResults);
              // Połącz krzywe z konfiguracji z dostępnymi krzywymi z API, unikając duplikatów
              return [...new Set([...baseCurves, ...availableCurves])];
            }
            return baseCurves;
          })()}
        />
      </main>

      {/* Modal */}
      <Modal
        title={config.modalTitle}
        message={config.modalMessage}
        isOpen={confirmOpen}
        onCancel={() => setConfirmOpen(false)}
        onConfirm={confirmUpdate}
      />
    </div>
  );
}