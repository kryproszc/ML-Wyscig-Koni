// Types dla uniwersalnego systemu FitCurve
export interface FitCurveConfig {
  // Identyfikacja typu
  dataType: string; // 'devJ', 'sigma', 'sd', 'addJ', 'sigmaLR', etc.
  
  // API configuration
  apiEndpoint: string; // '/calc/paid/selected_dev_j', '/calc/sigma/selected_sigma', etc.
  
  // Dane i logika
  thresholdValue: number; // 1 dla devJ, 0 dla sigma, etc.
  dataKey: string; // klucz w response: 'selected_dev_j', 'selected_sigma', etc.
  
  // UI labels
  displayName: string; // "Dev J", "Sigma", "SD", etc.
  tableTitle: string; // "Tabela współczynników Dev J"
  resultsTableTitle: string; // "Tabela współczynników Dev J z dopasowanych krzywych"
  r2TableTitle: string; // "Tabela R² dla dopasowanych krzywych Dev J"
  chartTitle: string; // "Wykres dopasowanych krzywych Dev J"
  
  // Wykres
  selectedCurves: string[]; // ["Initial Selection", "Exponential_weighted"]
  initialSelectionColor: string; // "text-blue-400"
  primaryCurveColor: string; // "text-purple-400"
  
  // Komunikaty
  loadingMessage: string; // "Ładowanie danych Dev J z poprzedniej zakładki..."
  noDataMessage: string; // "Przejdź do zakładki \"Współczynniki Dev J\" i oblicz współczynniki"
  modalTitle: string; // "Aktualizacja wektora Dev J"
  modalMessage: string; // "Czy na pewno chcesz zaktualizować wektor Dev J?"
  
  // Threshold message
  thresholdMessage: string; // "Kliknij na wartości > 1" lub "Kliknij na wartości > 0"
  
  // Optional flags
  disableAutoLoading?: boolean; // jeśli true, nie ładuje automatycznie preview ani selectedIndexes
}

export interface FitCurveData {
  // Obecne dane z store
  preview: number[] | null;
  previewCandidate: number[] | null;
  selectedIndexes: number[];
  simResults: Record<string, Record<string, number>> | null;
  r2Scores: Record<string, number> | null;
  tailCount: number | "";
  
  // Powiązane dane (dla wysyłki razem)
  relatedData?: {
    [key: string]: number[] | null;
  };
}

export interface FitCurveActions {
  setPreview: (data: number[]) => void;
  setPreviewCandidate: (data: number[]) => void;
  setSelectedIndexes: (indexes: number[]) => void;
  setSimResults: (results: Record<string, Record<string, number>>) => void;
  setR2Scores: (scores: Record<string, number>) => void;
  setTailCount: (count: number | "") => void;
  clearSimResults: () => void;
  clearR2Scores: () => void;
}