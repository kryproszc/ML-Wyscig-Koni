'use client';

import React from 'react';

interface ChartInfoSectionProps {
  config: {
    initialSelectionColor: string;
    primaryCurveColor: string;
    selectedCurves: string[];
  };
}

export function ChartInfoSection({ config }: ChartInfoSectionProps) {
  const [initialCurve, primaryCurve] = config.selectedCurves;
  
  return (
    <section className="text-sm text-center">
      <p className="text-gray-300">
        Wykres pokazuje krzywą{' '}
        <strong className={config.initialSelectionColor}>{initialCurve}</strong>
        {' '}oraz{' '}
        <strong className={config.primaryCurveColor}>{primaryCurve}</strong>
      </p>
    </section>
  );
}