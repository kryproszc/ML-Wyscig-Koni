'use client';

import React from 'react';

interface DpRangeControlsProps {
  dpRange: [number, number];
  onRangeChange: (range: [number, number]) => void;
  title: string;
}

export function DpRangeControls({ dpRange, onRangeChange, title }: DpRangeControlsProps) {
  return (
    <>
      <h2 className="text-xl font-bold mb-4 text-center">
        {title}
      </h2>
      <section className="flex flex-col lg:flex-row items-center gap-4">
        <label className="text-sm font-medium">Zakres dp:</label>
        <input
          type="number"
          min={1}
          value={dpRange[0]}
          onChange={(e) => onRangeChange([+e.target.value, dpRange[1]])}
          className="bg-gray-700 text-white px-2 py-1 rounded w-20"
        />
        <span className="text-sm">do</span>
        <input
          type="number"
          min={1}
          value={dpRange[1]}
          onChange={(e) => onRangeChange([dpRange[0], +e.target.value])}
          className="bg-gray-700 text-white px-2 py-1 rounded w-20"
        />
      </section>
    </>
  );
}