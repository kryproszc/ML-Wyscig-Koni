'use client';

import React from 'react';
import { GenericTable } from '@/shared/ui';

interface SimulationResultsTableProps {
  simResults: Record<string, Record<string, number>>;
  title: string;
}

export function SimulationResultsTable({ simResults, title }: SimulationResultsTableProps) {
  return (
    <section>
      <h2 className="text-xl font-bold mb-4 text-center">
        {title}
      </h2>
      <GenericTable
        cols={[
          "Krzywa",
          ...Object.keys(Object.values(simResults)[0]!).map(key => 
            key.replace('dp: ', 'k:')
          ),
        ]}
        rows={Object.keys(simResults).length}
        stickyFirstCol
        renderCell={(row, col) => {
          /* 1. -- klucz krzywej ------------------------------------------------ */
          const curveKeys = Object.keys(simResults);
          const curve = curveKeys[row];
          if (!curve) return "–";

          /* kolumna z nazwą krzywej */
          if (col === 0) return <strong>{curve}</strong>;

          /* 2. -- klucz dp dla danej krzywej ----------------------------------- */
          const dpKeys = Object.keys(simResults[curve] ?? {});
          const dpKey = dpKeys[col - 1];
          if (!dpKey) return "–";

          /* 3. -- wartość komórki --------------------------------------------- */
          const value = simResults[curve]?.[dpKey];
          return value !== undefined ? value.toFixed(6) : "–";
        }}
      />
    </section>
  );
}