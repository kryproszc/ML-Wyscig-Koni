// Store mappings for different FitCurve data types
export const DEV_J_STORE_MAPPING = {
  preview: 'devJPreview',
  previewCandidate: 'devPreviewCandidate',
  selectedIndexes: 'selectedDevJIndexes',
  simResults: 'simResults',
  r2Scores: 'r2Scores',
  tailCount: 'tailCountCL',
  finalCustom: 'devFinalCustom',
  baseData: ['devJ', 'sigma', 'sd'],
  finalData: ['finalDevJ', 'finalSigma'],
  clearMethods: ['clearSimResults', 'clearR2Scores'],
  setMethods: {
    setPreview: 'setDevJPreview',
    setPreviewCandidate: 'setDevPreviewCandidate',
    setSelectedIndexes: 'setSelectedDevJIndexes',
    setSimResults: 'setSimResults',
    setR2Scores: 'setR2Scores',
    setTailCount: 'setTailCountCL',
  }
};

export const SIGMA_STORE_MAPPING = {
  preview: 'sigmaPreview',
  previewCandidate: 'sigmaPreviewCandidate',
  selectedIndexes: 'selectedSigmaIndexes',
  simResults: 'simResultsSigma',
  r2Scores: 'r2ScoresSigma',
  tailCount: 'tailCountSigma',
  finalCustom: 'sigmaFinalCustom',
  baseData: ['sigma', 'sd', 'devJ'],
  finalData: ['finalSigma', 'finalDevJ'],
  clearMethods: ['clearSimResultsSigma', 'clearR2ScoresSigma'],
  setMethods: {
    setPreview: 'setSigmaPreview',
    setPreviewCandidate: 'setSigmaPreviewCandidate',
    setSelectedIndexes: 'setSelectedSigmaIndexes',
    setSimResults: 'setSimResultsSigma',
    setR2Scores: 'setR2ScoresSigma',
    setTailCount: 'setTailCountSigma',
  }
};

// AddPaid store mappings
export const ADD_J_STORE_MAPPING = {
  preview: 'addJPreview',
  previewCandidate: 'addJPreviewCandidate',
  selectedIndexes: 'selectedAddJIndexes',
  simResults: 'simResultsAddJ',
  r2Scores: 'r2ScoresAddJ',
  tailCount: 'tailCountAddJ',
  finalCustom: 'addJFinalCustom',
  baseData: ['addJ', 'sigmaLR', 'sdLR'],
  finalData: ['finalAddJ', 'finalSigmaLR', 'finalSdLR'],
  clearMethods: ['clearSimResultsAddJ', 'clearR2ScoresAddJ'],
  setMethods: {
    setPreview: 'setAddJPreview',
    setPreviewCandidate: 'setAddJPreviewCandidate',
    setSelectedIndexes: 'setSelectedAddJIndexes',
    setSimResults: 'setSimResultsAddJ',
    setR2Scores: 'setR2ScoresAddJ',
    setTailCount: 'setTailCountAddJ',
  }
};

export const SIGMA_LR_STORE_MAPPING = {
  preview: 'sigmaLRPreview',
  previewCandidate: 'sigmaLRPreviewCandidate',
  selectedIndexes: 'selectedSigmaLRIndexes',
  simResults: 'simResultsSigmaLR',
  r2Scores: 'r2ScoresSigmaLR',
  tailCount: 'tailCountSigmaLR',
  finalCustom: 'sigmaLRFinalCustom',
  baseData: ['sigmaLR', 'addJ', 'sdLR'],
  finalData: ['finalSigmaLR', 'finalAddJ', 'finalSdLR'],
  clearMethods: ['clearSimResultsSigmaLR', 'clearR2ScoresSigmaLR'],
  setMethods: {
    setPreview: 'setSigmaLRPreview',
    setPreviewCandidate: 'setSigmaLRPreviewCandidate',
    setSelectedIndexes: 'setSelectedSigmaLRIndexes',
    setSimResults: 'setSimResultsSigmaLR',
    setR2Scores: 'setR2ScoresSigmaLR',
    setTailCount: 'setTailCountSigmaLR',
  }
};

// Incurred store mappings  
export const DEV_J_INCURRED_STORE_MAPPING = {
  preview: 'devJPreview',
  previewCandidate: 'devPreviewCandidate',
  selectedIndexes: 'selectedDevJIndexes',
  simResults: 'simResults',
  r2Scores: 'r2Scores',
  tailCount: 'tailCountCL',
  finalCustom: 'devFinalCustom',
  baseData: ['devJ', 'sigma', 'sd'],
  finalData: ['finalDevJ', 'finalSigma'],
  clearMethods: ['clearSimResults', 'clearR2Scores'],
  setMethods: {
    setPreview: 'setDevJPreview',
    setPreviewCandidate: 'setDevPreviewCandidate',
    setSelectedIndexes: 'setSelectedDevJIndexes',
    setSimResults: 'setSimResults',
    setR2Scores: 'setR2Scores',
    setTailCount: 'setTailCountCL',
  }
};

export const SIGMA_INCURRED_STORE_MAPPING = {
  preview: 'sigmaPreview', 
  previewCandidate: 'sigmaPreviewCandidate',
  selectedIndexes: 'selectedSigmaIndexes',
  simResults: 'simResultsSigma',
  r2Scores: 'r2ScoresSigma',
  tailCount: 'tailCountSigma',
  finalCustom: 'sigmaFinalCustom',
  baseData: ['sigma', 'sd', 'devJ'],
  finalData: ['finalSigma', 'finalDevJ'],
  clearMethods: ['clearSimResultsSigma', 'clearR2ScoresSigma'],
  setMethods: {
    setPreview: 'setSigmaPreview',
    setPreviewCandidate: 'setSigmaPreviewCandidate',
    setSelectedIndexes: 'setSelectedSigmaIndexes',
    setSimResults: 'setSimResultsSigma',
    setR2Scores: 'setR2ScoresSigma',
    setTailCount: 'setTailCountSigma',
  }
};

// Przykład jak łatwo dodać nowe mapowanie:
export const SD_STORE_MAPPING = {
  preview: 'sdPreview',
  previewCandidate: 'sdPreviewCandidate',
  selectedIndexes: 'selectedSdIndexes',
  simResults: 'simResultsSd',
  r2Scores: 'r2ScoresSd',
  tailCount: 'tailCountSd',
  finalCustom: 'sdFinalCustom',
  baseData: ['sd', 'devJ', 'sigma'],
  finalData: ['finalSd', 'finalDevJ'],
  clearMethods: ['clearSimResultsSd', 'clearR2ScoresSd'],
  setMethods: {
    setPreview: 'setSdPreview',
    setPreviewCandidate: 'setSdPreviewCandidate',
    setSelectedIndexes: 'setSelectedSdIndexes',
    setSimResults: 'setSimResultsSd',
    setR2Scores: 'setR2ScoresSd',
    setTailCount: 'setTailCountSd',
  }
};

// PaidIncurred store mappings
export const R_J_PAID_TO_INCURRED_STORE_MAPPING = {
  preview: 'rJPaidToIncurredPreview',
  previewCandidate: 'rJPaidToIncurredPreviewCandidate',
  selectedIndexes: 'selectedRJPaidToIncurredIndexes',
  simResults: 'simResultsRJPaidToIncurred',
  r2Scores: 'r2ScoresRJPaidToIncurred',
  tailCount: 'tailCountRJPaidToIncurred',
  finalCustom: 'rJPaidToIncurredFinalCustom',
  baseData: ['rJPaidToIncurred', 'varJPaidToIncurred'],
  finalData: ['rJPaidToIncurred', 'varJPaidToIncurred'],
  clearMethods: ['clearSimResultsRJPaidToIncurred', 'clearR2ScoresRJPaidToIncurred'],
  setMethods: {
    setPreview: 'setRJPaidToIncurredPreview',
    setPreviewCandidate: 'setRJPaidToIncurredPreviewCandidate',
    setSelectedIndexes: 'setSelectedRJPaidToIncurredIndexes',
    setSimResults: 'setSimResultsRJPaidToIncurred',
    setR2Scores: 'setR2ScoresRJPaidToIncurred',
    setTailCount: 'setTailCountRJPaidToIncurred',
  }
};

export const VAR_J_PAID_TO_INCURRED_STORE_MAPPING = {
  preview: 'varJPaidToIncurredPreview',
  previewCandidate: 'varJPaidToIncurredPreviewCandidate',
  selectedIndexes: 'selectedVarJPaidToIncurredIndexes',
  simResults: 'simResultsVarJPaidToIncurred',
  r2Scores: 'r2ScoresVarJPaidToIncurred',
  tailCount: 'tailCountVarJPaidToIncurred',
  finalCustom: 'varJPaidToIncurredFinalCustom',
  baseData: ['varJPaidToIncurred', 'rJPaidToIncurred'],
  finalData: ['varJPaidToIncurred', 'rJPaidToIncurred'],
  clearMethods: ['clearSimResultsVarJPaidToIncurred', 'clearR2ScoresVarJPaidToIncurred'],
  setMethods: {
    setPreview: 'setVarJPaidToIncurredPreview',
    setPreviewCandidate: 'setVarJPaidToIncurredPreviewCandidate',
    setSelectedIndexes: 'setSelectedVarJPaidToIncurredIndexes',
    setSimResults: 'setSimResultsVarJPaidToIncurred',
    setR2Scores: 'setR2ScoresVarJPaidToIncurred',
    setTailCount: 'setTailCountVarJPaidToIncurred',
  }
};