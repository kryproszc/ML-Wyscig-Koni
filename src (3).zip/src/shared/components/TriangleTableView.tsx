// shared/components/TriangleTableView.tsx
'use client';

import React from 'react';

export interface TriangleTableViewProps {
  title: string;
  triangle?: (number | null)[][] | null;
  noDataMessage: string;
  withNumericHeaders?: boolean;
  rowLabels?: string[];
  columnLabels?: string[];
  className?: string;
}

export function TriangleTableView({
  title,
  triangle,
  noDataMessage,
  withNumericHeaders = true,
  rowLabels = [],
  columnLabels = [],
  className = "space-y-4"
}: TriangleTableViewProps) {
  
  if (!triangle || triangle.length === 0) {
    return (
      <div className={className}>
        <h3 className="text-xl font-semibold text-white mb-4">{title}</h3>
        <p className="text-gray-400 text-sm">
          {noDataMessage}
        </p>
      </div>
    );
  }

  // Przygotuj nagłówki kolumn
  const maxCols = Math.max(...triangle.map(row => row?.length || 0));
  const headers = columnLabels.length > 0 
    ? columnLabels.slice(0, maxCols)
    : withNumericHeaders 
      ? Array.from({ length: maxCols }, (_, i) => `${i}`)
      : [];

  return (
    <div className={className}>
      <h3 className="text-xl font-semibold text-white mb-4">{title}</h3>
      
      <div className="overflow-x-auto bg-[#1e293b] rounded-lg border border-gray-700">
        <table className="min-w-full text-sm">
          {/* Nagłówki kolumn */}
          {headers.length > 0 && (
            <thead className="bg-[#334155] text-gray-200">
              <tr>
                {/* Komórka narożna */}
                <th className="px-3 py-2 text-left border-b border-gray-600 font-medium">
                  #
                </th>
                {headers.map((header, colIndex) => (
                  <th key={colIndex} className="px-3 py-2 text-center border-b border-gray-600 font-medium">
                    {header}
                  </th>
                ))}
              </tr>
            </thead>
          )}
          
          <tbody className="text-gray-300">
            {triangle.map((row, rowIndex) => {
              const rowLabel = rowLabels[rowIndex] || `${rowIndex}`;
              
              return (
                <tr key={rowIndex} className="border-b border-gray-700 hover:bg-[#2d3748] transition-colors">
                  {/* Etykieta wiersza */}
                  <td className="px-3 py-2 font-medium text-blue-400 bg-[#334155] border-r border-gray-600">
                    {rowLabel}
                  </td>
                  
                  {/* Komórki danych */}
                  {Array.from({ length: maxCols }, (_, colIndex) => {
                    const value = row?.[colIndex];
                    const isEmpty = value === null || value === undefined;
                    
                    return (
                      <td key={colIndex} className="px-3 py-2 text-center font-mono">
                        {isEmpty ? (
                          <span className="text-gray-600">-</span>
                        ) : (
                          <span className={typeof value === 'number' && value !== 0 ? 'text-white' : 'text-gray-400'}>
                            {typeof value === 'number' 
                              ? value.toLocaleString('pl-PL', { 
                                  minimumFractionDigits: 0, 
                                  maximumFractionDigits: 2 
                                })
                              : String(value)
                            }
                          </span>
                        )}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}