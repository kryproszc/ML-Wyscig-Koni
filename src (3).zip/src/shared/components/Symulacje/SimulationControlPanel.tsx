// shared/components/Symulacje/SimulationControlPanel.tsx
'use client';

import { type ReactNode } from 'react';

export interface SimulationParams {
  iloscSymulacji: number;
  ziarno: number;
  podzialZiarna: number;
  skalowanie: number;
  skalowanie2: number;
}

export interface DataAvailabilityStatus {
  label: string;
  isAvailable: boolean;
  status: string;
}

export interface SimulationControlPanelProps {
  simulationParams: SimulationParams;
  kwantyle: string;
  isCalculating: boolean;
  isCalculatingStatistics: boolean;
  hasResults: boolean;
  statisticsResultsCount: number;
  dataAvailability: DataAvailabilityStatus[];
  
  onUpdateSimulationParam: (key: keyof SimulationParams, value: number) => void;
  onSetKwantyle: (value: string) => void;
  onExecuteCalculations: () => void;
  onExecuteStatistics: () => void;
  onClearResults: () => void;
  onClearStatistics: () => void;
  onExportStatistics: () => void;
  
  children?: ReactNode;
}

export function SimulationControlPanel({
  simulationParams,
  kwantyle,
  isCalculating,
  isCalculatingStatistics,
  hasResults,
  statisticsResultsCount,
  dataAvailability,
  onUpdateSimulationParam,
  onSetKwantyle,
  onExecuteCalculations,
  onExecuteStatistics,
  onClearResults,
  onClearStatistics,
  onExportStatistics,
  children
}: SimulationControlPanelProps) {
  return (
    <aside className="w-80 bg-[#1e293b] border-r border-gray-700 p-6 sticky top-0 h-screen overflow-y-auto">
      <div className="space-y-6">
        {/* Nagłówek Sidebar */}
        <div>
          <h2 className="text-xl font-bold text-white mb-4">⚙️ Panel Kontrolny</h2>
          <p className="text-sm text-gray-400">Wybierz opcje obliczeń symulacji</p>
        </div>

        {/* Parametry Symulacji */}
        <div className="space-y-3">
          <h3 className="text-lg font-bold text-white">🎯 Parametry Symulacji</h3>
          
          {/* Ilość symulacji */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Ilość symulacji:
            </label>
            <input
              type="number"
              value={simulationParams.iloscSymulacji}
              onChange={(e) => onUpdateSimulationParam('iloscSymulacji', parseInt(e.target.value) || 1000)}
              className="w-full px-2 py-1.5 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm"
              min="1"
              max="10000"
            />
          </div>

          {/* Ziarno */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Ziarno:
            </label>
            <input
              type="number"
              value={simulationParams.ziarno}
              onChange={(e) => onUpdateSimulationParam('ziarno', parseInt(e.target.value) || 1111)}
              className="w-full px-2 py-1.5 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm"
              min="1"
            />
          </div>

          {/* Podział ziarna */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Podział ziarna:
            </label>
            <input
              type="number"
              value={simulationParams.podzialZiarna}
              onChange={(e) => onUpdateSimulationParam('podzialZiarna', parseInt(e.target.value) || 1000)}
              className="w-full px-2 py-1.5 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm"
              min="1"
            />
          </div>
        </div>

        {/* Dostępne dane do obliczeń */}
        <div className="space-y-3">
          <h3 className="text-lg font-bold text-white">📋 Dostępne dane do obliczeń</h3>
          
          {dataAvailability.map((data, index) => (
            <div key={index} className="flex items-center gap-3 p-3 rounded-lg bg-slate-800">
              <div className={`w-3 h-3 rounded-full ${data.isAvailable ? 'bg-green-500' : 'bg-red-500'}`}></div>
              <div>
                <span className="text-white font-semibold">{data.label}</span>
                <p className="text-xs text-gray-400">{data.status}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Dodatkowa zawartość (np. specyficzne dla typu symulacji) */}
        {children}

        {/* Divider */}
        <hr className="border-gray-600" />

        {/* Action Buttons */}
        <div className="space-y-2 pt-3">
          <button 
            onClick={onExecuteCalculations}
            disabled={isCalculating}
            className={`w-full py-2 px-3 rounded-lg transition-colors font-medium text-sm ${
              isCalculating 
                ? 'bg-gray-600 cursor-not-allowed' 
                : 'bg-green-600 hover:bg-green-700'
            } text-white`}
          >
            {isCalculating ? '⏳ Wykonywanie...' : '✅ Wykonaj obliczenia'}
          </button>
          
          {/* Skalowanie 1 */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Skalowanie 1:
            </label>
            <input
              type="number"
              step="0.1"
              value={simulationParams.skalowanie}
              onChange={(e) => onUpdateSimulationParam('skalowanie', parseFloat(e.target.value) || 1)}
              className="w-full px-2 py-1.5 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm"
              min="0.1"
              max="10"
            />
          </div>

          {/* Skalowanie 2 */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Skalowanie 2:
            </label>
            <input
              type="number"
              step="0.1"
              value={simulationParams.skalowanie2}
              onChange={(e) => onUpdateSimulationParam('skalowanie2', parseFloat(e.target.value) || 1)}
              className="w-full px-2 py-1.5 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm"
              min="0.1"
              max="10"
            />
          </div>

          {/* Kwantyle */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Kwantyle:
            </label>
            <input
              type="text"
              value={kwantyle}
              onChange={(e) => onSetKwantyle(e.target.value)}
              className="w-full px-2 py-1.5 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm"
              placeholder="0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.95,0.99,0.995"
            />
          </div>

          {/* Przycisk Wykonaj statystyki */}
          <button 
            onClick={onExecuteStatistics}
            disabled={isCalculatingStatistics}
            className={`w-full py-2 px-3 rounded-lg transition-colors font-medium text-sm ${
              isCalculatingStatistics
                ? 'bg-gray-600 cursor-not-allowed opacity-50' 
                : 'bg-blue-600 hover:bg-blue-700'
            } text-white`}
          >
            {isCalculatingStatistics ? '⏳ Wykonywanie statystyk...' : '📊 Wykonaj statystyki'}
          </button>
          
          {hasResults && (
            <button 
              onClick={onClearResults}
              className="w-full bg-red-600 hover:bg-red-700 text-white py-2 px-3 rounded-lg transition-colors font-medium text-sm"
            >
              🗑️ Wyczyść wyniki
            </button>
          )}
          
          {statisticsResultsCount > 0 && (
            <>
              <button 
                onClick={onClearStatistics}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 px-3 rounded-lg transition-colors font-medium text-sm"
              >
                📊 Wyczyść statystyki
              </button>
              
              <button 
                onClick={onExportStatistics}
                className="w-full bg-gray-600 hover:bg-gray-700 text-white py-2 px-3 rounded-lg transition-colors font-medium text-sm"
              >
                📊 Generuj raport
              </button>
            </>
          )}
        </div>
      </div>
    </aside>
  );
}