// shared/components/Symulacje/SimulationLayout.tsx
'use client';

import { type ReactNode } from 'react';

export interface SimulationLayoutProps {
  sidebar: ReactNode;
  children: ReactNode;
}

export function SimulationLayout({ sidebar, children }: SimulationLayoutProps) {
  return (
    <div className="flex h-full min-h-screen bg-[#0f172a]">
      {/* Sidebar Panel */}
      {sidebar}

      {/* Main Content Area */}
      <main className="flex-1 p-8 bg-[#0f172a] min-h-screen">
        <div className="w-full max-w-none">
          <div className="space-y-6">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}