// shared/components/Symulacje/SimulationStatisticsTable.tsx
'use client';

export interface StatisticResult {
  column: number;
  mean: number;
  std: number;
  SCR: number;
  quantiles: number[];
}

export interface SimulationStatisticsTableProps {
  statisticsResults: StatisticResult[];
  kwantyle: string;
  skalowanie: number;
  skalowanie2: number;
  title?: string;
  subtitle?: string;
}

export function SimulationStatisticsTable({
  statisticsResults,
  kwantyle,
  skalowanie,
  skalowanie2,
  title = "📊 Wyniki Statystyk",
  subtitle = "Analiza statystyczna wyników symulacji"
}: SimulationStatisticsTableProps) {
  if (statisticsResults.length === 0) {
    return (
      <div className="bg-[#1e293b] rounded-lg border border-gray-700 p-8 text-center">
        <h2 className="text-2xl font-bold text-gray-400 mb-4">📊 Brak wyników statystyk</h2>
        <p className="text-gray-500 mb-6">
          Wykonaj najpierw obliczenia symulacji, a następnie kliknij "Wykonaj statystyki" 
          aby zobaczyć analizę statystyczną wyników.
        </p>
        <div className="text-sm text-gray-600">
          <p>1. Wybierz opcje obliczeń (Brutto/Netto)</p>
          <p>2. Kliknij "✅ Wykonaj obliczenia"</p>
          <p>3. Kliknij "📊 Wykonaj statystyki"</p>
        </div>
      </div>
    );
  }

  const quantileLabels = kwantyle.split(',').map(q => q.trim());

  return (
    <div className="bg-[#1e293b] rounded-lg border border-gray-700 overflow-hidden">
      <div className="bg-[#334155] px-6 py-4 border-b border-gray-700">
        <h2 className="text-xl font-bold text-white">{title}</h2>
        <p className="text-sm text-gray-400 mt-1">{subtitle}</p>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="bg-[#475569] text-gray-200 text-xs uppercase font-medium">
            <tr>
              <th className="px-4 py-3 border-r border-gray-600 w-40">Statystyka</th>
              {/* Nagłówki kolumn - każda kolumna ma własną kolumnę w tabeli */}
              {statisticsResults.map((stat, index) => (
                <th key={index} className="px-4 py-3 border-r border-gray-600 text-center min-w-[140px]">
                  Kolumna {stat.column + 1}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-[#1e293b] text-gray-300">
            {/* Wiersz: Średnia */}
            <tr className="border-b border-gray-700 hover:bg-[#2d3748] transition-colors">
              <td className="px-4 py-4 border-r border-gray-600 font-semibold text-blue-400 bg-[#334155]">
                Średnia
              </td>
              {statisticsResults.map((stat, index) => (
                <td key={index} className="px-4 py-4 border-r border-gray-600 text-center font-mono">
                  {typeof stat.mean === 'number' 
                    ? stat.mean.toLocaleString('pl-PL', { 
                        minimumFractionDigits: 2, 
                        maximumFractionDigits: 2 
                      })
                    : '-'
                  }
                </td>
              ))}
            </tr>
            
            {/* Wiersz: Odchylenie standardowe */}
            <tr className="border-b border-gray-700 hover:bg-[#2d3748] transition-colors">
              <td className="px-4 py-4 border-r border-gray-600 font-semibold text-blue-400 bg-[#334155]">
                Odch. Std.
              </td>
              {statisticsResults.map((stat, index) => (
                <td key={index} className="px-4 py-4 border-r border-gray-600 text-center font-mono">
                  {typeof stat.std === 'number' 
                    ? stat.std.toLocaleString('pl-PL', { 
                        minimumFractionDigits: 2, 
                        maximumFractionDigits: 2 
                      })
                    : '-'
                  }
                </td>
              ))}
            </tr>
            
            {/* Wiersz: SCR */}
            <tr className="border-b border-gray-700 hover:bg-[#2d3748] transition-colors">
              <td className="px-4 py-4 border-r border-gray-600 font-semibold text-orange-400 bg-[#334155]">
                SCR
              </td>
              {statisticsResults.map((stat, index) => (
                <td key={index} className="px-4 py-4 border-r border-gray-600 text-center font-mono text-orange-400 font-semibold">
                  {typeof stat.SCR === 'number' 
                    ? stat.SCR.toLocaleString('pl-PL', { 
                        minimumFractionDigits: 2, 
                        maximumFractionDigits: 2 
                      })
                    : '-'
                  }
                </td>
              ))}
            </tr>
            
            {/* Wiersze: Kwantyle */}
            {quantileLabels.map((q, qIdx) => (
              <tr key={qIdx} className="border-b border-gray-700 hover:bg-[#2d3748] transition-colors">
                <td className="px-4 py-4 border-r border-gray-600 font-semibold text-green-400 bg-[#334155]">
                  Q{(parseFloat(q) * 100).toFixed(1)}%
                </td>
                {statisticsResults.map((stat, statIdx) => (
                  <td key={statIdx} className="px-4 py-4 border-r border-gray-600 text-center font-mono">
                    {stat.quantiles && stat.quantiles[qIdx] !== undefined 
                      ? (typeof stat.quantiles[qIdx] === 'number' 
                          ? stat.quantiles[qIdx].toLocaleString('pl-PL', { 
                              minimumFractionDigits: 2, 
                              maximumFractionDigits: 2 
                            })
                          : '-'
                        )
                      : '-'
                    }
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {/* Stopka z informacjami */}
      <div className="bg-[#334155] px-6 py-3 border-t border-gray-700 text-xs text-gray-400">
        <div className="flex justify-between items-center">
          <span>
            📊 Kwantyle: {kwantyle} | 🎯 Skalowanie 1: {skalowanie} | 🎯 Skalowanie 2: {skalowanie2}
          </span>
          <span>
            📊 Liczba kolumn: {statisticsResults.length}
          </span>
        </div>
      </div>
    </div>
  );
}