/* ------------------------------------------------------------------ */
/*                        Summary Tab Configuration Types             */
/* ------------------------------------------------------------------ */

import { OverrideMap, SourceSwitchMap } from './developmentEnd'

export interface SummaryConfig {
  // Identyfikacja kontekstu
  tableContext: string // Uniwersalny string dla wszystkich kontekstów
  
  // Opcjonalny hook store - jeśli nie podany, używa useTrainDevideStoreDet
  useStore?: any
  
  // Store selectors - leftCount
  leftCountSelector: (state: any) => number
  setLeftCountSelector: (state: any) => (n: number) => void
  
  // Store selectors - selectedCurve  
  selectedCurveSelector: (state: any) => string | null
  setSelectedCurveSelector: (state: any) => (c: string | null) => void
  
  // Store selectors - manualOverrides
  manualOverridesSelector: (state: any) => OverrideMap
  setManualOverridesSelector: (state: any) => (o: OverrideMap) => void
  
  // Store selectors - sourceSwitches
  sourceSwitchesSelector: (state: any) => SourceSwitchMap
  setSourceSwitchesSelector: (state: any) => (s: SourceSwitchMap) => void
  
  // Store selectors - dane bazowe
  baseDataSelector: (state: any) => number[] | undefined
  simResultsSelector: (state: any) => Record<string, Record<string, number>> | undefined
  
  // Store selectors - selected values z tabeli Selected Value
  selectedValuesSelector?: (state: any) => number[] | undefined
  
  // Store selectors - kombinowane dane
  setCombinedDataSelector: (state: any) => (data: (number | string)[]) => void
  
  // Store selectors - pozostałe
  setRemainingHeadersSelector: (state: any) => (headers: string[]) => void
  
  // Transformacje danych
  transformBaseData?: (data: number[] | undefined, leftCount: number) => number[] | undefined
  transformSimResults?: (results: any) => Record<string, Record<string, number>> | undefined
  
  // Opcjonalne zachowania
  disabledCurves?: string[]
  debugLabel?: string
}