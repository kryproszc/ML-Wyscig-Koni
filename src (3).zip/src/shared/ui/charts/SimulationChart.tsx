import React, { useMemo } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

type SimResults = Record<string, Record<string, number>>;

type Props = {
  simResults: SimResults | null;
  devJ?: number[];
  dpRange: [number, number];
  selectedCurves: string[];
};

export const SimulationChart = ({
  simResults,
  devJ,
  dpRange,
  selectedCurves,
}: Props) => {
  // Oblicz dynamiczny domain Y na podstawie wszystkich wartości
  const yAxisDomain = useMemo(() => {
    if (!simResults) return [0, 1];
    
    const allValues: number[] = [];
    

    
    // Zbierz wszystkie wartości z simResults
    Object.values(simResults).forEach(curveData => {
      Object.values(curveData).forEach(value => {
        if (typeof value === 'number' && !isNaN(value) && isFinite(value)) {
          allValues.push(value);
        }
      });
    });
    
    // Dodaj wartości z devJ (Initial Selection)
    if (devJ) {
      devJ.forEach(value => {
        if (typeof value === 'number' && !isNaN(value) && isFinite(value)) {
          allValues.push(value);
        }
      });
    }
    
    if (allValues.length === 0) return [0, 1];
    
    const minValue = Math.min(...allValues);
    const maxValue = Math.max(...allValues);
    const range = maxValue - minValue;
    
    // Dodaj 10% marginesu w górę i w dół
    const margin = range * 0.1;
    const yMin = minValue - margin;
    const yMax = maxValue + margin;
    
    return [yMin, yMax];
  }, [simResults, devJ]);

  const data = useMemo(() => {
    if (!simResults) return [];
    
    // Weź klucze z pierwszej dostępnej krzywej zamiast zakładać że jest "Exponential"
    const firstCurve = Object.keys(simResults)[0];
    if (!firstCurve) return [];
    

    
    const allDpKeys = Object.keys(simResults[firstCurve] ?? {});
    const chartData = allDpKeys
      .filter((dpKey) => {
        const n = parseInt(dpKey.replace("dp: ", ""), 10);
        return n >= dpRange[0] && n <= dpRange[1];
      })
      .map((dpKey) => {
        const point: Record<string, number | string> = { dp: dpKey };
        for (const curve in simResults) {
          point[curve] = simResults[curve]?.[dpKey] ?? 0;
        }
        const idx = parseInt(dpKey.replace("dp: ", ""), 10) - 1;
        const devVal = devJ?.[idx];
        if (typeof devVal === "number") point["Initial Selection"] = devVal;
        return point;
      });
      
    return chartData;
  }, [simResults, devJ, dpRange, selectedCurves]);

  if (!simResults) return null;

  // Funkcja do formatowania liczb
  const formatNumber = (value: number): string => {
    if (value >= 1000000) {
      return (value / 1000000).toFixed(2) + 'M';
    }
    if (value >= 1000) {
      return (value / 1000).toFixed(2) + 'k';
    }
    return value.toFixed(3);
  };

  // Funkcja do formatowania tooltipa
  const formatTooltip = (value: any, name: string) => {
    if (typeof value === 'number') {
      return [formatNumber(value), name];
    }
    return [value, name];
  };

  return (
    <div className="w-full h-[600px]">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{ top: 30, right: 40, left: 80, bottom: 100 }}
          style={{ background: "#1a1a2e", borderRadius: 12, padding: 15 }}
        >
          <CartesianGrid stroke="#444" strokeDasharray="3 3" />
          <XAxis 
            dataKey="dp" 
            stroke="#ccc" 
            interval={0} 
            tick={{ fill: "#ccc", fontSize: 14 }} 
          />
          <YAxis 
            stroke="#ccc" 
            domain={yAxisDomain}
            tick={{ fill: "#ccc", fontSize: 12 }}
            tickFormatter={formatNumber}
            width={80}
          />
          <Tooltip
            contentStyle={{ 
              background: "#2c2c3e", 
              borderColor: "#666", 
              color: "#fff",
              fontSize: "14px",
              borderRadius: "8px"
            }}
            labelStyle={{ color: "#aaa", fontSize: "12px" }}
            formatter={formatTooltip}
          />
          <Legend 
            verticalAlign="bottom" 
            height={60} 
            wrapperStyle={{ 
              paddingTop: 30,
              fontSize: "14px"
            }} 
          />

          {selectedCurves.includes("Initial Selection") && (
            <Line type="monotone" dataKey="Initial Selection" stroke="#ef4444" strokeWidth={3} name="Initial Selection" dot={{ r: 4 }} />
          )}
          
          {/* Dynamiczne renderowanie wszystkich krzywych z simResults */}
          {simResults && Object.keys(simResults).map((curveName, index) => {
            if (!selectedCurves.includes(curveName) || curveName === "Initial Selection") return null;
            
            const colors = [
              "#8b5cf6", // purple
              "#10b981", // green  
              "#f59e0b", // yellow
              "#2dd4bf", // teal
              "#4f8bff", // blue
              "#f87171", // red
              "#facc15", // amber
              "#ec4899", // pink
            ];
            
            const color = colors[index % colors.length];
            
            return (
              <Line 
                key={curveName}
                type="monotone" 
                dataKey={curveName} 
                stroke={color} 
                strokeWidth={3} 
                name={curveName}
                dot={{ r: 4 }} 
              />
            );
          })}
          
          {/* Backward compatibility - static curves */}
          {selectedCurves.includes("Exponential") && !simResults?.["Exponential"] && (
            <Line type="monotone" dataKey="Exponential" stroke="#4f8bff" strokeWidth={3} dot={{ r: 4 }} />
          )}
          {selectedCurves.includes("Exponential_weighted") && !simResults?.["Exponential_weighted"] && (
            <Line type="monotone" dataKey="Exponential_weighted" stroke="#8b5cf6" strokeWidth={3} name="Exponential Weighted" dot={{ r: 4 }} />
          )}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};
