import { TableData } from '@/components/TableData';

interface DataTableViewProps {
  title: string;
  data: string[][] | null | undefined;
  noDataMessage: string;
  fallbackComponent?: React.ComponentType;
  className?: string;
  titleClassName?: string;
}

/**
 * Generic reusable table view component for displaying formatted data
 * Part of Atomic Design - Molecule level
 */
export function DataTableView({
  title,
  data,
  noDataMessage,
  fallbackComponent: FallbackComponent,
  className = "space-y-4",
  titleClassName = "text-xl font-semibold"
}: DataTableViewProps) {
  
  if (!data || data.length === 0) {
    return (
      <div className={className}>
        <p className="text-gray-400 text-sm">
          {noDataMessage}
        </p>
        {FallbackComponent && <FallbackComponent />}
      </div>
    );
  }

  return (
    <div className={className}>
      <h2 className={titleClassName}>{title}</h2>
      <TableData data={data} />
    </div>
  );
}
