import { useMemo } from 'react';

interface ValidationFunctions {
  isPaidTriangleLoaded: () => boolean;
  isDiscountRatesLoaded: () => boolean;
  isNettoBruttoLoaded: () => boolean;
  canSelectBrutto: boolean;
  canSelectBruttoDysk: boolean;
  canSelectNettoDysk: boolean;
}

export function useDataValidation(
  paidTriangle: any,
  discountRatesTriangle: any,
  paramsymTriangle: any
): ValidationFunctions {
  
  const isPaidTriangleLoaded = () => {
    return Array.isArray(paidTriangle) && paidTriangle.length > 0;
  };

  const isDiscountRatesLoaded = () => {
    return discountRatesTriangle && Object.keys(discountRatesTriangle).length > 0;
  };

  const isNettoBruttoLoaded = () => {
    return paramsymTriangle && Object.keys(paramsymTriangle).length > 0;
  };

  const validation = useMemo(() => {
    const paidLoaded = isPaidTriangleLoaded();
    const discountLoaded = isDiscountRatesLoaded();
    const netBruttoLoaded = isNettoBruttoLoaded();

    return {
      isPaidTriangleLoaded,
      isDiscountRatesLoaded,
      isNettoBruttoLoaded,
      canSelectBrutto: paidLoaded,
      canSelectBruttoDysk: paidLoaded && discountLoaded,
      canSelectNettoDysk: paidLoaded && discountLoaded && netBruttoLoaded
    };
  }, [paidTriangle, discountRatesTriangle, paramsymTriangle]);

  return validation;
}