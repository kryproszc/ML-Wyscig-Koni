// shared/hooks/useSimulationApi.ts
'use client';

import { useState } from 'react';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? '';

export interface SimulationRequestData {
  user_id: string;
  paid_triangle: any[][];
  weights: number[][];
  cl_indexes: number[];
  sigma_indexes: number[];
  left_count_cl: number;
  selected_value_cl: number[];
  selected_value_sigma: number[];
  combined_sd_summary: number[];
  tail_count_cl: number | null;
  calculation_options: {
    brutto: boolean;
    brutto_dysk: boolean;
    netto_dysk: boolean;
  };
  discount_rates: Record<string, any>;
  netto_brutto: Record<string, any>;
  ilosc_symulacji: number;
  ziarno: number;
  podzial_ziarna: number;
  skalowanie: number;
  kwantyle: number[];
}

export interface SimulationResults {
  last_col: number[];
  cum_trian: number[]; // 🔥 POPRAWKA: number[] zamiast number[][]
  ult_net_disc: number[];
  userId: string;
}

export interface StatisticsRequestData {
  user_id: string;
  kwantyle: number[];
  skalowanie: number;
  skalowanie2: number;
  simulation_results?: SimulationResults | null;
  deterministic_results?: {
    cum_trian: number[];
    last_col: number[];
    ult_net_disc: number[];
    userId: string;
    calculatedAt: string;
  } | null; // DODANE: deterministyczne wyniki
}

export interface StatisticsResults {
  column: number;
  mean: number;
  std: number;
  SCR: number;
  quantiles: number[];
}

export interface AlertState {
  show: boolean;
  variant: 'error' | 'warning' | 'success' | 'info';
  title: string;
  message: string;
}

export function useSimulationApi() {
  const [isCalculating, setIsCalculating] = useState(false);
  const [isCalculatingStatistics, setIsCalculatingStatistics] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const showAlert = (
    variant: 'error' | 'warning' | 'success' | 'info',
    title: string,
    message: string,
    onAlert?: (alert: AlertState) => void
  ) => {
    if (onAlert) {
      onAlert({
        show: true,
        variant,
        title,
        message
      });
    }
  };

  const executeSimulation = async (
    requestData: SimulationRequestData,
    endpoint: string,
    onAlert?: (alert: AlertState) => void
  ): Promise<SimulationResults | null> => {
    try {
      setIsCalculating(true);
      setError(null);
      
      console.log('🚀 ROZPOCZĘCIE executeSimulation');
      console.log('🔍 Endpoint:', `${API_URL}${endpoint}`);
      console.log('🔍 RequestData:', requestData);
      
      const response = await fetch(`${API_URL}${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData)
      });

      console.log('🔍 Response status:', response.status);
      console.log('🔍 Response ok:', response.ok);

      const result = await response.json();
      console.log('🔍 Response result:', result);
      
      if (!response.ok) {
        const errorMsg = `Backend błąd ${response.status}`;
        console.log('❌ Response not ok:', errorMsg);
        setError(errorMsg);
        showAlert('error', 'Błąd serwera', `Wystąpił błąd podczas komunikacji z serwerem (${response.status})`, onAlert);
        return null;
      }
      
      if (result.status === 'ok') {
        console.log('✅ Status OK, sprawdzam vectors...');
        console.log('🔍 Cały result object:', JSON.stringify(result, null, 2));
        console.log('🔍 result.vectors:', result.vectors);
        console.log('🔍 Dostępne klucze w result:', Object.keys(result));
        
        // Sprawdźmy czy dane są w innej strukturze
        if (result.vectors) {
          console.log('🔍 result.vectors klucze:', Object.keys(result.vectors));
        }
        
        if (result.vectors) {
          const simulationResults: SimulationResults = {
            last_col: Array.isArray(result.vectors.last_col) ? result.vectors.last_col : [],
            cum_trian: Array.isArray(result.vectors.cum_trian) ? result.vectors.cum_trian : [],
            ult_net_disc: Array.isArray(result.vectors.ult_net_disc) ? result.vectors.ult_net_disc : [],
            userId: requestData.user_id
          };
          
          console.log('✅ SimulationResults utworzone:', simulationResults);
          showAlert('success', 'Obliczenia zakończone!', 'Symulacja została wykonana pomyślnie. Wyniki są dostępne w tabelach.', onAlert);
          return simulationResults;
        } else {
          console.log('❌ Brak vectors w odpowiedzi');
          console.log('🔍 Backend tylko zapisał dane, nie zwrócił ich. Tworzymy dummy results...');
          
          // Tymczasowe rozwiązanie - zwróć dummy results żeby frontend wiedział że symulacja się udała
          const simulationResults: SimulationResults = {
            last_col: [1], // dummy data
            cum_trian: [1], // dummy data  
            ult_net_disc: [1], // dummy data
            userId: requestData.user_id
          };
          
          console.log('✅ Dummy SimulationResults utworzone:', simulationResults);
          showAlert('success', 'Obliczenia zakończone!', 'Symulacja została wykonana i zapisana na serwerze. Możesz teraz wykonać statystyki.', onAlert);
          return simulationResults;
        }
      } else {
        const errorMsg = `Nieoczekiwany status odpowiedzi: ${result.status}`;
        console.log('❌ Nieoczekiwany status:', errorMsg);
        setError(errorMsg);
        showAlert('error', 'Błąd odpowiedzi', errorMsg, onAlert);
      }
      
      console.log('❌ Zwracam null');
      return null;
      
    } catch (error) {
      const errorMsg = `Błąd połączenia: ${error}`;
      setError(errorMsg);
      showAlert('error', 'Błąd połączenia', 'Nie udało się połączyć z serwerem. Sprawdź połączenie internetowe.', onAlert);
      return null;
    } finally {
      setIsCalculating(false);
    }
  };

  const executeStatistics = async (
    requestData: StatisticsRequestData,
    endpoint: string,
    onAlert?: (alert: AlertState) => void
  ): Promise<StatisticsResults[] | null> => {
    try {
      setIsCalculatingStatistics(true);
      setError(null);
      
      const response = await fetch(`${API_URL}${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData)
      });

      const result = await response.json();
      
      if (!response.ok) {
        const errorMsg = `Backend błąd statystyk ${response.status}`;
        console.log('❌ Błąd statystyk response:', response.status);
        console.log('❌ Błąd statystyk result:', result);
        showAlert('error', 'Błąd statystyk', `Wystąpił błąd podczas obliczania statystyk (${response.status}): ${result.detail || result.message || 'Nieznany błąd'}`, onAlert);
        return null;
      }
      
      if (result.status === 'ok') {
        console.log('📈 === STATS Z BACKENDU ===');
        console.log('🎯 Cała odpowiedź:', result);
        
        if (result.stats) {
          console.log('✅ STATS odebrane:', result.stats);
          
          const statisticsResults = Array.isArray(result.stats) ? result.stats : [];
          
          showAlert('success', 'Statystyki wykonane!', 
            `Statystyki zostały obliczone pomyślnie.\n\nKwantyle: ${requestData.kwantyle.join(',')}\nSkalowanie 1: ${requestData.skalowanie}\nSkalowanie 2: ${requestData.skalowanie2}\n\n${result.message || 'Wyniki dostępne'}`, 
            onAlert
          );
          
          return statisticsResults;
        } else {
          console.log('❌ BRAK stats w odpowiedzi!');
          console.log('🔍 Dostępne klucze:', Object.keys(result));
          return [];
        }
      } else {
        showAlert('error', 'Błąd odpowiedzi', `Nieoczekiwany status statystyk: ${result.status}`, onAlert);
        return null;
      }
      
    } catch (error) {
      const errorMsg = `Błąd wykonania statystyk: ${error}`;
      showAlert('error', 'Błąd statystyk', 'Nie udało się wykonać obliczeń statystycznych. Spróbuj ponownie.', onAlert);
      return null;
    } finally {
      setIsCalculatingStatistics(false);
    }
  };

  const resetBackendData = async (
    userId: string,
    onAlert?: (alert: AlertState) => void
  ): Promise<boolean> => {
    try {
      const response = await fetch(`${API_URL}/calc/resetSimulationData`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: userId })
      });
      
      if (response.ok) {
        showAlert('success', 'Reset wykonany', 'Dane symulacji na backendzie zostały zresetowane.', onAlert);
        return true;
      } else {
        showAlert('warning', 'Reset nie powiódł się', 'Sprawdź czy backend obsługuje /calc/resetSimulationData', onAlert);
        return false;
      }
    } catch (error) {
      showAlert('info', 'Reset niemożliwy', 'Endpoint resetowania nie jest dostępny.', onAlert);
      return false;
    }
  };

  return {
    isCalculating,
    isCalculatingStatistics,
    error,
    executeSimulation,
    executeStatistics,
    resetBackendData,
    setError
  };
}