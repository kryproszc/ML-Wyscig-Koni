'use client';

import { useEffect, useMemo } from 'react';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useUserStore } from '@/app/_components/useUserStore';
import { useLabelsStore } from '@/stores/useLabelsStore';
import type { CustomCell } from '@/stores/trainDevideStoreDeterministyczny';
import type { FitCurveConfig, FitCurveData, FitCurveActions } from '@/shared/components/fit-curve';

interface UseFitCurveDataProps {
  config: FitCurveConfig;
  // Mapowanie pól store dla różnych typów danych
  storeMapping: {
    preview: string;
    previewCandidate: string;
    selectedIndexes: string;
    simResults: string;
    r2Scores: string;
    tailCount: string;
    finalCustom: string;
    baseData: string[];
    finalData: string[];
    clearMethods: string[];
    setMethods: {
      setPreview: string;
      setPreviewCandidate: string;
      setSelectedIndexes: string;
      setSimResults: string;
      setR2Scores: string;
      setTailCount: string;
    };
  };
  // Hook store'u - może być useTrainDevideStoreDet, useAddPaidStore, etc.
  useStore: () => any;
}

export function useFitCurveData({ config, storeMapping, useStore }: UseFitCurveDataProps) {
  const store = useStore();
  const userId = useUserStore((s) => s.userId);
  
  // Labels from store for column headers
  const rawDetColumnLabels = useLabelsStore(s => s.detColumnLabels);
  const detColumnLabels = useMemo(
    () => ["", ...rawDetColumnLabels],
    [rawDetColumnLabels]
  );

  // Dynamically get data from store based on mapping
  const preview = (store as any)[storeMapping.preview];
  const previewCandidate = (store as any)[storeMapping.previewCandidate];
  const selectedIndexes = (store as any)[storeMapping.selectedIndexes];
  const simResults = (store as any)[storeMapping.simResults];
  const r2Scores = (store as any)[storeMapping.r2Scores];
  const tailCount = (store as any)[storeMapping.tailCount];
  const finalCustom = (store as any)[storeMapping.finalCustom];

  console.log(`🎯 [${config.dataType}] tailCount debug:`, {
    tailCountKey: storeMapping.tailCount,
    tailCountValue: tailCount,
    tailCountType: typeof tailCount,
    storeKeys: Object.keys(store)
  });

  // Get base data sources
  const baseDataValues = storeMapping.baseData.map(key => (store as any)[key]).filter(Boolean);
  const finalDataValues = storeMapping.finalData.map(key => {
    const data = (store as any)[key];
    return data?.values || data;
  }).filter(Boolean);

  // Get actions
  const actions: FitCurveActions = {
    setPreview: (store as any)[storeMapping.setMethods.setPreview],
    setPreviewCandidate: (store as any)[storeMapping.setMethods.setPreviewCandidate],
    setSelectedIndexes: (store as any)[storeMapping.setMethods.setSelectedIndexes],
    setSimResults: (store as any)[storeMapping.setMethods.setSimResults],
    setR2Scores: (store as any)[storeMapping.setMethods.setR2Scores],
    setTailCount: (store as any)[storeMapping.setMethods.setTailCount],
    clearSimResults: storeMapping.clearMethods?.[0] ? (store as any)[storeMapping.clearMethods[0]] : (() => {}),
    clearR2Scores: storeMapping.clearMethods?.[1] ? (store as any)[storeMapping.clearMethods[1]] : (() => {}),
  };

  console.log(`🎯 [${config.dataType}] setTailCount debug:`, {
    setTailCountKey: storeMapping.setMethods.setTailCount,
    setTailCountFn: actions.setTailCount,
    isFunctionValid: typeof actions.setTailCount === 'function'
  });

  /* ------- bieżący wektor -------- */
  const currentVector = useMemo(() => {
    // Debug dla AddPaid - tylko jeśli nie ma danych
    if ((config.dataType === 'addJ' || config.dataType === 'sigmaLR' || config.dataType === 'sdLR') && !baseDataValues.length) {
      console.log(`🔍 [${config.dataType}] Brak danych w store:`, {
        baseDataKeys: storeMapping.baseData,
        storeValues: storeMapping.baseData.map(key => ({ key, value: (store as any)[key] }))
      });
    }
    
    // Najpierw sprawdź czy są dane z finalData
    const baseVector = finalDataValues[0]?.length ? finalDataValues[0] : 
                      baseDataValues[0]?.length ? baseDataValues[0] : 
                      [];
    
    if (!baseVector?.length) return [];
    
    const merged = [...baseVector];
    (Object.entries(finalCustom ?? {}) as [string, CustomCell][]).forEach(
      ([i, cell]) => (merged[Number(i)] = cell.value)
    );
    return merged;
  }, [finalDataValues, baseDataValues, finalCustom]);

  /* ------- automatyczne inicjalizowanie z danych -------- */
  useEffect(() => {
    // Debug dla Incurred
    if (config.dataType === 'devJ' && config.apiEndpoint.includes('incurred')) {
      console.log(`🔍 [useFitCurveData] ${config.dataType} Incurred debug:`, {
        preview: preview?.length || 0,
        currentVector: currentVector?.length || 0,
        baseDataValues: baseDataValues.map(v => v?.length || 0),
        disableAutoLoading: config.disableAutoLoading
      });
    }
    
    // Jeśli config ma disableAutoLoading=true, nie ładuj automatycznie danych
    if (config.disableAutoLoading) {
      console.log(`🚫 Auto-loading disabled for ${config.dataType} - waiting for manual "Dopasuj krzywę" click`);
      return;
    }
    
    // Debug tylko jeśli są problemy z danymi
    if (!currentVector?.length && baseDataValues.length > 0) {
      console.log(`🔍 FitCurve${config.displayName} - problem z danymi:`, {
        [`${config.dataType}Preview`]: preview?.length || 0,
        baseData: baseDataValues.map(v => v?.length || 0),
        [`current${config.displayName}Vector`]: currentVector?.length || 0,
      });
    }
    
    // Jeśli nie ma preview, ale są dane, załaduj je automatycznie
    // TYLKO jeśli disableAutoLoading nie jest ustawione
    if (!preview && currentVector?.length && !config.disableAutoLoading) {
      console.log(`🔄 Auto-loading ${config.dataType} data:`, currentVector);
      actions.setPreview(currentVector);
      
      // Automatycznie wybierz wartości > threshold
      const autoSelected = currentVector
        .map((v, i) => (v > config.thresholdValue ? i : -1))
        .filter((i) => i >= 0);
      actions.setSelectedIndexes(autoSelected);
      console.log(`✅ Auto-selected ${config.dataType} indexes:`, autoSelected);
    }
  }, [
    ...baseDataValues, 
    ...finalDataValues, 
    preview, 
    currentVector, 
    actions.setPreview, 
    actions.setSelectedIndexes, 
    tailCount, 
    config.dataType, 
    config.displayName, 
    config.thresholdValue,
    config.disableAutoLoading
  ]);

  // Funkcja do ręcznego odświeżania danych
  const forceRefreshData = () => {
    console.log(`🔄 Force refresh ${config.dataType} - loading data directly`);
    if (currentVector?.length) {
      actions.setPreview(currentVector);
      
      // Specjalna logika dla PaidToIncurred r_j - wykluczenie wartości równych 1
      let autoSelected: number[];
      if (config.dataType === 'rJ' && config.thresholdValue < 0) {
        // Dla r_j PaidToIncurred: wybierz wszystkie OPRÓCZ tych równych 1.0 (z tolerancją)
        autoSelected = currentVector
          .map((v, i) => (Math.abs(v - 1.0) > 0.0001 ? i : -1))
          .filter((i) => i >= 0);
        console.log(`✅ PaidToIncurred r_j - excluded values equal to 1.0, selected indexes:`, autoSelected);
      } else {
        // Standardowa logika dla innych typów
        autoSelected = currentVector
          .map((v, i) => (v > config.thresholdValue ? i : -1))
          .filter((i) => i >= 0);
      }
      
      actions.setSelectedIndexes(autoSelected);
      console.log(`✅ Force refreshed ${config.dataType} with data:`, currentVector);
    }
  };

  // Prepare fit curve data
  const data: FitCurveData = {
    preview,
    previewCandidate,
    selectedIndexes: selectedIndexes || [],
    simResults,
    r2Scores,
    tailCount: tailCount ?? "",
    relatedData: {
      // Add related data based on baseData
      ...Object.fromEntries(
        storeMapping.baseData.slice(1).map((key, index) => [
          key, 
          baseDataValues[index + 1]
        ])
      )
    }
  };

  // Helper function to convert camelCase to snake_case
  const toSnakeCase = (str: string) => {
    return str.replace(/([A-Z])/g, '_$1').toLowerCase();
  };

  // Build request data function
  const buildRequestData = (validIndexes: number[]) => {
    const snakeCaseDataType = toSnakeCase(config.dataType);
    
    const baseRequest = {
      [config.dataKey]: validIndexes.map((i) => preview![i]!),
      selected_indexes: validIndexes,
      tail_values: tailCount === "" ? null : [Number(tailCount)],
      user_id: userId,
      [`full_${snakeCaseDataType}`]: preview,
    };

    // Add related data to request - wszystkie baseData oprócz pierwszego (które jest już w baseRequest)
    storeMapping.baseData.slice(1).forEach((key, index) => {
      const relatedData = baseDataValues[index + 1];
      if (relatedData) {
        const snakeCaseKey = toSnakeCase(key);
        baseRequest[`full_${snakeCaseKey}`] = relatedData;
        baseRequest[`selected_${snakeCaseKey}`] = validIndexes.map((i) => relatedData[i]!);
      }
    });

    return baseRequest;
  };

  // Process API response
  const processApiResponse = (response: any) => {
    console.log(`🔍 [processApiResponse] Full response for ${config.dataType}:`, response);
    const { simulation_results, r2_scores, se_pred } = response;
    
    if (simulation_results) {
      console.log(`📊 [${config.dataType}] simulation_results structure:`, simulation_results);
      
      // Log all curve names found in simulation_results
      const allCurveNames = new Set<string>();
      Object.entries(simulation_results).forEach(([dp, curves]) => {
        Object.keys(curves as Record<string, number>).forEach(curveName => {
          allCurveNames.add(curveName);
        });
      });
      console.log(`🎯 [${config.dataType}] Available curve names:`, Array.from(allCurveNames));
      console.log(`🎯 [${config.dataType}] Expected curves in config:`, config.selectedCurves);
      
      const sim: Record<string, Record<string, number>> = {};
      Object.entries(simulation_results).forEach(([dp, curves]) =>
        Object.entries(curves as Record<string, number>).forEach(
          ([curve, v]) => {
            if (!sim[curve]) sim[curve] = {};
            sim[curve][dp] = v;
          }
        )
      );
      actions.setSimResults(sim);
    }

    if (r2_scores) {
      console.log(`📊 [${config.dataType}] r2_scores structure:`, r2_scores);
      console.log(`🎯 [${config.dataType}] R2 curve names:`, Object.keys(r2_scores));
      
      const r2: Record<string, number> = {};
      Object.entries(r2_scores).forEach(([curve, obj]) => {
        const v = (obj as any)["Wartość"];
        r2[curve] = typeof v === "number" ? v : Number(v);
      });
      actions.setR2Scores(r2);
    }

    // Handle se_pred for MultPaid (devJ and sigma) and AddPaid (addJ)
    if (se_pred && Array.isArray(se_pred) && (config.dataType === 'devJ' || config.dataType === 'sigma' || config.dataType === 'addJ')) {
      console.log(`✅ [processApiResponse] Zapisuję se_pred dla ${config.dataType}:`, se_pred);
      
      if (config.dataType === 'addJ') {
        // For AddPaid, save se_pred to simResultsSdLR
        (store as any).setSimResultsSdLR?.(se_pred);
        console.log(`✅ [processApiResponse] Zapisano se_pred do simResultsSdLR dla AddPaid:`, se_pred);
      } else {
        // For MultPaid (devJ/sigma)
        (store as any).setSePred?.(se_pred);
      }
    }

    // Log additional data
    Object.keys(response).forEach(key => {
      if (key.endsWith('_data') || key === 'processed_data') {
        console.log(`📊 ${key} processed:`, response[key]);
      }
    });
  };

  // Prepare related data info for UI
  const relatedDataInfo = {
    labels: storeMapping.baseData.slice(1),
    lengths: baseDataValues.slice(1).map(data => data?.length || 0)
  };

  return {
    data,
    actions,
    currentVector,
    userId: userId!,
    detColumnLabels,
    forceRefreshData,
    buildRequestData,
    processApiResponse,
    relatedDataInfo: relatedDataInfo.lengths.some(l => l > 0) ? relatedDataInfo : undefined
  };
}