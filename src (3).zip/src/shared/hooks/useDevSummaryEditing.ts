/* ------------------------------------------------------------------ */
/*                    useDevSummaryEditing Hook                      */
/* ------------------------------------------------------------------ */

import { useState } from 'react'
import type { OverrideMap } from '@/shared/types/developmentEnd'

export function useDevSummaryEditing() {
  const [editingIndex, setEditingIndex] = useState<number | null>(null)
  const [editValue, setEditValue] = useState<string>('')

  const startEditing = (index: number, currentValue: string) => {
    setEditingIndex(index)
    setEditValue(currentValue)
  }

  const stopEditing = () => {
    setEditingIndex(null)
    setEditValue('')
  }

  const saveEdit = (
    index: number,
    manualOverrides: OverrideMap,
    setManualOverrides: (overrides: OverrideMap) => void
  ) => {
    const num = parseFloat(editValue)
    if (!Number.isNaN(num)) {
      const current = manualOverrides[index]?.value
      if (current !== num) {
        setManualOverrides({
          ...manualOverrides,
          [index]: { curve: "manual", value: num },
        })
      }
    }
    stopEditing()
  }

  const clearManualOverride = (
    index: number,
    manualOverrides: OverrideMap,
    setManualOverrides: (overrides: OverrideMap) => void
  ) => {
    const updated = { ...manualOverrides }
    delete updated[index]
    setManualOverrides(updated)
  }

  return {
    editingIndex,
    editValue,
    setEditValue,
    startEditing,
    stopEditing,
    saveEdit,
    clearManualOverride
  }
}
