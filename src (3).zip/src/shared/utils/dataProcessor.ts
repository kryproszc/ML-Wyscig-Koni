export const processSelectedRow = (triangle: any, selectedLine: number | null) => {
  if (!triangle || selectedLine === null || !triangle[selectedLine]) {
    return {};
  }

  const selectedRow = triangle[selectedLine];
  const values: { [key: string]: number | null } = {};
  
  Object.keys(selectedRow).forEach(colKey => {
    const colIndex = parseInt(colKey);
    if (colIndex !== 0) { // Skip column 0 (labels)
      const value = selectedRow[colIndex];
      if (typeof value === 'number') {
        values[colKey] = value;
      }
    }
  });
  
  return { "0": values };
};

export const processSelectedValues = (
  selectedValues: any[] | undefined, 
  fallbackSummary: any[] | undefined, 
  fallbackVector: any[] | undefined, 
  defaultValue: number = 1.0
): number[] => {
  // 1. Priority: selectedValues (if no NaN)
  if (Array.isArray(selectedValues) && selectedValues.length > 0) {
    const hasAnyNaN = selectedValues.some((val: any) => 
      val === null || val === undefined || isNaN(val) || !Number.isFinite(val)
    );
    
    if (!hasAnyNaN) {
      const validValues = selectedValues
        .filter((val: any) => Number.isFinite(val))
        .map((val: any) => parseFloat(val));
      
      if (validValues.length > 0) {
        return validValues;
      }
    }
  }
  
  // 2. Fallback: summary
  if (Array.isArray(fallbackSummary) && fallbackSummary.length > 0) {
    const validCombined = fallbackSummary
      .map(val => typeof val === 'string' ? parseFloat(val) : val)
      .filter(val => val !== null && !isNaN(val));
    
    if (validCombined.length > 0) {
      return validCombined;
    }
  }
  
  // 3. Fallback: vector
  if (Array.isArray(fallbackVector) && fallbackVector.length > 0) {
    return fallbackVector.filter(val => typeof val === 'number' && !isNaN(val));
  }
  
  // 4. Default
  return [defaultValue];
};