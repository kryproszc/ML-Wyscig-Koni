export const formatPolishNumber = (value: number, decimals: number = 2) => {
  return new Intl.NumberFormat('pl-PL', { 
    minimumFractionDigits: decimals, 
    maximumFractionDigits: decimals 
  }).format(value);
};

export const formatCurrency = (value: number, currency: string = 'PLN') => {
  return new Intl.NumberFormat('pl-PL', { 
    style: 'currency', 
    currency 
  }).format(value);
};

export const formatPercentage = (value: number, decimals: number = 2) => {
  return new Intl.NumberFormat('pl-PL', { 
    style: 'percent',
    minimumFractionDigits: decimals, 
    maximumFractionDigits: decimals 
  }).format(value / 100);
};