// shared/utils/simulationValidators.ts

export interface VectorValidationResult {
  isValid: boolean;
  errorMessage?: string;
  vectorCL: number[];
  vectorSigma: number[];
  vectorSD: number[];
}

export interface DataAvailabilityCheck {
  paidTriangle: boolean;
  discountRates: boolean;
  nettoBrutto: boolean;
}

export interface CalculationOptions {
  brutto: boolean;
  brutto_dysk: boolean;
  netto_dysk: boolean;
}

/**
 * Waliduje długości wektorów używanych w symulacji
 */
export function validateVectorLengths(
  vectorCL: number[],
  vectorSigma: number[],
  vectorSD: number[]
): VectorValidationResult {
  const lengthCL = vectorCL.length;
  const lengthSigma = vectorSigma.length;
  const lengthSD = vectorSD.length;

  // Sprawdź czy wszystkie długości są równe (pomijamy puste wektory SD)
  if (lengthSD > 0 && (lengthCL !== lengthSigma || lengthCL !== lengthSD || lengthSigma !== lengthSD)) {
    return {
      isValid: false,
      errorMessage: `Długość wektorów Dev, Sigma, sd nie jest równa. Ich długości muszą być sobie równe.\n\n` +
        `Dev (CL): ${lengthCL} elementów\n` +
        `Sigma: ${lengthSigma} elementów\n` +
        `SD: ${lengthSD} elementów`,
      vectorCL,
      vectorSigma,
      vectorSD
    };
  }

  // Jeśli SD jest pusty, sprawdź tylko CL i Sigma
  if (lengthSD === 0 && lengthCL !== lengthSigma) {
    return {
      isValid: false,
      errorMessage: `Długość wektorów Dev i Sigma nie jest równa. Ich długości muszą być sobie równe.\n\n` +
        `Dev (CL): ${lengthCL} elementów\n` +
        `Sigma: ${lengthSigma} elementów`,
      vectorCL,
      vectorSigma,
      vectorSD
    };
  }

  return {
    isValid: true,
    vectorCL,
    vectorSigma,
    vectorSD
  };
}

/**
 * Sprawdza dostępność danych dla różnych typów obliczeń
 */
export function checkDataAvailability(
  paidTriangle: any[],
  discountRatesTriangle: any,
  paramsymTriangle: any
): DataAvailabilityCheck {
  const isPaidTriangleLoaded = Array.isArray(paidTriangle) && paidTriangle.length > 0;
  const isDiscountRatesLoaded = discountRatesTriangle && Object.keys(discountRatesTriangle).length > 0;
  const isNettoBruttoLoaded = paramsymTriangle && Object.keys(paramsymTriangle).length > 0;

  return {
    paidTriangle: isPaidTriangleLoaded,
    discountRates: isDiscountRatesLoaded,
    nettoBrutto: isNettoBruttoLoaded
  };
}

/**
 * Określa opcje obliczeń na podstawie dostępnych danych
 */
export function getCalculationOptions(availability: DataAvailabilityCheck): CalculationOptions {
  return {
    brutto: availability.paidTriangle,
    brutto_dysk: availability.paidTriangle && availability.discountRates,
    netto_dysk: availability.paidTriangle && availability.discountRates && availability.nettoBrutto
  };
}

/**
 * Przetwarza tablicę wartości na liczby z filtrowaniem nieprawidłowych wartości
 */
export function processValueArray(values: any[]): number[] {
  if (!Array.isArray(values) || values.length === 0) {
    return [];
  }
  
  return values
    .filter((val: any) => Number.isFinite(val))
    .map((val: any) => parseFloat(val));
}

/**
 * Przygotowuje wektor selectedValueCL z fallbackami
 */
export function prepareSelectedValueCL(
  selectedValuesCL: any[],
  combinedDevJSummary: any[],
  devJ: any[]
): number[] {
  // PRIORYTET 1: selectedValuesCL
  if (Array.isArray(selectedValuesCL) && selectedValuesCL.length > 0) {
    const processed = processValueArray(selectedValuesCL);
    if (processed.length > 0) return processed;
  }
  
  // FALLBACK 1: combinedDevJSummary
  if (Array.isArray(combinedDevJSummary) && combinedDevJSummary.length > 0) {
    const processed = combinedDevJSummary
      .map(val => typeof val === 'string' ? parseFloat(val) : val)
      .filter(val => val !== null && !isNaN(val) && Number.isFinite(val));
    if (processed.length > 0) return processed;
  }
  
  // FALLBACK 2: devJ
  if (Array.isArray(devJ) && devJ.length > 0) {
    const processed = processValueArray(devJ);
    if (processed.length > 0) return processed;
  }
  
  // OSTATECZNY FALLBACK
  return [1.0];
}

/**
 * Przygotowuje wektor selectedValueSigma z fallbackami
 */
export function prepareSelectedValueSigma(
  selectedValuesSigma: any[],
  combinedSigmaSummary: any[],
  sigma: any[]
): number[] {
  // PRIORYTET 1: selectedValuesSigma
  if (Array.isArray(selectedValuesSigma) && selectedValuesSigma.length > 0) {
    const processed = processValueArray(selectedValuesSigma);
    if (processed.length > 0) return processed;
  }
  
  // FALLBACK 1: combinedSigmaSummary
  if (Array.isArray(combinedSigmaSummary) && combinedSigmaSummary.length > 0) {
    const processed = combinedSigmaSummary
      .map(val => typeof val === 'string' ? parseFloat(val) : val)
      .filter(val => val !== null && !isNaN(val) && Number.isFinite(val));
    if (processed.length > 0) return processed;
  }
  
  // FALLBACK 2: sigma
  if (Array.isArray(sigma) && sigma.length > 0) {
    const processed = processValueArray(sigma);
    if (processed.length > 0) return processed;
  }
  
  // OSTATECZNY FALLBACK
  return [0.1];
}

/**
 * Przygotowuje wektor combinedSDSummary z fallbackami
 */
export function prepareCombinedSDSummary(
  selectedValuesSD: any[],
  combinedSDSummary: any[],
  sd: any[]
): number[] {
  // PRIORYTET 1: selectedValuesSD
  if (Array.isArray(selectedValuesSD) && selectedValuesSD.length > 0) {
    const processed = processValueArray(selectedValuesSD);
    if (processed.length > 0) return processed;
  }
  
  // FALLBACK 1: combinedSDSummary
  if (Array.isArray(combinedSDSummary) && combinedSDSummary.length > 0) {
    const processed = combinedSDSummary
      .map((val: string | number) => typeof val === 'string' ? parseFloat(val) : val)
      .filter((val: number) => Number.isFinite(val));
    if (processed.length > 0) return processed;
  }
  
  // FALLBACK 2: sd
  if (Array.isArray(sd) && sd.length > 0) {
    const processed = processValueArray(sd);
    if (processed.length > 0) return processed;
  }
  
  // Jeśli brak danych SD, zwróć pustą tablicę
  return [];
}

/**
 * Przetwarza parametry netto/brutto
 */
export function processNetBruttoParams(
  paramsymTriangle: any,
  selectedParamsymLine: number | null
): Record<string, any> {
  if (!paramsymTriangle || selectedParamsymLine === null) {
    return {};
  }

  const selectedRow = paramsymTriangle[selectedParamsymLine];
  if (!selectedRow) {
    return {};
  }

  const values: { [key: string]: number | null } = {};
  Object.keys(selectedRow).forEach(colKey => {
    const colIndex = parseInt(colKey);
    if (colIndex !== 0) {
      const value = selectedRow[colIndex];
      if (typeof value === 'number') {
        values[colKey] = value;
      }
    }
  });

  return { "0": values };
}

/**
 * Przetwarza stopy dyskontowe
 */
export function processDiscountRates(
  discountRatesTriangle: any,
  selectedDiscountRateLine: number | null
): Record<string, any> {
  if (!discountRatesTriangle || selectedDiscountRateLine === null) {
    return {};
  }

  const selectedRow = discountRatesTriangle[selectedDiscountRateLine];
  if (!selectedRow) {
    return {};
  }

  const processedRow: { [key: string]: number | null } = {};
  Object.keys(selectedRow).forEach(colKey => {
    const colIndex = parseInt(colKey);
    if (colIndex !== 0) {
      const value = selectedRow[colIndex];
      processedRow[colKey] = typeof value === 'number' ? value : null;
    }
  });

  return { "0": processedRow };
}

/**
 * Parsuje kwantyle ze stringa
 */
export function parseQuantiles(kwantylesString: string): number[] {
  return kwantylesString
    .split(',')
    .map(k => parseFloat(k.trim()))
    .filter(k => !isNaN(k) && k > 0 && k < 1);
}