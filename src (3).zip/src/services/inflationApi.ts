/**
 * Serwis do obsługi inflacji przez API backend
 */

export interface InflationRequest {
  user_id: string;
  triangle: (number | null)[][];
  inflationVector: (number | null)[];
  // Dodatkowe metadane jeśli potrzebne
  triangleMetadata?: {
    rowLabels?: string[];
    columnLabels?: string[];
    dataType?: 'cumulative' | 'incremental';
    hasHeaders?: boolean;
  };
}

export interface InflationResponse {
  success: boolean;
  adjustedTriangle: (number | null)[][];
  message?: string;
  // Dodatkowe informacje z backendu
  metadata?: {
    inflationApplied: boolean;
    originalRows: number;
    adjustedRows: number;
    processingTime?: number;
  };
  error?: string;
}

export class InflationApiService {
  private readonly baseUrl: string;

  constructor(baseUrl: string = 'http://localhost:8000') {
    this.baseUrl = baseUrl;
  }

  /**
   * Wysyła trójkąt i wektor inflacji na backend do przetworzenia
   */
  async applyInflationToTriangle(request: InflationRequest): Promise<InflationResponse> {
    try {
      console.log('🚀 [InflationApiService] Wysyłanie request do backendu:', {
        userId: request.user_id,
        triangleSize: `${request.triangle.length}x${request.triangle[0]?.length || 0}`,
        inflationVectorLength: request.inflationVector.length,
        endpoint: `${this.baseUrl}/calc/paid/inflation`
      });

      const response = await fetch(`${this.baseUrl}/calc/paid/inflation`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(request),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }

      const data: InflationResponse = await response.json();
      
      console.log('✅ [InflationApiService] Odpowiedź z backendu:', {
        success: data.success,
        hasAdjustedTriangle: !!data.adjustedTriangle,
        adjustedTriangleSize: data.adjustedTriangle ? 
          `${data.adjustedTriangle.length}x${data.adjustedTriangle[0]?.length || 0}` : 'N/A',
        message: data.message
      });

      return data;

    } catch (error) {
      console.error('❌ [InflationApiService] Błąd podczas komunikacji z backendem:', error);
      
      // Zwróć strukturyzowaną odpowiedź błędu
      return {
        success: false,
        adjustedTriangle: request.triangle, // Zwróć oryginalny trójkąt jako fallback
        error: error instanceof Error ? error.message : 'Nieznany błąd komunikacji z backendem',
        message: 'Nie udało się nałożyć inflacji - używam oryginalnych danych'
      };
    }
  }

  /**
   * Sprawdza czy backend jest dostępny i obsługuje inflację
   */
  async checkInflationSupport(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/health`, {
        method: 'GET',
      });
      return response.ok;
    } catch (error) {
      console.warn('⚠️ [InflationApiService] Backend niedostępny:', error);
      return false;
    }
  }

  /**
   * Waliduje request przed wysłaniem
   */
  validateRequest(request: InflationRequest): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!request.user_id || request.user_id.trim() === '') {
      errors.push('Brak user_id');
    }

    if (!request.triangle || request.triangle.length === 0) {
      errors.push('Trójkąt jest pusty');
    }

    if (!request.inflationVector || request.inflationVector.length === 0) {
      errors.push('Wektor inflacji jest pusty');
    }

    // Sprawdź czy trójkąt ma poprawną strukturę
    if (request.triangle && request.triangle.length > 0) {
      const firstRowLength = request.triangle[0]?.length || 0;
      for (let i = 1; i < request.triangle.length; i++) {
        if ((request.triangle[i]?.length || 0) !== firstRowLength) {
          errors.push(`Nierówna długość wierszy w trójkącie (wiersz ${i})`);
          break;
        }
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }
}

// Singleton instance
export const inflationApiService = new InflationApiService();