import * as XLSX from 'xlsx';

export type DevJResult = {
  volume: number;
  subIndex?: number;
  values: number[];
};

export type OverrideRow = { index: number; curve: string; value: number };

export type StatisticsResult = {
  column: number;
  mean: number;
  std: number;
  SCR: number;
  quantiles: number[];
};

export function exportStatisticsToExcel(
  statisticsResults: StatisticsResult[],
  kwantyle: string,
  skalowanie: number,
  simulationParams: {
    iloscSymulacji: number;
    ziarno: number;
    podzialZiarna: number;
    skalowanie: number;
  }
) {
  if (!statisticsResults || statisticsResults.length === 0) {
    alert('Brak danych statystyk do eksportu');
    return;
  }

  // Przygotuj nagłówki tabeli
  const headers = ['Statystyka', ...statisticsResults.map((_, index) => `Kolumna ${index + 1}`)];
  
  // Przygotuj wiersze danych
  const rows: any[][] = [];
  
  // Wiersz średniej
  rows.push(['Średnia', ...statisticsResults.map(stat => stat.mean)]);
  
  // Wiersz odchylenia standardowego
  rows.push(['Odchylenie standardowe', ...statisticsResults.map(stat => stat.std)]);
  
  // Wiersz SCR
  rows.push(['SCR', ...statisticsResults.map(stat => stat.SCR)]);
  
  // Wiersze kwantyli
  const kwantyleArray = kwantyle.split(',').map(k => parseFloat(k.trim()));
  kwantyleArray.forEach((q, qIdx) => {
    const quantileLabel = `Q${(q * 100).toFixed(1)}%`;
    const quantileValues = statisticsResults.map(stat => 
      stat.quantiles && stat.quantiles[qIdx] !== undefined ? stat.quantiles[qIdx] : null
    );
    rows.push([quantileLabel, ...quantileValues]);
  });

  // Główna tabela statystyk
  const mainTable = [headers, ...rows];

  // Tabela z parametrami
  const paramsTable = [
    ['Parametr', 'Wartość'],
    ['Ilość symulacji', simulationParams.iloscSymulacji],
    ['Ziarno', simulationParams.ziarno],
    ['Podział ziarna', simulationParams.podzialZiarna],
    ['Skalowanie', skalowanie],
    ['Kwantyle', kwantyle],
    ['Data eksportu', new Date().toLocaleString('pl-PL')]
  ];

  // Utwórz arkusz główny
  const wsMain = XLSX.utils.aoa_to_sheet([
    ['Wyniki Statystyk Chain Ladder'],
    ['Analiza statystyczna wyników symulacji metodą Chain Ladder'],
    [],
    ...mainTable
  ]);

  // Utwórz arkusz z parametrami
  const wsParams = XLSX.utils.aoa_to_sheet(paramsTable);

  // Utwórz workbook
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, wsMain, 'Statystyki');
  XLSX.utils.book_append_sheet(wb, wsParams, 'Parametry');

  // Zapisz plik
  const fileName = `statystyki_chain_ladder_${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(wb, fileName);
}

export function exportDevJToExcel(
  devJResults: DevJResult[],
  finalDevJ?: DevJResult,
  customFinal?: number[],
  overrides: OverrideRow[] = []   // <── NOWY, opcjonalny parametr
) {
  const maxLength = Math.max(...devJResults.map((r) => r.values.length));

  /* 1) Tabela porównawcza */
  const comparisonHeader = ['volume', ...Array.from({ length: maxLength }, (_, j) => `j=${j}`)];
  const comparisonRows = devJResults.map((r) => [
    r.subIndex !== undefined ? `${r.volume},${r.subIndex}` : `${r.volume}`,
    ...r.values,
  ]);
  const comparisonTable = [comparisonHeader, ...comparisonRows];

  /* 2) Finalny wektor */
  const finalValues = customFinal ?? finalDevJ?.values ?? [];
  const finalHeader = ['Wektor finalny', ...Array.from({ length: finalValues.length }, (_, j) => `j=${j}`)];
  const finalRow    = ['dev_final', ...finalValues];
  const finalTable  = [finalHeader, finalRow];

  /* 3) Overrides (jeśli są) */
  const overridesTable =
    overrides.length > 0
      ? [
          ['j (index)', 'curve', 'value'],
          ...overrides.map(o => [o.index, o.curve, o.value]),
        ]
      : [];

  /* 4) Składamy arkusz główny (comparison + final) */
  const wsMain = XLSX.utils.aoa_to_sheet([
    ...comparisonTable,
    [], // pusta linia
    ...finalTable,
  ]);

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, wsMain, 'dev_j');

  /* 5) Drugi arkusz z overrides (opcjonalny) */
  if (overridesTable.length) {
    const wsOv = XLSX.utils.aoa_to_sheet(overridesTable);
    XLSX.utils.book_append_sheet(wb, wsOv, 'overrides');
  }

  XLSX.writeFile(wb, 'dev_j_export.xlsx');
}
