import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// Typy analogiczne do trainDevideStoreDeterministyczny ale dla AddPaid
export interface DevJResult {
  volume: number;
  values: number[];
}

export interface SigmaResult {
  volume: number;
  values: number[];
}

export interface DevFinalValue {
  curve: string;
  value: number;
}

export interface FinalDevJ {
  values: number[];
  volume: number;
}

export interface FinalSigma {
  values: number[];
  volume: number;
}

export interface AddCoefficientsStore {
  // Trójkąt exposure (z exposureStore) - tylko referencja
  // exposureTriangle będzie pobierany z exposureStore
  
  // Trójkąt paid (z trainDevideStoreDeterministyczny) - tylko referencja  
  // paidTriangle będzie pobierany z trainDevideStoreDeterministyczny
  
  // Wyniki train_devide dla AddPaid
  trainDevideAdd: number[][] | null;
  selectedWeightsAdd?: number[][];
  selectedCellsAdd: [number, number][];
  
  // Volume i parametry - USUNIĘTE, używamy głównego store (trainDevideStoreDeterministyczny)
  // volume: number;
  // decimalPlaces: number;
  
  // Wyniki dev_j
  devJ: number[] | null;
  devJResults: DevJResult[];
  finalDevJ: FinalDevJ | null;
  finalDevVector: number[] | null;
  devFinalCustom: Record<number, DevFinalValue>;
  selectedDevJVolume: number | null;
  selectedDevJSubIndex: number | null;
  
  // Wyniki sigma
  sigma: number[] | null;
  sd: number[] | null;
  sigmaResults: SigmaResult[];
  finalSigma: FinalSigma | null;
  selectedSigmaVolume: number | null;
  selectedSigmaSubIndex: number | null;
  
  // UI settings
  minMaxHighlighting: boolean;
  minMaxCells: Array<[number, number]>;
  minCells: Array<[number, number]>;
  maxCells: Array<[number, number]>;
  
  // Modals
  isMissingFinalModalOpen: boolean;
  
  // Curve fitting data (dla przyszłych kroków)
  fitCurveData: any;
  devSummaryData: any;
  
  // Actions - train_devide
  setTrainDevideAdd: (data: number[][]) => void;
  setSelectedWeightsAdd: (weights: number[][]) => void;
  setSelectedCellsAdd: (cells: [number, number][]) => void;
  resetSelectionAdd: () => void;
  toggleRowAdd: (rowIndex: number) => void;
  toggleCellAdd: (r: number, c: number) => void;
  toggleWeightCellAdd: (r: number, c: number) => void;
  clearAllWeights: () => void;
  calculateMinMaxCells: () => void;
  applyVolumeToWeights: (volume: number) => void;
  
  // Actions - volume & decimal places - VOLUME I DECIMAL PLACES USUNIĘTE (używamy głównego store)
  // setVolume: (volume: number) => void;
  // setDecimalPlaces: (places: number) => void;
  
  // Actions - dev_j
  setDevJ: (values: number[]) => void;
  addDevJResult: (volume: number, values: number[]) => void;
  setSelectedDevJVolume: (volume: number, subIndex?: number) => void;
  setFinalDevJ: (final: FinalDevJ | undefined) => void;
  setFinalDevVector: (vector: number[]) => void;
  setDevFinalCustom: (index: number, curve: string, value: number) => void;
  clearDevJResults: () => void;
  clearAllDevFinalValues: () => void;
  
  // Actions - sigma
  setSigma: (values: number[]) => void;
  setSd: (values: number[]) => void;
  addSigmaResult: (volume: number, values: number[]) => void;
  setSelectedSigmaVolume: (volume: number, subIndex?: number) => void;
  setFinalSigma: (final: FinalSigma | undefined) => void;
  clearSigmaResults: () => void;
  clearAllSigmaFinalValues: () => void;
  
  // Actions - UI
  setMinMaxHighlighting: (highlighting: boolean) => void;
  setMinMaxCells: (cells: Array<[number, number]>) => void;
  setMinCells: (cells: Array<[number, number]>) => void;
  setMaxCells: (cells: Array<[number, number]>) => void;
  
  // Actions - modals
  openMissingFinalModal: () => void;
  closeMissingFinalModal: () => void;
  
  // Actions - curve fitting (dla przyszłości)
  clearFitCurveData: () => void;
  clearDevSummaryData: () => void;
  
  // Actions - reset
  resetAll: () => void;
}

const initialState = {
  trainDevideAdd: null,
  selectedWeightsAdd: undefined,
  selectedCellsAdd: [] as [number, number][],
  devJ: null,
  devJResults: [],
  finalDevJ: null,
  finalDevVector: null,
  devFinalCustom: {},
  selectedDevJVolume: null,
  selectedDevJSubIndex: null,
  sigma: null,
  sd: null,
  sigmaResults: [],
  finalSigma: null,
  selectedSigmaVolume: null,
  selectedSigmaSubIndex: null,
  minMaxHighlighting: false,
  minMaxCells: [],
  minCells: [],
  maxCells: [],
  isMissingFinalModalOpen: false,
  fitCurveData: null,
  devSummaryData: null,
};

export const useAddCoefficientsStore = create<AddCoefficientsStore>()(
  persist(
    (set, get) => ({
      ...initialState,
      
      // Train devide actions
      setTrainDevideAdd: (data) => set({ trainDevideAdd: data }),
      setSelectedWeightsAdd: (weights) => set({ selectedWeightsAdd: weights }),
      setSelectedCellsAdd: (cells) => set({ selectedCellsAdd: cells }),
      
      resetSelectionAdd: () => {
        console.log('🔄 resetSelectionAdd called');
        const { trainDevideAdd } = get();
        if (!trainDevideAdd?.length) return;
        
        const rows = trainDevideAdd.length;
        const cols = trainDevideAdd[0]?.length || 0;
        
        // 🔥 PRZYWRÓCONE: Wszystkie komórki domyślnie zaznaczone (jak wcześniej)
        const newWeights = Array(rows).fill(null).map(() => Array(cols).fill(1));
        
        console.log('🔄 resetSelectionAdd setting weights (first 3 rows):', newWeights.slice(0, 3));
        set({
          selectedWeightsAdd: newWeights,
          selectedCellsAdd: [],
        });
      },

      toggleCellAdd: (r, c) => {
        const sel = get().selectedCellsAdd;
        const idx = sel.findIndex(([row, col]) => row === r && col === c);
        if (idx >= 0)
          set({ selectedCellsAdd: sel.filter(([row, col]) => !(row === r && col === c)) });
        else set({ selectedCellsAdd: [...sel, [r, c]] });
      },
      
      toggleRowAdd: (r) => {
        const cur = get().selectedWeightsAdd;
        const trainData = get().trainDevideAdd;
        if (!cur || !trainData) return;

        // Sprawdzamy czy cały wiersz jest zaznaczony
        const dataRow = trainData[r];
        if (!dataRow) return;

        let hasAnyData = false;
        let allSelected = true;
        
        // Sprawdzamy stan aktualny wiersza
        for (let j = 0; j < dataRow.length; j++) {
          const cell = dataRow[j];
          const hasData = cell !== null && cell !== undefined && typeof cell === 'number';
          
          if (hasData) {
            hasAnyData = true;
            if (cur[r]?.[j] !== 1) {
              allSelected = false;
              break;
            }
          }
        }

        // Jeśli nie ma danych, nie rób nic
        if (!hasAnyData) return;

        // Przełącz stan całego wiersza
        const upd = cur.map((row, i) => {
          if (i !== r) return row;
          return row.map((cell, j) => {
            const cellData = dataRow[j];
            const hasData = cellData !== null && cellData !== undefined && typeof cellData === 'number';
            // Jeśli komórka ma dane, ustaw przeciwny stan do aktualnego stanu wiersza
            if (hasData) {
              return allSelected ? 0 : 1;
            }
            // Jeśli komórka nie ma danych, zostaw bez zmian
            return cell;
          });
        });

        set({ selectedWeightsAdd: upd });
        
        // Jeśli min/max highlighting jest włączone, przelicz ponownie
        if (get().minMaxHighlighting) {
          get().calculateMinMaxCells();
        }
      },
      
      toggleWeightCellAdd: (r, c) => {
        const cur = get().selectedWeightsAdd;
        if (!cur) return;

        // Przełącz tylko konkretną komórkę
        const upd = cur.map((row, i) =>
          row.map((cell, j) => (i === r && j === c ? (cell === 1 ? 0 : 1) : cell))
        );
        set({ selectedWeightsAdd: upd });
        
        // Jeśli min/max highlighting jest włączone, przelicz ponownie
        if (get().minMaxHighlighting) {
          get().calculateMinMaxCells();
        }
      },

      clearAllWeights: () => {
        const cur = get().selectedWeightsAdd;
        if (cur) {
          // 🔥 PRZYWRÓCONE: Wszystkie komórki zaznaczone (jak wcześniej)
          set({ selectedWeightsAdd: cur.map((r) => r.map(() => 1)) });
        }
      },
      
      // Volume & decimal places - VOLUME I DECIMAL PLACES USUNIĘTE (używamy głównego store - trainDevideStoreDeterministyczny)
      // setDecimalPlaces: (places) => set({ decimalPlaces: places }),
      
      // Dev_j actions
      setDevJ: (values) => set({ devJ: values }),
      addDevJResult: (volume, values) => {
        const { devJResults } = get();
        const existingIndex = devJResults.findIndex(r => r.volume === volume);
        
        if (existingIndex >= 0) {
          const updated = [...devJResults];
          updated[existingIndex] = { volume, values };
          set({ devJResults: updated });
        } else {
          set({ devJResults: [...devJResults, { volume, values }] });
        }
      },
      setSelectedDevJVolume: (volume, subIndex) => set({
        selectedDevJVolume: volume,
        selectedDevJSubIndex: subIndex,
      }),
      setFinalDevJ: (final) => set({ finalDevJ: final }),
      setFinalDevVector: (vector) => set({ finalDevVector: vector }),
      setDevFinalCustom: (index, curve, value) => {
        const { devFinalCustom } = get();
        set({
          devFinalCustom: {
            ...devFinalCustom,
            [index]: { curve, value },
          },
        });
      },
      clearDevJResults: () => set({ devJResults: [] }),
      clearAllDevFinalValues: () => set({
        finalDevJ: null,
        finalDevVector: null,
        devFinalCustom: {},
        selectedDevJVolume: null,
        selectedDevJSubIndex: null,
      }),
      
      // Sigma actions
      setSigma: (values) => set({ sigma: values }),
      setSd: (values) => set({ sd: values }),
      addSigmaResult: (volume, values) => {
        const { sigmaResults } = get();
        const existingIndex = sigmaResults.findIndex(r => r.volume === volume);
        
        if (existingIndex >= 0) {
          const updated = [...sigmaResults];
          updated[existingIndex] = { volume, values };
          set({ sigmaResults: updated });
        } else {
          set({ sigmaResults: [...sigmaResults, { volume, values }] });
        }
      },
      setSelectedSigmaVolume: (volume, subIndex) => set({
        selectedSigmaVolume: volume,
        selectedSigmaSubIndex: subIndex,
      }),
      setFinalSigma: (final) => set({ finalSigma: final }),
      clearSigmaResults: () => set({ sigmaResults: [] }),
      clearAllSigmaFinalValues: () => set({
        finalSigma: null,
        selectedSigmaVolume: null,
        selectedSigmaSubIndex: null,
      }),
      
      // UI actions
      setMinMaxHighlighting: (enabled) => {
        console.log('setMinMaxHighlighting (AddPaid):', enabled);
        set({ minMaxHighlighting: enabled });
        if (enabled) get().calculateMinMaxCells();
        else set({ minMaxCells: [], minCells: [], maxCells: [] });
      },
      setMinMaxCells: (cells) => set({ minMaxCells: cells }),
      setMinCells: (cells) => set({ minCells: cells }),
      setMaxCells: (cells) => set({ maxCells: cells }),

      calculateMinMaxCells: () => {
        const trainData = get().trainDevideAdd;
        const weights = get().selectedWeightsAdd;
        if (!trainData || !weights || trainData.length === 0) return;

        console.log('🔢 calculateMinMaxCells (AddPaid) started', { 
          trainDataRows: trainData.length, 
          trainDataCols: trainData[0]?.length,
          weightsRows: weights.length, 
          weightsCols: weights[0]?.length 
        });

        const minMaxCells: [number, number][] = [];
        const minCells: [number, number][] = [];
        const maxCells: [number, number][] = [];
        
        // Dla każdej kolumny znajdź min/max spośród zaznaczonych komórek
        const numCols = trainData[0]?.length || 0;
        
        for (let col = 0; col < numCols; col++) {
          const selectedValues: { value: number; row: number }[] = [];
          
          for (let row = 0; row < trainData.length; row++) {
            const cellValue = trainData[row]?.[col];
            const isSelected = weights[row]?.[col] === 1;
            
            if (isSelected && cellValue != null && typeof cellValue === 'number') {
              selectedValues.push({ 
                value: cellValue, 
                row 
              });
            }
          }
          
          console.log(`📊 AddPaid Kolumna ${col}:`, {
            selectedCount: selectedValues.length,
            values: selectedValues.map(v => `[${v.row}] = ${v.value}`)
          });
          
          if (selectedValues.length > 1) {
            const minItem = selectedValues.reduce((min, curr) => 
              curr.value < min.value ? curr : min
            );
            const maxItem = selectedValues.reduce((max, curr) => 
              curr.value > max.value ? curr : max
            );
            
            // +1 bo w TableDataDet mamy nagłówki!
            minCells.push([minItem.row + 1, col + 1]);
            maxCells.push([maxItem.row + 1, col + 1]);
            minMaxCells.push([minItem.row + 1, col + 1]);
            if (minItem.row !== maxItem.row) {
              minMaxCells.push([maxItem.row + 1, col + 1]);
            }
            
            console.log(`✅ AddPaid Kolumna ${col} - Min: [${minItem.row}]=${minItem.value}, Max: [${maxItem.row}]=${maxItem.value}`);
          } else {
            console.log(`⚠️ AddPaid Kolumna ${col} - za mało wybranych wartości (${selectedValues.length})`);
          }
        }
        
        console.log('🎯 calculateMinMaxCells (AddPaid) RESULT:', { 
          minCells: minCells.length, 
          maxCells: maxCells.length,
          minCellsData: minCells,
          maxCellsData: maxCells
        });
        set({ minMaxCells, minCells, maxCells });
      },

      // Funkcja do aplikowania volume na weights (wywoływana z zewnątrz gdy volume się zmieni)
      applyVolumeToWeights: (volume) => {
        const matrix = get().trainDevideAdd;
        if (!matrix || matrix.length === 0 || !matrix[0]) return;

        console.log('🔧 applyVolumeToWeights (AddPaid) started with volume:', volume);

        const numRows = matrix.length;
        const numCols = matrix[0].length;
        const weights: number[][] = Array.from({ length: numRows }, () =>
          new Array(numCols).fill(0)
        );

        for (let col = 0; col < numCols; col++) {
          let filled = 0;
          for (let row = numRows - 1; row >= 0 && filled < volume; row--) {
            const val = matrix[row]?.[col];
            // 🔥 PRZYWRÓCONE: Jak wcześniej - tylko sprawdzamy czy liczba != 0
            if (typeof val === 'number' && val !== 0) {
              weights[row]![col] = 1;
              filled++;
            }
          }
        }
        
        console.log('🔧 applyVolumeToWeights (AddPaid) setting weights:', weights.slice(0, 3));
        set({ selectedWeightsAdd: weights });
        
        // Przelicz Min/Max po zmianie volume jeśli jest włączone
        if (get().minMaxHighlighting) {
          get().calculateMinMaxCells();
        }
      },
      
      // Modal actions
      openMissingFinalModal: () => set({ isMissingFinalModalOpen: true }),
      closeMissingFinalModal: () => set({ isMissingFinalModalOpen: false }),
      
      // Curve fitting actions
      clearFitCurveData: () => set({ fitCurveData: null }),
      clearDevSummaryData: () => set({ devSummaryData: null }),
      
      // Reset
      resetAll: () => set({
        ...initialState,
        selectedCellsAdd: [], // Explicitly set as empty array
        selectedWeightsAdd: undefined, // Explicitly set as undefined
      }),
    }),
    {
      name: 'add-coefficients-store',
      partialize: (state) => ({
        devJResults: state.devJResults,
        sigmaResults: state.sigmaResults,
        finalDevJ: state.finalDevJ,
        finalDevVector: state.finalDevVector,
        devFinalCustom: state.devFinalCustom,
        finalSigma: state.finalSigma,
        minMaxHighlighting: state.minMaxHighlighting,
      }),
      storage: {
        getItem: (n) => {
          const i = sessionStorage.getItem(n);
          return i ? JSON.parse(i) : null;
        },
        setItem: (n, v) => sessionStorage.setItem(n, JSON.stringify(v)),
        removeItem: (n) => sessionStorage.removeItem(n),
      },
    }
  )
);