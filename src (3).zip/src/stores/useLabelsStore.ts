import { create } from 'zustand';

interface LabelsState {
  // GLOBALNE nazwy z ostatnio wczytanego pliku (niezależnie od zakładki)
  globalRowLabels: string[];
  globalColumnLabels: string[];
  lastLoadedFile: string; // nazwa ostatnio wczytanego pliku
  
  // Główna zakładka (Paid)- metody stochastyczne
  rowLabels: string[];
  columnLabels: string[];
  
  // Zakładka Det
  detRowLabels: string[];
  detColumnLabels: string[];
  
  // Zakładka Incurred
  incurredRowLabels: string[];
  incurredColumnLabels: string[];
  
  // Settery dla globalnych (używane przez wszystkie zakładki)
  setGlobalLabels: (rowLabels: string[], columnLabels: string[], fileName: string) => void;
  
  // Settery dla głównej zakładki
  setRowLabels: (labels: string[]) => void;
  setColumnLabels: (labels: string[]) => void;
  
  // Settery dla Det
  setDetRowLabels: (labels: string[]) => void;
  setDetColumnLabels: (labels: string[]) => void;
  
  // Settery dla Incurred
  setIncurredRowLabels: (labels: string[]) => void;
  setIncurredColumnLabels: (labels: string[]) => void;
  
  clearLabels: () => void;
}

export const useLabelsStore = create<LabelsState>((set) => ({
  // Globalne
  globalRowLabels: [],
  globalColumnLabels: [],
  lastLoadedFile: '',
  
  // Główne
  rowLabels: [],
  columnLabels: [],
  
  // Det
  detRowLabels: [],
  detColumnLabels: [],
  
  // Incurred
  incurredRowLabels: [],
  incurredColumnLabels: [],
  
  // Setter globalny - aktualizuje zarówno globalne jak i lokalne dla danej zakładki
  setGlobalLabels: (rowLabels, columnLabels, fileName) => set((state) => ({
    globalRowLabels: rowLabels,
    globalColumnLabels: columnLabels,
    lastLoadedFile: fileName,
  })),
  
  // Settery główne
  setRowLabels: (labels) => set((state) => ({ 
    rowLabels: labels,
    globalRowLabels: labels, // aktualizuj też globalne
    lastLoadedFile: 'paid-data'
  })),
  setColumnLabels: (labels) => set((state) => ({ 
    columnLabels: labels,
    globalColumnLabels: labels // aktualizuj też globalne
  })),
  
  // Settery Det
  setDetRowLabels: (labels) => set((state) => ({ 
    detRowLabels: labels,
    globalRowLabels: labels, // aktualizuj też globalne
    lastLoadedFile: 'det-data'
  })),
  setDetColumnLabels: (labels) => set((state) => ({ 
    detColumnLabels: labels,
    globalColumnLabels: labels // aktualizuj też globalne
  })),
  
  // Settery Incurred
  setIncurredRowLabels: (labels) => set((state) => ({ 
    incurredRowLabels: labels,
    // ❌ NIE aktualizuj globalnych - pełna niezależność zakładek
    // globalRowLabels: labels, // aktualizuj też globalne
    lastLoadedFile: 'incurred-data'
  })),
  setIncurredColumnLabels: (labels) => set((state) => ({ 
    incurredColumnLabels: labels,
    // ❌ NIE aktualizuj globalnych - pełna niezależność zakładek
    // globalColumnLabels: labels // aktualizuj też globalne
  })),
  
  clearLabels: () => set({ 
    globalRowLabels: [],
    globalColumnLabels: [],
    lastLoadedFile: '',
    rowLabels: [], 
    columnLabels: [],
    detRowLabels: [],
    detColumnLabels: [],
    incurredRowLabels: [],
    incurredColumnLabels: []
  }),
}));
