import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface AddSimulationParams {
  iloscSymulacji: number;
  ziarno: number;
  podzialZiarna: number;
  skalowanie: number;
  skalowanie2: number;
}

export interface AddStatisticResult {
  column: number; // Kompatybilne z shared komponentami
  mean: number;
  std: number;
  quantiles: number[];
  SCR: number;
  columnName?: string; // Dodatkowe pole z nazwą kolumny
}

export interface AddSimulationResults {
  last_col: number[];
  cum_trian: number[];
  ult_net_disc: number[];
  userId: string;
  shouldShowResults?: boolean;
}

export interface AddSimulationStore {
  // Parametry symulacji
  simulationParams: AddSimulationParams;
  kwantyle: string;
  
  // Wyniki statystyk
  statisticsResults: AddStatisticResult[];
  
  // Wyniki symulacji
  simulationResults: AddSimulationResults | null;
  
  // Akcje - parametry
  updateSimulationParam: <K extends keyof AddSimulationParams>(
    key: K,
    value: AddSimulationParams[K]
  ) => void;
  setKwantyle: (kwantyle: string) => void;
  
  // Akcje - wyniki
  setStatisticsResults: (results: AddStatisticResult[]) => void;
  
  // Akcje - wyniki symulacji
  setSimulationResults: (results: AddSimulationResults) => void;
  clearSimulationResults: () => void;
  hasSimulationResults: () => boolean;
  
  // Reset
  resetParams: () => void;
  resetAll: () => void;
}

const defaultSimulationParams: AddSimulationParams = {
  iloscSymulacji: 1000,
  ziarno: 1111,
  podzialZiarna: 1000,
  skalowanie: 1,
  skalowanie2: 1,
};

const defaultKwantyle = "0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.95,0.99,0.995";

const initialState = {
  simulationParams: defaultSimulationParams,
  kwantyle: defaultKwantyle,
  statisticsResults: [] as AddStatisticResult[],
  simulationResults: null as AddSimulationResults | null,
};

export const useAddSimulationStore = create<AddSimulationStore>()(
  persist(
    (set, get) => ({
      ...initialState,
      
      // Akcje - parametry
      updateSimulationParam: (key, value) => {
        console.log(`🏪 [AddSimulationStore] Updating ${key}:`, value);
        set((state) => ({
          simulationParams: {
            ...state.simulationParams,
            [key]: value,
          },
        }));
      },
      
      setKwantyle: (kwantyle) => {
        console.log('🏪 [AddSimulationStore] Setting kwantyle:', kwantyle);
        set({ kwantyle });
      },
      
      // Akcje - wyniki
      setStatisticsResults: (results) => {
        console.log('🏪 [AddSimulationStore] Setting statistics results:', results);
        set({ statisticsResults: results });
      },
      
      // Akcje - wyniki symulacji
      setSimulationResults: (results) => {
        console.log('🏪 [AddSimulationStore] Setting simulation results:', results);
        set({ simulationResults: results });
      },
      
      clearSimulationResults: () => {
        console.log('🏪 [AddSimulationStore] Clearing simulation results');
        set({ simulationResults: null });
      },
      
      hasSimulationResults: () => {
        return get().simulationResults !== null;
      },
      
      // Reset
      resetParams: () => {
        console.log('🏪 [AddSimulationStore] Resetting params');
        set({ 
          simulationParams: defaultSimulationParams,
          kwantyle: defaultKwantyle 
        });
      },
      
      resetAll: () => {
        console.log('🏪 [AddSimulationStore] Resetting all');
        set(initialState);
      },
    }),
    {
      name: 'add-simulation-store',
      partialize: (state) => ({
        simulationParams: state.simulationParams,
        kwantyle: state.kwantyle,
        // Nie persist'uj statisticsResults - to są dane przejściowe
      }),
      storage: {
        getItem: (name) => {
          const item = sessionStorage.getItem(name);
          return item ? JSON.parse(item) : null;
        },
        setItem: (name, value) => sessionStorage.setItem(name, JSON.stringify(value)),
        removeItem: (name) => sessionStorage.removeItem(name),
      },
    }
  )
);