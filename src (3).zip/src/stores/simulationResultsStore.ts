import { create } from 'zustand';
import { persist } from 'zustand/middleware';

/* ──────────────────────────── TYPY ──────────────────────────── */

export interface SimulationResults {
  last_col: number[];
  cum_trian: number[];
  ult_net_disc: number[];
  calculatedAt?: string; // Timestamp obliczeń
  userId?: string; // ID użytkownika dla którego obliczono
  shouldShowResults?: boolean; // Flaga czy pokazywać wyniki
  timestamp?: number; // Timestamp liczbowy dla porównań
}

interface SimulationResultsState {
  // Stan wyników
  results: SimulationResults | null;
  isCalculating: boolean;
  lastError: string | null;
  
  // Akcje
  setResults: (results: SimulationResults) => void;
  clearResults: () => void;
  setCalculating: (calculating: boolean) => void;
  setError: (error: string | null) => void;
  hideResults: () => void; // Ukryj wyniki bez usuwania danych
  showResults: () => void; // Pokaż wyniki z powrotem
  
  // Getters pomocnicze
  hasResults: () => boolean;
  getResultsForUser: (userId: string) => SimulationResults | null;
}

/* ──────────────────────────── STORE ──────────────────────────── */

// Usuń stare dane z localStorage przy inicjalizacji
if (typeof window !== 'undefined') {
  localStorage.removeItem('simulation-results-storage');
}

export const useSimulationResultsStore = create<SimulationResultsState>()(
  persist(
    (set, get) => ({
      // Stan początkowy
      results: null,
      isCalculating: false,
      lastError: null,
      
      // Akcje
      setResults: (results: SimulationResults) => {
        set({
          results: {
            ...results,
            shouldShowResults: true,
            timestamp: Date.now(),
            calculatedAt: new Date().toISOString()
          },
          lastError: null
        });
        console.log('✅ [SimulationResultsStore] Zapisano wyniki symulacji z flagą shouldShowResults dla użytkownika:', results.userId);
      },
      
      clearResults: () => {
        set({
          results: null,
          lastError: null
        });
        console.log('🗑️ [SimulationResultsStore] Wyczyszczono wyniki symulacji');
      },
      
      hideResults: () => {
        const { results } = get();
        if (results) {
          set({
            results: {
              ...results,
              shouldShowResults: false
            }
          });
          console.log('👁️ [SimulationResultsStore] Ukryto wyniki symulacji (bez usuwania danych)');
        }
      },

      showResults: () => {
        const { results } = get();
        if (results) {
          set({
            results: {
              ...results,
              shouldShowResults: true
            }
          });
          console.log('👁️ [SimulationResultsStore] Pokazano wyniki symulacji z powrotem');
        }
      },
      
      setCalculating: (calculating: boolean) => {
        set({ isCalculating: calculating });
        if (calculating) {
          set({ lastError: null });
        }
      },
      
      setError: (error: string | null) => {
        set({ lastError: error, isCalculating: false });
        console.log('❌ [SimulationResultsStore] Błąd symulacji:', error);
      },
      
      // Getters pomocnicze
      hasResults: () => {
        const { results } = get();
        return results !== null && 
               results.shouldShowResults === true &&
               Array.isArray(results.last_col) && results.last_col.length > 0;
      },
      
      getResultsForUser: (userId: string) => {
        const { results } = get();
        if (!results || results.userId !== userId || !results.shouldShowResults) {
          return null;
        }
        
        return results;
      }
    }),
    {
      name: 'simulation-results-storage',
      version: 1,
      // Tylko zapisujemy wyniki, nie stan ładowania
      partialize: (state) => ({
        results: state.results,
        lastError: state.lastError
      }),
      storage: {
        getItem: (name) => {
          const str = sessionStorage.getItem(name);
          if (!str) return null;
          return JSON.parse(str);
        },
        setItem: (name, value) => {
          sessionStorage.setItem(name, JSON.stringify(value));
        },
        removeItem: (name) => sessionStorage.removeItem(name),
      },
    }
  )
);

/* ──────────────────────────── EKSPORT ──────────────────────────── */

export default useSimulationResultsStore;