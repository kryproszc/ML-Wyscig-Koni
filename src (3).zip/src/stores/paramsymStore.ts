import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// Typy dla Parametry Netto/Brutto store
export interface ParamsymTriangleData {
  [rowIndex: number]: {
    [colIndex: number]: number | string | null;  // Dodaj string dla labeli
  };
}

export interface ParamsymStore {
  // Dane trójkąta parametrów netto/brutto
  paramsymTriangle: ParamsymTriangleData;
  
  // Wybór linii parametrów
  selectedParamsymLine: number | null;
  availableParamsymLines: { index: number; label: string; values: (number | null)[] }[];
  
  // Metadane
  selectedSheetName: string;
  uploadedFileName: string;
  
  // Ustawienia wyświetlania
  decimalPlaces: number;
  
  // Akcje
  setParamsymTriangle: (triangle: ParamsymTriangleData) => void;
  setSelectedParamsymLine: (lineIndex: number | null) => void;
  updateAvailableParamsymLines: () => void;
  setSelectedSheetName: (name: string) => void;
  setUploadedFileName: (name: string) => void;
  setDecimalPlaces: (places: number) => void;
  resetData: () => void;
}

const initialState = {
  paramsymTriangle: {},
  selectedParamsymLine: null,
  availableParamsymLines: [],
  selectedSheetName: '',
  uploadedFileName: '',
  decimalPlaces: 2,
};

// Usuń stare dane z localStorage przy inicjalizacji
if (typeof window !== 'undefined') {
  localStorage.removeItem('paramsym-store');
}

export const useParamsymStore = create<ParamsymStore>()(
  persist(
    (set, get) => ({
      ...initialState,
      
      setParamsymTriangle: (triangle) => {
        set({ paramsymTriangle: triangle });
        // Automatycznie przygotuj dostępne linie
        get().updateAvailableParamsymLines();
      },
      
      setSelectedParamsymLine: (lineIndex) => set({ selectedParamsymLine: lineIndex }),
      
      updateAvailableParamsymLines: () => {
        const triangle = get().paramsymTriangle;
        const lines: { index: number; label: string; values: (number | null)[] }[] = [];
        
        // Iteruj przez wiersze trójkąta
        Object.keys(triangle).forEach(rowIndexStr => {
          const rowIndex = parseInt(rowIndexStr);
          const row = triangle[rowIndex];
          if (!row) return;
          
          // Pobierz label z pierwszej kolumny (kolumna 0)
          const labelValue = row[0];
          const label = labelValue !== null && labelValue !== undefined ? String(labelValue) : `Wiersz ${rowIndex + 1}`;
          
          // Pobierz wartości ze WSZYSTKICH kolumn OPRÓCZ kolumny 0 (etykiety)
          const values: (number | null)[] = [];
          const colKeys = Object.keys(row).map(Number).sort((a, b) => a - b);
          for (const colIndex of colKeys) {
            if (colIndex !== 0) { // Pomijamy TYLKO kolumnę 0 (etykiety), bierzemy wszystkie inne
              const cellValue = row[colIndex] ?? null;
              // Konwertuj stringi na liczby, zostaw null jak jest
              if (typeof cellValue === 'string') {
                const numValue = Number(cellValue);
                values.push(Number.isFinite(numValue) ? numValue : null);
              } else {
                values.push(cellValue);
              }
            }
          }
          
          // Dodaj linię tylko jeśli ma jakieś wartości
          if (values.some(v => v !== null)) {
            lines.push({
              index: rowIndex,
              label,
              values
            });
          }
        });
        
        console.log('🔍 updateAvailableParamsymLines result:', lines);
        set({ availableParamsymLines: lines });
      },
      
      setSelectedSheetName: (name) => set({ selectedSheetName: name }),
      setUploadedFileName: (name) => set({ uploadedFileName: name }),
      setDecimalPlaces: (places) => set({ decimalPlaces: places }),
      
      resetData: () => set(initialState),
    }),
    {
      name: 'paramsym-store',
      partialize: (state) => ({
        paramsymTriangle: state.paramsymTriangle,
        selectedParamsymLine: state.selectedParamsymLine,
        availableParamsymLines: state.availableParamsymLines,
        selectedSheetName: state.selectedSheetName,
        uploadedFileName: state.uploadedFileName,
        decimalPlaces: state.decimalPlaces,
      }),
      storage: {
        getItem: (name) => {
          const str = sessionStorage.getItem(name);
          if (!str) return null;
          return JSON.parse(str);
        },
        setItem: (name, value) => {
          sessionStorage.setItem(name, JSON.stringify(value));
        },
        removeItem: (name) => sessionStorage.removeItem(name),
      },
    }
  )
);