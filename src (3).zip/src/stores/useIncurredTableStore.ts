import { create } from 'zustand';
import * as XLSX from 'xlsx';
import { validateDataValues, ValidationPresets } from '@/utils/dataValidation';
import type { RowData } from '@/types/table';
import { parseRange, toExcelRange } from '@/utils/parseTableRange';

/* -------------------------------------------------------------------- */
/* Store dla tabeli danych incurred - kopia useDetailTableStore        */
/* -------------------------------------------------------------------- */
type IncurredTableStore = {
  table?: File;
  isHydrated: boolean;
  workbook?: XLSX.WorkBook;
  selectedSheet?: XLSX.WorkSheet;
  selectedSheetJSON?: RowData[];
  selectedCells?: number[][];
  selectedSheetName?: string;
  isValid?: boolean;
  validationErrorReason?: string;

  // 🆕 ID generacji danych dla wymuszenia odświeżenia komponentów
  dataGenerationId: number;
  incrementDataGeneration: () => void;

  // 🆕 Indywidualne ustawienia typu danych dla zakładki "Incurred"
  triangleType: 'paid' | 'incurred';
  setTriangleType: (type: 'paid' | 'incurred') => void;
  dataType: 'cumulative' | 'incremental';
  setDataType: (type: 'cumulative' | 'incremental') => void;

  // 🆕 Ustawienie czy dane zawierają podpisy kolumn i wierszy
  hasHeaders: boolean;
  setHasHeaders: (hasHeaders: boolean) => void;

  // 🆕 Ustawienia inflacji
  useInflation: boolean;
  setUseInflation: (use: boolean) => void;

  // 🆕 Ostatnie zatwierdzone ustawienia dla sprawdzania zmian
  lastApprovedSettings?: {
    sheetName: string | null;
    rowStart: number;
    rowEnd: number;
    colStart: number;
    colEnd: number;
    hasHeaders: boolean;
    dataType: 'cumulative' | 'incremental';
    useInflation: boolean;
    dataId?: string; // 🔥 Unikalny identyfikator dla pełnej niezależności
  };
  setLastApprovedSettings: (settings: {
    sheetName: string | null;
    rowStart: number;
    rowEnd: number;
    colStart: number;
    colEnd: number;
    hasHeaders: boolean;
    dataType: 'cumulative' | 'incremental';
    useInflation: boolean;
    dataId?: string; // 🔥 Unikalny identyfikator dla pełnej niezależności
  }) => void;

  uploadedFileName?: string;
  setUploadedFileName: (fileName: string) => void;
  previousSheetJSON?: RowData[];

  /* ---------- Zakres danych ---------- */
  startRow: number;
  endRow: number;
  startCol: number;
  endCol: number;

  /* ---------- Akcje ---------- */
  setTable: (table: File) => void;
  setWorkbook: (wb: XLSX.WorkBook) => void;
  setSelectedSheet: (sheet: XLSX.WorkSheet) => void;
  setSelectedSheetName: (name: string) => void;
  setSelectedCells: (cells: number[][]) => void;
  setRangeAndUpdate: (range: {
    startRow: number;
    endRow: number;
    startCol: number;
    endCol: number;
  }) => void;
  getDefaultRange: () =>
    | { startRow: number; endRow: number; startCol: number; endCol: number }
    | undefined;
  getSheetNames: () => string[];
  sheetNames: string[];
  resetData: () => void;
};

export const useIncurredTableStore = create<IncurredTableStore>((set, get) => ({
  /* ---------- Stan początkowy ---------- */
  table: undefined,
  isHydrated: false,
  workbook: undefined,
  selectedSheet: undefined,
  selectedSheetJSON: undefined,
  selectedCells: undefined,
  selectedSheetName: undefined,
  isValid: false,
  validationErrorReason: undefined,
  previousSheetJSON: undefined,

  // 🆕 Domyślne ustawienia dla incurred
  dataGenerationId: 0,
  triangleType: 'incurred',
  dataType: 'cumulative',
  hasHeaders: true,
  useInflation: false,
  lastApprovedSettings: undefined,

  uploadedFileName: undefined,

  /* Zakres */
  startRow: 1,
  endRow: 1,
  startCol: 1,
  endCol: 1,

  /* Computed properties */
  sheetNames: [],

  /* ---------- Akcje ---------- */
  incrementDataGeneration: () => set(state => ({ dataGenerationId: state.dataGenerationId + 1 })),

  setTriangleType: (type) => set({ triangleType: type }),
  setDataType: (type) => set({ dataType: type }),
  setHasHeaders: (hasHeaders) => set({ hasHeaders }),
  setUseInflation: (use) => set({ useInflation: use }),
  setLastApprovedSettings: (settings) => set({ lastApprovedSettings: settings }),

  setTable: (table) => set({ table }),
  setUploadedFileName: (fileName) => set({ uploadedFileName: fileName }),

  setWorkbook: (wb) => {
    const sheetNames = wb.SheetNames || [];
    set({ 
      workbook: wb,
      sheetNames: sheetNames,
      selectedSheetName: sheetNames.length > 0 ? sheetNames[0] : undefined
    });
    // Automatyczne ustawienie pierwszego arkusza
    if (sheetNames.length > 0) {
      const firstSheetName = sheetNames[0];
      if (firstSheetName) {
        const firstSheet = wb.Sheets[firstSheetName];
        if (firstSheet) {
          get().setSelectedSheet(firstSheet);
        }
      }
    }
  },

  setSelectedSheet: (sheet) => {
    const currentJSON = get().selectedSheetJSON;
    const json = XLSX.utils.sheet_to_json<RowData>(sheet, { header: 1 });
    
    console.log('🔍 [useIncurredTableStore.setSelectedSheet]', {
      currentJSON: currentJSON?.length || 'undefined',
      newJSON: json?.length || 'undefined',
      willSetPreviousTo: currentJSON ? currentJSON.length : 'undefined',
      storeType: 'INCURRED' // 🔥 Oznaczenie że to incurred store
    });
    
    set({
      selectedSheet: sheet,
      // 🔥 WAŻNE: previousSheetJSON tylko z TEGO store'a, nie z innych zakładek
      previousSheetJSON: currentJSON,  // poprzednie dane TYLKO z incurred (może być undefined przy pierwszym użyciu)
      selectedSheetJSON: json,         // nowe dane
    });
  },

  setSelectedSheetName: (name) => {
    const { workbook } = get();
    if (!workbook || !workbook.Sheets || !workbook.Sheets[name]) return;

    const sheet = workbook.Sheets[name];
    set({ selectedSheetName: name });
    get().setSelectedSheet(sheet);
  },

  setSelectedCells: (cells) => set({ selectedCells: cells }),

  setRangeAndUpdate: ({ startRow, endRow, startCol, endCol }) => {
    set({ startRow, endRow, startCol, endCol });

    const { selectedSheetJSON } = get();
    if (!selectedSheetJSON) {
      set({ isValid: false, validationErrorReason: 'Brak danych do walidacji' });
      return;
    }

    try {
      // Wyciągnij fragment na podstawie zakresu
      const fragment = selectedSheetJSON
        .slice(startRow - 1, endRow)
        .map((row) => row.slice(startCol - 1, endCol));

      // Walidacja za pomocą ValidationPresets.incurred() lub paid() - używajmy paid dla teraz
      const validation = validateDataValues(fragment, ValidationPresets.paid());
      
      set({
        isValid: validation.isValid,
        validationErrorReason: validation.isValid ? undefined : validation.reason
      });
    } catch (error) {
      set({
        isValid: false,
        validationErrorReason: `Błąd walidacji: ${(error as Error).message}`
      });
    }
  },

  getDefaultRange: () => {
    const { selectedSheetJSON } = get();
    if (!selectedSheetJSON || selectedSheetJSON.length === 0) return undefined;

    // Znajdź rozmiary danych (pomijając puste komórki na końcu)
    let maxRow = selectedSheetJSON.length;
    let maxCol = 0;

    for (const row of selectedSheetJSON) {
      if (row && row.length > maxCol) {
        maxCol = row.length;
      }
    }

    // Usuń puste wiersze na końcu
    while (maxRow > 0) {
      const lastRow = selectedSheetJSON[maxRow - 1];
      if (lastRow && lastRow.some(cell => cell != null && cell !== '')) {
        break;
      }
      maxRow--;
    }

    // Usuń puste kolumny na końcu
    for (let col = maxCol - 1; col >= 0; col--) {
      let hasData = false;
      for (let row = 0; row < maxRow; row++) {
        const cell = selectedSheetJSON[row]?.[col];
        if (cell != null && cell !== '') {
          hasData = true;
          break;
        }
      }
      if (hasData) {
        maxCol = col + 1;
        break;
      }
    }

    return {
      startRow: 1,
      endRow: maxRow,
      startCol: 1,
      endCol: maxCol,
    };
  },

  getSheetNames: () => {
    const { sheetNames } = get();
    return sheetNames;
  },

  resetData: () => {
    console.log('🧹 [useIncurredTableStore.resetData] Czyszczenie danych...');
    set({
      table: undefined,
      workbook: undefined,
      selectedSheet: undefined,
      selectedSheetJSON: undefined,
      selectedCells: undefined,
      selectedSheetName: undefined,
      isValid: false,
      validationErrorReason: undefined,
      previousSheetJSON: undefined,
      uploadedFileName: undefined,
      sheetNames: [],
      startRow: 1,
      endRow: 1,
      startCol: 1,
      endCol: 1,
      // Zachowaj ustawienia konfiguracji
      dataGenerationId: 0,
      lastApprovedSettings: undefined,
    });
    console.log('✅ [useIncurredTableStore.resetData] Dane wyczyszczone');
  },
}));