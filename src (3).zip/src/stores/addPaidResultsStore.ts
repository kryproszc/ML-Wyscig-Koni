import { create } from 'zustand';
import { persist } from 'zustand/middleware';

/* ──────────────────────────── TYPY ──────────────────────────── */

export interface AddPaidResults {
  // Wyniki w tym samym formacie co MultPaid
  last_col: number[];
  cum_trian: number[];
  ult_net_disc: number[];
  calculatedAt?: string; // Timestamp obliczeń
  userId?: string; // ID użytkownika dla którego obliczono
  shouldShowResults?: boolean; // Flaga czy pokazywać wyniki
}

interface AddPaidResultsState {
  // Stan wyników
  results: AddPaidResults | null;
  isCalculating: boolean;
  lastError: string | null;
  
  // Akcje
  setResults: (results: AddPaidResults) => void;
  clearResults: () => void;
  setCalculating: (calculating: boolean) => void;
  setError: (error: string | null) => void;
  hideResults: () => void; // Ukryj wyniki bez usuwania danych
  showResults: () => void; // Pokaż wyniki z powrotem
  
  // Getters pomocnicze
  hasResults: () => boolean;
  getResultsForUser: (userId: string) => AddPaidResults | null;
}

/* ──────────────────────────── STORE ──────────────────────────── */

// Usuń stare dane z localStorage przy inicjalizacji
if (typeof window !== 'undefined') {
  localStorage.removeItem('addpaid-results-storage');
}

export const useAddPaidResultsStore = create<AddPaidResultsState>()(
  persist(
    (set, get) => ({
      // Stan początkowy
      results: null,
      isCalculating: false,
      lastError: null,
      
      // Akcje
      setResults: (results: AddPaidResults) => {
        console.log('🏪 [AddPaidResultsStore] Setting results:', results);
        set({ 
          results: {
            ...results,
            calculatedAt: new Date().toISOString(),
            shouldShowResults: true // Domyślnie pokazuj wyniki
          },
          lastError: null 
        });
      },
      
      clearResults: () => {
        console.log('🏪 [AddPaidResultsStore] Clearing results');
        set({ 
          results: null, 
          lastError: null 
        });
      },
      
      setCalculating: (calculating: boolean) => {
        console.log('🏪 [AddPaidResultsStore] Setting calculating:', calculating);
        set({ isCalculating: calculating });
      },
      
      setError: (error: string | null) => {
        console.log('🏪 [AddPaidResultsStore] Setting error:', error);
        set({ 
          lastError: error,
          isCalculating: false 
        });
      },
      
      hideResults: () => {
        const current = get().results;
        if (current) {
          console.log('🏪 [AddPaidResultsStore] Hiding results');
          set({ 
            results: { 
              ...current, 
              shouldShowResults: false 
            } 
          });
        }
      },
      
      showResults: () => {
        const current = get().results;
        if (current) {
          console.log('🏪 [AddPaidResultsStore] Showing results');
          set({ 
            results: { 
              ...current, 
              shouldShowResults: true 
            } 
          });
        }
      },
      
      // Getters pomocnicze
      hasResults: () => {
        const results = get().results;
        return results !== null;
      },
      
      getResultsForUser: (userId: string) => {
        const results = get().results;
        if (results && results.userId === userId) {
          return results;
        }
        return null;
      },
    }),
    {
      name: 'addpaid-results-storage',
      partialize: (state) => ({
        results: state.results,
        // Nie persist'uj isCalculating, lastError - to są stany przejściowe
      }),
      storage: {
        getItem: (name) => {
          const item = sessionStorage.getItem(name);
          return item ? JSON.parse(item) : null;
        },
        setItem: (name, value) => sessionStorage.setItem(name, JSON.stringify(value)),
        removeItem: (name) => sessionStorage.removeItem(name),
      },
    }
  )
);