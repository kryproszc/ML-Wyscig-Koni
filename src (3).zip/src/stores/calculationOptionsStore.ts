import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface CalculationOptions {
  brutto: boolean;
  bruttoDysk: boolean;
  nettoDysk: boolean;
}

export interface CalculationOptionsStore {
  // Stan opcji
  selectedOptions: CalculationOptions;
  
  // Actions
  setSelectedOptions: (options: CalculationOptions) => void;
  toggleOption: (option: keyof CalculationOptions) => void;
  resetOptions: () => void;
}

// Stan początkowy
const initialOptions: CalculationOptions = {
  brutto: false,
  bruttoDysk: false,
  nettoDysk: false
};

export const useCalculationOptionsStore = create<CalculationOptionsStore>()(
  persist(
    (set, get) => ({
      selectedOptions: initialOptions,
      
      setSelectedOptions: (options) => set({ selectedOptions: options }),
      
      toggleOption: (option) => set((state) => ({
        selectedOptions: {
          ...state.selectedOptions,
          [option]: !state.selectedOptions[option]
        }
      })),
      
      resetOptions: () => set({ selectedOptions: initialOptions }),
    }),
    {
      name: 'calculation-options-storage', // klucz w sessionStorage
      storage: {
        getItem: (n) => {
          const i = sessionStorage.getItem(n);
          return i ? JSON.parse(i) : null;
        },
        setItem: (n, v) => sessionStorage.setItem(n, JSON.stringify(v)),
        removeItem: (n) => sessionStorage.removeItem(n),
      },
    }
  )
);