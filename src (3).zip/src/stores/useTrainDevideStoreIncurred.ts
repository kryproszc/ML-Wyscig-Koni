import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import * as XLSX from 'xlsx';

/* ──────────────────────────── TYPY ──────────────────────────── */

export type SourceType = 'base' | 'curve' | 'custom';

export type DevJResult = {
  volume: number;
  subIndex?: number;
  values: number[];
};

export type SigmaResult = {
  volume: number;
  subIndex?: number;
  values: number[];
};

export interface CustomCell {
  curve: string;
  value: number;
}

export type ComparisonEntry = {
  data: any[];
  labelA: string;
  labelB: string;
};

/* ─────────────────── INTERFEJS STANU (dla danych incurred) ─────────────────── */

export type TrainDevideStoreIncurred = {
  /* ————— Loader IncurredTriangle ————— */
  workbookIncurred?: XLSX.WorkBook;
  setWorkbookIncurred: (wb: XLSX.WorkBook) => void;

  uploadedFileNameIncurred?: string;
  setUploadedFileNameIncurred: (n: string) => void;

  selectedSheetNameIncurred?: string;
  setSelectedSheetNameIncurred: (n: string) => void;

  /* zakres */
  startRowIncurred: number;
  endRowIncurred: number;
  startColIncurred: number;
  endColIncurred: number;
  setRangeAndUpdateIncurred: (r: {
    startRow: number;
    endRow: number;
    startCol: number;
    endCol: number;
  }) => void;
  getDefaultRangeIncurred: () =>
    | { startRow: number; endRow: number; startCol: number; endCol: number }
    | undefined;

  /* JSON + walidacja */
  selectedSheetIncurred?: (string | number)[][];
  previousSheetIncurred?: (string | number)[][];
  isValidIncurred: boolean;
  validationErrorReasonIncurred?: string;

  /* ————— Dane incurred triangle ————— */
  incurredTriangle?: (number | null)[][];
  setIncurredTriangle: (d: (number | null)[][]) => void;

  incurredTriangle_bez_inf?: (number | null)[][] | null;
  setIncurredTriangle_bez_inf: (d: (number | null)[][] | null) => void;

  reserve?: (number | null)[][] | null;
  setReserve: (d: (number | null)[][] | null) => void;

  /* ————— Comparison tables ————— */
  removeComparisonTable: (index: number) => void;
  comparisonTables: ComparisonEntry[];
  addComparisonTable: (entry: ComparisonEntry) => void;
  clearComparisonTables: () => void;

  comparisonLabels: { labelA: string; labelB: string };
  setComparisonLabels: (l: { labelA: string; labelB: string }) => void;

  comparisonTable: any[];
  setComparisonTable: (d: any[]) => void;

  selectedDataA: string | null;
  selectedDataB: string | null;
  setSelectedDataA: (k: string | null) => void;
  setSelectedDataB: (k: string | null) => void;

  /* ————— Combined summaries ————— */
  combinedDevJSummary: (number | string)[];
  setCombinedDevJSummary: (v: (number | string)[]) => void;

  combinedSigmaSummary: (number | string)[];
  setCombinedSigmaSummary: (v: (number | string)[]) => void;

  /* ===== SELECTED VALUES (effectiveValues z FinalTable) ===== */
  selectedValuesCL: number[];
  setSelectedValuesCL: (v: number[]) => void;

  selectedValuesSigma: number[];
  setSelectedValuesSigma: (v: number[]) => void;

  selectedValuesSD: number[];
  setSelectedValuesSD: (v: number[]) => void;

  selectedValuesRJPaidToIncurred: number[];
  setSelectedValuesRJPaidToIncurred: (v: number[]) => void;

  selectedValuesVarJPaidToIncurred: number[];
  setSelectedValuesVarJPaidToIncurred: (v: number[]) => void;

  remainingDevJHeaders: string[];
  setRemainingDevJHeaders: (headers: string[]) => void;

  leftCountSummary: number;
  setLeftCountSummary: (n: number) => void;

  /* Separate left counts for CL and Sigma */
  leftCountCL: number;
  setLeftCountCL: (n: number) => void;
  
  leftCountSigma: number;
  setLeftCountSigma: (n: number) => void;

  selectedCurveSummary: string | null;
  setSelectedCurveSummary: (c: string | null) => void;

  manualOverridesSummary: Record<number, { curve: string; value: number }>;
  setManualOverridesSummary: (
    o: Record<number, { curve: string; value: number }>
  ) => void;

  // Nowy stan dla przełączania źródła współczynników
  sourceSwitchesSummary: Record<number, { curve: string; value: number }>;
  setSourceSwitchesSummary: (switches: Record<number, { curve: string; value: number }>) => void;

  /* Separate selection states for Sigma */
  selectedCurveSigma: string | null;
  setSelectedCurveSigma: (c: string | null) => void;

  manualOverridesSigma: Record<number, { curve: string; value: number }>;
  setManualOverridesSigma: (
    o: Record<number, { curve: string; value: number }>
  ) => void;

  sourceSwitchesSigma: Record<number, { curve: string; value: number }>;
  setSourceSwitchesSigma: (switches: Record<number, { curve: string; value: number }>) => void;

  /* === SD Summary states (analogiczne do CL/Sigma) === */
  leftCountSD: number;
  setLeftCountSD: (n: number) => void;

  selectedCurveSD: string | null;
  setSelectedCurveSD: (c: string | null) => void;

  manualOverridesSD: Record<number, { curve: string; value: number }>;
  setManualOverridesSD: (
    o: Record<number, { curve: string; value: number }>
  ) => void;

  sourceSwitchesSD: Record<number, { curve: string; value: number }>;
  setSourceSwitchesSD: (switches: Record<number, { curve: string; value: number }>) => void;

  combinedSDSummary?: (number | string)[];
  setCombinedSDSummary: (combined: (number | string)[]) => void;
  clearCombinedSDSummary: () => void;

  /* === PaidIncurred Summary states (analogiczne do CL/Sigma/SD) === */
  leftCountRJPaidToIncurred: number;
  setLeftCountRJPaidToIncurred: (n: number) => void;

  selectedCurveRJPaidToIncurred: string | null;
  setSelectedCurveRJPaidToIncurred: (c: string | null) => void;

  manualOverridesRJPaidToIncurred: Record<number, { curve: string; value: number }>;
  setManualOverridesRJPaidToIncurred: (
    o: Record<number, { curve: string; value: number }>
  ) => void;

  sourceSwitchesRJPaidToIncurred: Record<number, { curve: string; value: number }>;
  setSourceSwitchesRJPaidToIncurred: (switches: Record<number, { curve: string; value: number }>) => void;

  combinedRJPaidToIncurredSummary?: (number | string)[];
  setCombinedRJPaidToIncurredSummary: (combined: (number | string)[]) => void;
  clearCombinedRJPaidToIncurredSummary: () => void;

  /* Separate states for VarJ PaidToIncurred */
  leftCountVarJPaidToIncurred: number;
  setLeftCountVarJPaidToIncurred: (n: number) => void;

  selectedCurveVarJPaidToIncurred: string | null;
  setSelectedCurveVarJPaidToIncurred: (c: string | null) => void;

  manualOverridesVarJPaidToIncurred: Record<number, { curve: string; value: number }>;
  setManualOverridesVarJPaidToIncurred: (
    o: Record<number, { curve: string; value: number }>
  ) => void;

  sourceSwitchesVarJPaidToIncurred: Record<number, { curve: string; value: number }>;
  setSourceSwitchesVarJPaidToIncurred: (switches: Record<number, { curve: string; value: number }>) => void;

  combinedVarJPaidToIncurredSummary?: (number | string)[];
  setCombinedVarJPaidToIncurredSummary: (combined: (number | string)[]) => void;
  clearCombinedVarJPaidToIncurredSummary: () => void;

  updateDevJAt: (idx: number, value: number) => void;

  selectedDevJVolume?: number;
  selectedDevJSubIndex?: number;
  setSelectedDevJVolume: (v: number, subIndex?: number) => void;

  /* ===== PREVIEW ===== */
  devPreviewCandidate?: number[];
  setDevPreviewCandidate: (v: number[]) => void;
  clearDevPreviewCandidate: () => void;

  /* ===== UI / CONFIG ===== */
  retainedCoeffCount: number;
  setRetainedCoeffCount: (val: number) => void;

  selectedCurve: string;
  setSelectedCurve: (name: string) => void;

  /* ===== Final vectors & custom overrides ===== */
  finalDevVector: number[];
  setFinalDevVector: (v: number[]) => void;

  devFinalCustom: Record<number, CustomCell>;
  setDevFinalValue: (idx: number, curve: string, value: number) => void;
  clearDevFinalValue: (idx: number) => void;
  clearAllDevFinalValues: () => void;

  /* ===== Dane do obliczeń dev_j ===== */
  trainDevideIncurred?: number[][];
  selectedWeightsIncurred?: number[][];
  safeWeights?: number[][];
  volume: number;
  selectedCellsIncurred: [number, number][];

  r2Scores?: Record<string, number>;
  setR2Scores: (r: Record<string, number>) => void;
  clearR2Scores: () => void;

  sePred?: number[];
  setSePred: (se: number[]) => void;
  clearSePred: () => void;

  /* ===== DevJ results ===== */
  devJResults: DevJResult[];
  setDevJResults: (results: DevJResult[]) => void;
  clearDevJResults: () => void;
  addDevJResult: (vol: number, values: number[]) => void;

  /* ===== Current calculation results ===== */
  devJ?: number[];
  setDevJ: (d: number[]) => void;
  
  sigma?: number[];
  setSigma: (d: number[]) => void;
  
  sd?: number[];
  setSd: (d: number[]) => void;

  /* ===== Sigma results ===== */
  sigmaResults: SigmaResult[];
  setSigmaResults: (results: SigmaResult[]) => void;
  clearSigmaResults: () => void;
  addSigmaResult: (vol: number, values: number[]) => void;

  /* ===== Final DevJ ===== */
  finalDevJ?: DevJResult;
  setFinalDevJ: (dev: DevJResult | undefined) => void;
  finalSigma?: SigmaResult;
  setFinalSigma: (sigma: SigmaResult | undefined) => void;

  /* ===== Reset functions ===== */
  resetIncurredTriangle: () => void;
  resetData: () => void;

  // Dodatkowe funkcje czyszczące (analogiczne do paid)
  clearFitCurveData: () => void;
  clearDevSummaryData: () => void;

  /* ===== Settery podstawowe ===== */
  setTrainDevideIncurred: (data: number[][] | undefined) => void;
  setSelectedWeightsIncurred: (weights: number[][] | undefined) => void;
  setSelectedCellsIncurred: (cells: [number, number][]) => void;
  setSafeWeights: (w: number[][]) => void;
  setVolume: (vol: number) => void;

  /* ===== Display settings ===== */
  decimalPlaces: number;
  setDecimalPlaces: (places: number) => void;

  /* ===== Selection and interaction functions ===== */
  toggleRowIncurred: (r: number) => void;
  toggleCellIncurred: (r: number, c: number) => void;
  toggleWeightCellIncurred: (r: number, c: number) => void;
  resetSelectionIncurred: () => void;

  /* ===== Min/Max highlighting ===== */
  minMaxHighlighting: boolean;
  minMaxCells: [number, number][];
  minCells: [number, number][];
  maxCells: [number, number][];
  setMinMaxHighlighting: (enabled: boolean) => void;
  calculateMinMaxCells: () => void;
  
  /* ===== Safe weights calculation ===== */
  safeWeights?: number[][];
  setSafeWeights: (w: number[][]) => void;
  calculateSafeWeights: () => void;

  /* ===== Volume selection ===== */
  selectedDevJVolume?: number;
  selectedDevJSubIndex?: number;
  setSelectedDevJVolume: (vol: number, subIdx?: number) => void;
  
  selectedSigmaVolume?: number;
  selectedSigmaSubIndex?: number;
  setSelectedSigmaVolume: (vol: number, subIdx?: number) => void;

  /* ===== PaidToIncurred functionality ===== */
  trainPaidToIncurred?: number[][];
  setTrainPaidToIncurred: (data: number[][] | undefined) => void;
  
  selectedWeightsPaidToIncurred?: number[][];
  safeWeightsPaidToIncurred?: number[][];
  selectedCellsPaidToIncurred: [number, number][];
  volumePaidToIncurred: number;
  
  devJPaidToIncurred?: number[];
  sigmaPaidToIncurred?: number[];
  sdPaidToIncurred?: number[];
  
  rJPaidToIncurred?: number[];
  varJPaidToIncurred?: number[];
  
  resIJPaidToIncurred?: number[][];
  lambdaJPaidToIncurred?: number;
  
  minMaxHighlightingPaidToIncurred: boolean;
  minMaxCellsPaidToIncurred: [number, number][];
  minCellsPaidToIncurred: [number, number][];
  maxCellsPaidToIncurred: [number, number][];
  
  setSelectedWeightsPaidToIncurred: (weights: number[][] | undefined) => void;
  setSafeWeightsPaidToIncurred: (w: number[][]) => void;
  setSelectedCellsPaidToIncurred: (cells: [number, number][]) => void;
  setVolumePaidToIncurred: (vol: number) => void;
  setDevJPaidToIncurred: (d: number[]) => void;
  setSigmaPaidToIncurred: (d: number[]) => void;
  setSdPaidToIncurred: (d: number[]) => void;
  
  setRJPaidToIncurred: (d: number[]) => void;
  setVarJPaidToIncurred: (d: number[]) => void;
  
  setResIJPaidToIncurred: (d: number[][]) => void;
  setLambdaJPaidToIncurred: (d: number) => void;
  setMinMaxHighlightingPaidToIncurred: (enabled: boolean) => void;
  
  toggleRowPaidToIncurred: (r: number) => void;
  toggleCellPaidToIncurred: (r: number, c: number) => void;
  toggleWeightCellPaidToIncurred: (r: number, c: number) => void;
  resetSelectionPaidToIncurred: () => void;

  /* ===== FitCurve functions for PaidToIncurred ===== */
  // TailCounts for PaidToIncurred
  tailCountRJPaidToIncurred?: number | '';
  setTailCountRJPaidToIncurred: (n: number | '') => void;
  tailCountVarJPaidToIncurred?: number | '';
  setTailCountVarJPaidToIncurred: (n: number | '') => void;

  // r_j FitCurve for PaidToIncurred
  rJPaidToIncurredPreview?: number[];
  setRJPaidToIncurredPreview: (data: number[]) => void;
  rJPaidToIncurredPreviewCandidate?: number[];
  setRJPaidToIncurredPreviewCandidate: (data: number[]) => void;
  selectedRJPaidToIncurredIndexes: number[];
  setSelectedRJPaidToIncurredIndexes: (indexes: number[]) => void;
  
  // var_j FitCurve for PaidToIncurred
  varJPaidToIncurredPreview?: number[];
  setVarJPaidToIncurredPreview: (data: number[]) => void;
  varJPaidToIncurredPreviewCandidate?: number[];
  setVarJPaidToIncurredPreviewCandidate: (data: number[]) => void;
  selectedVarJPaidToIncurredIndexes: number[];
  setSelectedVarJPaidToIncurredIndexes: (indexes: number[]) => void;
  
  // Simulation Results for PaidToIncurred
  simResultsRJPaidToIncurred?: any;
  setSimResultsRJPaidToIncurred: (data: any) => void;
  clearSimResultsRJPaidToIncurred: () => void;
  simResultsVarJPaidToIncurred?: any;
  setSimResultsVarJPaidToIncurred: (data: any) => void;
  clearSimResultsVarJPaidToIncurred: () => void;
  
  // R2 Scores for PaidToIncurred
  r2ScoresRJPaidToIncurred?: any;
  setR2ScoresRJPaidToIncurred: (data: any) => void;
  clearR2ScoresRJPaidToIncurred: () => void;
  r2ScoresVarJPaidToIncurred?: any;
  setR2ScoresVarJPaidToIncurred: (data: any) => void;
  clearR2ScoresVarJPaidToIncurred: () => void;
  
  // Final Custom values for PaidToIncurred
  rJPaidToIncurredFinalCustom: Record<number, { curve: string; value: number }>;
  varJPaidToIncurredFinalCustom: Record<number, { curve: string; value: number }>;

  /* ===== Funkcje czyszczące PaidToIncurred FitCurve ===== */
  clearPaidToIncurredFitCurveData: () => void;

  /* ===== FitCurve functions for Incurred ===== */
  // TailCounts
  tailCountCL?: number | '';
  setTailCountCL: (n: number | '') => void;
  tailCountSigma?: number | '';
  setTailCountSigma: (n: number | '') => void;

  // Dev J FitCurve
  devJPreview?: number[];
  setDevJPreview: (data: number[]) => void;
  devPreviewCandidate?: number[];
  setDevPreviewCandidate: (data: number[]) => void;
  selectedDevJIndexes: number[];
  setSelectedDevJIndexes: (indexes: number[]) => void;
  
  // Sigma FitCurve  
  sigmaPreview?: number[];
  setSigmaPreview: (data: number[]) => void;
  sigmaPreviewCandidate?: number[];
  setSigmaPreviewCandidate: (data: number[]) => void;
  selectedSigmaIndexes: number[];
  setSelectedSigmaIndexes: (indexes: number[]) => void;
  
  // Simulation Results
  simResults?: any;
  setSimResults: (data: any) => void;
  clearSimResults: () => void;
  simResultsSigma?: any;
  setSimResultsSigma: (data: any) => void;
  clearSimResultsSigma: () => void;
  
  // R2 Scores
  r2Scores?: any;
  setR2Scores: (data: any) => void;
  clearR2Scores: () => void;
  r2ScoresSigma?: any;
  setR2ScoresSigma: (data: any) => void;
  clearR2ScoresSigma: () => void;
  
  // Final Custom values
  devFinalCustom: Record<number, { curve: string; value: number }>;
  sigmaFinalCustom: Record<number, { curve: string; value: number }>;
};

export const useTrainDevideStoreIncurred = create<TrainDevideStoreIncurred>()(
  persist(
    (set, get) => ({
      /* ————— Loader ————— */
      workbookIncurred: undefined,
      uploadedFileNameIncurred: undefined,
      selectedSheetNameIncurred: undefined,
      startRowIncurred: 1,
      endRowIncurred: 1,
      startColIncurred: 1,
      endColIncurred: 1,

      selectedSheetIncurred: undefined,
      previousSheetIncurred: undefined,
      isValidIncurred: false,
      validationErrorReasonIncurred: undefined,

      /* ————— Główne dane ————— */
      incurredTriangle: undefined,
      incurredTriangle_bez_inf: null,
      reserve: null,

      /* ————— Comparison ————— */
      comparisonTables: [],
      comparisonLabels: { labelA: '', labelB: '' },
      comparisonTable: [],
      selectedDataA: null,
      selectedDataB: null,

      /* ————— Combined summaries ————— */
      combinedDevJSummary: [],
      combinedSigmaSummary: [],

      /* ===== Selected values ===== */
      selectedValuesCL: [],
      selectedValuesSigma: [],
      selectedValuesSD: [],
      selectedValuesRJPaidToIncurred: [],
      selectedValuesVarJPaidToIncurred: [],

      remainingDevJHeaders: [],

      /* ===== Left counts ===== */
      leftCountSummary: 0,
      leftCountCL: 0,
      leftCountSigma: 0,
      leftCountSD: 0,

      /* ===== Curve selections ===== */
      selectedCurveSummary: null,
      selectedCurveSigma: null,
      selectedCurveSD: null,
      selectedCurve: 'Manual',

      /* ===== Manual overrides ===== */
      manualOverridesSummary: {},
      manualOverridesSigma: {},
      manualOverridesSD: {},

      /* ===== Source switches ===== */
      sourceSwitchesSummary: {},
      sourceSwitchesSigma: {},
      sourceSwitchesSD: {},

      /* ===== SD Summary ===== */
      combinedSDSummary: undefined,

      /* ===== PaidIncurred Summary ===== */
      leftCountRJPaidToIncurred: 0,
      selectedCurveRJPaidToIncurred: null,
      manualOverridesRJPaidToIncurred: {},
      sourceSwitchesRJPaidToIncurred: {},
      combinedRJPaidToIncurredSummary: undefined,
      
      leftCountVarJPaidToIncurred: 0,
      selectedCurveVarJPaidToIncurred: null,
      manualOverridesVarJPaidToIncurred: {},
      sourceSwitchesVarJPaidToIncurred: {},
      combinedVarJPaidToIncurredSummary: undefined,

      /* ===== DevJ ===== */
      selectedDevJVolume: undefined,
      selectedDevJSubIndex: undefined,

      /* ===== Preview ===== */
      devPreviewCandidate: undefined,

      /* ===== Config ===== */
      retainedCoeffCount: 0,

      /* ===== Final vectors ===== */
      finalDevVector: [],
      devFinalCustom: {},

      /* ===== Dane do obliczeń ===== */
      trainDevideIncurred: undefined,
      selectedWeightsIncurred: undefined,
      safeWeights: undefined,
      volume: 0,
      selectedCellsIncurred: [],

      /* ===== Display settings ===== */
      decimalPlaces: 6,

      /* ===== PaidToIncurred ===== */
      trainPaidToIncurred: undefined,
      selectedWeightsPaidToIncurred: undefined,
      safeWeightsPaidToIncurred: undefined,
      selectedCellsPaidToIncurred: [],
      volumePaidToIncurred: 0,
      devJPaidToIncurred: undefined,
      sigmaPaidToIncurred: undefined,
      sdPaidToIncurred: undefined,
      
      rJPaidToIncurred: undefined,
      varJPaidToIncurred: undefined,
      
      resIJPaidToIncurred: undefined,
      lambdaJPaidToIncurred: undefined,
      minMaxHighlightingPaidToIncurred: false,
      minMaxCellsPaidToIncurred: [],
      minCellsPaidToIncurred: [],
      maxCellsPaidToIncurred: [],

      /* ===== FitCurve fields for PaidToIncurred ===== */
      tailCountRJPaidToIncurred: "",
      tailCountVarJPaidToIncurred: "",
      selectedRJPaidToIncurredIndexes: [],
      selectedVarJPaidToIncurredIndexes: [],
      rJPaidToIncurredFinalCustom: {},
      varJPaidToIncurredFinalCustom: {},

      r2Scores: undefined,
      sePred: undefined,

      /* ===== Current results ===== */
      devJ: undefined,
      sigma: undefined,
      sd: undefined,

      /* ===== Results ===== */
      devJResults: [],
      sigmaResults: [],
      finalDevJ: undefined,
      finalSigma: undefined,

      /* ===== Min/Max highlighting ===== */
      minMaxHighlighting: false,
      minMaxCells: [],
      minCells: [],
      maxCells: [],

      /* ===== Safe weights ===== */
      safeWeights: undefined,

      /* ===== Volume selection ===== */
      selectedSigmaVolume: undefined,
      selectedSigmaSubIndex: undefined,

      /* ===== FitCurve initial state ===== */
      // TailCounts
      tailCountCL: '',
      tailCountSigma: '',

      // Dev J FitCurve
      devJPreview: undefined,
      devPreviewCandidate: undefined,
      selectedDevJIndexes: [],
      
      // Sigma FitCurve
      sigmaPreview: undefined,
      sigmaPreviewCandidate: undefined,
      selectedSigmaIndexes: [],
      
      // Simulation Results
      simResults: undefined,
      simResultsSigma: undefined,
      
      // R2 Scores
      r2Scores: undefined,
      r2ScoresSigma: undefined,
      
      // Final Custom values
      devFinalCustom: {},
      sigmaFinalCustom: {},

      /* ————— Akcje Loader ————— */
      setWorkbookIncurred: (wb) => set({ workbookIncurred: wb }),
      setUploadedFileNameIncurred: (n) => set({ uploadedFileNameIncurred: n }),
      setSelectedSheetNameIncurred: (n) => set({ selectedSheetNameIncurred: n }),

      setRangeAndUpdateIncurred: (r) => set({
        startRowIncurred: r.startRow,
        endRowIncurred: r.endRow,
        startColIncurred: r.startCol,
        endColIncurred: r.endCol,
      }),

      getDefaultRangeIncurred: () => {
        const { selectedSheetIncurred } = get();
        if (!selectedSheetIncurred || selectedSheetIncurred.length === 0) return undefined;

        let maxRow = selectedSheetIncurred.length;
        let maxCol = 0;

        for (const row of selectedSheetIncurred) {
          if (row && row.length > maxCol) {
            maxCol = row.length;
          }
        }

        return {
          startRow: 1,
          endRow: maxRow,
          startCol: 1,
          endCol: maxCol,
        };
      },

      /* ————— Główne akcje ————— */
      setIncurredTriangle: (d) => set({ incurredTriangle: d }),
      setIncurredTriangle_bez_inf: (d) => set({ incurredTriangle_bez_inf: d }),
      setReserve: (d) => set({ reserve: d }),

      /* ————— Comparison ————— */
      addComparisonTable: (entry) => set(state => ({
        comparisonTables: [...state.comparisonTables, entry]
      })),
      removeComparisonTable: (index) => set(state => ({
        comparisonTables: state.comparisonTables.filter((_, i) => i !== index)
      })),
      clearComparisonTables: () => set({ comparisonTables: [] }),
      setComparisonLabels: (l) => set({ comparisonLabels: l }),
      setComparisonTable: (d) => set({ comparisonTable: d }),
      setSelectedDataA: (k) => set({ selectedDataA: k }),
      setSelectedDataB: (k) => set({ selectedDataB: k }),

      /* ————— Combined summaries ————— */
      setCombinedDevJSummary: (v) => set({ combinedDevJSummary: v }),
      setCombinedSigmaSummary: (v) => set({ combinedSigmaSummary: v }),

      /* ===== Selected values ===== */
      setSelectedValuesCL: (v) => set({ selectedValuesCL: v }),
      setSelectedValuesSigma: (v) => set({ selectedValuesSigma: v }),
      setSelectedValuesSD: (v) => set({ selectedValuesSD: v }),
      setSelectedValuesRJPaidToIncurred: (v) => set({ selectedValuesRJPaidToIncurred: v }),
      setSelectedValuesVarJPaidToIncurred: (v) => set({ selectedValuesVarJPaidToIncurred: v }),

      setRemainingDevJHeaders: (headers) => set({ remainingDevJHeaders: headers }),

      /* ===== Left counts ===== */
      setLeftCountSummary: (n) => set({ leftCountSummary: n }),
      setLeftCountCL: (n) => set({ leftCountCL: n }),
      setLeftCountSigma: (n) => set({ leftCountSigma: n }),
      setLeftCountSD: (n) => set({ leftCountSD: n }),

      /* ===== Curve selections ===== */
      setSelectedCurveSummary: (c) => set({ selectedCurveSummary: c }),
      setSelectedCurveSigma: (c) => set({ selectedCurveSigma: c }),
      setSelectedCurveSD: (c) => set({ selectedCurveSD: c }),
      setSelectedCurve: (name) => set({ selectedCurve: name }),

      /* ===== Manual overrides ===== */
      setManualOverridesSummary: (o) => set({ manualOverridesSummary: o }),
      setManualOverridesSigma: (o) => set({ manualOverridesSigma: o }),
      setManualOverridesSD: (o) => set({ manualOverridesSD: o }),

      /* ===== Source switches ===== */
      setSourceSwitchesSummary: (switches) => set({ sourceSwitchesSummary: switches }),
      setSourceSwitchesSigma: (switches) => set({ sourceSwitchesSigma: switches }),
      setSourceSwitchesSD: (switches) => set({ sourceSwitchesSD: switches }),

      /* ===== PaidIncurred Summary ===== */
      setLeftCountRJPaidToIncurred: (n) => set({ leftCountRJPaidToIncurred: n }),
      setSelectedCurveRJPaidToIncurred: (c) => set({ selectedCurveRJPaidToIncurred: c }),
      setManualOverridesRJPaidToIncurred: (o) => set({ manualOverridesRJPaidToIncurred: o }),
      setSourceSwitchesRJPaidToIncurred: (switches) => set({ sourceSwitchesRJPaidToIncurred: switches }),
      setCombinedRJPaidToIncurredSummary: (combined) => set({ combinedRJPaidToIncurredSummary: combined }),
      clearCombinedRJPaidToIncurredSummary: () => set({ combinedRJPaidToIncurredSummary: undefined }),

      setLeftCountVarJPaidToIncurred: (n) => set({ leftCountVarJPaidToIncurred: n }),
      setSelectedCurveVarJPaidToIncurred: (c) => set({ selectedCurveVarJPaidToIncurred: c }),
      setManualOverridesVarJPaidToIncurred: (o) => set({ manualOverridesVarJPaidToIncurred: o }),
      setSourceSwitchesVarJPaidToIncurred: (switches) => set({ sourceSwitchesVarJPaidToIncurred: switches }),
      setCombinedVarJPaidToIncurredSummary: (combined) => set({ combinedVarJPaidToIncurredSummary: combined }),
      clearCombinedVarJPaidToIncurredSummary: () => set({ combinedVarJPaidToIncurredSummary: undefined }),

      /* ===== SD Summary ===== */
      setCombinedSDSummary: (combined) => set({ combinedSDSummary: combined }),
      clearCombinedSDSummary: () => set({ combinedSDSummary: undefined }),

      /* ===== DevJ ===== */
      updateDevJAt: (idx, value) => set(state => {
        const newResults = [...state.devJResults];
        if (newResults[idx]) {
          newResults[idx] = { ...newResults[idx], values: [...newResults[idx].values] };
          // Logika aktualizacji wartości
        }
        return { devJResults: newResults };
      }),

      setSelectedDevJVolume: (v, subIndex) => set({ 
        selectedDevJVolume: v, 
        selectedDevJSubIndex: subIndex 
      }),

      /* ===== Preview ===== */
      setDevPreviewCandidate: (v) => set({ devPreviewCandidate: v }),
      clearDevPreviewCandidate: () => set({ devPreviewCandidate: undefined }),

      /* ===== Config ===== */
      setRetainedCoeffCount: (val) => set({ retainedCoeffCount: val }),

      /* ===== Final vectors ===== */
      setFinalDevVector: (v) => set({ finalDevVector: v }),
      setDevFinalValue: (idx, curve, value) => set(state => ({
        devFinalCustom: { ...state.devFinalCustom, [idx]: { curve, value } }
      })),
      clearDevFinalValue: (idx) => set(state => {
        const { [idx]: removed, ...rest } = state.devFinalCustom;
        return { devFinalCustom: rest };
      }),
      clearAllDevFinalValues: () => set({ devFinalCustom: {} }),

      /* ===== Dane do obliczeń ===== */
      setTrainDevideIncurred: (data) => set({ trainDevideIncurred: data }),
      setSelectedWeightsIncurred: (weights) => set({ selectedWeightsIncurred: weights }),
      setSelectedCellsIncurred: (cells) => set({ selectedCellsIncurred: cells }),
      setSafeWeights: (w) => set({ safeWeights: w }),
      setVolume: (vol) => set({ volume: vol }),

      /* ===== Display settings ===== */
      setDecimalPlaces: (places) => set({ decimalPlaces: places }),

      /* ===== PaidToIncurred setters ===== */
      setTrainPaidToIncurred: (data) => set({ trainPaidToIncurred: data }),
      setSelectedWeightsPaidToIncurred: (weights) => set({ selectedWeightsPaidToIncurred: weights }),
      setSafeWeightsPaidToIncurred: (w) => set({ safeWeightsPaidToIncurred: w }),
      setSelectedCellsPaidToIncurred: (cells) => set({ selectedCellsPaidToIncurred: cells }),
      setVolumePaidToIncurred: (vol) => set({ volumePaidToIncurred: vol }),
      setDevJPaidToIncurred: (d) => set({ devJPaidToIncurred: d }),
      setSigmaPaidToIncurred: (d) => set({ sigmaPaidToIncurred: d }),
      setSdPaidToIncurred: (d) => set({ sdPaidToIncurred: d }),
      
      setRJPaidToIncurred: (d) => set({ rJPaidToIncurred: d }),
      setVarJPaidToIncurred: (d) => set({ varJPaidToIncurred: d }),
      
      setResIJPaidToIncurred: (d) => set({ resIJPaidToIncurred: d }),
      setLambdaJPaidToIncurred: (d) => set({ lambdaJPaidToIncurred: d }),
      setMinMaxHighlightingPaidToIncurred: (enabled) => set({ minMaxHighlightingPaidToIncurred: enabled }),

      /* ===== Current results setters ===== */
      setDevJ: (d) => {
        console.log('🔧 [Store] setDevJ called with:', d);
        console.log('🔧 [Store] Type of d:', typeof d, Array.isArray(d) ? 'array' : 'not array');
        console.log('🔧 [Store] Length:', d?.length);
        set({ devJ: d });
      },
      setSigma: (d) => set({ sigma: d }),
      setSd: (d) => set({ sd: d }),

      /* ===== R2 & SE ===== */
      setR2Scores: (r) => set({ r2Scores: r }),
      clearR2Scores: () => set({ r2Scores: undefined }),
      setSePred: (se) => set({ sePred: se }),
      clearSePred: () => set({ sePred: undefined }),

      /* ===== Results ===== */
      setDevJResults: (results) => set({ devJResults: results }),
      clearDevJResults: () => set({ devJResults: [] }),
      addDevJResult: (vol, values) => set(state => {
        const newResults = [...state.devJResults];
        const existingIndex = newResults.findIndex(r => r.volume === vol);
        if (existingIndex >= 0) {
          newResults[existingIndex] = { volume: vol, values };
        } else {
          newResults.push({ volume: vol, values });
        }
        return { devJResults: newResults };
      }),
      setSigmaResults: (results) => set({ sigmaResults: results }),
      clearSigmaResults: () => set({ sigmaResults: [] }),
      addSigmaResult: (vol, values) => set(state => {
        const newResults = [...state.sigmaResults];
        const existingIndex = newResults.findIndex(r => r.volume === vol);
        if (existingIndex >= 0) {
          newResults[existingIndex] = { volume: vol, values };
        } else {
          newResults.push({ volume: vol, values });
        }
        return { sigmaResults: newResults };
      }),
      setFinalDevJ: (dev) => set({ finalDevJ: dev }),
      setFinalSigma: (sigma) => set({ finalSigma: sigma }),

      /* ===== Reset functions ===== */
      resetIncurredTriangle: () => set({
        incurredTriangle: undefined,
        incurredTriangle_bez_inf: null,
        reserve: null,
        trainDevideIncurred: undefined,
        selectedWeightsIncurred: undefined,
        selectedCellsIncurred: [],
        volume: 0,
      }),

      resetData: () => set({
        workbookIncurred: undefined,
        uploadedFileNameIncurred: undefined,
        selectedSheetNameIncurred: undefined,
        startRowIncurred: 1,
        endRowIncurred: 1,
        startColIncurred: 1,
        endColIncurred: 1,
        selectedSheetIncurred: undefined,
        previousSheetIncurred: undefined,
        isValidIncurred: false,
        validationErrorReasonIncurred: undefined,
        incurredTriangle: undefined,
        incurredTriangle_bez_inf: null,
        reserve: null,
        trainDevideIncurred: undefined,
        selectedWeightsIncurred: undefined,
        selectedCellsIncurred: [],
        volume: 0,
      }),

      /* ===== Volume selection setters ===== */
      setSelectedSigmaVolume: (vol, subIdx) => set({ 
        selectedSigmaVolume: vol, 
        selectedSigmaSubIndex: subIdx 
      }),

      /* ===== Selection and interaction functions ===== */
      toggleRowIncurred: (r) => {
        const state = get();
        const current = state.selectedWeightsIncurred;
        if (!current || !state.trainDevideIncurred) return;
        
        const newWeights = current.map((row, i) => 
          i === r ? row.map(cell => cell === 1 ? 0 : 1) : [...row]
        );
        set({ selectedWeightsIncurred: newWeights });
        
        // Przelicz Min/Max po toggle wiersza
        get().calculateMinMaxCells();
        
        // Przelicz SafeWeights automatycznie
        get().calculateSafeWeights();
      },

      toggleCellIncurred: (r, c) => {
        const state = get();
        const current = state.selectedWeightsIncurred;
        if (!current || !state.trainDevideIncurred) return;
        
        const newWeights = current.map((row, i) => 
          i === r ? row.map((cell, j) => j === c ? (cell === 1 ? 0 : 1) : cell) : [...row]
        );
        set({ selectedWeightsIncurred: newWeights });
      },

      toggleWeightCellIncurred: (r, c) => {
        console.log('🔄 === TOGGLE WEIGHT CELL INCURRED ===');
        console.log(`📍 Kliknięto komórkę [${r}, ${c}]`);
        
        const cur = get().selectedWeightsIncurred;
        if (!cur) {
          console.log('❌ Brak macierzy selectedWeightsIncurred');
          return;
        }

        const oldValue = cur[r]?.[c];
        console.log(`🔢 Stara wartość: ${oldValue}`);

        // Przełącz tylko konkretną komórkę
        const upd = cur.map((row, i) =>
          row.map((cell, j) => (i === r && j === c ? (cell === 1 ? 0 : 1) : cell))
        );
        
        const newValue = upd[r]?.[c];
        console.log(`🔢 Nowa wartość: ${newValue}`);
        console.log('🧮 Nowe statystyki wag:', {
          totalSelected: upd.flat().filter(w => w === 1).length,
          totalUnselected: upd.flat().filter(w => w === 0).length
        });
        console.log('🔄 === END TOGGLE WEIGHT CELL INCURRED ===');
        
        set({ selectedWeightsIncurred: upd });
        
        // Przelicz Min/Max po toggle komórki
        get().calculateMinMaxCells();
        
        // Przelicz SafeWeights automatycznie
        get().calculateSafeWeights();
      },

      resetSelectionIncurred: () => {
        const state = get();
        if (!state.trainDevideIncurred) return;
        
        const newWeights = state.trainDevideIncurred.map(row => 
          row.map(() => 1)
        );
        set({ selectedWeightsIncurred: newWeights });
        
        // Przelicz Min/Max po reset
        get().calculateMinMaxCells();
        
        // Przelicz SafeWeights automatycznie
        get().calculateSafeWeights();
      },

      /* ===== Min/Max highlighting ===== */
      setMinMaxHighlighting: (enabled) => {
        set({ minMaxHighlighting: enabled });
        if (enabled) get().calculateMinMaxCells();
      },

      calculateMinMaxCells: () => {
        const trainData = get().trainDevideIncurred;
        const weights = get().selectedWeightsIncurred;
        if (!trainData || !weights || trainData.length === 0) return;

        console.log('🔢 calculateMinMaxCells INCURRED started', { 
          trainDataRows: trainData.length, 
          trainDataCols: trainData[0]?.length,
          weightsRows: weights.length, 
          weightsCols: weights[0]?.length 
        });

        const minMaxCells: [number, number][] = [];
        const minCells: [number, number][] = [];
        const maxCells: [number, number][] = [];
        
        // Dla każdej kolumny znajdź min/max spośród zaznaczonych komórek
        const numCols = trainData[0]?.length || 0;
        
        for (let col = 0; col < numCols; col++) {
          const selectedValues: { value: number; row: number }[] = [];
          
          for (let row = 0; row < trainData.length; row++) {
            const cellValue = trainData[row]?.[col];
            const isSelected = weights[row]?.[col] === 1;
            
            if (isSelected && cellValue != null && typeof cellValue === 'number') {
              selectedValues.push({ 
                value: cellValue, 
                row 
              });
            }
          }
          
          console.log(`📊 INCURRED Kolumna ${col}:`, {
            selectedCount: selectedValues.length,
            values: selectedValues.map(v => `[${v.row}] = ${v.value}`)
          });
          
          if (selectedValues.length > 1) {
            const minItem = selectedValues.reduce((min, curr) => 
              curr.value < min.value ? curr : min
            );
            const maxItem = selectedValues.reduce((max, curr) => 
              curr.value > max.value ? curr : max
            );
            
            // +1 bo w TableDataDet mamy nagłówki!
            minCells.push([minItem.row + 1, col + 1]);
            maxCells.push([maxItem.row + 1, col + 1]);
            minMaxCells.push([minItem.row + 1, col + 1]);
            if (minItem.row !== maxItem.row) {
              minMaxCells.push([maxItem.row + 1, col + 1]);
            }
            
            console.log(`✅ INCURRED Kolumna ${col} - Min: [${minItem.row}]=${minItem.value}, Max: [${maxItem.row}]=${maxItem.value}`);
          } else {
            console.log(`⚠️ INCURRED Kolumna ${col} - za mało wybranych wartości (${selectedValues.length})`);
          }
        }
        
        console.log('🎯 calculateMinMaxCells INCURRED RESULT:', { 
          minCells: minCells.length, 
          maxCells: maxCells.length,
          minCellsData: minCells,
          maxCellsData: maxCells
        });
        set({ minMaxCells, minCells, maxCells });
      },

      /* ===== Safe weights calculation ===== */
      setSafeWeights: (w) => set({ safeWeights: w }),
      
      calculateSafeWeights: () => {
        const { trainDevideIncurred, selectedWeightsIncurred } = get();
        
        if (!trainDevideIncurred || !selectedWeightsIncurred) {
          set({ safeWeights: undefined });
          return;
        }

        // Odtwórz safeWeights tak jak w usePaidCL (bez ostatniego wiersza)
        const trainMatrix = trainDevideIncurred.slice(0, -1);
        const safeWeights = trainMatrix.map((row, rowIndex) => 
          row.map((cell, colIndex) => {
            // Jeśli komórka ma NaN/null/undefined - waga = 0 (nie ma danych)
            if (cell === null || cell === undefined || isNaN(cell)) return 0;
            
            // Jeśli komórka ma liczbę - użyj wagi z selectedWeightsIncurred
            const originalWeight = selectedWeightsIncurred?.[rowIndex]?.[colIndex];
            return originalWeight === 1 ? 1 : 0;
          })
        );

        set({ safeWeights });
        console.log('🟦 === SAFEWEIGHTS AUTOMATYCZNE (INCURRED) ===');
        safeWeights.forEach((row, i) => {
          console.log(`Wiersz ${i}:`, row);
        });
        
        console.log('📊 Statystyki safeWeights automatyczne (incurred):', {
          rows: safeWeights.length,
          cols: safeWeights[0]?.length || 0,
          totalSelected: safeWeights.flat().filter(w => w === 1).length,
          totalZeros: safeWeights.flat().filter(w => w === 0).length,
          source: 'AUTO_INCURRED'
        });
      },

      /* ===== FitCurve functions for Incurred ===== */
      // TailCounts
      setTailCountCL: (n) => set({ tailCountCL: n }),
      setTailCountSigma: (n) => set({ tailCountSigma: n }),

      // Dev J FitCurve
      setDevJPreview: (data) => set({ devJPreview: data }),
      setDevPreviewCandidate: (data) => set({ devPreviewCandidate: data }),
      setSelectedDevJIndexes: (indexes) => set({ selectedDevJIndexes: indexes }),
      
      // Sigma FitCurve
      setSigmaPreview: (data) => set({ sigmaPreview: data }),
      setSigmaPreviewCandidate: (data) => set({ sigmaPreviewCandidate: data }),
      setSelectedSigmaIndexes: (indexes) => set({ selectedSigmaIndexes: indexes }),
      
      // Simulation Results
      setSimResults: (data) => set({ simResults: data }),
      clearSimResults: () => set({ simResults: undefined }),
      setSimResultsSigma: (data) => set({ simResultsSigma: data }),
      clearSimResultsSigma: () => set({ simResultsSigma: undefined }),
      
      // R2 Scores
      setR2Scores: (data) => set({ r2Scores: data }),
      clearR2Scores: () => set({ r2Scores: undefined }),
      setR2ScoresSigma: (data) => set({ r2ScoresSigma: data }),
      clearR2ScoresSigma: () => set({ r2ScoresSigma: undefined }),

      /* ===== FitCurve functions implementation for PaidToIncurred ===== */
      setTailCountRJPaidToIncurred: (n) => set({ tailCountRJPaidToIncurred: n }),
      setTailCountVarJPaidToIncurred: (n) => set({ tailCountVarJPaidToIncurred: n }),
      
      setRJPaidToIncurredPreview: (data) => set({ rJPaidToIncurredPreview: data }),
      setRJPaidToIncurredPreviewCandidate: (data) => set({ rJPaidToIncurredPreviewCandidate: data }),
      setSelectedRJPaidToIncurredIndexes: (indexes) => set({ selectedRJPaidToIncurredIndexes: indexes }),
      
      setVarJPaidToIncurredPreview: (data) => set({ varJPaidToIncurredPreview: data }),
      setVarJPaidToIncurredPreviewCandidate: (data) => set({ varJPaidToIncurredPreviewCandidate: data }),
      setSelectedVarJPaidToIncurredIndexes: (indexes) => set({ selectedVarJPaidToIncurredIndexes: indexes }),
      
      setSimResultsRJPaidToIncurred: (data) => set({ simResultsRJPaidToIncurred: data }),
      clearSimResultsRJPaidToIncurred: () => set({ simResultsRJPaidToIncurred: undefined }),
      setSimResultsVarJPaidToIncurred: (data) => set({ simResultsVarJPaidToIncurred: data }),
      clearSimResultsVarJPaidToIncurred: () => set({ simResultsVarJPaidToIncurred: undefined }),
      
      setR2ScoresRJPaidToIncurred: (data) => set({ r2ScoresRJPaidToIncurred: data }),
      clearR2ScoresRJPaidToIncurred: () => set({ r2ScoresRJPaidToIncurred: undefined }),
      setR2ScoresVarJPaidToIncurred: (data) => set({ r2ScoresVarJPaidToIncurred: data }),
      clearR2ScoresVarJPaidToIncurred: () => set({ r2ScoresVarJPaidToIncurred: undefined }),

      /* ===== Funkcja czyszcząca dane FitCurve PaidToIncurred ===== */
      clearPaidToIncurredFitCurveData: () => set({
        // Preview i candidates
        rJPaidToIncurredPreview: undefined,
        rJPaidToIncurredPreviewCandidate: undefined,
        varJPaidToIncurredPreview: undefined,
        varJPaidToIncurredPreviewCandidate: undefined,
        
        // Selected indexes
        selectedRJPaidToIncurredIndexes: [],
        selectedVarJPaidToIncurredIndexes: [],
        
        // Simulation results
        simResultsRJPaidToIncurred: undefined,
        simResultsVarJPaidToIncurred: undefined,
        
        // R2 scores
        r2ScoresRJPaidToIncurred: undefined,
        r2ScoresVarJPaidToIncurred: undefined,
        
        // Tail counts
        tailCountRJPaidToIncurred: "",
        tailCountVarJPaidToIncurred: "",
        
        // Final custom
        rJPaidToIncurredFinalCustom: {},
        varJPaidToIncurredFinalCustom: {},
      }),

      /* ===== Funkcje czyszczące ===== */
      clearFitCurveData: () => set({
        devPreviewCandidate: undefined,
        r2Scores: undefined,
        sePred: undefined,
      }),

      clearDevSummaryData: () => set({
        combinedDevJSummary: [],
        combinedSigmaSummary: [],
        combinedSDSummary: undefined,
        selectedValuesCL: [],
        selectedValuesSigma: [],
        selectedValuesSD: [],
      }),

      /* ===== PaidToIncurred functions ===== */
      
      toggleRowPaidToIncurred: (r) => {
        console.log('🔄 === TOGGLE ROW PAID TO INCURRED ===');
        console.log(`📍 Kliknięto wiersz ${r}`);
        
        const state = get();
        const current = state.selectedWeightsPaidToIncurred;
        if (!current || !state.trainPaidToIncurred) {
          console.log('❌ Brak danych do toggle row');
          return;
        }
        
        const newWeights = current.map((row, i) => 
          i === r ? row.map(cell => cell === 1 ? 0 : 1) : [...row]
        );
        
        console.log(`🔢 Wiersz ${r} po przełączeniu:`, newWeights[r]);
        console.log('🔄 === END TOGGLE ROW PAID TO INCURRED ===');
        
        set({ selectedWeightsPaidToIncurred: newWeights });
      },

      toggleCellPaidToIncurred: (r, c) => {
        console.log('🔄 === TOGGLE CELL PAID TO INCURRED ===');
        console.log(`📍 Kliknięto komórkę [${r}, ${c}]`);
        
        const state = get();
        const current = state.selectedWeightsPaidToIncurred;
        if (!current || !state.trainPaidToIncurred) {
          console.log('❌ Brak danych do toggle cell');
          return;
        }
        
        const oldValue = current[r]?.[c];
        const newWeights = current.map((row, i) => 
          i === r ? row.map((cell, j) => j === c ? (cell === 1 ? 0 : 1) : cell) : [...row]
        );
        const newValue = newWeights[r]?.[c];
        
        console.log(`🔢 Wartość [${r}, ${c}]: ${oldValue} -> ${newValue}`);
        console.log('🔄 === END TOGGLE CELL PAID TO INCURRED ===');
        
        set({ selectedWeightsPaidToIncurred: newWeights });
      },

      toggleWeightCellPaidToIncurred: (r, c) => {
        console.log('🔄 === TOGGLE WEIGHT CELL PAID TO INCURRED ===');
        console.log(`📍 Kliknięto komórkę [${r}, ${c}]`);
        
        const cur = get().selectedWeightsPaidToIncurred;
        if (!cur) {
          console.log('❌ Brak macierzy selectedWeightsPaidToIncurred');
          return;
        }

        const oldValue = cur[r]?.[c];
        console.log(`🔢 Stara wartość: ${oldValue}`);

        // Przełącz tylko konkretną komórkę
        const upd = cur.map((row, i) =>
          row.map((cell, j) => (i === r && j === c ? (cell === 1 ? 0 : 1) : cell))
        );
        
        const newValue = upd[r]?.[c];
        console.log(`🔢 Nowa wartość: ${newValue}`);
        console.log('🧮 Nowe statystyki wag:', {
          totalSelected: upd.flat().filter(w => w === 1).length,
          totalUnselected: upd.flat().filter(w => w === 0).length
        });
        console.log('🔄 === END TOGGLE WEIGHT CELL PAID TO INCURRED ===');
        
        set({ selectedWeightsPaidToIncurred: upd });
      },

      resetSelectionPaidToIncurred: () => {
        console.log('🔄 === RESET SELECTION PAID TO INCURRED ===');
        
        const state = get();
        if (!state.trainPaidToIncurred) {
          console.log('❌ Brak trainPaidToIncurred do reset');
          return;
        }
        
        const newWeights = state.trainPaidToIncurred.map(row => 
          row.map((cell) => {
            // Jeśli komórka jest null/undefined/pusty string/NaN - waga = 0
            if (cell === null || cell === undefined || cell === "" || isNaN(Number(cell))) {
              return 0;
            }
            // Jeśli ma prawidłową wartość - waga = 1
            return 1;
          })
        );
        
        const stats = {
          rows: newWeights.length,
          cols: newWeights[0]?.length || 0,
          totalSelected: newWeights.flat().filter(w => w === 1).length,
          totalUnselected: newWeights.flat().filter(w => w === 0).length,
        };
        
        console.log('✅ Reset selection z automatycznym zerowaniem pustych komórek');
        console.log('🔢 Nowe wymiary wag:', stats);
        console.log('📊 Szczegółowa analiza pustych komórek:');
        state.trainPaidToIncurred.forEach((row, i) => {
          row.forEach((cell, j) => {
            if (cell === null || cell === undefined || cell === "" || isNaN(Number(cell))) {
              console.log(`  Komórka [${i}, ${j}] jest pusta: "${cell}" -> waga = 0`);
            }
          });
        });
        console.log('🔄 === END RESET SELECTION PAID TO INCURRED ===');
        
        set({ selectedWeightsPaidToIncurred: newWeights });
      },

      // Min/Max highlighting dla PaidToIncurred
      setMinMaxHighlightingPaidToIncurred: (enabled) => {
        set({ minMaxHighlightingPaidToIncurred: enabled });
      },

    }),
    {
      name: 'incurred-store',
      partialize: (state) => ({
        // Zachowaj tylko PaidToIncurred FitCurve data i ważne ustawienia
        rJPaidToIncurredPreview: state.rJPaidToIncurredPreview,
        rJPaidToIncurredPreviewCandidate: state.rJPaidToIncurredPreviewCandidate,
        selectedRJPaidToIncurredIndexes: state.selectedRJPaidToIncurredIndexes,
        varJPaidToIncurredPreview: state.varJPaidToIncurredPreview,
        varJPaidToIncurredPreviewCandidate: state.varJPaidToIncurredPreviewCandidate,
        selectedVarJPaidToIncurredIndexes: state.selectedVarJPaidToIncurredIndexes,
        
        // FitCurve simulation results
        simResultsRJPaidToIncurred: state.simResultsRJPaidToIncurred,
        simResultsVarJPaidToIncurred: state.simResultsVarJPaidToIncurred,
        r2ScoresRJPaidToIncurred: state.r2ScoresRJPaidToIncurred,
        r2ScoresVarJPaidToIncurred: state.r2ScoresVarJPaidToIncurred,
        
        // Tail counts
        tailCountRJPaidToIncurred: state.tailCountRJPaidToIncurred,
        tailCountVarJPaidToIncurred: state.tailCountVarJPaidToIncurred,
        
        // Final custom values
        rJPaidToIncurredFinalCustom: state.rJPaidToIncurredFinalCustom,
        varJPaidToIncurredFinalCustom: state.varJPaidToIncurredFinalCustom,
        
        // Summary states for PaidIncurred
        leftCountRJPaidToIncurred: state.leftCountRJPaidToIncurred,
        selectedCurveRJPaidToIncurred: state.selectedCurveRJPaidToIncurred,
        manualOverridesRJPaidToIncurred: state.manualOverridesRJPaidToIncurred,
        sourceSwitchesRJPaidToIncurred: state.sourceSwitchesRJPaidToIncurred,
        combinedRJPaidToIncurredSummary: state.combinedRJPaidToIncurredSummary,
        
        leftCountVarJPaidToIncurred: state.leftCountVarJPaidToIncurred,
        selectedCurveVarJPaidToIncurred: state.selectedCurveVarJPaidToIncurred,
        manualOverridesVarJPaidToIncurred: state.manualOverridesVarJPaidToIncurred,
        sourceSwitchesVarJPaidToIncurred: state.sourceSwitchesVarJPaidToIncurred,
        combinedVarJPaidToIncurredSummary: state.combinedVarJPaidToIncurredSummary,
        
        // Podstawowe dane z calculation
        rJPaidToIncurred: state.rJPaidToIncurred,
        varJPaidToIncurred: state.varJPaidToIncurred,
        resIJPaidToIncurred: state.resIJPaidToIncurred,
        lambdaJPaidToIncurred: state.lambdaJPaidToIncurred,
        
        // Display settings
        decimalPlaces: state.decimalPlaces,
      }),
      storage: createJSONStorage(() => sessionStorage), // Używa sessionStorage
    }
  )
);