import { create } from 'zustand';

// Typy dla Exposure store
export interface ExposureTriangleData {
  [rowIndex: number]: {
    [colIndex: number]: number | null;
  };
}

export interface ExposureStore {
  // Dane trójkąta ekspozycji
  exposureTriangle: ExposureTriangleData;
  
  // Oryginalne dane exposure (bez inflacji) - używane do obliczeń inflacji
  originalExposureTriangle: ExposureTriangleData;
  
  // Wybór linii ekspozycji
  selectedExposureLine: number | null;
  availableExposureLines: { index: number; label: string; values: (number | null)[] }[];
  
  // Metadane
  selectedSheetName: string;
  uploadedFileName: string;
  
  // Ustawienia wyświetlania
  decimalPlaces: number;
  
  // Wynik inflacji
  inflationResult: (number | null)[] | null;
  
  // Akcje
  setExposureTriangle: (triangle: ExposureTriangleData) => void;
  setOriginalExposureTriangle: (triangle: ExposureTriangleData) => void;
  setInflationResult: (result: (number | null)[] | null) => void;
  setSelectedExposureLine: (lineIndex: number | null) => void;
  updateAvailableExposureLines: () => void;
  setSelectedSheetName: (name: string) => void;
  setUploadedFileName: (name: string) => void;
  setDecimalPlaces: (places: number) => void;
  resetData: () => void;
}

const initialState = {
  exposureTriangle: {},
  originalExposureTriangle: {},
  selectedExposureLine: null,
  availableExposureLines: [],
  selectedSheetName: '',
  uploadedFileName: '',
  decimalPlaces: 2,
  inflationResult: null,
};

// Usuń stare dane z sessionStorage i localStorage przy inicjalizacji
if (typeof window !== 'undefined') {
  sessionStorage.removeItem('exposure-store');
  localStorage.removeItem('exposure-store');
}

export const useExposureStore = create<ExposureStore>()((set, get) => ({
  ...initialState,
  
  setExposureTriangle: (triangle) => {
    set({ exposureTriangle: triangle });
    // Automatycznie przygotuj dostępne linie
    get().updateAvailableExposureLines();
  },
  
  setOriginalExposureTriangle: (triangle) => set({ originalExposureTriangle: triangle }),
  
  setSelectedExposureLine: (lineIndex) => set({ selectedExposureLine: lineIndex }),
  
  updateAvailableExposureLines: () => {
    const triangle = get().exposureTriangle;
    const lines: { index: number; label: string; values: (number | null)[] }[] = [];
    
    // Iteruj przez wiersze trójkąta
    Object.keys(triangle).forEach(rowIndexStr => {
      const rowIndex = parseInt(rowIndexStr);
      const row = triangle[rowIndex];
      if (!row) return;
      
      // Pobierz label z pierwszej kolumny (kolumna 0)
      const labelValue = row[0];
      const label = labelValue !== null && labelValue !== undefined ? String(labelValue) : `Wiersz ${rowIndex + 1}`;
      
      // Pobierz wartości ze WSZYSTKICH kolumn OPRÓCZ kolumny 0 (etykiety)
      const values: (number | null)[] = [];
      const colKeys = Object.keys(row).map(Number).sort((a, b) => a - b);
      for (const colIndex of colKeys) {
        if (colIndex !== 0) { // Pomijamy TYLKO kolumnę 0 (etykiety), bierzemy wszystkie inne
          values.push(row[colIndex] ?? null);
        }
      }
      
      // Dodaj linię tylko jeśli ma jakieś wartości
      if (values.some(v => v !== null)) {
        lines.push({
          index: rowIndex,
          label,
          values
        });
      }
    });
    
    console.log('🔍 updateAvailableExposureLines result:', lines);
    set({ availableExposureLines: lines });
  },
  
  setSelectedSheetName: (name) => set({ selectedSheetName: name }),
  setUploadedFileName: (name) => set({ uploadedFileName: name }),
  setDecimalPlaces: (places) => set({ decimalPlaces: places }),
  setInflationResult: (result) => set({ inflationResult: result }),
  
  resetData: () => set(initialState),
}));