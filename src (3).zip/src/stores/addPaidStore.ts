import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// Typy dla AddPaid store - teraz tylko dla paid triangle data
export interface AddPaidTriangleData {
  [rowIndex: number]: {
    [colIndex: number]: number | null;
  };
}

export interface AddPaidStore {
  // Metadane pliku
  selectedSheetName: string;
  uploadedFileName: string;
  
  // Ustawienia wyświetlania
  decimalPlaces: number;
  
  // FitCurve Add J pola
  selectedAddJIndexes: number[];
  addJPreview: number[] | null;
  addJPreviewCandidate: number[] | null;
  simResultsAddJ: any;
  r2ScoresAddJ: any;
  tailCountAddJ: number;
  addJFinalCustom: number[] | null;
  finalAddJ: number[] | null;
  
  // FitCurve Sigma LR pola
  selectedSigmaLRIndexes: number[];
  sigmaLRPreview: number[] | null;
  sigmaLRPreviewCandidate: number[] | null;
  simResultsSigmaLR: any;
  r2ScoresSigmaLR: any;
  tailCountSigmaLR: number;
  sigmaLRFinalCustom: number[] | null;
  finalSigmaLR: number[] | null;
  
  // FitCurve SD LR pola
  selectedSdLRIndexes: number[];
  sdLRPreview: number[] | null;
  sdLRPreviewCandidate: number[] | null;
  simResultsSdLR: any;
  r2ScoresSdLR: any;
  tailCountSdLR: number;
  sdLRFinalCustom: number[] | null;
  finalSdLR: number[] | null;
  
  // Bazowe dane (to będzie wypełnione z innych zakładek)
  addJ: number[] | null;
  sigmaLR: number[] | null;
  sdLR: number[] | null;
  
  // Akcje
  setSelectedSheetName: (name: string) => void;
  setUploadedFileName: (name: string) => void;
  setDecimalPlaces: (places: number) => void;
  
  // FitCurve Add J akcje
  setSelectedAddJIndexes: (indexes: number[]) => void;
  setAddJPreview: (data: number[] | null) => void;
  setAddJPreviewCandidate: (data: number[] | null) => void;
  setSimResultsAddJ: (data: any) => void;
  setR2ScoresAddJ: (data: any) => void;
  setTailCountAddJ: (count: number) => void;
  setAddJFinalCustom: (data: number[] | null) => void;
  setFinalAddJ: (data: number[] | null) => void;
  clearSimResultsAddJ: () => void;
  clearR2ScoresAddJ: () => void;
  
  // FitCurve Sigma LR akcje
  setSelectedSigmaLRIndexes: (indexes: number[]) => void;
  setSigmaLRPreview: (data: number[] | null) => void;
  setSigmaLRPreviewCandidate: (data: number[] | null) => void;
  setSimResultsSigmaLR: (data: any) => void;
  setR2ScoresSigmaLR: (data: any) => void;
  setTailCountSigmaLR: (count: number) => void;
  setSigmaLRFinalCustom: (data: number[] | null) => void;
  setFinalSigmaLR: (data: number[] | null) => void;
  clearSimResultsSigmaLR: () => void;
  clearR2ScoresSigmaLR: () => void;
  
  // FitCurve SD LR akcje
  setSelectedSdLRIndexes: (indexes: number[]) => void;
  setSdLRPreview: (data: number[] | null) => void;
  setSdLRPreviewCandidate: (data: number[] | null) => void;
  setSimResultsSdLR: (data: any) => void;
  setR2ScoresSdLR: (data: any) => void;
  setTailCountSdLR: (count: number) => void;
  setSdLRFinalCustom: (data: number[] | null) => void;
  setFinalSdLR: (data: number[] | null) => void;
  clearSimResultsSdLR: () => void;
  clearR2ScoresSdLR: () => void;
  
  // Bazowe dane akcje
  setAddJ: (data: number[] | null) => void;
  setSigmaLR: (data: number[] | null) => void;
  setSdLR: (data: number[] | null) => void;
  
  // Selected Values (analogiczne do MultPaid)
  selectedValuesAddLR: number[];
  setSelectedValuesAddLR: (v: number[]) => void;
  selectedValuesAddSigma: number[];
  setSelectedValuesAddSigma: (v: number[]) => void;
  selectedValuesAddSD: number[];
  setSelectedValuesAddSD: (v: number[]) => void;
  
  // Summary - LR (Add) pola
  leftCountAddLR: number;
  selectedCurveAddLR: string | null;
  manualOverridesAddLR: Record<number, { curve: string; value: number }>;
  sourceSwitchesAddLR: Record<number, { curve: string; value: number }>;
  combinedAddLRSummary: (number | string)[];
  
  // Summary - Sigma LR pola
  leftCountAddSigma: number;
  selectedCurveAddSigma: string | null;
  manualOverridesAddSigma: Record<number, { curve: string; value: number }>;
  sourceSwitchesAddSigma: Record<number, { curve: string; value: number }>;
  combinedAddSigmaSummary: (number | string)[];
  
  // Summary - SD LR pola
  leftCountAddSD: number;
  selectedCurveAddSD: string | null;
  manualOverridesAddSD: Record<number, { curve: string; value: number }>;
  sourceSwitchesAddSD: Record<number, { curve: string; value: number }>;
  combinedAddSDSummary: (number | string)[];
  
  // Summary akcje - LR (Add)
  setLeftCountAddLR: (n: number) => void;
  setSelectedCurveAddLR: (c: string | null) => void;
  setManualOverridesAddLR: (o: Record<number, { curve: string; value: number }>) => void;
  setSourceSwitchesAddLR: (s: Record<number, { curve: string; value: number }>) => void;
  setCombinedAddLRSummary: (data: (number | string)[]) => void;
  
  // Summary akcje - Sigma LR
  setLeftCountAddSigma: (n: number) => void;
  setSelectedCurveAddSigma: (c: string | null) => void;
  setManualOverridesAddSigma: (o: Record<number, { curve: string; value: number }>) => void;
  setSourceSwitchesAddSigma: (s: Record<number, { curve: string; value: number }>) => void;
  setCombinedAddSigmaSummary: (data: (number | string)[]) => void;
  
  // Summary akcje - SD LR
  setLeftCountAddSD: (n: number) => void;
  setSelectedCurveAddSD: (c: string | null) => void;
  setManualOverridesAddSD: (o: Record<number, { curve: string; value: number }>) => void;
  setSourceSwitchesAddSD: (s: Record<number, { curve: string; value: number }>) => void;
  setCombinedAddSDSummary: (data: (number | string)[]) => void;
  
  resetData: () => void;
}

const initialState = {
  selectedSheetName: '',
  uploadedFileName: '',
  decimalPlaces: 2,
  
  // FitCurve Add J
  selectedAddJIndexes: [],
  addJPreview: null,
  addJPreviewCandidate: null,
  simResultsAddJ: null,
  r2ScoresAddJ: null,
  tailCountAddJ: 0,
  addJFinalCustom: null,
  finalAddJ: null,
  
  // FitCurve Sigma LR
  selectedSigmaLRIndexes: [],
  sigmaLRPreview: null,
  sigmaLRPreviewCandidate: null,
  simResultsSigmaLR: null,
  r2ScoresSigmaLR: null,
  tailCountSigmaLR: 0,
  sigmaLRFinalCustom: null,
  finalSigmaLR: null,
  
  // FitCurve SD LR
  selectedSdLRIndexes: [],
  sdLRPreview: null,
  sdLRPreviewCandidate: null,
  simResultsSdLR: null,
  r2ScoresSdLR: null,
  tailCountSdLR: 0,
  sdLRFinalCustom: null,
  finalSdLR: null,
  
  // Bazowe dane
  addJ: null,
  sigmaLR: null,
  sdLR: null,
  
  // Selected Values (analogiczne do MultPaid)
  selectedValuesAddLR: [],
  selectedValuesAddSigma: [],
  selectedValuesAddSD: [],
  
  // Summary - LR (Add)
  leftCountAddLR: 0,
  selectedCurveAddLR: null,
  manualOverridesAddLR: {},
  sourceSwitchesAddLR: {},
  combinedAddLRSummary: [],
  
  // Summary - Sigma LR
  leftCountAddSigma: 0,
  selectedCurveAddSigma: null,
  manualOverridesAddSigma: {},
  sourceSwitchesAddSigma: {},
  combinedAddSigmaSummary: [],
  
  // Summary - SD LR
  leftCountAddSD: 0,
  selectedCurveAddSD: null,
  manualOverridesAddSD: {},
  sourceSwitchesAddSD: {},
  combinedAddSDSummary: [],
};

export const useAddPaidStore = create<AddPaidStore>()(
  persist(
    (set, get) => ({
      ...initialState,
      
      setSelectedSheetName: (name) => set({ selectedSheetName: name }),
      setUploadedFileName: (name) => set({ uploadedFileName: name }),
      setDecimalPlaces: (places) => set({ decimalPlaces: places }),
      
      // FitCurve Add J akcje
      setSelectedAddJIndexes: (indexes) => set({ selectedAddJIndexes: indexes }),
      setAddJPreview: (data) => set({ addJPreview: data }),
      setAddJPreviewCandidate: (data) => set({ addJPreviewCandidate: data }),
      setSimResultsAddJ: (data) => set({ simResultsAddJ: data }),
      setR2ScoresAddJ: (data) => set({ r2ScoresAddJ: data }),
      setTailCountAddJ: (count) => set({ tailCountAddJ: count }),
      setAddJFinalCustom: (data) => set({ addJFinalCustom: data }),
      setFinalAddJ: (data) => set({ finalAddJ: data }),
      clearSimResultsAddJ: () => set({ simResultsAddJ: null }),
      clearR2ScoresAddJ: () => set({ r2ScoresAddJ: null }),
      
      // FitCurve Sigma LR akcje
      setSelectedSigmaLRIndexes: (indexes) => set({ selectedSigmaLRIndexes: indexes }),
      setSigmaLRPreview: (data) => set({ sigmaLRPreview: data }),
      setSigmaLRPreviewCandidate: (data) => set({ sigmaLRPreviewCandidate: data }),
      setSimResultsSigmaLR: (data) => set({ simResultsSigmaLR: data }),
      setR2ScoresSigmaLR: (data) => set({ r2ScoresSigmaLR: data }),
      setTailCountSigmaLR: (count) => set({ tailCountSigmaLR: count }),
      setSigmaLRFinalCustom: (data) => set({ sigmaLRFinalCustom: data }),
      setFinalSigmaLR: (data) => set({ finalSigmaLR: data }),
      clearSimResultsSigmaLR: () => set({ simResultsSigmaLR: null }),
      clearR2ScoresSigmaLR: () => set({ r2ScoresSigmaLR: null }),
      
      // FitCurve SD LR akcje
      setSelectedSdLRIndexes: (indexes) => set({ selectedSdLRIndexes: indexes }),
      setSdLRPreview: (data) => set({ sdLRPreview: data }),
      setSdLRPreviewCandidate: (data) => set({ sdLRPreviewCandidate: data }),
      setSimResultsSdLR: (data) => set({ simResultsSdLR: data }),
      setR2ScoresSdLR: (data) => set({ r2ScoresSdLR: data }),
      setTailCountSdLR: (count) => set({ tailCountSdLR: count }),
      setSdLRFinalCustom: (data) => set({ sdLRFinalCustom: data }),
      setFinalSdLR: (data) => set({ finalSdLR: data }),
      clearSimResultsSdLR: () => set({ simResultsSdLR: null }),
      clearR2ScoresSdLR: () => set({ r2ScoresSdLR: null }),
      
      // Bazowe dane akcje
      setAddJ: (data) => set({ addJ: data }),
      setSigmaLR: (data) => set({ sigmaLR: data }),
      setSdLR: (data) => set({ sdLR: data }),
      
      // Selected Values akcje (analogiczne do MultPaid)
      setSelectedValuesAddLR: (v) => {
        console.log('🏪 AddPaid STORE - setSelectedValuesAddLR called:', v)
        set({ selectedValuesAddLR: [...v] })
      },
      setSelectedValuesAddSigma: (v) => {
        console.log('🏪 AddPaid STORE - setSelectedValuesAddSigma called:', v)
        set({ selectedValuesAddSigma: [...v] })
      },
      setSelectedValuesAddSD: (v) => {
        console.log('🏪 AddPaid STORE - setSelectedValuesAddSD called:', v)
        set({ selectedValuesAddSD: [...v] })
      },
      
      // Summary akcje - LR (Add)
      setLeftCountAddLR: (n) => set({ leftCountAddLR: n }),
      setSelectedCurveAddLR: (c) => set({ selectedCurveAddLR: c }),
      setManualOverridesAddLR: (o) => set({ manualOverridesAddLR: { ...o } }),
      setSourceSwitchesAddLR: (s) => set({ sourceSwitchesAddLR: { ...s } }),
      setCombinedAddLRSummary: (data) => set({ combinedAddLRSummary: [...data] }),
      
      // Summary akcje - Sigma LR
      setLeftCountAddSigma: (n) => set({ leftCountAddSigma: n }),
      setSelectedCurveAddSigma: (c) => set({ selectedCurveAddSigma: c }),
      setManualOverridesAddSigma: (o) => set({ manualOverridesAddSigma: { ...o } }),
      setSourceSwitchesAddSigma: (s) => set({ sourceSwitchesAddSigma: { ...s } }),
      setCombinedAddSigmaSummary: (data) => set({ combinedAddSigmaSummary: [...data] }),
      
      // Summary akcje - SD LR
      setLeftCountAddSD: (n) => set({ leftCountAddSD: n }),
      setSelectedCurveAddSD: (c) => set({ selectedCurveAddSD: c }),
      setManualOverridesAddSD: (o) => set({ manualOverridesAddSD: { ...o } }),
      setSourceSwitchesAddSD: (s) => set({ sourceSwitchesAddSD: { ...s } }),
      setCombinedAddSDSummary: (data) => set({ combinedAddSDSummary: [...data] }),
      
      resetData: () => set(initialState),
    }),
    {
      name: 'addpaid-store',
      partialize: (state) => ({
        selectedSheetName: state.selectedSheetName,
        uploadedFileName: state.uploadedFileName,
        decimalPlaces: state.decimalPlaces,
        selectedAddJIndexes: state.selectedAddJIndexes,
        selectedSigmaLRIndexes: state.selectedSigmaLRIndexes,
        selectedSdLRIndexes: state.selectedSdLRIndexes,
        tailCountAddJ: state.tailCountAddJ,
        tailCountSigmaLR: state.tailCountSigmaLR,
        tailCountSdLR: state.tailCountSdLR,
        addJ: state.addJ,
        sigmaLR: state.sigmaLR,
        sdLR: state.sdLR,
        finalAddJ: state.finalAddJ,
        finalSigmaLR: state.finalSigmaLR,
        finalSdLR: state.finalSdLR,
      }),
      storage: {
        getItem: (n) => {
          const i = sessionStorage.getItem(n);
          return i ? JSON.parse(i) : null;
        },
        setItem: (n, v) => sessionStorage.setItem(n, JSON.stringify(v)),
        removeItem: (n) => sessionStorage.removeItem(n),
      },
    }
  )
);