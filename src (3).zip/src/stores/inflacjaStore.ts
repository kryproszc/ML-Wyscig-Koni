import { create } from 'zustand';

// Typy dla Parametry Inflacji store
export interface InflacjaTriangleData {
  [rowIndex: number]: {
    [colIndex: number]: number | string | null;  // Dodaj string dla labeli
  };
}

export interface InflacjaStore {
  // Dane trójkąta parametrów inflacji
  inflacjaTriangle: InflacjaTriangleData;
  
  // Wybór linii parametrów inflacji
  selectedInflacjaLine: number | null;
  availableInflacjaLines: { index: number; label: string; values: (number | null)[] }[];
  
  // Metadane
  selectedSheetName: string;
  uploadedFileName: string;
  
  // Ustawienia wyświetlania
  decimalPlaces: number;
  
  // Akcje
  setInflacjaTriangle: (triangle: InflacjaTriangleData) => void;
  setSelectedInflacjaLine: (lineIndex: number | null) => void;
  updateAvailableInflacjaLines: () => void;
  setSelectedSheetName: (name: string) => void;
  setUploadedFileName: (name: string) => void;
  setDecimalPlaces: (places: number) => void;
  resetData: () => void;
}

const initialState = {
  inflacjaTriangle: {},
  selectedInflacjaLine: null,
  availableInflacjaLines: [],
  selectedSheetName: '',
  uploadedFileName: '',
  decimalPlaces: 2,
};

// Usuń stare dane z localStorage przy inicjalizacji
if (typeof window !== 'undefined') {
  localStorage.removeItem('inflacja-store');
}

export const useInflacjaStore = create<InflacjaStore>()((set, get) => ({
  ...initialState,
  
  setInflacjaTriangle: (triangle) => {
    set({ inflacjaTriangle: triangle });
    // Automatycznie przygotuj dostępne linie
    get().updateAvailableInflacjaLines();
  },
  
  setSelectedInflacjaLine: (lineIndex) => set({ selectedInflacjaLine: lineIndex }),
  
  updateAvailableInflacjaLines: () => {
    const triangle = get().inflacjaTriangle;
    const lines: { index: number; label: string; values: (number | null)[] }[] = [];
    
    // Iteruj przez wiersze trójkąta
    Object.keys(triangle).forEach(rowIndexStr => {
      const rowIndex = parseInt(rowIndexStr);
      const row = triangle[rowIndex];
      if (!row) return;
      
      // Pobierz label z pierwszej kolumny (kolumna 0)
      const labelValue = row[0];
      const label = labelValue !== null && labelValue !== undefined ? String(labelValue) : `Wiersz ${rowIndex + 1}`;
      
      // Pobierz wartości ze WSZYSTKICH kolumn OPRÓCZ kolumny 0 (etykiety)
      const values: (number | null)[] = [];
      const colKeys = Object.keys(row).map(Number).sort((a, b) => a - b);
      for (const colIndex of colKeys) {
        if (colIndex !== 0) { // Pomijamy TYLKO kolumnę 0 (etykiety), bierzemy wszystkie inne
          const cellValue = row[colIndex] ?? null;
          // Konwertuj stringi na liczby, zostaw null jak jest
          if (typeof cellValue === 'string') {
            const numValue = Number(cellValue);
            values.push(Number.isFinite(numValue) ? numValue : null);
          } else {
            values.push(cellValue);
          }
        }
      }
      
      // Dodaj linię tylko jeśli ma jakieś wartości
      if (values.some(v => v !== null)) {
        lines.push({
          index: rowIndex,
          label,
          values
        });
      }
    });
    
    console.log('🔍 updateAvailableInflacjaLines result:', lines);
    set({ availableInflacjaLines: lines });
  },
  
  setSelectedSheetName: (name) => set({ selectedSheetName: name }),
  setUploadedFileName: (name) => set({ uploadedFileName: name }),
  setDecimalPlaces: (places) => set({ decimalPlaces: places }),
  
  resetData: () => set(initialState),
}));