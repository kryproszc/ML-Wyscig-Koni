import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface SimulationParams {
  iloscSymulacji: number;
  ziarno: number;
  podzialZiarna: number;
  skalowanie: number;
  skalowanie2: number;
}

interface CLSimulationStore {
  // Parametry symulacji
  simulationParams: SimulationParams;
  
  // Kwantyle
  kwantyle: string;
  
  // Stany obliczania
  isCalculatingStatistics: boolean;
  
  // Wyniki statystyk
  statisticsResults: any[];
  
  // Akcje dla parametrów symulacji
  setSimulationParams: (params: Partial<SimulationParams>) => void;
  updateSimulationParam: <K extends keyof SimulationParams>(key: K, value: SimulationParams[K]) => void;
  
  // Akcje dla kwantyli
  setKwantyle: (kwantyle: string) => void;
  
  // Akcje dla stanów obliczania
  setIsCalculatingStatistics: (calculating: boolean) => void;
  
  // Akcje dla wyników
  setStatisticsResults: (results: any[]) => void;
  clearStatisticsResults: () => void;
  
  // Reset całego store
  resetStore: () => void;
}

const defaultSimulationParams: SimulationParams = {
  iloscSymulacji: 1000,
  ziarno: 1111,
  podzialZiarna: 1000,
  skalowanie: 1,
  skalowanie2: 1
};

const defaultKwantyle = "0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.95,0.99,0.995";

export const useCLSimulationStore = create<CLSimulationStore>()(
  persist(
    (set, get) => ({
      // Stan początkowy
      simulationParams: defaultSimulationParams,
      kwantyle: defaultKwantyle,
      isCalculatingStatistics: false,
      statisticsResults: [],
      
      // Akcje dla parametrów symulacji
      setSimulationParams: (params) => {
        set((state) => ({
          simulationParams: { ...state.simulationParams, ...params }
        }));
      },
      
      updateSimulationParam: (key, value) => {
        set((state) => ({
          simulationParams: { ...state.simulationParams, [key]: value }
        }));
      },
      
      // Akcje dla kwantyli
      setKwantyle: (kwantyle) => set({ kwantyle }),
      
      // Akcje dla stanów obliczania
      setIsCalculatingStatistics: (calculating) => set({ isCalculatingStatistics: calculating }),
      
      // Akcje dla wyników
      setStatisticsResults: (results) => set({ statisticsResults: results }),
      clearStatisticsResults: () => set({ statisticsResults: [] }),
      
      // Reset
      resetStore: () => {
        set({
          simulationParams: defaultSimulationParams,
          kwantyle: defaultKwantyle,
          isCalculatingStatistics: false,
          statisticsResults: []
        });
      }
    }),
    {
      name: 'cl-simulation-store',
      version: 4, // ZWIĘKSZONE: wymuś reset cache po usunięciu skalowanie2
      storage: {
        getItem: (name) => {
          const item = sessionStorage.getItem(name);
          return item ? JSON.parse(item) : null;
        },
        setItem: (name, value) => sessionStorage.setItem(name, JSON.stringify(value)),
        removeItem: (name) => sessionStorage.removeItem(name),
      },
    }
  )
);