import { create } from 'zustand';
import { persist } from 'zustand/middleware';

/* ──────────────────────────── TYPY ──────────────────────────── */

export interface ChainLadderResults {
  // 🔵 MultPaid results - opcjonalne
  last_col?: number[];
  cum_trian?: number[];
  ult_net_disc?: number[];
  // 🔴 MultIncurred results - opcjonalne  
  last_col_incurred?: number[];
  cum_trian_incurred?: number[];
  ult_net_disc_incurred?: number[];
  // 🆕 Metadane
  calculatedAt?: string; // Timestamp obliczeń
  userId?: string; // ID użytkownika dla którego obliczono
  shouldShowResults?: boolean; // Flaga czy pokazywać wyniki (resetuje się przy przechodzeniu między zakładkami)
  calculationType?: 'paid' | 'incurred'; // 🆕 Typ obliczeń - MultPaid vs MultIncurred
}

interface ChainLadderResultsState {
  // Stan wyników
  results: ChainLadderResults | null;
  isCalculating: boolean;
  lastError: string | null;
  
  // Akcje
  setResults: (results: ChainLadderResults) => void;
  clearResults: () => void;
  setCalculating: (calculating: boolean) => void;
  setError: (error: string | null) => void;
  hideResults: () => void; // Ukryj wyniki bez usuwania danych
  showResults: () => void; // Pokaż wyniki z powrotem
  
  // Getters pomocnicze
  hasResults: () => boolean;
  getResultsForUser: (userId: string) => ChainLadderResults | null;
}

/* ──────────────────────────── STORE ──────────────────────────── */

// Usuń stare dane z localStorage przy inicjalizacji
if (typeof window !== 'undefined') {
  localStorage.removeItem('chain-ladder-results-storage');
}

export const useChainLadderResultsStore = create<ChainLadderResultsState>()(
  persist(
    (set, get) => ({
      // Stan początkowy
      results: null,
      isCalculating: false,
      lastError: null,
      
      // Akcje
      setResults: (results: ChainLadderResults) => {
        set({
          results: {
            ...results,
            shouldShowResults: true,
            timestamp: Date.now(),
            calculatedAt: new Date().toISOString()
          },
          lastError: null
        });
        console.log('✅ [ChainLadderResultsStore] Zapisano wyniki z flagą shouldShowResults dla użytkownika:', results.userId);
      },
      
      clearResults: () => {
        set({
          results: null,
          lastError: null
        });
        console.log('🗑️ [ChainLadderResultsStore] Wyczyszczono wyniki');
      },
      
      hideResults: () => {
        const { results } = get();
        if (results) {
          set({
            results: {
              ...results,
              shouldShowResults: false
            }
          });
          console.log('👁️ [ChainLadderResultsStore] Ukryto wyniki (bez usuwania danych)');
        }
      },

      showResults: () => {
        const { results } = get();
        if (results) {
          set({
            results: {
              ...results,
              shouldShowResults: true
            }
          });
          console.log('👁️ [ChainLadderResultsStore] Pokazano wyniki z powrotem');
        }
      },
      
      setCalculating: (calculating: boolean) => {
        set({ isCalculating: calculating });
        if (calculating) {
          set({ lastError: null });
        }
      },
      
      setError: (error: string | null) => {
        set({ lastError: error, isCalculating: false });
        console.log('❌ [ChainLadderResultsStore] Błąd:', error);
      },
      
      // Getters pomocnicze
      hasResults: () => {
        const { results } = get();
        return results !== null && 
               results.shouldShowResults === true &&
               ((Array.isArray(results.last_col) && results.last_col.length > 0) ||
                (Array.isArray(results.last_col_incurred) && results.last_col_incurred.length > 0));
      },
      
      getResultsForUser: (userId: string) => {
        const { results } = get();
        if (!results || results.userId !== userId || !results.shouldShowResults) {
          return null;
        }
        
        return results;
      }
    }),
    {
      name: 'chain-ladder-results-storage',
      version: 1,
      // Tylko zapisujemy wyniki, nie stan ładowania
      partialize: (state) => ({
        results: state.results,
        lastError: state.lastError
      }),
      storage: {
        getItem: (name) => {
          const str = sessionStorage.getItem(name);
          if (!str) return null;
          return JSON.parse(str);
        },
        setItem: (name, value) => {
          sessionStorage.setItem(name, JSON.stringify(value));
        },
        removeItem: (name) => sessionStorage.removeItem(name),
      },
    }
  )
);

/* ──────────────────────────── EKSPORT ──────────────────────────── */

export default useChainLadderResultsStore;