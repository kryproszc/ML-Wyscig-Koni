'use client';

import { useBootStore } from '@/stores/useBootStore';
import { useTableStore } from '@/stores/tableStore';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Label,
  ReferenceLine,
} from 'recharts';

// Histogram
function OnlyHistogram() {
  const { histogramData } = useBootStore();

  if (!histogramData.length) return null;

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-gray-100 border-2 border-gray-500 rounded-md px-3 py-2 shadow-lg">
          <div className="text-gray-900 text-sm font-medium">
            <div>Przedział: {label}</div>
            <div>Częstość: {Number(payload[0].value).toLocaleString('pl-PL')}</div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-gradient-to-br from-gray-50 to-white border border-gray-300 rounded-2xl shadow-2xl p-8 text-gray-900 w-full hover:shadow-3xl transition-shadow duration-300">
      <h4 className="text-lg font-bold mb-6 text-gray-800 text-center border-b-2 border-gray-400 pb-3 tracking-tight">
        Histogram wyników symulacji
      </h4>
      <ResponsiveContainer width="100%" height={380}>
        <BarChart 
          data={histogramData} 
          margin={{ top: 30, right: 40, left: 50, bottom: 60 }}
        >
          <CartesianGrid 
            strokeDasharray="2 2" 
            stroke="#9ca3af" 
            strokeWidth={1}
          />
          <XAxis 
            dataKey="bin" 
            angle={-45} 
            textAnchor="end" 
            height={80} 
            stroke="#374151"
            fontSize={12}
            fontFamily="serif"
            tickLine={{ stroke: '#374151', strokeWidth: 1 }}
            axisLine={{ stroke: '#374151', strokeWidth: 2 }}
            tickFormatter={(value) => {
              const firstNumber = value.toString().split(' - ')[0];
              const cleanNumber = firstNumber.replace(/\s/g, '').replace(',', '.');
              const num = Number(cleanNumber);
              return isNaN(num) ? value : Math.round(num).toLocaleString('pl-PL');
            }}
          />
          <YAxis 
            stroke="#374151"
            fontSize={12}
            fontFamily="serif"
            tickLine={{ stroke: '#374151', strokeWidth: 1 }}
            axisLine={{ stroke: '#374151', strokeWidth: 2 }}
            label={{
              value: 'Częstość',
              angle: -90,
              position: 'insideLeft',
              style: { textAnchor: 'middle', fontSize: '12px', fontFamily: 'serif', fill: '#374151' }
            }}
          />
          <Tooltip content={<CustomTooltip />} />
          <Bar 
            dataKey="count" 
            fill="#4f5d75" 
            stroke="#6c7b95"
            strokeWidth={0.8}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

// SimChart (lewy)
function SimChart() {
  const { quantileResult, percentileMatch } = useBootStore();

  const data = quantileResult
    ? Object.entries(quantileResult).map(([q, val]) => ({
        quantile: parseFloat(q),
        sim: val?.value ?? 0,
      }))
    : [];

  if (!quantileResult) return null;

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-gray-100 border-2 border-gray-500 rounded-md px-3 py-2 shadow-lg">
          <div className="text-gray-900 text-sm font-medium">
            <div>Kwantyl: {(Number(label) * 100).toFixed(0)}%</div>
            <div>Ultimate: {Number(payload[0].value).toLocaleString('pl-PL')} zł</div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-gradient-to-br from-gray-50 to-white border border-gray-300 rounded-2xl shadow-2xl p-6 text-gray-900 w-full h-full flex flex-col hover:shadow-3xl transition-shadow duration-300">
      <h4 className="text-lg font-bold mb-4 text-gray-800 text-center border-b-2 border-gray-400 pb-3 tracking-tight">
        Kwantyle: Ultimate
      </h4>
      <div className="flex-1">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 20, right: 30, left: 60, bottom: 50 }}>
            <CartesianGrid 
              strokeDasharray="2 2" 
              stroke="#9ca3af" 
              strokeWidth={1}
            />
            <XAxis 
              dataKey="quantile" 
              type="number" 
              domain={[0, 1]} 
              ticks={[0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]}
              stroke="#374151"
              fontSize={12}
              fontFamily="serif"
              tickLine={{ stroke: '#374151', strokeWidth: 1 }}
              axisLine={{ stroke: '#374151', strokeWidth: 2 }}
              tickFormatter={(value) => (value * 100).toFixed(0) + '%'}
              label={{
                value: 'Kwantyl',
                position: 'insideBottom',
                offset: -10,
                style: { textAnchor: 'middle', fontSize: '12px', fontFamily: 'serif', fill: '#374151' }
              }}
            />
            <YAxis 
              domain={['dataMin', 'dataMax']}
              stroke="#374151"
              fontSize={12}
              fontFamily="serif"
              tickLine={{ stroke: '#374151', strokeWidth: 1 }}
              axisLine={{ stroke: '#374151', strokeWidth: 2 }}
              tickFormatter={(value) => Math.round(Number(value)).toLocaleString('pl-PL')}
            />

            <Tooltip content={<CustomTooltip />} />
            <Line 
              type="monotone" 
              dataKey="sim" 
              stroke="#000000" 
              strokeWidth={2.5} 
              dot={false}
              isAnimationActive={false}
            />

            {percentileMatch?.sim != null && (
              <ReferenceLine
                x={percentileMatch.sim}
                stroke="#dc2626"
                strokeWidth={3}
                strokeDasharray="6 3"
                label={{
                  value: `▲ ${(percentileMatch.sim * 100).toFixed(1)}%`,
                  position: 'insideTopRight' as any,
                  fill: '#dc2626',
                  fontSize: 13,
                  fontWeight: 'bold',
                  fontFamily: 'serif'
                }}
              />
            )}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

// DiffChart (prawy)
function DiffChart() {
  const { quantileResult, percentileMatch } = useBootStore();
  const activeType = useTableStore((s) => s.activeStochTriangle ?? 'paid');
  const ibnrLabel = activeType === 'paid' ? 'IBNR' : 'IBNR + RBNP';

  const data = quantileResult
    ? Object.entries(quantileResult).map(([q, val]) => ({
        quantile: parseFloat(q),
        diff: val?.value_minus_latest ?? 0,
      }))
    : [];

  if (!quantileResult) return null;

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-gray-100 border-2 border-gray-500 rounded-md px-3 py-2 shadow-lg">
          <div className="text-gray-900 text-sm font-medium">
            <div>Kwantyl: {(Number(label) * 100).toFixed(0)}%</div>
            <div>{ibnrLabel}: {Number(payload[0].value).toLocaleString('pl-PL')} zł</div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-gradient-to-br from-gray-50 to-white border border-gray-300 rounded-2xl shadow-2xl p-6 text-gray-900 w-full h-full flex flex-col hover:shadow-3xl transition-shadow duration-300">
      <h4 className="text-lg font-bold mb-4 text-gray-800 text-center border-b-2 border-gray-400 pb-3 tracking-tight">
        Kwantyle: {ibnrLabel}
      </h4>
      <div className="flex-1">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 20, right: 30, left: 60, bottom: 50 }}>
            <CartesianGrid 
              strokeDasharray="2 2" 
              stroke="#9ca3af" 
              strokeWidth={1}
            />
            <XAxis 
              dataKey="quantile" 
              type="number" 
              domain={[0, 1]} 
              ticks={[0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]}
              stroke="#374151"
              fontSize={12}
              fontFamily="serif"
              tickLine={{ stroke: '#374151', strokeWidth: 1 }}
              axisLine={{ stroke: '#374151', strokeWidth: 2 }}
              tickFormatter={(value) => (value * 100).toFixed(0) + '%'}
              label={{
                value: 'Kwantyl',
                position: 'insideBottom',
                offset: -10,
                style: { textAnchor: 'middle', fontSize: '12px', fontFamily: 'serif', fill: '#374151' }
              }}
            />
            <YAxis 
              domain={['dataMin', 'dataMax']}
              stroke="#374151"
              fontSize={12}
              fontFamily="serif"
              tickLine={{ stroke: '#374151', strokeWidth: 1 }}
              axisLine={{ stroke: '#374151', strokeWidth: 2 }}
              tickFormatter={(value) => Math.round(Number(value)).toLocaleString('pl-PL')}
            />

            <Tooltip content={<CustomTooltip />} />
            <Line 
              type="monotone" 
              dataKey="diff" 
              stroke="#000000" 
              strokeWidth={2.5} 
              dot={false}
              isAnimationActive={false}
            />

            {percentileMatch?.diff != null && (
              <ReferenceLine
                x={percentileMatch.diff}
                stroke="#dc2626"
                strokeWidth={3}
                strokeDasharray="6 3"
                label={{
                  value: `▲ ${(percentileMatch.diff * 100).toFixed(1)}%`,
                  position: 'insideTopRight' as any,
                  fill: '#dc2626',
                  fontSize: 13,
                  fontWeight: 'bold',
                  fontFamily: 'serif'
                }}
              />
            )}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export const ChartsBoot = {
  OnlyHistogram,
  SimChart,
  DiffChart,
};
