import { useCallback } from 'react';
import type { DevJResult, SimResults } from './useDataOptions';

export interface UsePayloadBuilderParams {
  simResults: SimResults;
  devJResults: DevJResult[];
  combinedDevJSummary: (number | string)[];
  finalDevVector: number[];
  finalDevJ?: DevJResult; // dodane dla odchyleń standardowych
}

export function usePayloadBuilder({
  simResults,
  devJResults,
  combinedDevJSummary,
  finalDevVector,
  finalDevJ,
}: UsePayloadBuilderParams) {
  const buildPayload = useCallback((key: string | null): any | null => {
    if (!key) return null;

    // Krzywa z symulacji
    if (key.startsWith('curve-')) {
      const curve = key.replace('curve-', '');
      const raw = simResults[curve];
      if (!raw) return null;
      
      const coeffs = Object.values(raw).filter(
        (v): v is number => typeof v === 'number' && Number.isFinite(v),
      );
      return { curve_name: curve, coeffs };
    }

    // Volume z devJResults
    if (key.startsWith('volume-')) {
      const vol = parseInt(key.replace('volume-', ''), 10);
      const found = devJResults.find((v) => v.volume === vol);
      return found ? { volume: found.volume, values: found.values, sdValues: found.sdValues } : null;
    }

    // Combined dev_j
    if (key === 'final-dev-j') {
      // Użyj finalDevJ.values jeśli istnieje (rzeczywiste wybrane wartości z custom selections)
      // W przeciwnym razie użyj combinedDevJSummary jako fallback
      const values = finalDevJ?.values ?? combinedDevJSummary
        .map((v) => {
          const n = parseFloat(String(v));
          return Number.isFinite(n) ? n : null;
        })
        .filter((v): v is number => v !== null);
      
      return { 
        final_dev_vector: values,
        final_sd_vector: finalDevJ?.sdValues, // dodaj odchylenia standardowe
      };
    }

    // Raw final dev vector
    if (key === 'final-dev-raw') {
      return { final_dev_vector: finalDevVector };
    }

    return null;
  }, [simResults, devJResults, combinedDevJSummary, finalDevVector, finalDevJ]);

  return { buildPayload };
}
