import { useCallback } from 'react';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';

export type ComparisonTableEntry = {
  data: any[];
  labelA: string;
  labelB: string;
};

export function useExcelExport() {
  const exportToExcel = useCallback((
    comparisonTables: ComparisonTableEntry[],
    filename: string = 'porownania.xlsx'
  ) => {
    if (comparisonTables.length === 0) return;

    const wb = XLSX.utils.book_new();

    comparisonTables.forEach((entry, idx) => {
      // Przygotuj dane z przemianowanymi kolumnami
      const renamed = entry.data.map((row) => {
        const obj: Record<string, any> = {};
        for (const [k, v] of Object.entries(row)) {
          let newKey = k;
          if (k === 'Projection A') newKey = entry.labelA;
          if (k === 'Projection B') newKey = entry.labelB;
          
          // Przekonwertuj stringi liczbowe na liczby
          const parsed =
            typeof v === 'string' && v.match(/^-?\d+([,\.]\d+)?$/)
              ? parseFloat(v.replace(',', '.'))
              : v;
          obj[newKey] = parsed;
        }
        return obj;
      });

      // Stwórz arkusz
      const sheet = XLSX.utils.json_to_sheet(renamed);
      
      // Wygeneruj bezpieczną nazwę arkusza
      const baseName = `${entry.labelA} vs ${entry.labelB}`
        .replace(/[:\/\\\?\*\[\]]/g, '-')
        .substring(0, 25);

      let safe = baseName;
      let sheetIndex = 1;
      while (wb.SheetNames.includes(safe)) {
        safe = `${baseName}-${sheetIndex}`;
        sheetIndex++;
      }

      XLSX.utils.book_append_sheet(wb, sheet, safe || `Porównanie ${idx + 1}`);
    });

    // Zapisz plik
    const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    saveAs(
      new Blob([wbout], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      }),
      filename,
    );
  }, []);

  return { exportToExcel };
}
