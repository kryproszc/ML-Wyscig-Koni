'use client';

import { useForm } from 'react-hook-form';
import { useRef } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import * as XLSX from 'xlsx';
import { useEffect, useState } from 'react';
import { useDetailTableStore } from '@/stores/useDetailTableStore';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useTrainDevideStoreSummary } from '@/stores/trainDevideStoreSummary';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { z } from 'zod';
import { SheetSelectDet } from '@/components/SheetSelectDet';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardFooter,
} from '@/components/ui/card';
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Loader2 } from 'lucide-react';
import { VisuallyHidden } from '@/components/ui/visually-hidden';
import { DataTypeSelector } from '@/components/DataTypeSelector';
import type { DataType } from '@/components/DataTypeSelector';
import { HeadersSelector } from '@/components/HeadersSelector';
import { convertIncrementalToCumulative } from '@/utils/dataConversion';
import { FileUploadSection, RangeInputSection } from '@/components/InputFormSections';
import Modal from '@/components/Modal';
import { resetAllStores } from '@/lib/resetAllStores';
import { EditablePaidTriangle } from '@/components/EditablePaidTriangle';

const schema = z.object({
  rowStart: z.coerce.number().min(1, "Wiersz początkowy musi być co najmniej 1"),
  rowEnd: z.coerce.number().min(1, "Wiersz końcowy musi być co najmniej 1"),
  colStart: z.coerce.number().min(1, "Kolumna początkowa musi być co najmniej 1"),
  colEnd: z.coerce.number().min(1, "Kolumna końcowa musi być co najmniej 1"),
  file: z.any(),
}).refine((data) => data.rowStart <= data.rowEnd, {
  message: "Wiersz początkowy nie może być większy od wiersza końcowego",
  path: ["rowEnd"],
}).refine((data) => data.colStart <= data.colEnd, {
  message: "Kolumna początkowa nie może być większa od kolumny końcowej", 
  path: ["colEnd"],
});
type FormField = z.infer<typeof schema>;




/* --------------------------------------------------------------------- */
export function InputDataTabDet() {
  /* ---------- Lokalny UI‑owy stan ---------- */
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [showErrorDialog, setShowErrorDialog] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [showWarningModal, setShowWarningModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  
  const [pendingFormData, setPendingFormData] = useState<FormField | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const editTriangleRef = useRef<{ handleClose: () => void }>(null);


  /* ---------- Zustanda – store „detaliczny” ---------- */
  const {
    workbook,
    isValid,
    selectedSheetJSON,
    previousSheetJSON,
    validationErrorReason,
    setWorkbook,
    getDefaultRange,
    setRangeAndUpdate,
    uploadedFileName,
    setUploadedFileName,
    selectedSheetName,
    lastApprovedSettings,
    setLastApprovedSettings,
  } = useDetailTableStore();

  const { 
    detRowLabels: rowLabels, 
    detColumnLabels: columnLabels, 
    setDetRowLabels: setRowLabels, 
    setDetColumnLabels: setColumnLabels,
    globalRowLabels,
    globalColumnLabels,
    lastLoadedFile
  } = useLabelsStore();

  // Store Paid dla funkcji czyszczących
  const paidStore = useTrainDevideStoreDet();
  const summaryStore = useTrainDevideStoreSummary();

const setPaidTriangle = useTrainDevideStoreDet((s) => s.setPaidTriangle);

  // Store dla ustawień input'a - używamy indywidualnych ustawień z detailTableStore
  const {
    dataType,
    setDataType,
    incrementDataGeneration,
    hasHeaders,
    setHasHeaders,
  } = useDetailTableStore();

  /* ---------- React‑hook‑form ---------- */
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    getValues,
    formState: { errors },
  } = useForm<FormField>({
    resolver: zodResolver(schema),
    defaultValues: {
      rowStart: 1,
      rowEnd: 1,
      colStart: 1,
      colEnd: 1,
    },
  });

  const file = watch('file');

  /* ---------- Synchronizacja zakresu z store'em (client-side only) ---------- */
  useEffect(() => {
    // Opóźnij do następnego tick'a żeby uniknąć problemów z hydratacją
    const timer = setTimeout(() => {
      const { startRow, endRow, startCol, endCol } =
        useDetailTableStore.getState();
      setValue('rowStart', startRow);
      setValue('rowEnd', endRow);
      setValue('colStart', startCol);
      setValue('colEnd', endCol);
    }, 0);

    return () => clearTimeout(timer);
  }, [setValue]);

  // WYŁĄCZONE: Automatyczna subskrypcja powodowała nadpisywanie ręcznych zmian
  // useEffect(() => {
  //   // Subskrybuj zmiany store'a po client-side hydration
  //   const timer = setTimeout(() => {
  //     const unsub = useDetailTableStore.subscribe((state) => {
  //       setValue('rowStart', state.startRow);
  //       setValue('rowEnd', state.endRow);
  //       setValue('colStart', state.startCol);
  //       setValue('colEnd', state.endCol);
  //     });
      
  //     return () => unsub();
  //   }, 0);

  //   return () => clearTimeout(timer);
  // }, [setValue]);

  /* ---------- Ładowanie pliku ---------- */
  const handleFileLoad = () => {
    const f = file?.[0];
    if (!f) {
      setErrorMessage("Najpierw wybierz plik Excel (.xlsx lub .xls).");
      setShowErrorDialog(true);
      return;
    }

    // Sprawdź rozmiar pliku (max 10MB)
    if (f.size > 10 * 1024 * 1024) {
      setErrorMessage("Plik jest za duży. Maksymalny rozmiar to 10MB.");
      setShowErrorDialog(true);
      return;
    }

    // Sprawdź rozszerzenie pliku
    const validExtensions = ['.xlsx', '.xls'];
    const fileName = f.name.toLowerCase();
    const hasValidExtension = validExtensions.some(ext => fileName.endsWith(ext));
    
    if (!hasValidExtension) {
      setErrorMessage("Nieprawidłowy format pliku. Wybierz plik Excel (.xlsx lub .xls).");
      setShowErrorDialog(true);
      return;
    }

    const reader = new FileReader();

    reader.onloadstart = () => {
      setIsLoading(true);
      setProgress(0);
    };

    reader.onprogress = (e) => {
      if (e.lengthComputable) {
        setProgress(Math.round((e.loaded / e.total) * 100));
      }
    };

    reader.onload = (evt) => {
      const binaryStr = evt.target?.result;
      if (typeof binaryStr === 'string') {
        try {
          const wb = XLSX.read(binaryStr, { type: 'binary' });

          // 🆕 Wyczyść paidTriangle PRZED resetowaniem DetailTableStore
          console.log('🧹 [handleFileLoad] Czyszczę paidTriangle przed wczytaniem nowego pliku...');
          paidStore.setPaidTriangle([]);
          
          // 🆕 Wyczyść trainDevideDet żeby wymusić przeliczenie w zakładce CL
          console.log('🧹 [handleFileLoad] Czyszczę trainDevideDet...');
          paidStore.setTrainDevideDet(undefined);
          
          // 🆕 Reset wszystkich ustawień do wartości domyślnych
          console.log('🔄 [handleFileLoad] Resetuję wszystkie ustawienia do domyślnych...');
          useDetailTableStore.getState().resetData();
          
          // 🆕 Reset ustawień typu danych i nagłówków do domyślnych
          console.log('🔄 [handleFileLoad] Ustawiam domyślne: skumulowane + nagłówki...');
          setDataType('cumulative'); // Resetuj do skumulowanych
          setHasHeaders(true); // Resetuj do "zawiera nagłówki"
          

          
          setWorkbook(wb);
          useDetailTableStore
            .getState()
            .setSelectedSheetName(wb.SheetNames[0]);

          setUploadedFileName(f.name);
        } catch (err) {
          console.error("Błąd podczas parsowania pliku:", err);
          setErrorMessage("Nie można odczytać pliku. Sprawdź czy plik nie jest uszkodzony i czy to prawidłowy plik Excel.");
          setShowErrorDialog(true);
        }
      } else {
        setErrorMessage("Nie można odczytać zawartości pliku.");
        setShowErrorDialog(true);
      }

      setIsLoading(false);
      setProgress(0);
    };

    reader.onerror = () => {
      setErrorMessage("Wystąpił błąd podczas wczytywania pliku. Spróbuj ponownie.");
      setShowErrorDialog(true);
      setIsLoading(false);
    };

    reader.readAsBinaryString(f);
  };

  /* ---------- Wykryj zakres automatycznie ---------- */
  const handleAutoRange = () => {
    const range = getDefaultRange();
    if (!range) return;
    
    // Aktualizuj formularz
    setValue('rowStart', range.startRow);
    setValue('rowEnd', range.endRow);
    setValue('colStart', range.startCol);
    setValue('colEnd', range.endCol);
    
    // Aktualizuj też store bezpośrednio
    useDetailTableStore.setState({
      startRow: range.startRow,
      endRow: range.endRow,
      startCol: range.startCol,
      endCol: range.endCol
    });
  };

  /* ---------- Sprawdzanie czy ustawienia lub plik się zmienił ---------- */
  const hasSettingsChanged = (newData: FormField) => {
    console.log('🔍 Sprawdzanie zmian ustawień:', {
      selectedSheetJSON: selectedSheetJSON?.length || 0,
      lastApprovedSettings,
      currentSheetName: selectedSheetName,
      newData,
      currentHasHeaders: hasHeaders,
      currentDataType: dataType,
      currentFileName: uploadedFileName,
      lastLoadedFile
    });

    // Sprawdź czy nie ma zapisanych ostatnich ustawień - to oznacza pierwsze użycie
    if (!lastApprovedSettings) {
      console.log('❌ Brak ostatnich ustawień - pierwsze użycie');
      return false;
    }



    // 🆕 Sprawdź czy wczytano nowy plik (różna nazwa pliku)
    if (uploadedFileName && lastLoadedFile && uploadedFileName !== lastLoadedFile) {
      console.log('✅ Wczytano nowy plik:', uploadedFileName, '!=', lastLoadedFile);
      return true;
    }
    
    // Sprawdź czy arkusz się zmienił
    if (selectedSheetName !== lastApprovedSettings.sheetName) {
      console.log('✅ Arkusz się zmienił:', selectedSheetName, '!=', lastApprovedSettings.sheetName);
      return true;
    }

    // Sprawdź czy zakres się zmienił
    if (newData.rowStart !== lastApprovedSettings.rowStart ||
        newData.rowEnd !== lastApprovedSettings.rowEnd ||
        newData.colStart !== lastApprovedSettings.colStart ||
        newData.colEnd !== lastApprovedSettings.colEnd) {
      console.log('✅ Zakres się zmienił');
      return true;
    }

    // 🆕 Sprawdź czy ustawienia nagłówków się zmieniły
    if (hasHeaders !== lastApprovedSettings.hasHeaders) {
      console.log('✅ Ustawienie nagłówków się zmieniło:', hasHeaders, '!=', lastApprovedSettings.hasHeaders);
      return true;
    }

    // 🆕 Sprawdź czy typ danych się zmienił
    if (dataType !== lastApprovedSettings.dataType) {
      console.log('✅ Typ danych się zmienił:', dataType, '!=', lastApprovedSettings.dataType);
      return true;
    }

    console.log('❌ Brak zmian');
    return false;
  };

  /* ---------- Sprawdzenie czy istnieją obliczenia do usunięcia ---------- */
  const hasExistingCalculations = () => {
    return checkExistingCalculations();
  };

  /* ---------- Submit formularza ---------- */
  const onSubmit = (data: FormField) => {
    console.log('📝 Submit formularza:', data);
    
    // 🔍 WALIDACJA KWADRATOWOŚCI - pierwsze sprawdzenie (przed sprawdzaniem zmian)
    let dataRows, dataCols;
    
    if (hasHeaders) {
      // Z nagłówkami: odejmuj 1 od każdego wymiaru
      dataRows = data.rowEnd - data.rowStart;      
      dataCols = data.colEnd - data.colStart;      
    } else {
      // Bez nagłówków: cały zakres to dane
      dataRows = data.rowEnd - data.rowStart + 1;  
      dataCols = data.colEnd - data.colStart + 1;  
    }

    if (dataRows !== dataCols) {
      console.error('❌ [onSubmit] Dane nie są kwadratowe:', {dataRows, dataCols, hasHeaders});
      setErrorMessage(`Liczba wczytanych wierszy musi być równa liczbie wczytanych kolumn. Wczytano: ${dataRows} wierszy × ${dataCols} kolumn.`);
      setShowErrorDialog(true);
      return; // Przerwij przetwarzanie
    }

    console.log('✅ [onSubmit] Walidacja kwadratowości przeszła:', {dataRows, dataCols});
    
    // Sprawdź czy ustawienia się zmieniły względem już wczytanych danych
    const settingsChanged = hasSettingsChanged(data);
    const hasCalculations = hasExistingCalculations();
    
    console.log('🔄 Ustawienia się zmieniły:', settingsChanged);
    console.log('🔄 Istnieją obliczenia:', hasCalculations);
    
    // 🆕 NOWA LOGIKA: Pokaż ostrzeżenie gdy istnieją obliczenia do stracenia
    // (niezależnie od tego czy to pierwsze wczytanie czy zmiana ustawień)
    if (hasCalculations) {
      // Zapisz dane formularza i pokaż modal ostrzeżenia
      console.log('⚠️ Pokazuję modal ostrzeżenia - istnieją obliczenia do stracenia');
      setPendingFormData(data);
      setShowWarningModal(true);
      return;
    }

    // Jeśli nie ma obliczeń do stracenia, wykonaj normalnie
    console.log('✅ Przetwarzam dane bez modala - brak obliczeń do stracenia');
    processFormData(data);
  };



// Funkcja do przetwarzania danych formularza
const processFormData = (data: FormField) => {
  console.log('🔄 [processFormData] Rozpoczynam przetwarzanie danych...', data);

  // reset dialogów
  setShowSuccessDialog(false);
  setShowErrorDialog(false);

  // Walidacja kwadratowości została przeniesiona do onSubmit()

  setRangeAndUpdate({
    startRow: data.rowStart,
    endRow: data.rowEnd,
    startCol: data.colStart,
    endCol: data.colEnd,
  });

  setTimeout(() => {
    let { isValid: v, selectedSheetJSON: json, previousSheetJSON: prev, validationErrorReason } =
      useDetailTableStore.getState();

    // 🚨 Sprawdź czy walidacja się nie powiodła
    if (v === false) {
      console.error('❌ Walidacja danych nie powiodła się:', validationErrorReason);
      setErrorMessage(validationErrorReason || "Dane wejściowe zawierają błędy. Sprawdź czy wszystkie komórki zawierają poprawne wartości liczbowe i nie ma pustych miejsc w środku danych.");
      setShowErrorDialog(true);
      return;
    }

    // 🔍 WALIDACJA PUSTEGO ZAKRESU - sprawdź czy są jakiekolwiek dane
    if (json && json.length > 0) {
      let hasAnyData = false;
      
      // Sprawdź czy w całym json jest jakakolwiek wartość różna od 0, null, undefined, ""
      for (let i = 0; i < json.length; i++) {
        const row = json[i];
        if (!row) continue; // Pomiń puste wiersze
        
        for (let j = 0; j < row.length; j++) {
          const cell = row[j];
          if (cell !== null && cell !== undefined && cell !== "" && cell !== 0 && cell !== "0") {
            hasAnyData = true;
            break;
          }
        }
        if (hasAnyData) break;
      }
      
      if (!hasAnyData) {
        console.error('❌ Wybrany zakres nie zawiera żadnych danych:', {
          selectedRange: `${data.rowStart}-${data.rowEnd} × ${data.colStart}-${data.colEnd}`,
          sheetName: selectedSheetName || 'nieznany',
          dataPreview: json.slice(0, 3)
        });
        setErrorMessage(`Wybrany zakres ${data.rowStart}-${data.rowEnd} × ${data.colStart}-${data.colEnd} w arkuszu "${selectedSheetName || 'nieznany'}" nie zawiera żadnych danych. Sprawdź czy wybrałeś właściwy arkusz i zakres.`);
        setShowErrorDialog(true);
        return;
      }
      
      console.log('✅ Znaleziono dane w wybranym zakresie');
    }

    // (1) ewentualna konwersja inkrementalnych -> skumulowane
    if (dataType === 'incremental' && json) {
      const converted = convertIncrementalToCumulative(json);
      useDetailTableStore.setState({ selectedSheetJSON: converted });
      json = converted;
    }

// (2) budowa body + etykiet zgodnie z hasHeaders
let body: any[][] = [];
let rowNames: string[] = [];
let colNames: string[] = [];

if (json && json.length > 0) {
  if (hasHeaders) {
    // ✅ Mamy podpisy – wyciągamy je z pierwszego wiersza/kolumny
    colNames = (json[0] ?? []).slice(1).map(c => String(c ?? ''));
    rowNames = json.slice(1).map(r => String((r && r[0]) ?? ''));
    body = json.slice(1).map(r => r.slice(1)); // samo „ciało"
  } else {
    // ✅ Brak podpisów – cała tabela to dane, generujemy nazwy 1,2,3...
    body = json; // CAŁA tabela to dane!
    rowNames = Array.from({ length: body.length }, (_, i) => String(i + 1));
    colNames = Array.from({ length: body[0]?.length || 0 }, (_, i) => String(i + 1));
  }

  // 🧹 INTELIGENTNE CZYSZCZENIE TRÓJKĄTA - zamień zera "pod trójkątem" na puste
  const cleanBody = body.map((row, rowIndex) => {
    return row.map((cell, colIndex) => {
      // Jeśli komórka ma wartość 0 (liczbę lub string "0")
      if (cell === 0 || cell === "0") {
        // Oblicz oczekiwaną pozycję dla struktury trójkąta
        const expectedMaxCols = Math.max(0, body.length - rowIndex);
        
        // Jeśli kolumna jest poza oczekiwaną strukturą trójkąta
        if (colIndex >= expectedMaxCols) {
          return null; // Zamień na null
        }
      }
      return cell;
    });
  });

  // zapis etykiet do store'a
  setRowLabels(rowNames);
  setColumnLabels(colNames);

  // numericTriangle (number|null) na bazie WYCZYSZCZONEGO body
  const numericTriangle: (number | null)[][] = cleanBody.map(row =>
    row.map(cell =>
      typeof cell === 'number'
        ? cell
        : cell == null || cell === ''
        ? null
        : Number.isFinite(Number(cell))
        ? Number(cell)
        : null
    )
  );
  
  setPaidTriangle(numericTriangle);

  // widok tabeli do podglądu (string|number) - używamy WYCZYSZCZONEGO body
  const sheetForStore: (string | number)[][] = cleanBody.map(row =>
    row.map(cell => (cell == null ? '' : typeof cell === 'number' ? cell : String(cell)))
  );
  useTrainDevideStoreDet.setState({ selectedSheetDet: sheetForStore });
}



    // (3) pokaż alert sukcesu
    setShowSuccessDialog(true);
      
    // 🆕 Zapisz globalnie informację o wczytanym pliku
    setTimeout(() => {
      const { setGlobalLabels } = useLabelsStore.getState();
      setGlobalLabels(rowNames, colNames, uploadedFileName || '');
    }, 0);
    
    setLastApprovedSettings({
      sheetName: selectedSheetName || null,
      rowStart: data.rowStart,
      rowEnd: data.rowEnd,
      colStart: data.colStart,
      colEnd: data.colEnd,
      hasHeaders,
      dataType,
    });
  }, 0);
};



  



  // Obsługa potwierdzenia w modalu
  const handleConfirmDataReplace = () => {
    resetAllStores(); 
    console.log('🚨 [handleConfirmDataReplace] Rozpoczynam czyszczenie danych...');
    setShowWarningModal(false);
    
    // Wyczyść wszystkie obliczenia z zakładek Paid (tak jak Reset współczynników)
    paidStore.clearDevJResults();
    paidStore.setFinalDevJ(undefined);
    paidStore.clearAllDevFinalValues();
    paidStore.clearFitCurveData();
    paidStore.clearDevSummaryData();
    
    // 🆕 Wyczyść trainDevideDet żeby wymusić przeliczenie w zakładce CL
    console.log('🧹 [handleConfirmDataReplace] Czyszczę trainDevideDet...');
    paidStore.setTrainDevideDet(undefined);
    
    // 🆕 Wyczyść dane trójkąta żeby wymusiło przeliczenie
    console.log('🧹 [handleConfirmDataReplace] Czyszczę paidTriangle...', {
      currentTriangleLength: paidStore.paidTriangle?.length || 0,
      currentTriangleType: Array.isArray(paidStore.paidTriangle) ? 'array' : typeof paidStore.paidTriangle
    });
    paidStore.setPaidTriangle([]);
    console.log('🧹 [handleConfirmDataReplace] paidTriangle po wyczyszczeniu:', {
      newTriangleLength: paidStore.paidTriangle?.length || 0
    });
    
    // 🆕 Wyczyść oryginalne dane trójkąta przy wczytywaniu nowych
    paidStore.clearOriginalPaidTriangle();
    
    // Wyczyść tabele ResultSummary - gdy kasujemy dane Paid
    summaryStore.clearSummaryData();
    
    if (pendingFormData) {
      console.log('📝 [handleConfirmDataReplace] Przetwarzam odłożone dane formularza...');
      
      // 🆕 Wymusimy odświeżenie komponentów przez incrementDataGeneration - PRZED processFormData
      console.log('🔄 [handleConfirmDataReplace] Incrementing dataGenerationId...');
      incrementDataGeneration();
      
      // Małe opóźnienie żeby React zdążył przetworzyć zmianę dataGenerationId
      setTimeout(() => {
        console.log('⏰ [handleConfirmDataReplace] Wywołuję processFormData po timeout...');
        processFormData(pendingFormData);
      }, 0);
      
      setPendingFormData(null);
    } else {
      console.log('⚠️ [handleConfirmDataReplace] Brak pendingFormData!');
    }
    console.log('✅ [handleConfirmDataReplace] Zakończono');
  };



  // Obsługa anulowania w modalu
  const handleCancelDataReplace = () => {
    setShowWarningModal(false);
    setPendingFormData(null);
  };

  /* ---------- Obsługa edycji trójkąta ---------- */
  // Ta funkcja już nie jest używana - usunięta
  
  /* ---------- Funkcja finalnego zapisu do store ---------- */
  const handleFinalEditSave = (editedData: (number | null)[][]) => {
    console.log('💾 [handleFinalEditSave] FINALNE zapisanie do store:', editedData.length, 'wierszy');
    
    // Zapisz dane do store (do analizy)
    setPaidTriangle(editedData);
    
    // Wyczyść obliczenia bo dane się zmieniły
    paidStore.clearDevJResults();
    paidStore.setFinalDevJ(undefined);
    paidStore.setTrainDevideDet(undefined);
    
    console.log('✅ [handleFinalEditSave] Dane zapisane do store i obliczenia wyczyszczone');
  };

  /* ---------- Sprawdzenie czy istnieją obliczenia ---------- */
  const checkExistingCalculations = (): boolean => {
    // Sprawdź czy devJResults ma jakiekolwiek elementy
    const hasDevJResults = paidStore.devJResults && 
                          Array.isArray(paidStore.devJResults) && 
                          paidStore.devJResults.length > 0;
    
    // Sprawdź czy finalDevJ nie jest undefined/null
    const hasFinalDevJ = paidStore.finalDevJ !== undefined && 
                        paidStore.finalDevJ !== null;
    
    // Sprawdź czy trainDevideDet ma jakiekolwiek elementy  
    const hasTrainData = paidStore.trainDevideDet && 
                        Array.isArray(paidStore.trainDevideDet) && 
                        paidStore.trainDevideDet.length > 0;
    
    const hasCalc = Boolean(hasDevJResults || hasFinalDevJ || hasTrainData);
    
    console.log('🔍 [checkExistingCalculations] devJResults:', hasDevJResults, 'finalDevJ:', hasFinalDevJ, 'trainData:', hasTrainData, 'Wynik:', hasCalc);
    return hasCalc;
  };

  const handleEditClose = () => {
    console.log('🔄 [handleEditClose] Użytkownik kliknął górny przycisk zamknij');
    if (editTriangleRef.current) {
      editTriangleRef.current.handleClose();
    } else {
      setShowEditModal(false);
    }
  };



  /* ------------------------------- JSX ------------------------------- */
  return (
    <div>
      {/* ---------- FORMULARZ ---------- */}
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="p-4 border rounded flex flex-col gap-4"
      >
        <Card>
          <CardHeader>
            <CardTitle>Wprowadź trójkąt danych paid, który wykorzystasz w dalszej analizie</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* --- Plik --- */}
            <div className="flex items-center gap-4">
              <input
                type="file"
                accept=".xlsx,.xls"
                className="border p-2 rounded-lg"
                {...register('file')}
              />
              <Button
                type="button"
                onClick={handleFileLoad}
                disabled={!file || file.length === 0}
                className="bg-blue-500 text-white"
              >
                Załaduj plik
              </Button>
              {uploadedFileName && (
                <span className="text-sm text-green-400 ml-2">
                  Wczytano: <strong>{uploadedFileName}</strong>
                </span>
              )}
            </div>

            {/* --- Arkusz --- */}
            <div>
              <Label>Wybór arkusza</Label>
              {/* Jeśli Twój SheetSelect nie przyjmuje „store”, usuń ten prop */}
              <SheetSelectDet />
            </div>

            
          <CardHeader>
            <CardTitle> Podaj zakres danych, które chcesz wczytać.</CardTitle>
          </CardHeader>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Wiersz początkowy</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('rowStart')}
                />
                {errors.rowStart && (
                  <p className="text-red-500 text-sm mt-1">{errors.rowStart.message}</p>
                )}
              </div>
              <div>
                <Label>Wiersz końcowy</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('rowEnd')}
                />
                {errors.rowEnd && (
                  <p className="text-red-500 text-sm mt-1">{errors.rowEnd.message}</p>
                )}
              </div>
              <div>
                <Label>Kolumna początkowa</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('colStart')}
                />
                {errors.colStart && (
                  <p className="text-red-500 text-sm mt-1">{errors.colStart.message}</p>
                )}
              </div>
              <div>
                <Label>Kolumna końcowa</Label>
                <Input
                  type="number"
                  disabled={!workbook}
                  {...register('colEnd')}
                />
                {errors.colEnd && (
                  <p className="text-red-500 text-sm mt-1">{errors.colEnd.message}</p>
                )}
              </div>
            </div>

            <Button
              type="button"
              onClick={handleAutoRange}
              variant="outline"
              disabled={!workbook}
              className="bg-blue-500 text-white"
            >
              Wykryj zakres automatycznie
            </Button>

            {/* --- Czy dane zawierają podpisy --- */}
            <HeadersSelector 
              hasHeaders={hasHeaders} 
              onHeadersChange={setHasHeaders} 
            />

            {/* --- Typ danych --- */}
            <DataTypeSelector
              dataType={dataType}
              onDataTypeChange={setDataType}
            />
          </CardContent>
          <CardFooter>
            <Button
              type="submit"
              className="bg-blue-500 text-white"
              disabled={!workbook}
            >
              Wczytaj
            </Button>
            
            {/* Przycisk do edycji trójkąta */}
            {paidStore.paidTriangle && paidStore.paidTriangle.length > 0 && (
              <Button
                type="button"
                onClick={() => setShowEditModal(true)}
                className="bg-green-600 hover:bg-green-700 text-white ml-3"
              >
                ✏️ Edytuj trójkąt danych
              </Button>
            )}
          </CardFooter>
        </Card>
      </form>

      {/* ---------- ALERTY ---------- */}

      {/* Błąd walidacji (czerwony) */}
      <AlertDialog open={showErrorDialog} onOpenChange={setShowErrorDialog}>
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center">
            <VisuallyHidden>
              <AlertDialogTitle>Błąd walidacji</AlertDialogTitle>
            </VisuallyHidden>
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-red-100 mb-4">
              <svg
                className="w-6 h-6 text-red-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
            </div>
            <AlertDialogDescription className="text-center text-red-600 font-medium">
              {errorMessage}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>OK</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Sukces (zielony) */}
      <AlertDialog
        open={showSuccessDialog}
        onOpenChange={setShowSuccessDialog}
      >
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center">
            <VisuallyHidden>
              <AlertDialogTitle>Powiadomienie</AlertDialogTitle>
            </VisuallyHidden>
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-green-100 mb-4">
              <svg
                className="w-6 h-6 text-green-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M5 13l4 4L19 7"
                />
              </svg>
            </div>
            <AlertDialogDescription className="text-center text-green-600 font-medium">
              {dataType === 'incremental' 
                ? "Dane inkrementalne zostały przekonwertowane na skumulowane i poprawnie wczytane (Det)."
                : "Dane skumulowane zostały poprawnie wczytane (Det)."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>OK</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ---------- Spinner podczas ładowania ---------- */}
      {isLoading && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-[#1e1e2f] rounded-lg p-8 flex flex-col items-center w-80">
            <Loader2 className="animate-spin h-10 w-10 text-white mb-6" />
            <div className="w-full bg-gray-700 rounded-full h-4 mb-4 overflow-hidden">
              <div
                className="bg-gray-300 h-full transition-all duration-300 ease-in-out"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="text-white text-sm font-medium">
              Ładowanie… {progress}%
            </div>
          </div>
        </div>
      )}

      {/* MODAL OSTRZEŻENIA O UTRACIE DANYCH */}
      <Modal
        title="Ostrzeżenie"
        message="Wykryto istniejące obliczenia. Czy na pewno chcesz kontynuować? Wszystkie obecne obliczenia i wyniki analizy zostaną utracone."
        isOpen={showWarningModal}
        onConfirm={handleConfirmDataReplace}
        onCancel={handleCancelDataReplace}
      />

      {/* MODAL EDYCJI TRÓJKĄTA - pełnoekranowy */}
      {showEditModal && (
        <div className="fixed inset-0 z-50 bg-[#1a1a2e] flex flex-col">
          {/* Nagłówek modala */}
          <div className="flex items-center justify-between p-4 border-b border-white/10 bg-[#1a1a2e]">
            <h2 className="text-xl font-semibold text-white">
              ✏️ Edycja trójkąta danych paid
            </h2>
            <Button
              onClick={handleEditClose}
              variant="outline"
              size="sm"
              className="text-white border-white/20 hover:bg-white/10"
            >
              ✕ Zamknij
            </Button>
          </div>
          
          {/* Zawartość modala */}
          <div className="flex-1 overflow-hidden p-4">
            <EditablePaidTriangle 
              ref={editTriangleRef}
              onCancel={() => setShowEditModal(false)}
              onFinalSave={handleFinalEditSave}
              hasExistingCalculations={checkExistingCalculations}
            />
          </div>
        </div>
      )}

    </div>
  );
}
