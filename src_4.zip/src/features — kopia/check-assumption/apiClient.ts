import type { ResidualsResp, DependenceResp, Dep2Resp } from './types';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

// Helper function to display data as table
const displayDataAsTable = (data: any[][], title: string) => {
  console.log(`\n=== ${title} ===`);
  console.table(data);
  console.log(`Wymiary: ${data.length} x ${data[0]?.length || 0}`);
  console.log('Pierwszych 3 wierszy:');
  data.slice(0, 3).forEach((row, i) => {
    console.log(`Wiersz ${i}:`, row);
  });
  console.log('================\n');
};

// Transform raw table data to triangle format expected by backend
const transformToTriangle = (rawData: any[][]): (number | null)[][] => {
  if (!rawData || rawData.length < 2) {
    console.warn('Brak danych lub za mało wierszy');
    return [];
  }

  console.log('=== TRANSFORMACJA DANYCH ===');
  console.log('Dane surowe przed transformacją:');
  displayDataAsTable(rawData, 'DANE SUROWE');

  // Usuń pierwszy wiersz (nagłówki) i pierwszą kolumnę (lata) z każdego wiersza
  const triangleData = rawData
    .slice(1) // usuń pierwszy wiersz (nagłówki)
    .map(row => 
      row.slice(1) // usuń pierwszą kolumnę (lata)
        .map(cell => {
          // Konwertuj puste stringi na null, resztę na liczby
          if (cell === '' || cell === null || cell === undefined) {
            return null;
          }
          const num = Number(cell);
          return isNaN(num) ? null : num;
        })
    );

  console.log('Dane po transformacji:');
  displayDataAsTable(triangleData, 'TRIANGLE DATA');
  console.log('Przykład pierwszego wiersza:', triangleData[0]);
  console.log('============================');

  return triangleData;
};

export class CheckAssumptionService {
  static async analyzeResiduals(triangle: any[][], alpha: number): Promise<ResidualsResp> {
    console.log('=== ANALYZE RESIDUALS DEBUG ===');
    
    // Wyświetl dane jako tabelę
    if (triangle && Array.isArray(triangle)) {
      displayDataAsTable(triangle, 'DANE Z STORE (RAW)');
      
      // Transformuj dane do formatu triangle
      const transformedTriangle = transformToTriangle(triangle);
      
      const payload = { triangle: transformedTriangle, alpha };
      console.log('Payload to send:', payload);
      
      // Pokaż też sample JSON (pierwsze 3 wiersze)
      const samplePayload = { 
        triangle: transformedTriangle.slice(0, 3), 
        alpha 
      };
      console.log('Sample JSON (3 pierwsze wiersze):');
      console.log(JSON.stringify(samplePayload, null, 2));
      console.log('===========================');
      
      const response = await fetch(`${API_BASE_URL}/analyze-residuals`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      console.log('Response status:', response.status);
      console.log('Response ok:', response.ok);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('API Error details:', {
          status: response.status,
          statusText: response.statusText,
          errorText: errorText
        });
        throw new Error(`Błąd pobierania danych z /analyze-residuals: ${response.status} ${errorText}`);
      }

      return response.json();
    } else {
      console.log('Triangle data is not an array or is null:', triangle);
      throw new Error('Brak danych triangular');
    }
  }

  static async analyzeDependence(triangle: any[][], ci: number): Promise<DependenceResp> {
    console.log('=== ANALYZE DEPENDENCE DEBUG ===');
    
    const transformedTriangle = transformToTriangle(triangle);
    const payload = { triangle: transformedTriangle, ci: ci };
    
    console.log('CI value:', ci);
    console.log('Payload:', payload);
    console.log('Transformed triangle sample:', transformedTriangle.slice(0, 3));
    console.log('===============================');
    
    const response = await fetch(`${API_BASE_URL}/analyze-dependence`, {
      method: 'POST',  
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    console.log('Response status:', response.status);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('API Error details:', {
        status: response.status,
        statusText: response.statusText,
        errorText: errorText
      });
      throw new Error(`Błąd pobierania danych z /analyze-dependence: ${response.status} ${errorText}`);
    }

    return response.json();
  }

  static async analyzeDep2(triangle: any[][], ci: number): Promise<Dep2Resp> {
    console.log('=== ANALYZE DEP2 DEBUG ===');
    
    const transformedTriangle = transformToTriangle(triangle);
    const payload = { triangle: transformedTriangle, ci: ci };
    
    console.log('CI value:', ci);
    console.log('Payload:', payload);
    console.log('Transformed triangle sample:', transformedTriangle.slice(0, 3));
    console.log('=========================');
    
    const response = await fetch(`${API_BASE_URL}/analyze-dep2`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    console.log('Response status:', response.status);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('API Error details:', {
        status: response.status,
        statusText: response.statusText,
        errorText: errorText
      });
      throw new Error(`Błąd pobierania danych z /analyze-dep2: ${response.status} ${errorText}`);
    }

    return response.json();
  }
}
