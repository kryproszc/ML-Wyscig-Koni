import React from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Area,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceLine,
} from 'recharts';

interface DensityChartProps {
  title: string;
  curve: Array<[number, number]>;
  ciArea: Array<[number, number]>;
  referenceValue: number;
  domain?: [number, number];
}

export const DensityChart: React.FC<DensityChartProps> = ({
  title,
  curve,
  ciArea,
  referenceValue,
  domain,
}) => {
  const curveData = curve.map(([x, y]) => ({ x, y }));
  const areaData = ciArea.map(([x, y]) => ({ x, y }));

  const chartDomain = domain || [
    Math.min(...curve.map(([x]) => x)),
    Math.max(...curve.map(([x]) => x)),
  ];

  return (
    <div className="bg-white border border-gray-300 rounded shadow p-6 text-gray-800 w-full">
      {title && <h4 className="text-sm font-medium mb-4">{title}</h4>}
      <ResponsiveContainer width="100%" height={400}>
        <ComposedChart data={curveData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis type="number" dataKey="x" domain={chartDomain} />
          <YAxis />
          <Tooltip formatter={(v: number) => v.toFixed(3)} />
          <Line
            type="monotone"
            dataKey="y"
            stroke="#000"
            dot={false}
            strokeWidth={1.5}
          />
          <Area
            type="monotone"
            dataKey="y"
            data={areaData}
            fill="#999"
            fillOpacity={0.4}
            isAnimationActive={false}
          />
          <ReferenceLine
            x={referenceValue}
            stroke="red"
            strokeWidth={2}
            isFront
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
};
