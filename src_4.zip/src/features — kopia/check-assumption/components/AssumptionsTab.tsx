import React, { useMemo, useState } from 'react';
import { ResidualChart } from './ResidualChart';
import { CHART_CONFIGS } from '../constants';
import type { ResidualsResp } from '../types';

interface AssumptionsTabProps {
  data: ResidualsResp | null;
  isLoading: boolean;
  error: string | null;
  alpha: number;
  onAlphaChange: (value: number) => void;
}

export const AssumptionsTab: React.FC<AssumptionsTabProps> = ({
  data,
  isLoading,
  error,
  alpha,
  onAlphaChange,
}) => {
  // Lokalny stan dla pola tekstowego
  const [localAlpha, setLocalAlpha] = useState(alpha.toString());
  const [showModal, setShowModal] = useState(false);

  // Synchronizuj lokalny stan z zewnętrznym parametrem
  React.useEffect(() => {
    setLocalAlpha(alpha.toString());
  }, [alpha]);

  const handleCalculate = () => {
    const numValue = parseFloat(localAlpha);
    
    // Sprawdź czy wartość jest poprawna
    if (isNaN(numValue)) {
      setLocalAlpha(alpha.toString());
      return;
    }
    
    // Sprawdź granice - pokaż modal dla 0
    if (numValue <= 0) {
      setShowModal(true);
      return;
    }
    
    // Sprawdź górną granicę
    if (numValue > 2) {
      setLocalAlpha(alpha.toString());
      return;
    }
    
    // Wartość jest OK - wyślij na backend
    onAlphaChange(numValue);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleCalculate();
    }
  };

  const chartData = useMemo(() => {
    if (!data) return [];
    
    return CHART_CONFIGS.map((cfg) => ({
      ...cfg,
      scatter: data.obs_vs_fitted.map((d) => ({
        x: cfg.xAccessor(d),
        y: d.standard_residuals,
      })),
      lowess: data.lowess_results[cfg.key].map((d) => ({
        x: d.x,
        y: d.lowess,
      })),
    }));
  }, [data]);

  return (
    <div className="text-white px-8 py-6 min-h-screen w-full">
      {/* Header z kontrolkami */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-blue-400">
            Analiza reszt modelu
          </h2>
          
          {/* Kompaktowe kontrolki Alpha */}
          <div className="flex items-center gap-4 bg-slate-800/80 px-6 py-4 rounded-lg border-2 border-slate-600 shadow-lg backdrop-blur-sm">
            <label className="text-sm font-semibold text-slate-200">
              Parametr Alpha:
            </label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="0"
                max="2"
                step="0.001"
                value={localAlpha}
                onChange={(e) => setLocalAlpha(e.target.value)}
                onKeyPress={handleKeyPress}
                className="w-24 px-3 py-2 text-white bg-slate-800 rounded-md border-2 border-slate-600 focus:outline-none focus:border-blue-400 focus:bg-slate-700 text-sm text-center font-mono shadow-inner"
                placeholder="1.000"
              />
              <button
                onClick={handleCalculate}
                disabled={isLoading}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 text-white text-sm rounded-md transition-all font-semibold shadow-lg hover:shadow-xl hover:scale-105 disabled:hover:scale-100"
              >
                Oblicz
              </button>
            </div>
          </div>
        </div>
        
        {/* Status info */}
        <div className="text-sm text-gray-400">
          Aktualnie: α = {alpha.toFixed(6)} (parametr wag dla reszt) • Dozwolony zakres: (0, 2]
          {isLoading && <span className="ml-4 text-blue-400 animate-pulse">• Obliczanie...</span>}
        </div>
      </div>

      {/* Error display */}
      {error && (
        <div className="mb-6 p-4 bg-red-900/20 border border-red-700 rounded-lg">
          <p className="text-red-400">{error}</p>
        </div>
      )}

      {/* Charts Grid */}
      {data && (
        <div className="space-y-6">
          <h3 className="text-lg font-semibold text-blue-300 border-b border-gray-700 pb-2">
            Wykresy diagnostyczne reszt
          </h3>
          
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
            {chartData.map(({ title, xLabel, scatter, lowess }, idx) => (
              <div key={idx} className="bg-gray-800/30 rounded-lg border border-gray-700 p-6">
                <ResidualChart
                  title={title}
                  xLabel={xLabel}
                  scatter={scatter}
                  lowess={lowess}
                />
              </div>
            ))}
          </div>

          {/* Interpretacja */}
          <div className="mt-8 bg-blue-900/20 border border-blue-700 rounded-lg p-6">
            <h4 className="text-lg font-semibold text-blue-300 mb-3">
              💡 Interpretacja wykresów
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-300">
              <div>
                <p><strong>Reszty vs. Dopasowane:</strong> Sprawdza homoskedastyczność - reszty powinny być równomiernie rozłożone</p>
                <p><strong>Reszty vs. Origin period:</strong> Wykrywa trendy czasowe w resztach</p>
              </div>
              <div>
                <p><strong>Reszty vs. Calendar period:</strong> Identyfikuje efekty kalendarzowe</p>
                <p><strong>Reszty vs. Development period:</strong> Sprawdza założenia o rozwoju szkód</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Loading state */}
      {isLoading && !data && (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
          <span className="ml-3 text-gray-400">Ładowanie analizy reszt...</span>
        </div>
      )}

      {/* Empty state */}
      {!data && !isLoading && !error && (
        <div className="text-center py-12 text-gray-500">
          <div className="text-4xl mb-4">📉</div>
          <p>Ustaw parametr Alpha i kliknij "Oblicz", aby rozpocząć analizę reszt</p>
        </div>
      )}

      {/* Modal ostrzeżenia */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-lg p-6 max-w-md mx-4 border border-gray-600">
            <div className="flex items-center mb-4">
              <div className="text-yellow-400 text-2xl mr-3">⚠️</div>
              <h3 className="text-lg font-semibold text-white">Nieprawidłowa wartość</h3>
            </div>
            <p className="text-gray-300 mb-6">
              Wartość parametru Alpha musi być z zakresu <strong>(0, 2]</strong>.
              <br />
              Wartość 0 nie jest dozwolona.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowModal(false);
                  setLocalAlpha(alpha.toString()); // Reset do aktualnej wartości
                }}
                className="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded transition-colors"
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
