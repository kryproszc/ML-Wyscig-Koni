import React from 'react';
import { useCheckAssumptionData } from '../hooks/useCheckAssumptionData';
import { TAB_CONFIGS } from '../constants';
import { ModelTab } from './ModelTab';
import { AssumptionsTab } from './AssumptionsTab';
import { AnalysisTab } from './AnalysisTab';
import { SummaryTab } from './SummaryTab';
import type { TabKey } from '../types';

export const CheckAssumption: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    alphaAssumptions,
    setAlphaAssumptions,
    ciAnalysis,
    setCiAnalysis,
    ciSummary,
    setCiSummary,
    residualsData,
    dependenceData,
    dep2Data,
    isLoadingResiduals,
    isLoadingDependence,
    isLoadingDep2,
    error,
  } = useCheckAssumptionData();

  const renderTabContent = () => {
    switch (activeTab) {
      case 'model':
        return <ModelTab />;
      
      case 'assumptions':
        return (
          <AssumptionsTab
            data={residualsData}
            isLoading={isLoadingResiduals}
            error={error}
            alpha={alphaAssumptions}
            onAlphaChange={setAlphaAssumptions}
          />
        );
      
      case 'analysis':
        return (
          <AnalysisTab
            data={dependenceData}
            isLoading={isLoadingDependence}
            error={error}
            ci={ciAnalysis}
            onCiChange={setCiAnalysis}
          />
        );
      
      case 'summary':
        return (
          <SummaryTab
            data={dep2Data}
            isLoading={isLoadingDep2}
            error={error}
            ci={ciSummary}
            onCiChange={setCiSummary}
          />
        );
      
      default:
        return null;
    }
  };

  return (
    <div>
      {/* Navigation tabs */}
      <nav className="flex gap-10 border-b border-slate-700 mb-6">
        {TAB_CONFIGS.map(({ key, label }) => (
          <button
            key={key}
            onClick={() => setActiveTab(key as TabKey)}
            className={`
              relative pb-2 text-sm sm:text-base font-semibold transition-colors
              ${
                activeTab === key
                  ? 'text-sky-400 after:absolute after:left-0 after:bottom-0 after:h-0.5 after:w-full after:bg-sky-400'
                  : 'text-slate-300 hover:text-sky-300'
              }
            `}
          >
            {label}
          </button>
        ))}
      </nav>

      {/* Tab content */}
      {renderTabContent()}
    </div>
  );
};
