'use client';

import { useEffect } from 'react';
import { useUserStore } from '@/app/_components/useUserStore';
import { HomeTabs } from '@/app/_components/HomeTabs';
import { UserSelector } from '@/app/_components/UserSelector';

export default function Page() {
  const userId = useUserStore((s) => s.userId);
  const setUserId = useUserStore((s) => s.setUserId);


  return userId ? <HomeTabs /> : <UserSelector />;
}
