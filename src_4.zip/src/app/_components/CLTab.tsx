import { TableData } from '@/components/TableData';
import { Button } from '@/components/ui/button';
import { useTableStore } from '@/stores/tableStore';
import { useState } from 'react';

export function CLTab(): React.ReactElement | null {
  const {
    clData,
    clWeights,
    setClWeights,
  } = useTableStore();

  const [decimals, setDecimals] = useState(2);

  const handleClick = (i: number, j: number) => {
    if (!clWeights) return;

    const updated = clWeights.map((row, rowIndex) =>
      rowIndex === i
        ? row.map((cell, colIndex) =>
            colIndex === j ? (cell === 1 ? 0 : 1) : cell
          )
        : [...row]
    );

    setClWeights(updated);
  };

  const resetSelection = () => {
    if (!clData) return;

    const newWeights = clData.slice(1).map((row) => row.slice(1).map(() => 1));
    setClWeights(newWeights);
  };

  if (!clData || !clWeights) {
    return <div className="text-red-400">Wróć do zakłądki 1. Trójkąt i zatwierdź trójkąt.</div>;
  }

  return (
    <div className="flex gap-8 p-8">
      {/* Panel boczny */}
      <div className="w-64 shrink-0 space-y-4">
        {/* Kontrolka miejsc po przecinku */}
        <div className="bg-gray-800 rounded-lg p-4">
          <label className="text-white text-sm font-medium mb-2 block">
            Miejsca po przecinku
          </label>
          <input
            type="number"
            min="0"
            max="6"
            value={decimals}
            onChange={(e) => setDecimals(Math.max(0, Math.min(6, parseInt(e.target.value) || 0)))}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        {/* Resetuj zaznaczenia */}
        <button
          onClick={resetSelection}
          className="w-full py-4 px-5 bg-gradient-to-r from-orange-600 to-orange-500 text-white rounded-xl font-bold hover:from-orange-700 hover:to-orange-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
        >
          Resetuj zaznaczenia
        </button>
      </div>

      {/* Tabela */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white">
          <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
            <h3 className="font-bold text-gray-800 text-lg tracking-tight">Trójkąt reszt</h3>
          </div>
          <div className="overflow-auto p-4" style={{ maxHeight: 'calc(100vh - 300px)' }}>
            <TableData
              data={clData}
              selected={[
                Array(clData[0]?.length || 0).fill(1),
                ...clWeights.map((row) => [1, ...row]),
              ]}
              onClick={(i, j) => handleClick(i - 1, j - 1)}
              variant="light"
              decimals={decimals}
            />
          </div>
        </div>
      </div>
    </div>
  );
}