import "@/styles/globals.css";
import type { Metadata } from "next";
import { GeistSans, GeistMono } from "geist/font"; // ← poprawne nazwy
import { Providers } from "./providers";

export const metadata: Metadata = {
  title: "ResLab",
  description: "Aplikacja do analizy rezerw ubezpieczeniowych z wykorzystaniem metod deterministycznych i stochastycznych. Umożliwia pracę na trójkątach szkód, porównanie wyników oraz ocenę ryzyka rezerw.",
  icons: [
    { rel: "icon", url: "/favicon.ico" },
    { rel: "icon", url: "/favicon.svg", type: "image/svg+xml" },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${GeistSans.variable} ${GeistMono.variable}`.trim()} suppressHydrationWarning>
      <body className="dark">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
