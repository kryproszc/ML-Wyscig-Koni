import { create } from 'zustand';
import type { DataType } from '@/components/DataTypeSelector';
import type { TriangleType } from '@/components/TriangleTypeSelector';

type InputSettingsStore = {
  // Typ trójkąta (Paid/Incurred)
  triangleType: TriangleType;
  setTriangleType: (type: TriangleType) => void;
  
  // Typ danych (Skumulowane/Inkrementalne)
  dataType: DataType;
  setDataType: (type: DataType) => void;
  
  // Reset wszystkich ustawień
  reset: () => void;
};

export const useInputSettingsStore = create<InputSettingsStore>((set) => ({
  // Domyślne wartości
  triangleType: 'paid',
  dataType: 'cumulative',
  
  // Settery
  setTriangleType: (type) => set({ triangleType: type }),
  setDataType: (type) => set({ dataType: type }),
  
  // Reset do wartości domyślnych
  reset: () => set({ 
    triangleType: 'paid', 
    dataType: 'cumulative' 
  }),
}));
