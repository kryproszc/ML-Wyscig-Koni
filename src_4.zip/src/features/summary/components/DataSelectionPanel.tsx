import React from 'react';
import Modal from '@/components/Modal';
import type { SelectOption } from '@/shared/hooks/useDataOptions';

export interface DataSelectionPanelProps {
  selectedA: string | null;
  selectedB: string | null;
  setSelectedA: (value: string | null) => void;
  setSelectedB: (value: string | null) => void;
  allOptions: SelectOption[];
  onSendData: () => void;
  onClearComparisons: () => void;
  onExportToExcel: () => void;
  onExportCalculations: () => void;
  showModal: boolean;
  setShowModal: (show: boolean) => void;
  methodType: string; // np. "Paid", "Incurred"
}

export const DataSelectionPanel: React.FC<DataSelectionPanelProps> = ({
  selectedA,
  selectedB,
  setSelectedA,
  setSelectedB,
  allOptions,
  onSendData,
  onClearComparisons,
  onExportToExcel,
  onExportCalculations,
  showModal,
  setShowModal,
  methodType,
}) => {
  return (
    <div className="w-64 shrink-0 space-y-4">
      <h2 className="text-lg font-semibold">Wybierz dane do analizy</h2>

      <div className="bg-gray-800 rounded-lg p-4">
        <label className="text-white text-sm font-medium mb-2 block">Współczynniki 1</label>
        <select
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          onChange={(e) => setSelectedA(e.target.value || null)}
          value={selectedA || ''}
        >
          <option value="">Wybierz współczynniki</option>
          {allOptions.map((o) => (
            <option key={o.key} value={o.key}>
              {o.label}
            </option>
          ))}
        </select>
      </div>

      <div className="bg-gray-800 rounded-lg p-4">
        <label className="text-white text-sm font-medium mb-2 block">Współczynniki 2</label>
        <select
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          onChange={(e) => setSelectedB(e.target.value || null)}
          value={selectedB || ''}
        >
          <option value="">Wybierz współczynniki</option>
          {allOptions.map((o) => (
            <option key={o.key} value={o.key}>
              {o.label}
            </option>
          ))}
        </select>
      </div>

      <button
        onClick={onSendData}
        className="w-full py-4 px-5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl font-bold hover:from-emerald-700 hover:to-emerald-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
      >
        Oblicz
      </button>


      <button
        onClick={onClearComparisons}
        className="w-full py-4 px-5 bg-gradient-to-r from-orange-600 to-orange-500 text-white rounded-xl font-bold hover:from-orange-700 hover:to-orange-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
      >
        🧹 Wyczyść porównania
      </button>
      <button
        onClick={onExportCalculations}
        className="w-full py-4 px-5 bg-gradient-to-r from-amber-600 to-amber-500 text-white rounded-xl font-bold hover:from-amber-700 hover:to-amber-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
      >
        🧮 Eksportuj obliczenia
      </button>

      <Modal
        isOpen={showModal}
        title="Wymagane dane"
        message="Aby wysłać dane, musisz wybrać przynajmniej jeden zestaw współczynników"
        onCancel={() => setShowModal(false)}
        onlyOk
      />

      <div className="text-sm text-gray-300 pt-6">
        Widok: <strong>Metoda {methodType}</strong>, krok: <strong>Wyniki</strong>
      </div>
    </div>
  );
};
