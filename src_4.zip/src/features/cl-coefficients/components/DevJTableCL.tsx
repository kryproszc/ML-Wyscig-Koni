'use client';

import React from 'react';
import { CoefficientsChart } from './CoefficientsChart';

import DevJTableBase from '@/shared/ui/organisms/DevJTable/DevJTableBase';
import type { DevJResult } from '@/shared/ui/organisms/DevJTable/DevJTableBase';

import { fmt, mergePreview } from '@/shared/ui/organisms/DevJTable/useDevJHelpers';

import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import type { CustomCell } from '@/stores/trainDevideStoreDeterministyczny';
type Props = {
  devJResults: DevJResult[];
  selectedVolume?: number;
  selectedSubIndex?: number;
  onSelectVolume: (v: number, subIndex?: number) => void;
  columnLabels?: string[]; // opcjonalne etykiety kolumn
  trainDevideData?: number[][]; // dane z tabeli współczynników rok do roku
  externalShowChart?: boolean; // kontrola wykresu z zewnątrz (panel boczny)
};

export default function DevJTableCL({
  devJResults,
  selectedVolume: selectedVolumeFromProps,
  selectedSubIndex,
  onSelectVolume,
  columnLabels,
  trainDevideData,
  externalShowChart = false,
}: Props) {
  /* --------------------- store selectors -------------------- */
  const {
    finalDevJ,
    setFinalDevJ,
    devFinalCustom,
    setDevFinalValue,
    clearDevFinalValue,
    clearAllDevFinalValues,
    setDevPreviewCandidate,

    isConfirmModalOpen,
    openConfirmModal,
    closeConfirmModal,
    confirmFinalDevJ,
    
    decimalPlaces, // dodane dla formatowania
    
    // Stany wykresu z store
    chartSelectedColumn,
    chartReferenceType,
    setChartSelectedColumn,
    setChartReferenceType,
    
    // Macierz wag do wyświetlenia w konsoli
    selectedWeightsDet,
  } = useTrainDevideStoreDet();

  // Wyświetl macierz wag w konsoli
  React.useEffect(() => {
    console.log('=== MACIERZ WAG (cl_weights / selectedWeightsDet) ===');
    console.log('Macierz wag:', selectedWeightsDet);
    console.log('Typ:', selectedWeightsDet ? 'number[][]' : 'undefined');
    if (selectedWeightsDet) {
      console.log('Wymiary:', selectedWeightsDet.length, 'x', selectedWeightsDet[0]?.length || 0);
      console.table(selectedWeightsDet);
    }
  }, [selectedWeightsDet]);

  /* --------------------- wykres state ---------------------- */
  const [showChart, setShowChart] = React.useState(false);
  
  // Usunięte lokalne stany - teraz używamy store
  // const [selectedColumnForChart, setSelectedColumnForChart] = React.useState<number>(0);
  // const [selectedReferenceType, setSelectedReferenceType] = React.useState<string>('none');

  // Użyj zewnętrznego stanu jeśli jest dostępny, inaczej lokalny
  const effectiveShowChart = externalShowChart || showChart;
  
  // Ref do wykresu dla przewijania
  const chartRef = React.useRef<HTMLDivElement>(null);

  /* --------------------- helpers ---------------------------- */
  const maxLen = React.useMemo(() => {
    if (trainDevideData && trainDevideData.length > 0) {
      return Math.max(...trainDevideData.map(row => row.length));
    }
    return Math.max(...devJResults.map((r) => r.values.length));
  }, [devJResults, trainDevideData]);

  const formatNumber = React.useCallback((n?: number) => {
    if (typeof n !== 'number') return '-';
    return n.toFixed(decimalPlaces);
  }, [decimalPlaces]);

  // Transformacja danych dla wykresu - wybrana kolumna vs wszystkie wolumy (z tabeli współczynników)
  const transformDataForChart = React.useCallback(() => {
    if (!trainDevideData || trainDevideData.length === 0 || chartSelectedColumn >= maxLen) return [];
    
    const chartData: Array<{
      volumeLabel: string;
      volume: number;
      value: number;
    }> = [];
    
    trainDevideData.forEach((row, rowIndex) => {
      const value = row[chartSelectedColumn];
      // Tylko rzeczywiste liczby - pomijamy null, undefined, NaN
      if (typeof value === 'number' && !isNaN(value) && isFinite(value)) {
        chartData.push({
          volumeLabel: `Wiersz ${rowIndex + 1}`,
          volume: rowIndex + 1, // używamy indeksu wiersza jako volume
          value: value
        });
      }
    });
    
    console.log('[DevJTableCL] Chart data for column', chartSelectedColumn, ':', chartData);
    
    return chartData;
  }, [trainDevideData, chartSelectedColumn, maxLen]);

  // Funkcja do pobierania wartości referencyjnej
  const getReferenceValue = React.useCallback(() => {
    if (!trainDevideData || chartReferenceType === 'none') return null;
    
    if (chartReferenceType === 'initial') {
      // Initial Selection - z finalDevJ lub devJResults
      if (finalDevJ && finalDevJ.values.length > chartSelectedColumn) {
        return finalDevJ.values[chartSelectedColumn];
      }
    } else if (chartReferenceType.startsWith('volume_')) {
      // Volume z indeksem - pobierz z trainDevideData
      const volumeIndexStr = chartReferenceType.split('_')[1];
      if (volumeIndexStr) {
        const volumeIndex = parseInt(volumeIndexStr);
        if (trainDevideData[volumeIndex] && trainDevideData[volumeIndex].length > chartSelectedColumn) {
          const value = trainDevideData[volumeIndex][chartSelectedColumn];
          return typeof value === 'number' && !isNaN(value) ? value : null;
        }
      }
    }
    
    return null;
  }, [trainDevideData, chartReferenceType, chartSelectedColumn, finalDevJ]);

  const chartData = transformDataForChart();
  const referenceValue = getReferenceValue();

  // Automatyczne przewijanie do wykresu gdy externalShowChart się włącza
  React.useEffect(() => {
    if (externalShowChart && chartRef.current) {
      // Małe opóźnienie żeby wykres się wyrenderował
      setTimeout(() => {
        chartRef.current?.scrollIntoView({ 
          behavior: 'smooth', 
          block: 'start' 
        });
      }, 100);
    }
  }, [externalShowChart]);

  // Lista dostępnych volume z devJResults
  const availableVolumes = React.useMemo(() => {
    return devJResults.map(result => ({
      volume: result.volume,
      subIndex: result.subIndex,
      label: `Volume ${result.volume}${result.subIndex !== undefined ? `.${result.subIndex}` : ''}`
    }));
  }, [devJResults]);

  // Lista dostępnych kolumn do wyboru
  const availableColumns = React.useMemo(() => {
    return Array.from({ length: maxLen }, (_, j) => ({
      index: j,
      label: (columnLabels && columnLabels.length > j ? columnLabels[j] : `j=${j}`) || `col-${j}`
    }));
  }, [maxLen, columnLabels]);

  const displayed = (j: number) => {
    const cell = (devFinalCustom as Record<number, CustomCell>)?.[j];
    return cell ? cell.value : finalDevJ?.values[j];
  };

  // Funkcja do znajdowania odpowiedniego odchylenia standardowego dla wybranego współczynnika
  const getSelectedStandardDeviation = (j: number) => {
    const selectedValue = displayed(j);
    if (selectedValue === undefined) return undefined;

    // Sprawdź czy to custom value z informacją o źródle
    const customCell = (devFinalCustom as Record<number, CustomCell>)?.[j];
    if (customCell && customCell.sourceVolume !== undefined) {
      // Znajdź odpowiednie volume w devJResults
      const sourceResult = devJResults.find(
        (result) => 
          result.volume === customCell.sourceVolume && 
          (result.subIndex ?? 0) === (customCell.sourceSubIndex ?? 0)
      );
      return sourceResult?.sdValues?.[j];
    }

    // Dla wartości z finalDevJ
    if (finalDevJ?.values[j] === selectedValue) {
      return finalDevJ?.sdValues?.[j];
    }

    return undefined;
  };

  // Przygotowanie mapy customSelections dla precyzyjnego podświetlania
  const getCustomSelections = () => {
    const selections: Record<number, { sourceVolume: number; sourceSubIndex?: number }> = {};
    
    // Dodaj custom selections z devFinalCustom
    Object.entries(devFinalCustom ?? {}).forEach(([j, cell]) => {
      if (cell.sourceVolume !== undefined) {
        selections[Number(j)] = {
          sourceVolume: cell.sourceVolume,
          sourceSubIndex: cell.sourceSubIndex,
        };
      }
    });
    
    // Dodaj selections z finalDevJ (jeśli nie ma custom override)
    if (finalDevJ) {
      Array.from({ length: maxLen }).forEach((_, j) => {
        if (selections[j]) return; // skip jeśli już ma custom selection
        
        const value = finalDevJ.values[j];
        if (value !== undefined) {
          selections[j] = {
            sourceVolume: finalDevJ.volume,
            sourceSubIndex: finalDevJ.subIndex,
          };
        }
      });
    }
    
    return selections;
  };

  const handleCell = (j: number, v: number, sourceVolume: number, sourceSubIndex?: number, event?: React.MouseEvent) => {
    // Sprawdź czy kliknięto na dokładnie tę samą komórkę (volume + subIndex + wartość)
    const customCell = (devFinalCustom as Record<number, CustomCell>)?.[j];
    const isExactSameCell = customCell && 
      customCell.value === v && 
      customCell.sourceVolume === sourceVolume && 
      (customCell.sourceSubIndex ?? 0) === (sourceSubIndex ?? 0);
    
    if (isExactSameCell) {
      // Klik na dokładnie tę samą komórkę - odznacz
      clearDevFinalValue(j);
    } else {
      // Zaznacz nową komórkę
      setDevFinalValue(j, 'dev_j', v, sourceVolume, sourceSubIndex);
    }
  };

  const handleSelectFinal = (v: number, subIndex?: number) => {
    onSelectVolume(v, subIndex);
    // Usunięte automatyczne ustawianie Final? - użytkownik wybiera to ręcznie
  };

  const handleSelectAsBaseFinal = (v: number, subIndex?: number) => {
    const res = devJResults.find((r) => r.volume === v && (r.subIndex ?? 0) === (subIndex ?? 0));
    if (!res) return;

    if (Object.keys(devFinalCustom ?? {}).length) {
      openConfirmModal(res);
    } else {
      clearAllDevFinalValues();
      setFinalDevJ(res);
    }
  };

  /* auto-select first volume for display, but Final? is user choice */
  React.useEffect(() => {
    // Automatycznie wybierz pierwszy wiersz do podglądu Initial Selection
    if (devJResults.length > 0 && !finalDevJ) {
      const firstResult = devJResults[0];
      if (firstResult) {
        clearAllDevFinalValues();
        setFinalDevJ(firstResult); // Potrzebne dla tabeli Initial Selection
        onSelectVolume(firstResult.volume, firstResult.subIndex);
        // Ustaw pierwszą kolumnę jako domyślną dla wykresu
        setChartSelectedColumn(0);
      }
    }
  }, [devJResults, finalDevJ, setFinalDevJ, clearAllDevFinalValues, onSelectVolume]);

  /* preview update */
  React.useEffect(() => {
    if (!finalDevJ?.values) return;
    setDevPreviewCandidate(
      mergePreview(finalDevJ.values, devFinalCustom as any)
    );
  }, [finalDevJ, devFinalCustom, setDevPreviewCandidate]);

  /* --------------------- render ------------------------------ */
  return (
    <>
      <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white mb-8">
        <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
          <h3 className="font-bold text-gray-800 text-lg tracking-tight">
            Tabela ważonych uśrednionych współczynników
          </h3>
        </div>
        <div className="overflow-auto p-4">
          <DevJTableBase
            results={devJResults}
            maxLength={maxLen}
            columnLabels={columnLabels}
            displayed={displayed}
            selectedVolume={selectedVolumeFromProps}
            selectedSubIndex={selectedSubIndex}
            onSelectVolume={handleSelectFinal}
            finalSelectedVolume={finalDevJ?.volume}
            finalSelectedSubIndex={finalDevJ?.subIndex}
            onSelectFinal={handleSelectAsBaseFinal}
            onCellToggle={handleCell}
            isConfirmModalOpen={isConfirmModalOpen}
            onConfirmFinal={confirmFinalDevJ}
            onCancelConfirm={closeConfirmModal}
            formatNumber={formatNumber} // przekazanie funkcji formatowania
            customSelections={getCustomSelections()} // precyzyjne podświetlanie
          />
        </div>
      </div>

      {/* Tabela odchylen standardowych */}
      {devJResults.length > 0 && (
        <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white mb-8">
          <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
            <h3 className="font-bold text-gray-800 text-lg tracking-tight">
              Tabela ważonych uśrednionych odchyleń standardowych
            </h3>
          </div>
          
          {/* wrapper: pełna szerokość + poziomy scroll */}
          <div className="overflow-auto p-4">
            <div className="relative w-full max-w-full overflow-x-auto">
            <table className="min-w-max bg-white rounded-xl shadow-md text-sm" style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
              <thead>
                <tr>
                  <th className="border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold text-left w-48 rounded-tl-xl">Volume</th>
                  {Array.from({ length: maxLen }).map((_, j) => {
                    const isLast = j === maxLen - 1
                    return (
                      <th
                        key={j}
                        className={`border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold text-center w-24 ${isLast ? 'rounded-tr-xl' : ''}`}
                      >
                        {columnLabels && columnLabels.length > j ? columnLabels[j] : `j=${j}`}
                      </th>
                    )
                  })}
                </tr>
              </thead>

              <tbody>
                {devJResults.map((result, rowIdx) => {
                  const isLastRow = rowIdx === devJResults.length - 1
                  return (
                  <tr
                    key={`${result.volume}-${result.subIndex ?? 0}`}
                    className={
                      selectedVolumeFromProps === result.volume && 
                      selectedSubIndex === (result.subIndex ?? 0)
                        ? "bg-blue-100" // podświetlenie aktualnie wybranego volume
                        : "hover:bg-gray-50"
                    }
                  >
                    <td className={`border border-gray-300 px-3 py-2 bg-gray-50 font-medium w-48 text-gray-900 ${isLastRow ? 'rounded-bl-xl' : ''}`}>
                      Volume {result.volume}{result.subIndex !== undefined ? `.${result.subIndex}` : ''}
                    </td>
                    {Array.from({ length: maxLen }).map((_, j) => {
                      const sdValue = result.sdValues?.[j];
                      
                      // Logika podświetlania - sprawdź czy ta konkretna komórka jest wybrana
                      const customCell = (devFinalCustom as Record<number, CustomCell>)?.[j];
                      const isThisSpecificCellSelected = customCell && 
                        customCell.value === result.values[j] && 
                        customCell.sourceVolume === result.volume && 
                        (customCell.sourceSubIndex ?? 0) === (result.subIndex ?? 0);

                      const isFinalDevJSelected = !customCell && 
                        finalDevJ?.volume === result.volume && 
                        (finalDevJ?.subIndex ?? 0) === (result.subIndex ?? 0) &&
                        finalDevJ?.values[j] === result.values[j];

                      const isSelected = isThisSpecificCellSelected || isFinalDevJSelected;
                      const isLastCell = j === maxLen - 1
                      
                      return (
                        <td
                          key={j}
                          className={`border border-gray-300 px-3 py-2 text-center transition-colors w-24 ${isLastRow && isLastCell ? 'rounded-br-xl' : ''} ${
                            result.sdValues?.[j] !== undefined
                              ? isSelected 
                                ? "bg-blue-200/70 text-gray-800 cursor-pointer"
                                : "bg-white text-gray-800 hover:bg-gray-100 cursor-pointer"
                              : "bg-gray-200 text-gray-500"
                          }`}
                          onClick={() => {
                            // Klik na odchylenie standardowe automatycznie wybiera odpowiedni współczynnik
                            if (result.values[j] !== undefined) {
                              handleCell(j, result.values[j], result.volume, result.subIndex);
                            }
                          }}
                        >
                          {sdValue !== undefined ? formatNumber(sdValue) : "–"}
                        </td>
                      );
                    })}
                  </tr>
                )})}
              </tbody>
            </table>
            </div>
          </div>
        </div>
      )}
{finalDevJ && (
  <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white mb-8">
    <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
      <h3 className="font-bold text-gray-800 text-lg tracking-tight">
        Tabela wybranych współczynników do dopasowania krzywej
      </h3>
    </div>

    {/* wrapper: pełna szerokość + poziomy scroll */}
    <div className="overflow-auto p-4">
      <div className="relative w-full max-w-full overflow-x-auto">
      <table className="min-w-max bg-white rounded-xl shadow-md text-sm" style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
        <thead>
          <tr>
            <th className="border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold text-left w-48 rounded-tl-xl"></th>
            {Array.from({ length: maxLen }).map((_, j) => {
              const isLast = j === maxLen - 1
              return (
                <th
                  key={j}
                  className={`border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold text-center w-24 ${isLast ? 'rounded-tr-xl' : ''}`}
                >
                  {columnLabels && columnLabels.length > j ? columnLabels[j] : `j=${j}`}
                </th>
              )
            })}
          </tr>
        </thead>

        <tbody>
          <tr>
            <td className="border border-gray-300 px-3 py-2 bg-gray-50 font-medium w-48 text-gray-900 ${devJResults.length > 0 ? '' : 'rounded-bl-xl'}">
              Initial Selection
            </td>
            {Array.from({ length: maxLen }).map((_, j) => {
              const isLast = j === maxLen - 1
              return (
                <td
                  key={j}
                  className={`border border-gray-300 px-3 py-2 text-center bg-white text-gray-900 w-24 ${devJResults.length === 0 && isLast ? 'rounded-br-xl' : ''}`}
                >
                  {formatNumber(displayed(j))}
                </td>
              )
            })}
          </tr>
          {devJResults.length > 0 && (
            <tr>
              <td className="border border-gray-300 px-3 py-2 bg-gray-50 font-medium w-48 text-gray-900 rounded-bl-xl">
                Odchyl. Standardowe
              </td>
              {Array.from({ length: maxLen }).map((_, j) => {
                // Sprawdź czy komórka j jest wybrana
                const isSelected = displayed(j) !== undefined;
                // Znajdź odpowiednie odchylenie dla wybranego współczynnika
                const sdValue = isSelected ? getSelectedStandardDeviation(j) : undefined;
                const isLast = j === maxLen - 1
                
                return (
                  <td
                    key={j}
                    className={`border border-gray-300 px-3 py-2 text-center bg-white text-gray-900 w-24 ${isLast ? 'rounded-br-xl' : ''}`}
                  >
                    {sdValue !== undefined ? formatNumber(sdValue) : "–"}
                  </td>
                );
              })}
            </tr>
          )}
        </tbody>
      </table>
      </div>
    </div>
  </div>
)}

{/* Wykres współczynników rozwoju - pod tabelą Initial Selection */}
{externalShowChart && chartData.length > 0 && (
  <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white mb-8" ref={chartRef}>
    <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
      <h3 className="font-bold text-gray-800 text-lg tracking-tight">
        Współczynniki rok do roku
      </h3>
    </div>
    <div className="p-4">
    
    {/* Kontrolki wykresu */}
    <div className="mb-6 p-6 bg-gray-100 rounded-lg border border-gray-300">
      <div className="flex flex-wrap items-start gap-6">
        <div className="flex flex-col gap-2">
          <label className="text-gray-700 font-semibold text-sm">Wybierz kolumnę:</label>
          <select
            value={chartSelectedColumn}
            onChange={(e) => {
              const newColumn = Number(e.target.value);
              console.log('[DevJTableCL] Changing column to:', newColumn);
              setChartSelectedColumn(newColumn);
            }}
            size={5}
            className="px-4 py-2 bg-white text-gray-800 border border-gray-300 rounded-md focus:border-indigo-500 focus:outline-none min-w-[120px] text-sm shadow-sm"
          >
          {availableColumns.map((col) => (
            <option key={col.index} value={col.index}>
              {col.label}
            </option>
          ))}
          </select>
        </div>
        
        <div className="flex flex-col gap-2">
          <label className="text-gray-700 font-semibold text-sm">Średni współczynnik:</label>
          <select
            value={chartReferenceType}
            onChange={(e) => {
              setChartReferenceType(e.target.value);
            }}
            size={5}
            className="px-4 py-2 bg-white text-gray-800 border border-gray-300 rounded-md focus:border-indigo-500 focus:outline-none min-w-[140px] text-sm shadow-sm"
          >
            <option value="none">Brak</option>
            {availableVolumes.map((vol, index) => (
              <option key={`volume_${index}`} value={`volume_${index}`}>
                {vol.label}
              </option>
            ))}
            <option value="initial">Initial Selection</option>
          </select>
        </div>
        
        <div className="flex flex-col gap-2 justify-end">
          <span className="text-gray-600 text-sm font-medium">
            Dane: {chartData.length} punkt{chartData.length !== 1 ? 'y' : ''}
            {referenceValue !== null && referenceValue !== undefined && (
              <span className="block">Ref: {referenceValue.toFixed(6)}</span>
            )}
          </span>
        </div>
      </div>
    </div>
    
    <CoefficientsChart
      title={`Współczynniki rok-do-roku dla kolumny: ${availableColumns[chartSelectedColumn]?.label || chartSelectedColumn}`}
      data={chartData.map((item, index) => ({
        period: index + 1,
        series: [{
          name: item.volumeLabel,
          value: item.value,
          volume: item.volume
        }]
      }))}
      selectedPeriod={undefined}
      onPeriodSelect={() => {}}
      referenceValue={referenceValue}
      referenceLabel={chartReferenceType === 'none' ? undefined : 
        chartReferenceType === 'initial' ? 'Initial Selection' :
        chartReferenceType.startsWith('volume_') ? (() => {
          const indexStr = chartReferenceType.split('_')[1];
          if (indexStr) {
            const index = parseInt(indexStr);
            return availableVolumes[index]?.label || `Volume ${index}`;
          }
          return 'Unknown Volume';
        })() : undefined}
    />
    </div>
  </div>
)}

    </>
  );
}