'use client';

import { useEffect } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useUserStore } from '@/app/_components/useUserStore';
import {
  useTrainDevideStoreDetIncurred,
} from '@/stores/trainDevideStoreDeterministycznyIncurred';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export function useIncurredCL() {
  const userId = useUserStore((s) => s.userId);
  const store  = useTrainDevideStoreDetIncurred();

  const {
    incurredTriangle,
    trainDevideDetIncurred,
    selectedWeightsDetIncurred,
    selectedCellsDetIncurred,
    volume,
    devJResults,
    setTrainDevideDetIncurred,
    setDevJ,
    addDevJResult,
    resetSelectionDetIncurred,
    toggleRowDetIncurred,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    setMinMaxHighlighting,
    selectedDevJVolume   : selectedVolume,
    selectedDevJSubIndex : selectedSubIndex,
    setSelectedDevJVolume: setSelectedVolume,
  } = store;

  /* -------- mutation 1 -------- */
  const mTrainDivide = useMutation({
    mutationKey: ['trainDivideIncurred', volume],
    mutationFn : async () => {
      const triangle = (incurredTriangle ?? []);
      const res = await fetch(`${API_URL}/calc/incurred/train_devide_incurred`, {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ user_id: userId, incurred_data_det: triangle }),
      });
      return res.json() as Promise<{ train_devide?: number[][] }>;
    },
    onSuccess: (d) => {
      if (d.train_devide) {
        setTrainDevideDetIncurred(d.train_devide);
        // Ustaw wszystkie komórki jako zaznaczone domyślnie
        resetSelectionDetIncurred();
      }
    },
  });

  /* -------- mutation 2 -------- */
  const mCL = useMutation({
    mutationKey: ['clIncurred', volume],
    mutationFn : async () => {
      const safeWeights =
        selectedWeightsDetIncurred?.map((r) => r.map((c) => (c === 1 ? 1 : 0))) ?? [];
      const res = await fetch(`${API_URL}/calc/incurred/cl`, {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({
          user_id          : userId,
          incurred_data_det: incurredTriangle,
          weights          : safeWeights,
        }),
      });
      return res.json() as Promise<{ 
        message?: string;
        train_devide?: number[][]; 
        dev_j?: number[];
        sd_j?: number[];  // odchylenia standardowe
      }>;
    },
    onSuccess: (d) => {
      console.log("🎯 PEŁNA ODPOWIEDŹ Z BACKENDU (/calc/incurred/cl):");
      console.log("📦 Raw response:", d);
      
      if (d.train_devide) setTrainDevideDetIncurred(d.train_devide);
      if (d.dev_j) {
        console.log("📈 dev_j (współczynniki):", d.dev_j);
        
        if (d.sd_j) {
          console.log("📉 sd_j (odchylenia standardowe):", d.sd_j);
          console.log("   • długość:", d.sd_j.length);
        }
        
        setDevJ(d.dev_j);
        addDevJResult(volume, d.dev_j, d.sd_j); // przekazanie sd_j
        setSelectedVolume(volume, undefined);
      }
    },
  });

  /* auto-start train_divide */
  useEffect(() => {
    console.log('🚀 [useIncurredCL] Auto-trigger check:', {
      incurredTriangleLength: incurredTriangle?.length || 0,
      trainDevideDetIncurredLength: trainDevideDetIncurred?.length || 0,
      shouldTrigger: incurredTriangle?.length && !trainDevideDetIncurred?.length
    });
    
    if (incurredTriangle?.length && !trainDevideDetIncurred?.length) {
      console.log('✅ [useIncurredCL] Auto-triggering train_divide mutation');
      mTrainDivide.mutate();
    } else {
      console.log('❌ [useIncurredCL] Auto-trigger conditions not met');
    }
  }, [incurredTriangle, trainDevideDetIncurred]);

  return {
    triangle      : incurredTriangle,
    trainDevide   : trainDevideDetIncurred,
    weights       : selectedWeightsDetIncurred,
    selectedCells : selectedCellsDetIncurred,
    devJResults,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    toggleRowDetIncurred,
    selectedVolume,
    selectedSubIndex,
    setSelectedVolume,

    runCL      : () => mCL.mutate(),
    isLoading  : mTrainDivide.isPending || mCL.isPending,
  };
}
