/* ------------------------------------------------------------------ */
/*                     Results Export Modal                            */
/* ------------------------------------------------------------------ */

'use client';

import React, { useState } from 'react';
import Modal from '@/components/Modal';
import { useCombinedResultsExport, type WeightedSummaryData } from '../hooks/useCombinedResultsExport';
import { CombinedExportDialog } from './CombinedExportDialog';

interface ResultsExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  weightedSummaryData?: WeightedSummaryData | null;
}

export const ResultsExportModal: React.FC<ResultsExportModalProps> = ({
  isOpen,
  onClose,
  weightedSummaryData,
}) => {
  const combinedExport = useCombinedResultsExport(weightedSummaryData || undefined);

  const handleCombinedExport = () => {
    combinedExport.initializeExportItems();
  };

  const closeCombinedExportDialog = () => {
    combinedExport.closeDialog();
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50">
        <div className="bg-gradient-to-br from-gray-50 to-white rounded-2xl p-6 max-w-3xl w-full mx-4 max-h-[80vh] flex flex-col border border-gray-300 shadow-2xl">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-semibold text-gray-800">📊 Eksport wyników</h2>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-800 text-3xl leading-none"
            >
              ×
            </button>
          </div>

          <div className="flex-1 flex flex-col justify-center items-center">
            <div className="bg-gradient-to-r from-gray-100 to-gray-50 rounded-lg p-8 max-w-md w-full text-center border border-gray-200">
              <div className="mb-6">
                <div className="text-4xl mb-4">📂</div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">
                  Łączny eksport
                </h3>
                <p className="text-gray-700 text-sm mb-2 font-medium">
                  Eksportuj wszystkie dane z obu metod do jednego pliku Excel
                </p>
                <p className="text-gray-600 text-xs">
                  Plik będzie zawierał oddzielne zakładki dla:
                </p>
                <ul className="text-gray-600 text-xs mt-2 space-y-1">
                  <li>• <span className="text-blue-600 font-medium">Obliczenia Paid</span></li>
                  <li>• <span className="text-green-600 font-medium">Obliczenia Incurred</span></li>
                  <li>• <span className="text-blue-600 font-medium">Paid Porównania</span></li>
                  <li>• <span className="text-green-600 font-medium">Incurred Porównania</span></li>
                  <li>• <span className="text-purple-600 font-medium">Podsumowanie ważone</span></li>
                </ul>
              </div>
              
              <button
                onClick={handleCombinedExport}
                className="w-full py-4 px-5 bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-700 hover:to-purple-600 text-white rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
              >
                📥 Otwórz dialog eksportu
              </button>
            </div>
          </div>

          <div className="flex justify-center mt-6 pt-4 border-t border-gray-300">
            <button
              onClick={onClose}
              className="py-4 px-6 bg-gradient-to-r from-gray-600 to-gray-500 hover:from-gray-700 hover:to-gray-600 text-white rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
            >
              Zamknij
            </button>
          </div>
        </div>
      </div>

      {/* ========== COMBINED EXPORT DIALOG ========== */}
      <CombinedExportDialog
        isOpen={combinedExport.isDialogOpen}
        exportItems={combinedExport.exportItems}
        selectedCount={combinedExport.selectedCount}
        onClose={closeCombinedExportDialog}
        onToggleItem={combinedExport.toggleItemSelection}
        onToggleAll={combinedExport.toggleAllSelection}
        onExport={combinedExport.exportSelectedCalculations}
      />
    </>
  );
};
