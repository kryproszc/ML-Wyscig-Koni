import React from 'react';
import { useCheckAssumptionData } from '../hooks/useCheckAssumptionData';
import { TAB_CONFIGS } from '../constants';
import { ModelTab } from './ModelTab';
import { AssumptionsTab } from './AssumptionsTab';
import { AnalysisTab } from './AnalysisTab';
import { SummaryTab } from './SummaryTab';
import type { TabKey } from '../types';

interface CheckAssumptionProps {
  activeTab: TabKey;
  setActiveTab: (tab: TabKey) => void;
  triangleType: 'paid' | 'incurred';
  setTriangleType: (type: 'paid' | 'incurred') => void;
}

export const CheckAssumption: React.FC<CheckAssumptionProps> = ({
  activeTab: activeTabProp,
  setActiveTab: setActiveTabProp,
  triangleType: triangleTypeProp,
  setTriangleType: setTriangleTypeProp,
}) => {
  const {
    alphaAssumptions,
    setAlphaAssumptions,
    ciAnalysis,
    setCiAnalysis,
    ciSummary,
    setCiSummary,
    residualsData,
    dependenceData,
    dep2Data,
    isLoadingResiduals,
    isLoadingDependence,
    isLoadingDep2,
    error,
  } = useCheckAssumptionData(activeTabProp, triangleTypeProp, setTriangleTypeProp);

  const renderTabContent = () => {
    switch (activeTabProp) {
      case 'model':
        return <ModelTab />;
      
      case 'assumptions':
        return (
          <AssumptionsTab
            data={residualsData}
            isLoading={isLoadingResiduals}
            error={error}
            alpha={alphaAssumptions}
            onAlphaChange={setAlphaAssumptions}
          />
        );
      
      case 'analysis':
        return (
          <AnalysisTab
            data={dependenceData}
            isLoading={isLoadingDependence}
            error={error}
            ci={ciAnalysis}
            onCiChange={setCiAnalysis}
          />
        );
      
      case 'summary':
        return (
          <SummaryTab
            data={dep2Data}
            isLoading={isLoadingDep2}
            error={error}
            ci={ciSummary}
            onCiChange={setCiSummary}
          />
        );
      
      default:
        return null;
    }
  };

  return (
    <div>
      {/* Navigation tabs - Poziom 1 (główne) */}
      <nav className="flex space-x-1 border-b border-slate-700 mb-6">
        {TAB_CONFIGS.map(({ key, label }) => (
          <button
            key={key}
            onClick={() => setActiveTabProp(key as TabKey)}
            className={`
              px-6 py-3 text-base font-medium transition-all rounded-t-lg
              ${
                activeTabProp === key
                  ? 'bg-slate-800 border-t border-l border-r border-slate-600 border-b-2 border-b-blue-400 text-blue-400 shadow-lg'
                  : 'text-slate-300 hover:text-blue-300 hover:bg-slate-800/30'
              }
            `}
          >
            {label}
          </button>
        ))}
      </nav>

      {/* Tab content */}
      {renderTabContent()}
    </div>
  );
};
