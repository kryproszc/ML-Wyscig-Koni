## Installation

```bash
pnpm install
```

## Development

```bash
pnpm dev
```

## Production
### Build

```bash
pnpm build
```

### Start

```bash
pnpm start
```
