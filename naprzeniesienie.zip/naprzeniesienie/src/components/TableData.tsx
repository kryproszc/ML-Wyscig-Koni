import type { RowData } from '@/types/table';

interface Props {
  data: RowData[];
  selected?: RowData[];
  onClick?: (x: number, y: number) => void;
  variant?: 'dark' | 'light';
}

export function TableData({ data, selected, onClick, variant = 'dark' }: Props) {
  const isLight = variant === 'light';
  
  return (
    <div className={`${isLight ? 'rounded-xl' : 'bg-[#1e293b] rounded-lg border border-gray-700'}`}>
      <table className="min-w-full text-sm" style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
        <tbody className={isLight ? 'text-gray-800' : 'text-gray-300'}>
          {data.map((row, i) => {
            const isFirstRow = i === 0;
            const isLastRow = i === data.length - 1;
            
            return (
            <tr
              key={i}
              className={`transition-colors ${
                isLight ? 'hover:bg-gray-50/50' : 'border-b border-gray-700 hover:bg-[#2d3748]'
              }`}
            >
              {row.map((cell, j) => {
                const isAY = j === 0;
                const isHeader = i === 0;
                const isEmpty = cell === null || cell === undefined || cell === '' || cell === '-';
                const isSelected = !isEmpty && selected?.[i]?.[j] === 1;
                const isFirstCol = j === 0;
                const isLastCol = j === row.length - 1;

                // Zaokrąglone rogi tylko dla jasnego stylu
                const cornerRadius = isLight ? (
                  isFirstRow && isFirstCol ? 'rounded-tl-xl' :
                  isFirstRow && isLastCol ? 'rounded-tr-xl' :
                  isLastRow && isFirstCol ? 'rounded-bl-xl' :
                  isLastRow && isLastCol ? 'rounded-br-xl' :
                  ''
                ) : '';

                const content =
                  typeof cell === 'number'
                    ? Math.round(cell).toLocaleString('pl-PL', {
                        useGrouping: true
                      }).replace(/\u00A0/g, ' ')
                    : isEmpty
                    ? '-'
                    : cell;

                const getCellStyles = () => {
                  if (isLight) {
                    if (isHeader) return "bg-gray-200 text-gray-900 font-semibold";
                    if (isAY) return "bg-gray-200 font-bold text-gray-700";
                    if (isEmpty) return "bg-gray-200 text-gray-500";
                    if (isSelected) return "bg-white text-gray-900";
                    return "bg-white text-gray-900";
                  } else {
                    if (isHeader) return "bg-[#334155] text-gray-200 font-medium border-b border-gray-600";
                    if (isAY) return "bg-[#334155] font-medium text-blue-400 border-r border-gray-600";
                    if (isSelected) return "bg-indigo-700/40 border border-indigo-500 shadow-inner";
                    return "";
                  }
                };

                const borderStyles = isLight ? "border border-gray-300" : "border border-slate-600";

                return (
                    <td
                      key={j}
                      className={`px-3 py-2 ${borderStyles} ${cornerRadius} whitespace-nowrap transition-colors ${
                        getCellStyles()
                      } cursor-pointer text-center`}
                      onClick={() => onClick?.(i, j)}
                    >
                      {content}
                    </td>
                );
              })}
            </tr>
          )})}
        </tbody>
      </table>
    </div>
  );
}
