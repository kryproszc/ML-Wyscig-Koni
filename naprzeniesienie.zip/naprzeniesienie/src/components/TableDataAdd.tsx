'use client';

import { useMemo } from 'react';
import { useAddCoefficientsStore } from '@/stores/addCoefficientsStore';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';

interface Props {
  data: (string | number)[][];
  weights?: number[][];
  selectedCells?: [number, number][];
  minMaxCells?: [number, number][];
  minCells?: [number, number][];
  maxCells?: [number, number][];
  onClick?: (i: number, j: number) => void;
  onToggleRow?: (rowIndex: number) => void;
  showRowToggle?: boolean;
}

export function TableDataAdd({ 
  data, 
  weights, 
  selectedCells = [], 
  minMaxCells = [], 
  minCells = [], 
  maxCells = [], 
  onClick,
  onToggleRow,
  showRowToggle = false 
}: Props) {
  const toggleWeight = useAddCoefficientsStore((s) => s.toggleWeightCellAdd);
  const decimalPlaces = useTrainDevideStoreDet((s) => s.decimalPlaces); // 🎯 Używaj z głównego store'a

  // Funkcja formatowania liczb
  const formatNumber = (cell: string | number): string => {
    if (typeof cell === 'number') {
      return cell.toFixed(decimalPlaces);
    }
    if (typeof cell === 'string' && !isNaN(Number(cell)) && cell !== '') {
      return Number(cell).toFixed(decimalPlaces);
    }
    return String(cell);
  };

  // Debug - sprawdźmy co otrzymujemy
  console.log('🎯 TableDataAdd received:', { 
    minCells: minCells.length, 
    maxCells: maxCells.length,
    minCellsData: minCells,
    maxCellsData: maxCells,
    weightsLength: weights?.length || 0,
    dataLength: data?.length || 0
  });

  const handleCellClick = (i: number, j: number) => {
    if (i === 0 || j === 0) return; // Nie pozwalamy kliknąć w nagłówki
    
    // Sprawdzamy czy komórka ma liczbową wartość (nie pustą)
    const cell = data[i]?.[j];
    if (cell === null || cell === undefined || cell === '') return;
    
    console.log(`Kliknięto komórkę AddPaid [${i}, ${j}]`);
    toggleWeight(i - 1, j - 1); // Odejmujemy 1 bo nagłówki dodają offset
    
    if (onClick) {
      onClick(i, j);
    }
  };

  const handleRowToggle = (rowIndex: number) => {
    if (rowIndex === 0 || !onToggleRow) return; // Nie pozwalamy na nagłówek
    onToggleRow(rowIndex - 1); // Odejmujemy 1 bo nagłówki dodają offset
  };

  // Memoizujemy stany zaznaczenia wierszy aby React wiedział o zmianach
  const rowSelectionStates = useMemo(() => {
    if (!weights || !data) return new Map<number, boolean>();
    
    const states = new Map<number, boolean>();
    
    for (let i = 1; i < data.length; i++) { // Zaczynamy od 1 bo 0 to nagłówek
      const weightRow = weights[i - 1];
      const dataRow = data[i];
      
      if (!weightRow || !dataRow) {
        states.set(i, false);
        continue;
      }
      
      let hasAnyData = false;
      let allSelected = true;
      
      for (let j = 1; j < dataRow.length; j++) { // Zaczynamy od 1 bo 0 to nagłówek
        const cell = dataRow[j];
        const hasData = cell !== null && cell !== undefined && cell !== '' && typeof cell !== 'undefined';
        
        if (hasData) {
          hasAnyData = true;
          if (weightRow[j - 1] !== 1) { // j-1 bo weights nie ma kolumny nagłówka
            allSelected = false;
            break;
          }
        }
      }
      
      states.set(i, hasAnyData && allSelected);
    }
    
    return states;
  }, [weights, data]);

  // Sprawdzamy czy cały wiersz jest zaznaczony - teraz używa memoizowanego stanu
  const isRowSelected = (rowIndex: number): boolean => {
    if (rowIndex === 0) return false;
    return rowSelectionStates.get(rowIndex) || false;
  };

  return (
    <div className="overflow-x-auto bg-white rounded-xl border border-gray-300">
      <table className="min-w-full text-sm border-collapse">
        <tbody>
          {data.map((row, i) => (
            <tr key={i}>
              {/* Kolumna z checkbox dla wierszy (tylko jeśli showRowToggle jest true) */}
              {showRowToggle && (
                <td className="p-2 text-center bg-gray-100 border border-gray-300">
                  {i === 0 ? (
                    <span className="text-gray-800 font-semibold text-xs">Cały wiersz</span>
                  ) : (
                    <input
                      type="checkbox"
                      checked={isRowSelected(i)}
                      onChange={() => handleRowToggle(i)}
                      className="w-4 h-4 text-blue-600 bg-white border-gray-400 rounded focus:ring-blue-500 focus:ring-2 cursor-pointer"
                    />
                  )}
                </td>
              )}
              
              {row.map((cell, j) => {
                const isHeaderRow = i === 0;
                const isHeaderCol = j === 0;
                const isHeader = isHeaderRow || isHeaderCol;
                
                // Sprawdzamy czy komórka ma dane liczbowe (nie pusta)
                const hasData = !isHeader && cell !== null && cell !== undefined && cell !== '';
                
                // Sprawdzamy czy komórka jest minimum lub maksimum
                const isMin = minCells?.some(([minI, minJ]) => minI === i && minJ === j);
                const isMax = maxCells?.some(([maxI, maxJ]) => maxI === i && maxJ === j);

                // Debug tylko dla min/max
                if (isMin || isMax) {
                  console.log(`🔍 AddPaid Min/Max komórka [${i}, ${j}]:`, { isMin, isMax, cell, hasData });
                }

                const cellStyle = isHeader
                  ? 'bg-gray-200 text-gray-900 font-semibold'
                  : hasData
                  ? weights?.[i - 1]?.[j - 1] === 1
                    ? isMin
                      ? 'bg-white text-gray-900 shadow-lg shadow-green-500/50'
                      : isMax
                      ? 'bg-white text-gray-900 shadow-lg shadow-red-500/50'
                      : 'bg-white text-gray-900'
                    : 'bg-gray-200 text-gray-500'
                  : 'bg-gray-100 text-gray-500';

                // Dynamiczne obramowanie - priorytet dla min/max
                const borderStyle = isMin
                  ? 'border-4 border-green-500'
                  : isMax
                  ? 'border-4 border-red-500'
                  : 'border border-gray-300';

                return (
                  <td
                    key={j}
                    className={`
                      p-2 text-center transition-all duration-200
                      ${cellStyle}
                      ${borderStyle}
                      ${hasData ? 'cursor-pointer hover:opacity-80' : 'cursor-default'}
                    `}
                    onClick={hasData ? () => handleCellClick(i, j) : undefined}
                  >
                    {isHeader ? cell : formatNumber(cell)}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}