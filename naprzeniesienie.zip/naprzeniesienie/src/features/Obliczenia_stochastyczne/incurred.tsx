'use client';

import { useMemo, useState } from 'react';
import { ClSimulationIncurred } from '@/features/Parametryzacja/MultIncurred/Symulacje/ClSimulationIncurred';

type StochasticIncurredMethodType = 'multiplikatywna' | 'addytywna' | 'mix';

export function StochasticIncurredTab() {
	const [methodType, setMethodType] = useState<StochasticIncurredMethodType>('multiplikatywna');

	const simulationEndpoint = useMemo(() => {
		if (methodType === 'multiplikatywna') return '/calc/incurred/simulation';
		if (methodType === 'addytywna') return '/calc/incurred/simulationaddytywna';
		return '/calc/incurred/simulation';
	}, [methodType]);

	const statisticsEndpoint = useMemo(() => {
		if (methodType === 'multiplikatywna') return '/calc/incurred/statistic';
		return '/calc/statisticClIncurred';
	}, [methodType]);

	return (
		<ClSimulationIncurred
			simulationEndpoint={simulationEndpoint}
			statisticsEndpoint={statisticsEndpoint}
			methodType={methodType}
			tableVariant="paid"
			topContent={
				<div className="mb-3 space-y-2">
					<label className="block text-sm font-medium text-gray-300">Wybór metody:</label>
					<div className="space-y-2">
						<label className="flex items-center gap-2 text-sm text-gray-200 cursor-pointer">
							<input
								type="radio"
								name="stochastic_method_incurred"
								checked={methodType === 'multiplikatywna'}
								onChange={() => setMethodType('multiplikatywna')}
								className="accent-blue-500"
							/>
							<span>Multiplikatywna</span>
						</label>
						<label className="flex items-center gap-2 text-sm text-gray-200 cursor-pointer">
							<input
								type="radio"
								name="stochastic_method_incurred"
								checked={methodType === 'addytywna'}
								onChange={() => setMethodType('addytywna')}
								className="accent-blue-500"
							/>
							<span>Addytywna</span>
						</label>
						<label className="flex items-center gap-2 text-sm text-gray-200 cursor-pointer">
							<input
								type="radio"
								name="stochastic_method_incurred"
								checked={methodType === 'mix'}
								onChange={() => setMethodType('mix')}
								className="accent-blue-500"
							/>
							<span>Mix metod</span>
						</label>
					</div>
				</div>
			}
		/>
	);
}
