'use client';

import { useEffect, useMemo, useState } from 'react';
import { useUserStore } from '@/app/_components/useUserStore';
import { useTrainDevideStoreIncurred } from '@/stores/useTrainDevideStoreIncurred';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useAddIncurredCoefficientsStore } from '@/stores/addIncurredCoefficientsStore';
import { useExposureStore } from '@/stores/exposureStore';
import { useDiscountRatesStore } from '@/stores/discountRatesStore';
import { useParamsymStore } from '@/stores/paramsymStore';
import { CalculationLayout, DataStatusPanel, EmptyState } from '@/shared/components/calculation';
import { DataTableView } from '@/shared/ui/molecules/DataTableView';
import { processSelectedRow, processSelectedValues } from '@/shared/utils';
import { useDataValidation } from '@/shared/hooks';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? '';
const INCURRED_TAB_STORAGE_KEY = 'deterministic-incurred-tab-state';

const roundPayloadNumbers = <T,>(value: T): T => {
	if (typeof value === 'number' && Number.isFinite(value)) {
		return Number(value.toFixed(15)) as T;
	}

	if (Array.isArray(value)) {
		return value.map((item) => roundPayloadNumbers(item)) as T;
	}

	if (value && typeof value === 'object') {
		const entries = Object.entries(value as Record<string, unknown>).map(([key, nested]) => [
			key,
			roundPayloadNumbers(nested),
		]);
		return Object.fromEntries(entries) as T;
	}

	return value;
};

type IncurredTabResults = {
	last_col_incurred: number[];
	cum_trian_incurred: number[];
	ult_net_disc_incurred: number[];
	userId?: string;
	shouldShowResults: boolean;
};

type IncurredTabPersistedState = {
	methodType: 'multiplikatywna' | 'addytywna' | 'mix';
	kChange: string;
	calculationResults: IncurredTabResults | null;
};

const getInitialIncurredTabState = (): IncurredTabPersistedState => {
	if (typeof window === 'undefined') {
		return {
			methodType: 'multiplikatywna',
			kChange: '0',
			calculationResults: null,
		};
	}

	try {
		const raw = window.sessionStorage.getItem(INCURRED_TAB_STORAGE_KEY);
		if (!raw) {
			return {
				methodType: 'multiplikatywna',
				kChange: '0',
				calculationResults: null,
			};
		}

		const parsed = JSON.parse(raw) as IncurredTabPersistedState;
		return {
			methodType: parsed?.methodType === 'addytywna' || parsed?.methodType === 'mix' ? parsed.methodType : 'multiplikatywna',
			kChange: typeof parsed?.kChange === 'string' ? parsed.kChange : '0',
			calculationResults: parsed?.calculationResults ?? null,
		};
	} catch {
		return {
			methodType: 'multiplikatywna',
			kChange: '0',
			calculationResults: null,
		};
	}
};

export function DeterministicIncurredTab() {
	const initialState = useMemo(() => getInitialIncurredTabState(), []);
	const [methodType, setMethodType] = useState<'multiplikatywna' | 'addytywna' | 'mix'>(initialState.methodType);
	const [kChange, setKChange] = useState<string>(initialState.kChange);
	const [isSending, setIsSending] = useState(false);
	const [lastSendMessage, setLastSendMessage] = useState<string>('Jeszcze nic nie wysłano.');
	const [calculationResults, setCalculationResults] = useState<IncurredTabResults | null>(initialState.calculationResults);

	const userId = useUserStore((s: any) => s.userId);
	const paidTriangle = useTrainDevideStoreDet((s) => s.paidTriangle);

	const {
		incurredTriangle,
		selectedValuesCL,
		combinedDevJSummary,
		devJ,
		rJPaidToIncurred,
		varJPaidToIncurred,
		selectedValuesRJPaidToIncurred,
		selectedValuesVarJPaidToIncurred,
		combinedRJPaidToIncurredSummary,
		combinedVarJPaidToIncurredSummary,
	} = useTrainDevideStoreIncurred();

	const {
		addJ,
		combinedAddLRSummary,
	} = useAddIncurredCoefficientsStore();

	const {
		exposureTriangle,
		selectedExposureLine,
		availableExposureLines,
	} = useExposureStore();

	const discountRatesTriangle = useDiscountRatesStore((s) => s.discountRatesTriangle);
	const selectedDiscountRateLine = useDiscountRatesStore((s) => s.selectedDiscountRateLine);

	const paramsymTriangle = useParamsymStore((s) => s.paramsymTriangle);
	const selectedParamsymLine = useParamsymStore((s) => s.selectedParamsymLine);

	const { isDiscountRatesLoaded, isNettoBruttoLoaded, canSelectBrutto, canSelectBruttoDysk, canSelectNettoDysk } =
		useDataValidation(incurredTriangle, discountRatesTriangle, paramsymTriangle);

	const isIncurredTriangleLoaded = () => Array.isArray(incurredTriangle) && incurredTriangle.length > 0;

	const exposureArray = useMemo(() => {
		if (!exposureTriangle || Object.keys(exposureTriangle).length === 0) return [];
		if (selectedExposureLine === null) return [];

		const selectedLine = availableExposureLines.find((line) => line.index === selectedExposureLine);
		if (!selectedLine) return [];

		return selectedLine.values;
	}, [exposureTriangle, selectedExposureLine, availableExposureLines]);

	const canSend = useMemo(() => {
		return Boolean(userId) && Array.isArray(incurredTriangle) && incurredTriangle.length > 0;
	}, [userId, incurredTriangle]);

	const vectorF = useMemo(() => {
		return processSelectedValues(selectedValuesCL, combinedDevJSummary, devJ as any[], 1.0);
	}, [selectedValuesCL, combinedDevJSummary, devJ]);

	const vectorFLength = vectorF.length;
	const parsedKChange = Number(kChange);
	const isMixMethod = methodType === 'mix';
	const isMixKInvalid = isMixMethod && (!Number.isFinite(parsedKChange) || parsedKChange > vectorFLength);

	const lightResultsTableData = useMemo(() => {
		if (!calculationResults) return null;

		const formatWholeNumber = (value: number) =>
			Math.round(value)
				.toLocaleString('pl-PL', {
					minimumFractionDigits: 0,
					maximumFractionDigits: 0,
					useGrouping: true,
				})
				.replace(/\u00A0/g, ' ');

		const headers = ['OKRES', 'LAST COLUMN (BRUTTO)', 'CUMULATIVE TRIANGLE', 'ULTIMATE NET DISCOUNTED'];
		const maxLength = Math.max(
			calculationResults.last_col_incurred.length,
			calculationResults.cum_trian_incurred.length,
			calculationResults.ult_net_disc_incurred.length,
		);

		const lastColSum = calculationResults.last_col_incurred.reduce((sum, value) => sum + (Number.isFinite(value) ? value : 0), 0);
		const cumTrianSum = calculationResults.cum_trian_incurred.reduce((sum, value) => sum + (Number.isFinite(value) ? value : 0), 0);
		const ultNetDiscSum = calculationResults.ult_net_disc_incurred.reduce((sum, value) => sum + (Number.isFinite(value) ? value : 0), 0);

		const rows: string[][] = [headers];

		for (let index = 0; index < maxLength; index += 1) {
			const lastColValue = calculationResults.last_col_incurred[index];
			const cumTrianValue = calculationResults.cum_trian_incurred[index];
			const ultNetDiscValue = calculationResults.ult_net_disc_incurred[index];

			rows.push([
				String(index + 1),
				typeof lastColValue === 'number' ? formatWholeNumber(lastColValue) : '-',
				typeof cumTrianValue === 'number' ? formatWholeNumber(cumTrianValue) : '-',
				typeof ultNetDiscValue === 'number' ? formatWholeNumber(ultNetDiscValue) : '-',
			]);
		}

		rows.push([
			'SUMA',
			formatWholeNumber(lastColSum),
			formatWholeNumber(cumTrianSum),
			formatWholeNumber(ultNetDiscSum),
		]);

		return rows;
	}, [calculationResults]);

	const handleSend = async () => {
		let computedKChange: number;

		if (methodType === 'multiplikatywna') {
			computedKChange = -1;
		} else if (methodType === 'addytywna') {
			computedKChange = vectorFLength;
		} else {
			let mixK = Number(kChange);

			if (!Number.isFinite(mixK)) {
				const promptValue = window.prompt('Podaj parametr k dla trybu Mix metod:', kChange || '0');
				if (promptValue === null) {
					setLastSendMessage('Anulowano wprowadzanie parametru k dla trybu Mix.');
					return;
				}
				setKChange(promptValue);
				mixK = Number(promptValue);
			}

			if (!Number.isFinite(mixK)) {
				setLastSendMessage('Parametr k dla trybu Mix musi być liczbą.');
				return;
			}

			if (mixK > vectorFLength) {
				setLastSendMessage(`Parametr k dla trybu Mix nie może być większy od: ${vectorFLength}`);
				return;
			}

			computedKChange = mixK;
		}

		if (!userId) {
			setLastSendMessage('Brak user_id - nie wysłano.');
			console.error('❌ [DeterministicIncurredTab] Brak user_id');
			return;
		}

		if (!Array.isArray(incurredTriangle) || incurredTriangle.length === 0) {
			setLastSendMessage('Brak incurred_triangle - nie wysłano.');
			console.error('❌ [DeterministicIncurredTab] Brak incurred_triangle');
			return;
		}

		const selectedValueCl = processSelectedValues(selectedValuesCL, combinedDevJSummary, devJ as any[], 1.0);
		const selectedValueLr = processSelectedValues([], combinedAddLRSummary, addJ as any[], 1.0);
		const rjFinal = processSelectedValues(
			selectedValuesRJPaidToIncurred,
			combinedRJPaidToIncurredSummary as any[],
			rJPaidToIncurred as any[],
			1.0,
		);
		const varjFinal = processSelectedValues(
			selectedValuesVarJPaidToIncurred,
			combinedVarJPaidToIncurredSummary as any[],
			varJPaidToIncurred as any[],
			1.0,
		);
		const discountRates = processSelectedRow(discountRatesTriangle, selectedDiscountRateLine);
		const nettoDysk = processSelectedRow(paramsymTriangle, selectedParamsymLine);
		const rjCalculated = Array.isArray(rJPaidToIncurred) ? rJPaidToIncurred : [];
		const varjCalculated = Array.isArray(varJPaidToIncurred) ? varJPaidToIncurred : [];
		const paidTriangleForPayload = Array.isArray(paidTriangle) && paidTriangle.length > 0 ? paidTriangle : undefined;

		const rawPayload = {
			user_id: userId,
			paid_triangle: paidTriangleForPayload,
			incurred_triangle: incurredTriangle,
			selected_value_cl: selectedValueCl,
			selected_value_lr: selectedValueLr,
			r_i_calculated: rjCalculated,
			var_j_calculated: varjCalculated,
			r_i_final: rjFinal,
			var_j_final: varjFinal,
			ekspozycja: exposureArray,
			k_change: computedKChange,
			discount_rates: discountRates,
			netto_dysk: nettoDysk,
			calculation_options: {
				brutto: canSelectBrutto,
				brutto_dysk: canSelectBruttoDysk,
				netto_dysk: canSelectNettoDysk,
			},
		};

		const payload = roundPayloadNumbers(rawPayload);

		const requestBody = JSON.stringify(payload);

		console.log('📤 [DeterministicIncurredTab] URL:', `${API_URL}/calc_change_method/execute_calculations_incurred`);
		console.log('📤 [DeterministicIncurredTab] Method:', 'POST');
		console.log('📤 [DeterministicIncurredTab] Headers:', { 'Content-Type': 'application/json' });
		console.log('📤 [DeterministicIncurredTab] Wysyłany payload (object):', payload);
		console.log('📤 [DeterministicIncurredTab] Wysyłany payload (JSON pretty):', JSON.stringify(payload, null, 2));
		console.log('📤 [DeterministicIncurredTab] Wysyłane body dokładnie:', requestBody);
		console.log('📤 [DeterministicIncurredTab] Klucze payloadu:', Object.keys(payload));

		try {
			setIsSending(true);
			setLastSendMessage('Wysyłanie...');

			const response = await fetch(`${API_URL}/calc_change_method/execute_calculations_incurred`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: requestBody,
			});

			const responseBody = await response.json().catch(() => null);

			console.log('📥 [DeterministicIncurredTab] Status odpowiedzi:', response.status);
			console.log('📥 [DeterministicIncurredTab] Odpowiedź backendu:', responseBody);

			if (!response.ok) {
				const detail =
					typeof responseBody?.detail === 'string'
						? responseBody.detail
						: responseBody?.detail
							? JSON.stringify(responseBody.detail)
							: responseBody?.message
								? String(responseBody.message)
								: 'Brak szczegółów błędu';
				setLastSendMessage(`Błąd wysyłki: ${response.status} - ${detail}`);
				return;
			}

			const vectors = responseBody?.vectors ?? responseBody ?? {};
			setCalculationResults({
				last_col_incurred: Array.isArray(vectors.last_col_incurred)
					? vectors.last_col_incurred
					: Array.isArray(vectors.last_col)
						? vectors.last_col
						: [],
				cum_trian_incurred: Array.isArray(vectors.cum_trian_incurred)
					? vectors.cum_trian_incurred
					: Array.isArray(vectors.cum_trian)
						? vectors.cum_trian
						: [],
				ult_net_disc_incurred: Array.isArray(vectors.ult_net_disc_incurred)
					? vectors.ult_net_disc_incurred
					: Array.isArray(vectors.ult_net_disc)
						? vectors.ult_net_disc
						: [],
				userId: userId,
				shouldShowResults: true,
			});

			setLastSendMessage('Wysłano poprawnie.');
		} catch (error) {
			console.error('❌ [DeterministicIncurredTab] Błąd podczas wysyłki:', error);
			setLastSendMessage(`Błąd wysyłki: ${error}`);
		} finally {
			setIsSending(false);
		}
	};

	const statusItems = [
		{ label: 'Trójkąt Incurred', isLoaded: isIncurredTriangleLoaded() },
		{ label: 'Stopy Dyskontowe', isLoaded: isDiscountRatesLoaded() },
		{ label: 'Netto/Brutto', isLoaded: isNettoBruttoLoaded() },
	];

	useEffect(() => {
		if (typeof window === 'undefined') return;

		const stateToPersist: IncurredTabPersistedState = {
			methodType,
			kChange,
			calculationResults,
		};

		window.sessionStorage.setItem(INCURRED_TAB_STORAGE_KEY, JSON.stringify(stateToPersist));
	}, [methodType, kChange, calculationResults]);

	return (
		<CalculationLayout
			sidebar={
				<div className="space-y-6">
					<div className="pt-2">
						<label className="block text-sm font-medium text-gray-300 mb-2">Wybór metody:</label>
						<div className="space-y-2">
							<label className="flex items-center gap-2 text-sm text-gray-200 cursor-pointer">
								<input
									type="radio"
									name="deterministic_method_incurred"
									checked={methodType === 'multiplikatywna'}
									onChange={() => setMethodType('multiplikatywna')}
									className="accent-blue-500"
								/>
								<span>Multiplikatywna</span>
							</label>
							<label className="flex items-center gap-2 text-sm text-gray-200 cursor-pointer">
								<input
									type="radio"
									name="deterministic_method_incurred"
									checked={methodType === 'addytywna'}
									onChange={() => setMethodType('addytywna')}
									className="accent-blue-500"
								/>
								<span>Addytywna</span>
							</label>
							<label className="flex items-center gap-2 text-sm text-gray-200 cursor-pointer">
								<input
									type="radio"
									name="deterministic_method_incurred"
									checked={methodType === 'mix'}
									onChange={() => setMethodType('mix')}
									className="accent-blue-500"
								/>
								<span>Mix metod</span>
							</label>
						</div>

						{isMixMethod && (
							<>
								<label htmlFor="kChangeIncurred" className="block text-sm font-medium text-gray-300 mt-3 mb-2">
									Parametr k (Mix):
								</label>
								<input
									id="kChangeIncurred"
									type="number"
									step="0.01"
									value={kChange}
									onChange={(event) => setKChange(event.target.value)}
									className="w-full rounded-lg border border-slate-600 bg-slate-800 px-3 py-2 text-white outline-none focus:border-blue-500"
								/>
							</>
						)}
					</div>

					<DataStatusPanel statusItems={statusItems} />

					<hr className="border-gray-600" />
					<div className="w-full flex flex-col gap-3 pt-4">
						<button
							onClick={handleSend}
							disabled={isSending || !canSend || isMixKInvalid}
							className={`w-full py-4 px-5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl font-bold hover:from-emerald-700 hover:to-emerald-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform ${
								isSending || !canSend || isMixKInvalid ? 'opacity-60 cursor-not-allowed hover:scale-100' : ''
							}`}
						>
							{isSending ? 'Wysyłanie...' : 'Oblicz'}
						</button>

						<button
							onClick={() => {}}
							className="w-full py-4 px-5 bg-gradient-to-r from-amber-600 to-amber-500 text-white rounded-xl font-bold hover:from-amber-700 hover:to-amber-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
						>
							Eksportuj do Excela
						</button>

						<button
							onClick={() => {
								setCalculationResults(null);
								setLastSendMessage('Wyczyszczono wyniki i komunikat wysyłki.');
							}}
							className="w-full py-4 px-5 bg-gradient-to-r from-orange-600 to-orange-500 text-white rounded-xl font-bold hover:from-orange-700 hover:to-orange-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
						>
							Reset współczynników
						</button>
					</div>
				</div>
			}
		>
			<div className="space-y-6">
				{calculationResults ? (
					<DataTableView
						title="Wyniki Obliczeń Change Method (Incurred)"
						data={lightResultsTableData}
						noDataMessage="Brak danych wynikowych do wyświetlenia"
						variant="light"
					/>
				) : (
					<EmptyState
						title="Wysyłka danych z zakładki Incurred"
						description={`
							Kliknij "Oblicz", aby wysłać payload na backend.<br/>
							<strong>Payload:</strong> user_id, incurred_triangle, selected_value_cl, selected_value_lr, r_i_calculated, var_j_calculated, r_i_final, var_j_final, ekspozycja, k_change, discount_rates, netto_dysk, calculation_options.<br/><br/>
							<strong>Status:</strong> ${lastSendMessage}
						`}
					/>
				)}
			</div>
		</CalculationLayout>
	);
}
