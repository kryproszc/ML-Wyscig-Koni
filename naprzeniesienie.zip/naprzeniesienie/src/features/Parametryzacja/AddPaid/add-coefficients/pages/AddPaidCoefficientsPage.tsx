'use client';

import React, { useState } from 'react';
import { useAddCL } from '../hooks/useAddPaid';
import SidebarPanelAdd from '../components/SidebarPanelAdd';
import { TableDataAdd } from '@/components/TableDataAdd';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { useAddCoefficientsStore } from '@/stores/addCoefficientsStore';
import { useDisplaySettingsPaidStore } from '@/stores/useDisplaySettingsPaidStore';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import CalculationPageLayout from '@/shared/components/calculation-tables/CalculationPageLayout';
import type { ResultRow } from '@/shared/components/calculation-tables/ResultsTable';

export default function AddPaidCoefficientsPage() {
  // Labels from store (JUŻ 1:1 z body — bez rogu)
  const detRowLabels = useLabelsStore((s) => s.detRowLabels);
  const detColumnLabels = useLabelsStore((s) => s.detColumnLabels);

  // Display settings for fullscreen
  const fullscreenMode = useDisplaySettingsPaidStore((s) => s.fullscreenMode);
  const tableScale = useDisplaySettingsPaidStore((s) => s.tableScale);
  const setFullscreenMode = useDisplaySettingsPaidStore((s) => s.setFullscreenMode);
  const increaseScale = useDisplaySettingsPaidStore((s) => s.increaseScale);
  const decreaseScale = useDisplaySettingsPaidStore((s) => s.decreaseScale);

  // Stan dla animacji zamykania
  const [isClosing, setIsClosing] = useState(false);

  const {
    triangle,
    trainDevide,
    weights,
    selectedCells,
    devJ,
    sigma,
    sd,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    toggleRowAdd,

    runSigma,
    isLoading,
  } = useAddCL();

  // Decimal places ze wspólnego store
  const mainStore = useTrainDevideStoreDet();
  const { decimalPlaces } = mainStore;
  // Niezależny volume tylko dla AddPaid
  const addStore = useAddCoefficientsStore();
  const { volumeAdd, setVolumeAdd } = addStore;

  // Funkcja do zamykania z animacją
  const handleCloseFullscreen = () => {
    setIsClosing(true);
    // Opóźnienie zamknięcia o czas trwania animacji
    setTimeout(() => {
      setFullscreenMode(false);
      setIsClosing(false);
    }, 300); // 300ms - szybsze zamykanie
  };

  // ---- Nagłówki kolumn dla tabeli współczynników ----
  const expectedColumnCount = trainDevide?.[0]?.length || 0;
  const labelsFromStore =
    detColumnLabels.length > 1
      ? detColumnLabels.slice(1, 1 + expectedColumnCount)
      : [];

  const coeffHeaderLabels =
    labelsFromStore.length === expectedColumnCount
      ? labelsFromStore
      : Array.from({ length: expectedColumnCount }, (_, i) => String(i + 1));

  // ---- Etykiety wierszy 1:1 (bez +1) ----
  const rowLabelAt = (i: number) => detRowLabels[i] ?? String(i + 1);

  // ---- Przygotowanie danych dla tabeli ----
  const tableData = trainDevide?.length ? [
    [''].concat(coeffHeaderLabels),
    ...trainDevide.map((row, i) => [
      rowLabelAt(i),
      ...row.map((c) => (c == null ? '' : c.toString())),
    ]),
  ] : [];

  // ---- Przygotowanie danych wyników ----
  const resultRows: ResultRow[] = [
    {
      label: 'LR',
      values: devJ || [],
      visible: !!devJ,
    },
    {
      label: 'sigma',
      values: sigma || [],
      visible: !!sigma,
    },
    {
      label: 'sd',
      values: sd || [],
      visible: true,
    },
  ];

  return (
    <CalculationPageLayout
      title="Tabela współczynników rok do roku"
      isLoading={isLoading}
      loadingMessage={`⏳ Oczekiwanie na dane wejściowe paidTriangle…`}
      noDataMessage="Brak wyników 😢"
      tableData={tableData}
      headerLabels={coeffHeaderLabels}
      rowLabels={detRowLabels}
      hasData={!!triangle?.length && !!trainDevide?.length}
      weights={weights}
      selectedCells={selectedCells}
      minMaxCells={minMaxCells}
      minCells={minCells}
      maxCells={maxCells}
      minMaxHighlighting={minMaxHighlighting}
      showRowToggle={true}
      onToggleRow={toggleRowAdd}
      tableComponent={TableDataAdd}
      resultRows={resultRows}
      resultsTitle="Wyniki obliczeń"
      decimalPlaces={decimalPlaces}
      fullscreenMode={fullscreenMode}
      isClosing={isClosing}
      onCloseFullscreen={handleCloseFullscreen}
      tableScale={tableScale}
      onIncreaseScale={increaseScale}
      onDecreaseScale={decreaseScale}
      showTopScaleControls={false}
      volume={volumeAdd}
      onVolumeChange={setVolumeAdd}
      onCalculate={runSigma}
      calculateLabel="Oblicz"
      sidebar={
        <SidebarPanelAdd
          onCalculate={runSigma}
          maxVolume={trainDevide?.length || 1}
          className="w-64 shrink-0"
        />
      }
    />
  );
}