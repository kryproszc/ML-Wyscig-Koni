export { IncurredTriangleView } from './IncurredTriangleView';
