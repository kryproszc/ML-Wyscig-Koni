"use client"

import React, { useMemo, useEffect } from "react"
import { useAddIncurredCoefficientsStore } from '@/stores/addIncurredCoefficientsStore'
import { useLabelsStore } from '@/stores/useLabelsStore'
import { DevSummaryLayout } from '@/shared/components/DevelopmentEnd'

export default function AddIncurredLRSummaryTab() {
  const leftCount = useAddIncurredCoefficientsStore(s => s.leftCountAddLR)
  const setLeftCount = useAddIncurredCoefficientsStore(s => s.setLeftCountAddLR)
  const selectedCurve = useAddIncurredCoefficientsStore(s => s.selectedCurveAddLR)
  const setSelectedCurve = useAddIncurredCoefficientsStore(s => s.setSelectedCurveAddLR)
  const manualOverrides = useAddIncurredCoefficientsStore(s => s.manualOverridesAddLR)
  const setManualOverrides = useAddIncurredCoefficientsStore(s => s.setManualOverridesAddLR)
  const sourceSwitches = useAddIncurredCoefficientsStore(s => s.sourceSwitchesAddLR)
  const setSourceSwitches = useAddIncurredCoefficientsStore(s => s.setSourceSwitchesAddLR)
  const baseData = useAddIncurredCoefficientsStore(s => s.addJ)
  const rawSimResults = useAddIncurredCoefficientsStore(s => s.simResultsAddJ)
  const setCombinedData = useAddIncurredCoefficientsStore(s => s.setCombinedAddLRSummary)

  useEffect(() => {
    const initialSelectionLength = baseData?.length ?? 0
    if (leftCount <= 0 && initialSelectionLength > 0) {
      setLeftCount(initialSelectionLength)
    }
  }, [baseData, leftCount, setLeftCount])

  const rawIncurredColumnLabels = useLabelsStore(s => s.incurredColumnLabels)
  const incurredColumnLabels = useMemo(
    () => ["", ...rawIncurredColumnLabels],
    [rawIncurredColumnLabels]
  )

  if (!baseData?.length || !rawSimResults) {
    return (
      <div className="p-6 text-gray-300">
        <p className="mb-2">Brak danych do podsumowania LR.</p>
        <p className="text-sm text-gray-400">
          Przejdź do kroku 2 „Współczynniki Add” i kliknij „Oblicz”, a następnie w kroku 3 (AddJ) kliknij „Dopasuj krzywe”.
        </p>
      </div>
    )
  }

  return (
    <DevSummaryLayout
      leftCount={leftCount}
      setLeftCount={setLeftCount}
      selectedCurve={selectedCurve}
      setSelectedCurve={setSelectedCurve}
      manualOverrides={manualOverrides}
      setManualOverrides={setManualOverrides}
      sourceSwitches={sourceSwitches}
      setSourceSwitches={setSourceSwitches}
      devJPreview={baseData || undefined}
      simResults={rawSimResults || undefined}
      setCombinedDevJ={setCombinedData}
      columnLabels={incurredColumnLabels}
      onRemainingDevJHeaders={() => {}}
      disabledCurves={[]}
      tableContext='AddLR'
      useClassicStyle={true}
      lockExponentialWeighted={true}
    />
  )
}
