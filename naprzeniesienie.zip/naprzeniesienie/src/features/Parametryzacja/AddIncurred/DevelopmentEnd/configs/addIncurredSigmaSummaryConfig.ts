export const addIncurredSigmaSummaryConfig = {};
