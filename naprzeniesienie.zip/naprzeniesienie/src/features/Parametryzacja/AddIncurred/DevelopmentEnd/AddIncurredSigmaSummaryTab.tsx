"use client"

import React, { useMemo, useEffect } from "react"
import { useAddIncurredCoefficientsStore } from '@/stores/addIncurredCoefficientsStore'
import { useLabelsStore } from '@/stores/useLabelsStore'
import { DevSummaryLayout } from '@/shared/components/DevelopmentEnd'

export default function AddIncurredSigmaSummaryTab() {
  const leftCount = useAddIncurredCoefficientsStore(s => s.leftCountAddSigma)
  const setLeftCount = useAddIncurredCoefficientsStore(s => s.setLeftCountAddSigma)
  const selectedCurve = useAddIncurredCoefficientsStore(s => s.selectedCurveAddSigma)
  const setSelectedCurve = useAddIncurredCoefficientsStore(s => s.setSelectedCurveAddSigma)
  const manualOverrides = useAddIncurredCoefficientsStore(s => s.manualOverridesAddSigma)
  const setManualOverrides = useAddIncurredCoefficientsStore(s => s.setManualOverridesAddSigma)
  const sourceSwitches = useAddIncurredCoefficientsStore(s => s.sourceSwitchesAddSigma)
  const setSourceSwitches = useAddIncurredCoefficientsStore(s => s.setSourceSwitchesAddSigma)
  const baseData = useAddIncurredCoefficientsStore(s => s.sigmaLR)
  const rawSimResults = useAddIncurredCoefficientsStore(s => s.simResultsSigmaLR)
  const setCombinedData = useAddIncurredCoefficientsStore(s => s.setCombinedAddSigmaSummary)

  useEffect(() => {
    const initialSelectionLength = baseData?.length ?? 0
    if (leftCount <= 0 && initialSelectionLength > 0) {
      setLeftCount(initialSelectionLength)
    }
  }, [baseData, leftCount, setLeftCount])

  const rawIncurredColumnLabels = useLabelsStore(s => s.incurredColumnLabels)
  const incurredColumnLabels = useMemo(
    () => ["", ...rawIncurredColumnLabels],
    [rawIncurredColumnLabels]
  )

  if (!baseData?.length || !rawSimResults) {
    return (
      <div className="p-6 text-gray-300">
        <p className="mb-2">Brak danych do podsumowania Sigma.</p>
        <p className="text-sm text-gray-400">
          Przejdź do kroku 2 „Współczynniki Add” i kliknij „Oblicz”, a następnie w kroku 3 (SigmaLR) kliknij „Dopasuj krzywe”.
        </p>
      </div>
    )
  }

  return (
    <DevSummaryLayout
      leftCount={leftCount}
      setLeftCount={setLeftCount}
      selectedCurve={selectedCurve}
      setSelectedCurve={setSelectedCurve}
      manualOverrides={manualOverrides}
      setManualOverrides={setManualOverrides}
      sourceSwitches={sourceSwitches}
      setSourceSwitches={setSourceSwitches}
      devJPreview={baseData || undefined}
      simResults={rawSimResults || undefined}
      setCombinedDevJ={setCombinedData}
      columnLabels={incurredColumnLabels}
      onRemainingDevJHeaders={() => {}}
      disabledCurves={[]}
      tableContext='AddSigma'
      useClassicStyle={true}
      lockExponentialWeighted={true}
    />
  )
}
