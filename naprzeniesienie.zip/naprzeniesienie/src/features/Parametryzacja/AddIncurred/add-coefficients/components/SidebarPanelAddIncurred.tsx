'use client';

import { Maximize2, Plus, Minus } from 'lucide-react';

type Props = {
  decimalPlaces: number;
  setDecimalPlaces: (places: number) => void;
  volume: number;
  setVolume: (volume: number) => void;
  maxVolume: number;
  minMaxHighlighting: boolean;
  toggleMinMax: () => void;
  tableScale: number;
  increaseScale: () => void;
  decreaseScale: () => void;
  onOpenFullscreen: () => void;
  onCalculate: () => void;
};

export default function SidebarPanelAddIncurred({
  decimalPlaces,
  setDecimalPlaces,
  volume,
  setVolume,
  maxVolume,
  minMaxHighlighting,
  toggleMinMax,
  tableScale,
  increaseScale,
  decreaseScale,
  onOpenFullscreen,
  onCalculate,
}: Props) {
  return (
    <div className="w-64 shrink-0 space-y-4">
      <div className="bg-gray-800 rounded-lg p-4 space-y-4">
        <div>
          <label className="text-white text-sm font-medium mb-2 block">Miejsca po przecinku</label>
          <input
            type="number"
            min={0}
            max={10}
            value={decimalPlaces}
            onChange={(e) => setDecimalPlaces(Number(e.target.value))}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm"
          />
        </div>

        <div>
          <label className="text-white text-sm font-medium mb-2 block">Wybierz volume</label>
          <input
            type="number"
            min={1}
            max={Math.max(1, maxVolume)}
            value={volume}
            onChange={(e) => {
              const nextValue = e.currentTarget.valueAsNumber;
              if (Number.isFinite(nextValue)) {
                setVolume(nextValue);
              }
            }}
            className="w-full px-3 py-2 bg-white border border-gray-600 rounded-md text-black text-sm font-medium"
          />
        </div>

        <button
          onClick={onCalculate}
          className="w-full py-4 px-5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl font-bold hover:from-emerald-700 hover:to-emerald-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
        >
          Oblicz
        </button>
      </div>

      <button
        onClick={toggleMinMax}
        className="w-full py-4 px-5 bg-gradient-to-r from-gray-600 to-gray-500 text-white rounded-xl font-bold hover:from-gray-700 hover:to-gray-600 transition-all duration-200"
      >
        {minMaxHighlighting ? '🔍 Ukryj Min/Max' : '🔍 Pokaż Min/Max'}
      </button>

      <div className="bg-gray-800 rounded-lg p-4">
        <div className="text-white text-lg font-medium mb-4">Ustawienia wyświetlania</div>

        <div className="space-y-4">
          <div>
            <label className="text-white text-sm font-medium mb-2 block">Rozmiar tabeli</label>
            <div className="flex items-center gap-2">
              <button
                onClick={decreaseScale}
                className="w-8 h-8 p-0 text-white border border-gray-600 rounded hover:bg-gray-700 flex items-center justify-center"
                disabled={tableScale <= 0.5}
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="text-white text-sm min-w-[3rem] text-center">{Math.round(tableScale * 100)}%</span>
              <button
                onClick={increaseScale}
                className="w-8 h-8 p-0 text-white border border-gray-600 rounded hover:bg-gray-700 flex items-center justify-center"
                disabled={tableScale >= 2.0}
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          <button
            onClick={onOpenFullscreen}
            className="w-full py-4 px-5 bg-gradient-to-r from-blue-600 to-blue-500 text-white rounded-xl font-bold hover:from-blue-700 hover:to-blue-600 transition-all duration-200 flex items-center justify-center gap-2"
          >
            <Maximize2 className="w-4 h-4 mr-2" />
            Pełny ekran
          </button>
        </div>
      </div>
    </div>
  );
}
