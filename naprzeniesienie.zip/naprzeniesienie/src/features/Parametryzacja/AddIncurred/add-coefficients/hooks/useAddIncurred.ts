'use client';

import { useEffect, useMemo, useRef } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useUserStore } from '@/app/_components/useUserStore';
import { useAddIncurredStore } from '@/stores/addIncurredStore';
import { useAddIncurredCoefficientsStore } from '@/stores/addIncurredCoefficientsStore';
import { useExposureStore } from '@/stores/exposureStore';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';
const EMPTY_TRAIN_DEVIDE: (number | null)[][] = [];

export function useAddIncurredCL() {
  const userId = useUserStore((s) => s.userId);
  const triangle = useAddIncurredStore((s) => s.incurredTriangle);
  const exposureStore = useExposureStore();
  const selectedExposureLine = exposureStore.selectedExposureLine;
  const availableExposureLines = exposureStore.availableExposureLines;

  const {
    trainDevideAddIncurred,
    selectedWeightsAddIncurred,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    volumeAddIncurred,
    decimalPlacesAddIncurred,
    devJ,
    sigma,
    sd,
    setTrainDevideAddIncurred,
    resetWeightsAddIncurred,
    toggleWeightCellAddIncurred,
    toggleRowAddIncurred,
    calculateMinMaxCells,
    clearMinMaxCells,
    setMinMaxHighlighting,
    setVolumeAddIncurred,
  } = useAddIncurredCoefficientsStore();

  const getExposureArray = () => {
    if (selectedExposureLine === null) return [];
    const selectedLine = availableExposureLines.find((line) => line.index === selectedExposureLine);
    return selectedLine?.values ?? [];
  };

  const getIncurredArray = () => {
    if (!triangle?.length) return [];
    return triangle.map((row) => row.map((cell) => (cell === null || cell === undefined ? null : cell)));
  };

  const mTrainDivideAddIncurred = useMutation({
    mutationKey: ['trainDivideAddIncurred', userId],
    mutationFn: async () => {
      const res = await fetch(`${API_URL}/calc/add/train_devide_add_incurred`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userId,
          add_data_incurred: getIncurredArray(),
          ekspozycja: getExposureArray(),
        }),
      });
      return res.json() as Promise<{ train_devide?: (number | null)[][] }>;
    },
    onSuccess: (data) => {
      const next = data.train_devide ?? [];
      setTrainDevideAddIncurred(next);

      const rows = next.length;
      const cols = next[0]?.length || 0;
      if (rows && cols) {
        resetWeightsAddIncurred(rows, cols);
      }
    },
  });

  const mAddCoefficientsIncurred = useMutation({
    mutationKey: ['coefficientsAddIncurred', userId, volumeAddIncurred],
    mutationFn: async () => {
      const safeWeights = selectedWeightsAddIncurred?.map((weightRow, rowIndex) =>
        weightRow.map((weight, colIndex) => {
          const trainValue = trainDevideAddIncurred?.[rowIndex]?.[colIndex];
          if (trainValue === null || trainValue === undefined) {
            return 0;
          }
          return weight === 1 ? 1 : 0;
        })
      ) ?? [];

      const res = await fetch(`${API_URL}/calc/add/wspolczynniki_add_incurred`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userId,
          add_data_incurred: getIncurredArray(),
          ekspozycja: getExposureArray(),
          weights: safeWeights,
        }),
      });

      return res.json() as Promise<{
        message?: string;
        LR_j?: number[];
        sigma_j?: number[];
        sd_j?: number[];
      }>;
    },
    onSuccess: (data) => {
      if (data.LR_j) {
        useAddIncurredCoefficientsStore.getState().setDevJ(data.LR_j);
        useAddIncurredCoefficientsStore.getState().setAddJ(data.LR_j);
      }
      if (data.sigma_j) {
        useAddIncurredCoefficientsStore.getState().setSigma(data.sigma_j);
        useAddIncurredCoefficientsStore.getState().setSigmaLR(data.sigma_j);
      }
      if (data.sd_j) {
        useAddIncurredCoefficientsStore.getState().setSd(data.sd_j);
        useAddIncurredCoefficientsStore.getState().setSdLR(data.sd_j);
      }
    },
  });

  const trainDevide = trainDevideAddIncurred ?? EMPTY_TRAIN_DEVIDE;
  const lastAutoRequestKeyRef = useRef<string | null>(null);

  const autoRequestKey = useMemo(() => {
    const rows = triangle?.length ?? 0;
    const cols = triangle?.[0]?.length ?? 0;
    const exposureLine = selectedExposureLine ?? 'none';
    return `${rows}:${cols}:${exposureLine}`;
  }, [triangle, selectedExposureLine]);

  useEffect(() => {
    const rows = trainDevide.length;
    const cols = trainDevide[0]?.length || 0;
    if (!rows || !cols) return;

    const currentRows = selectedWeightsAddIncurred?.length || 0;
    const currentCols = selectedWeightsAddIncurred?.[0]?.length || 0;
    if (currentRows !== rows || currentCols !== cols) {
      resetWeightsAddIncurred(rows, cols);
    }
  }, [trainDevide, selectedWeightsAddIncurred, resetWeightsAddIncurred]);

  useEffect(() => {
    if (
      triangle?.length &&
      selectedExposureLine !== null &&
      !trainDevideAddIncurred?.length &&
      lastAutoRequestKeyRef.current !== autoRequestKey
    ) {
      lastAutoRequestKeyRef.current = autoRequestKey;
      mTrainDivideAddIncurred.mutate();
    }
  }, [triangle, selectedExposureLine, trainDevideAddIncurred, autoRequestKey]);

  useEffect(() => {
    if (!minMaxHighlighting) {
      if (minCells.length || maxCells.length || minMaxCells.length) {
        clearMinMaxCells();
      }
      return;
    }
    calculateMinMaxCells(trainDevide);
  }, [
    minMaxHighlighting,
    trainDevide,
    selectedWeightsAddIncurred,
    minCells.length,
    maxCells.length,
    minMaxCells.length,
    calculateMinMaxCells,
    clearMinMaxCells,
  ]);

  return {
    triangle,
    trainDevide,
    weights: selectedWeightsAddIncurred,
    selectedCells: [],
    devJ,
    sigma,
    sd,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    volumeAddIncurred,
    decimalPlacesAddIncurred,
    toggleRowAdd: (rowIndex: number) => toggleRowAddIncurred(rowIndex, trainDevide[rowIndex] ?? []),
    toggleWeightCellAddIncurred,
    setMinMaxHighlighting,
    setVolumeAddIncurred,
    runSigma: () => mAddCoefficientsIncurred.mutate(),
    isLoading: mTrainDivideAddIncurred.isPending || mAddCoefficientsIncurred.isPending,
  };
}
