'use client';

import { useState } from 'react';
import { SegmentedTabs } from '@/app/_components/DeterministicMethodsTab';
import FitCurveAddJIncurred from './FitCurveAddJIncurred';
import FitCurveSigmaLRIncurred from './FitCurveSigmaLRIncurred';

type Tab = 'AddJ' | 'SigmaLR';

export function AddIncurredFitCurveTabs() {
  const [active, setActive] = useState<Tab>('AddJ');
  const tabs: Readonly<Tab[]> = ['AddJ', 'SigmaLR'];

  return (
    <div className="w-full">
      <SegmentedTabs<Tab>
        active={active}
        setActive={setActive}
        tabs={tabs}
        ariaLabel="Tryb dopasowania AddIncurred"
      />

      <div className="mt-3">
        {active === 'AddJ' && <FitCurveAddJIncurred />}
        {active === 'SigmaLR' && <FitCurveSigmaLRIncurred />}
      </div>
    </div>
  );
}
