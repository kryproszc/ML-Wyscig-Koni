/* ------------------------------------------------------------------ */
/*                       PaidDevSummaryTab.tsx                       */
/* ------------------------------------------------------------------ */
"use client"

import React from "react";
import { GenericSummaryTab } from '@/shared/components/DevelopmentEnd'
import { clSummaryConfig } from './configs'

export default function PaidDevSummaryTab() {
  return <GenericSummaryTab config={clSummaryConfig} />
}
