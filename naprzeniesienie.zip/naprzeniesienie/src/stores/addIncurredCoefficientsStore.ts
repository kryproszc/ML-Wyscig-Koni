import { create } from 'zustand';
import { persist } from 'zustand/middleware';

type CellCoord = [number, number];

interface AddIncurredCoefficientsStore {
  trainDevideAddIncurred: (number | null)[][] | null;
  volumeAddIncurred: number;
  decimalPlacesAddIncurred: number;
  selectedWeightsAddIncurred?: number[][];
  selectedCellsAddIncurred: CellCoord[];

  minMaxHighlighting: boolean;
  minMaxCells: CellCoord[];
  minCells: CellCoord[];
  maxCells: CellCoord[];

  devJ: number[] | null;
  sigma: number[] | null;
  sd: number[] | null;

  selectedAddJIndexes: number[];
  addJPreview: number[] | null;
  addJPreviewCandidate: number[] | null;
  simResultsAddJ: Record<string, Record<string, number>> | null;
  r2ScoresAddJ: Record<string, number> | null;
  tailCountAddJ: number | '';
  addJFinalCustom: Record<number, { curve: string; value: number }>;
  finalAddJ: number[] | null;

  selectedSigmaLRIndexes: number[];
  sigmaLRPreview: number[] | null;
  sigmaLRPreviewCandidate: number[] | null;
  simResultsSigmaLR: Record<string, Record<string, number>> | null;
  r2ScoresSigmaLR: Record<string, number> | null;
  tailCountSigmaLR: number | '';
  sigmaLRFinalCustom: Record<number, { curve: string; value: number }>;
  finalSigmaLR: number[] | null;

  addJ: number[] | null;
  sigmaLR: number[] | null;
  sdLR: number[] | null;

  leftCountAddLR: number;
  selectedCurveAddLR: string | null;
  manualOverridesAddLR: Record<number, { curve: string; value: number }>;
  sourceSwitchesAddLR: Record<number, { curve: string; value: number }>;
  combinedAddLRSummary: (number | string)[];

  leftCountAddSigma: number;
  selectedCurveAddSigma: string | null;
  manualOverridesAddSigma: Record<number, { curve: string; value: number }>;
  sourceSwitchesAddSigma: Record<number, { curve: string; value: number }>;
  combinedAddSigmaSummary: (number | string)[];

  leftCountAddSD: number;
  selectedCurveAddSD: string | null;
  manualOverridesAddSD: Record<number, { curve: string; value: number }>;
  sourceSwitchesAddSD: Record<number, { curve: string; value: number }>;
  combinedAddSDSummary: (number | string)[];

  setVolumeAddIncurred: (volume: number) => void;
  setDecimalPlacesAddIncurred: (places: number) => void;
  setTrainDevideAddIncurred: (data: (number | null)[][] | null) => void;
  setSelectedWeightsAddIncurred: (weights?: number[][]) => void;
  resetWeightsAddIncurred: (rows: number, cols: number) => void;
  toggleWeightCellAddIncurred: (row: number, col: number) => void;
  toggleRowAddIncurred: (row: number, rowData: (number | null)[]) => void;
  setMinMaxHighlighting: (enabled: boolean) => void;
  calculateMinMaxCells: (trainDevide: (number | null)[][]) => void;
  clearMinMaxCells: () => void;
  setDevJ: (values: number[] | null) => void;
  setSigma: (values: number[] | null) => void;
  setSd: (values: number[] | null) => void;
  setSelectedAddJIndexes: (indexes: number[]) => void;
  setAddJPreview: (data: number[] | null) => void;
  setAddJPreviewCandidate: (data: number[] | null) => void;
  setSimResultsAddJ: (data: Record<string, Record<string, number>> | null) => void;
  setR2ScoresAddJ: (data: Record<string, number> | null) => void;
  setTailCountAddJ: (count: number | '') => void;
  setAddJFinalCustom: (data: Record<number, { curve: string; value: number }>) => void;
  setFinalAddJ: (data: number[] | null) => void;

  setSelectedSigmaLRIndexes: (indexes: number[]) => void;
  setSigmaLRPreview: (data: number[] | null) => void;
  setSigmaLRPreviewCandidate: (data: number[] | null) => void;
  setSimResultsSigmaLR: (data: Record<string, Record<string, number>> | null) => void;
  setR2ScoresSigmaLR: (data: Record<string, number> | null) => void;
  setTailCountSigmaLR: (count: number | '') => void;
  setSigmaLRFinalCustom: (data: Record<number, { curve: string; value: number }>) => void;
  setFinalSigmaLR: (data: number[] | null) => void;

  setAddJ: (data: number[] | null) => void;
  setSigmaLR: (data: number[] | null) => void;
  setSdLR: (data: number[] | null) => void;
  setLeftCountAddLR: (n: number) => void;
  setSelectedCurveAddLR: (c: string | null) => void;
  setManualOverridesAddLR: (o: Record<number, { curve: string; value: number }>) => void;
  setSourceSwitchesAddLR: (s: Record<number, { curve: string; value: number }>) => void;
  setCombinedAddLRSummary: (data: (number | string)[]) => void;

  setLeftCountAddSigma: (n: number) => void;
  setSelectedCurveAddSigma: (c: string | null) => void;
  setManualOverridesAddSigma: (o: Record<number, { curve: string; value: number }>) => void;
  setSourceSwitchesAddSigma: (s: Record<number, { curve: string; value: number }>) => void;
  setCombinedAddSigmaSummary: (data: (number | string)[]) => void;

  setLeftCountAddSD: (n: number) => void;
  setSelectedCurveAddSD: (c: string | null) => void;
  setManualOverridesAddSD: (o: Record<number, { curve: string; value: number }>) => void;
  setSourceSwitchesAddSD: (s: Record<number, { curve: string; value: number }>) => void;
  setCombinedAddSDSummary: (data: (number | string)[]) => void;
  clearSimResultsAddJ: () => void;
  clearR2ScoresAddJ: () => void;
  clearSimResultsSigmaLR: () => void;
  clearR2ScoresSigmaLR: () => void;
  resetData: () => void;
}

const initialState = {
  trainDevideAddIncurred: null,
  volumeAddIncurred: 1,
  decimalPlacesAddIncurred: 6,
  selectedWeightsAddIncurred: undefined,
  selectedCellsAddIncurred: [] as CellCoord[],
  minMaxHighlighting: false,
  minMaxCells: [] as CellCoord[],
  minCells: [] as CellCoord[],
  maxCells: [] as CellCoord[],
  devJ: null,
  sigma: null,
  sd: null,
  selectedAddJIndexes: [],
  addJPreview: null,
  addJPreviewCandidate: null,
  simResultsAddJ: null,
  r2ScoresAddJ: null,
  tailCountAddJ: '',
  addJFinalCustom: {},
  finalAddJ: null,
  selectedSigmaLRIndexes: [],
  sigmaLRPreview: null,
  sigmaLRPreviewCandidate: null,
  simResultsSigmaLR: null,
  r2ScoresSigmaLR: null,
  tailCountSigmaLR: '',
  sigmaLRFinalCustom: {},
  finalSigmaLR: null,
  addJ: null,
  sigmaLR: null,
  sdLR: null,
  leftCountAddLR: 0,
  selectedCurveAddLR: null,
  manualOverridesAddLR: {},
  sourceSwitchesAddLR: {},
  combinedAddLRSummary: [],
  leftCountAddSigma: 0,
  selectedCurveAddSigma: null,
  manualOverridesAddSigma: {},
  sourceSwitchesAddSigma: {},
  combinedAddSigmaSummary: [],
  leftCountAddSD: 0,
  selectedCurveAddSD: null,
  manualOverridesAddSD: {},
  sourceSwitchesAddSD: {},
  combinedAddSDSummary: [],
};

export const useAddIncurredCoefficientsStore = create<AddIncurredCoefficientsStore>()(
  persist(
    (set, get) => ({
      ...initialState,

      setVolumeAddIncurred: (volume) =>
        set({ volumeAddIncurred: Number.isFinite(volume) ? Math.max(1, volume) : 1 }),
      setDecimalPlacesAddIncurred: (places) =>
        set({ decimalPlacesAddIncurred: Math.min(10, Math.max(0, places)) }),
      setTrainDevideAddIncurred: (data) => set({ trainDevideAddIncurred: data }),
      setSelectedWeightsAddIncurred: (weights) => set({ selectedWeightsAddIncurred: weights }),

      resetWeightsAddIncurred: (rows, cols) => {
        if (rows <= 0 || cols <= 0) {
          set({ selectedWeightsAddIncurred: undefined });
          return;
        }
        const weights = Array.from({ length: rows }, () => Array.from({ length: cols }, () => 1));
        set({ selectedWeightsAddIncurred: weights });
      },

      toggleWeightCellAddIncurred: (row, col) => {
        const current = get().selectedWeightsAddIncurred;
        if (!current?.[row]) return;
        const next = current.map((weightRow, rowIdx) =>
          weightRow.map((value, colIdx) => (rowIdx === row && colIdx === col ? (value === 1 ? 0 : 1) : value))
        );
        set({ selectedWeightsAddIncurred: next });
      },

      toggleRowAddIncurred: (row, rowData) => {
        const current = get().selectedWeightsAddIncurred;
        if (!current?.[row]) return;

        let hasData = false;
        let allSelected = true;
        rowData.forEach((cell, colIdx) => {
          if (cell !== null && cell !== undefined) {
            hasData = true;
            if (current[row][colIdx] !== 1) allSelected = false;
          }
        });

        if (!hasData) return;

        const next = current.map((weightRow, rowIdx) => {
          if (rowIdx !== row) return weightRow;
          return weightRow.map((value, colIdx) =>
            rowData[colIdx] !== null && rowData[colIdx] !== undefined ? (allSelected ? 0 : 1) : value
          );
        });

        set({ selectedWeightsAddIncurred: next });
      },

      setMinMaxHighlighting: (enabled) => set({ minMaxHighlighting: enabled }),

      calculateMinMaxCells: (trainDevide) => {
        const weights = get().selectedWeightsAddIncurred;
        if (!weights?.length || !trainDevide?.length) {
          set({ minCells: [], maxCells: [], minMaxCells: [] });
          return;
        }

        let minValue = Infinity;
        let maxValue = -Infinity;
        let minCoord: CellCoord | null = null;
        let maxCoord: CellCoord | null = null;

        trainDevide.forEach((row, rowIdx) => {
          row.forEach((cell, colIdx) => {
            if (cell === null || cell === undefined) return;
            if (weights[rowIdx]?.[colIdx] !== 1) return;

            if (cell < minValue) {
              minValue = cell;
              minCoord = [rowIdx + 1, colIdx + 1];
            }
            if (cell > maxValue) {
              maxValue = cell;
              maxCoord = [rowIdx + 1, colIdx + 1];
            }
          });
        });

        const minCells = minCoord ? [minCoord] : [];
        const maxCells = maxCoord ? [maxCoord] : [];
        set({ minCells, maxCells, minMaxCells: [...minCells, ...maxCells] });
      },

      clearMinMaxCells: () => set({ minCells: [], maxCells: [], minMaxCells: [] }),
      setDevJ: (values) => set({ devJ: values }),
      setSigma: (values) => set({ sigma: values }),
      setSd: (values) => set({ sd: values }),
      setSelectedAddJIndexes: (indexes) => set({ selectedAddJIndexes: indexes }),
      setAddJPreview: (data) => set({ addJPreview: data }),
      setAddJPreviewCandidate: (data) => set({ addJPreviewCandidate: data }),
      setSimResultsAddJ: (data) => set({ simResultsAddJ: data }),
      setR2ScoresAddJ: (data) => set({ r2ScoresAddJ: data }),
      setTailCountAddJ: (count) => set({ tailCountAddJ: count }),
      setAddJFinalCustom: (data) => set({ addJFinalCustom: data }),
      setFinalAddJ: (data) => set({ finalAddJ: data }),

      setSelectedSigmaLRIndexes: (indexes) => set({ selectedSigmaLRIndexes: indexes }),
      setSigmaLRPreview: (data) => set({ sigmaLRPreview: data }),
      setSigmaLRPreviewCandidate: (data) => set({ sigmaLRPreviewCandidate: data }),
      setSimResultsSigmaLR: (data) => set({ simResultsSigmaLR: data }),
      setR2ScoresSigmaLR: (data) => set({ r2ScoresSigmaLR: data }),
      setTailCountSigmaLR: (count) => set({ tailCountSigmaLR: count }),
      setSigmaLRFinalCustom: (data) => set({ sigmaLRFinalCustom: data }),
      setFinalSigmaLR: (data) => set({ finalSigmaLR: data }),

      setAddJ: (data) => set({ addJ: data }),
      setSigmaLR: (data) => set({ sigmaLR: data }),
      setSdLR: (data) => set({ sdLR: data }),
      setLeftCountAddLR: (n) => set({ leftCountAddLR: n }),
      setSelectedCurveAddLR: (c) => set({ selectedCurveAddLR: c }),
      setManualOverridesAddLR: (o) => set({ manualOverridesAddLR: { ...o } }),
      setSourceSwitchesAddLR: (s) => set({ sourceSwitchesAddLR: { ...s } }),
      setCombinedAddLRSummary: (data) => set({ combinedAddLRSummary: [...data] }),
      setLeftCountAddSigma: (n) => set({ leftCountAddSigma: n }),
      setSelectedCurveAddSigma: (c) => set({ selectedCurveAddSigma: c }),
      setManualOverridesAddSigma: (o) => set({ manualOverridesAddSigma: { ...o } }),
      setSourceSwitchesAddSigma: (s) => set({ sourceSwitchesAddSigma: { ...s } }),
      setCombinedAddSigmaSummary: (data) => set({ combinedAddSigmaSummary: [...data] }),
      setLeftCountAddSD: (n) => set({ leftCountAddSD: n }),
      setSelectedCurveAddSD: (c) => set({ selectedCurveAddSD: c }),
      setManualOverridesAddSD: (o) => set({ manualOverridesAddSD: { ...o } }),
      setSourceSwitchesAddSD: (s) => set({ sourceSwitchesAddSD: { ...s } }),
      setCombinedAddSDSummary: (data) => set({ combinedAddSDSummary: [...data] }),
      clearSimResultsAddJ: () => set({ simResultsAddJ: null }),
      clearR2ScoresAddJ: () => set({ r2ScoresAddJ: null }),
      clearSimResultsSigmaLR: () => set({ simResultsSigmaLR: null }),
      clearR2ScoresSigmaLR: () => set({ r2ScoresSigmaLR: null }),

      resetData: () => set(initialState),
    }),
    {
      name: 'addincurred-coefficients-store',
      partialize: (state) => ({
        trainDevideAddIncurred: state.trainDevideAddIncurred,
        volumeAddIncurred: state.volumeAddIncurred,
        decimalPlacesAddIncurred: state.decimalPlacesAddIncurred,
        selectedWeightsAddIncurred: state.selectedWeightsAddIncurred,
        addJ: state.addJ,
        sigmaLR: state.sigmaLR,
        sdLR: state.sdLR,
        selectedAddJIndexes: state.selectedAddJIndexes,
        simResultsAddJ: state.simResultsAddJ,
        r2ScoresAddJ: state.r2ScoresAddJ,
        addJPreview: state.addJPreview,
        tailCountAddJ: state.tailCountAddJ,
        finalAddJ: state.finalAddJ,
        selectedSigmaLRIndexes: state.selectedSigmaLRIndexes,
        simResultsSigmaLR: state.simResultsSigmaLR,
        r2ScoresSigmaLR: state.r2ScoresSigmaLR,
        sigmaLRPreview: state.sigmaLRPreview,
        tailCountSigmaLR: state.tailCountSigmaLR,
        finalSigmaLR: state.finalSigmaLR,
        leftCountAddLR: state.leftCountAddLR,
        selectedCurveAddLR: state.selectedCurveAddLR,
        manualOverridesAddLR: state.manualOverridesAddLR,
        sourceSwitchesAddLR: state.sourceSwitchesAddLR,
        combinedAddLRSummary: state.combinedAddLRSummary,
        leftCountAddSigma: state.leftCountAddSigma,
        selectedCurveAddSigma: state.selectedCurveAddSigma,
        manualOverridesAddSigma: state.manualOverridesAddSigma,
        sourceSwitchesAddSigma: state.sourceSwitchesAddSigma,
        combinedAddSigmaSummary: state.combinedAddSigmaSummary,
        leftCountAddSD: state.leftCountAddSD,
        selectedCurveAddSD: state.selectedCurveAddSD,
        manualOverridesAddSD: state.manualOverridesAddSD,
        sourceSwitchesAddSD: state.sourceSwitchesAddSD,
        combinedAddSDSummary: state.combinedAddSDSummary,
      }),
      storage: {
        getItem: (name) => {
          const item = sessionStorage.getItem(name);
          return item ? JSON.parse(item) : null;
        },
        setItem: (name, value) => sessionStorage.setItem(name, JSON.stringify(value)),
        removeItem: (name) => sessionStorage.removeItem(name),
      },
    }
  )
);
