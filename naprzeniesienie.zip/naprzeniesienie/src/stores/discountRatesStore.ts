import { create } from 'zustand';

// Typy dla Stopy dyskontowe store
export interface DiscountRatesTriangleData {
  [rowIndex: number]: {
    [colIndex: number]: number | string | null;  // Dodaj string dla labeli
  };
}

export interface DiscountRatesStore {
  // Dane trójkąta stóp dyskontowych
  discountRatesTriangle: DiscountRatesTriangleData;
  selectedSheetName: string;
  uploadedFileName: string;
  decimalPlaces: number;
  selectedDiscountRateLine: number | null;
  availableDiscountRateLines: { index: number; label: string; values: (number | null)[] }[];

  // Actions
  setDiscountRatesTriangle: (triangle: DiscountRatesTriangleData) => void;
  setSelectedSheetName: (name: string) => void;
  setUploadedFileName: (name: string) => void;
  setDecimalPlaces: (places: number) => void;
  setSelectedDiscountRateLine: (line: number | null) => void;
  updateAvailableDiscountRateLines: () => void;
  resetData: () => void;
}

// Stan początkowy
const initialState = {
  discountRatesTriangle: {},
  selectedSheetName: '',
  uploadedFileName: '',
  decimalPlaces: 2,
  selectedDiscountRateLine: null,
  availableDiscountRateLines: [],
};

// Usuń stare dane z localStorage przy inicjalizacji
if (typeof window !== 'undefined') {
  localStorage.removeItem('discount-rates-store');
}

export const useDiscountRatesStore = create<DiscountRatesStore>()((set, get) => ({
  ...initialState,
  
  setDiscountRatesTriangle: (triangle) => {
    // Wyczyść sessionStorage przy każdym nowym wczytaniu
    const keysToRemove = Object.keys(sessionStorage).filter(key => 
      key.startsWith('discount-rates-') || key.includes('discountRates')
    );
    keysToRemove.forEach(key => sessionStorage.removeItem(key));
    
    set({ discountRatesTriangle: triangle });
    // Automatycznie przygotuj dostępne linie
    get().updateAvailableDiscountRateLines();
  },
  
  setSelectedDiscountRateLine: (line) => set({ selectedDiscountRateLine: line }),
  
  updateAvailableDiscountRateLines: () => {
    const triangle = get().discountRatesTriangle;
    const lines: { index: number; label: string; values: (number | null)[] }[] = [];
    
    // Iteruj przez wiersze trójkąta
    Object.keys(triangle).forEach(rowIndexStr => {
      const rowIndex = parseInt(rowIndexStr);
      const row = triangle[rowIndex];
      if (!row) return;
      
      // Pobierz label z pierwszej kolumny (kolumna 0)
      const labelValue = row[0];
      const label = labelValue !== null && labelValue !== undefined ? String(labelValue) : `Wiersz ${rowIndex + 1}`;
      
      // Pobierz wartości ze WSZYSTKICH kolumn OPRÓCZ kolumny 0 (etykiety)
      const values: (number | null)[] = [];
      const colKeys = Object.keys(row).map(Number).sort((a, b) => a - b);
      for (const colIndex of colKeys) {
        if (colIndex !== 0) { // Pomijamy TYLKO kolumnę 0 (etykiety), bierzemy wszystkie inne
          const cellValue = row[colIndex] ?? null;
          // Konwertuj stringi na liczby, zostaw null jak jest
          if (typeof cellValue === 'string') {
            const numValue = Number(cellValue);
            values.push(Number.isFinite(numValue) ? numValue : null);
          } else {
            values.push(cellValue);
          }
        }
      }
      
      // Dodaj linię tylko jeśli ma jakieś wartości
      if (values.some(v => v !== null)) {
        lines.push({
          index: rowIndex,
          label,
          values
        });
      }
    });
    
    console.log('🔍 updateAvailableDiscountRateLines result:', lines);
    set({ availableDiscountRateLines: lines });
  },
  
  setSelectedSheetName: (name) => set({ selectedSheetName: name }),
  setUploadedFileName: (name) => set({ uploadedFileName: name }),
  setDecimalPlaces: (places) => set({ decimalPlaces: places }),
  
  resetData: () => set(initialState),
}));