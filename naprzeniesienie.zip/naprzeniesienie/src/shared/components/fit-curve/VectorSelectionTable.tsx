'use client';

import React from 'react';
import clsx from 'clsx';
import { GenericTable } from '@/shared/ui';
import type { FitCurveConfig } from './types';

interface VectorSelectionTableProps {
  preview: number[] | null;
  selectedIndexes: number[];
  config: FitCurveConfig;
  columnLabels: string[];
  onToggleIndex: (index: number) => void;
  relatedDataInfo?: {
    labels: string[];
    lengths: number[];
  };
}

export function VectorSelectionTable({
  preview,
  selectedIndexes,
  config,
  columnLabels,
  onToggleIndex,
  relatedDataInfo
}: VectorSelectionTableProps) {
  if (!preview) return null;

  const isClassicPaidStyle =
    config.apiEndpoint === '/calc/paid/selected_dev_j' ||
    config.apiEndpoint === '/calc/sigma/selected_sigma' ||
    config.apiEndpoint === '/calc/incurred/selected_dev_j' ||
    config.apiEndpoint === '/calc/incurred/selected_sigma' ||
    config.apiEndpoint === '/calc/add/selected_add_j' ||
    config.apiEndpoint === '/calc/add/selected_add_j_incurred' ||
    config.apiEndpoint === '/calc/add/selected_sigma_LR' ||
    config.apiEndpoint === '/calc/add/selected_sigma_LR_incurred' ||
    config.apiEndpoint === '/calc/paid_incurred/fit_curve_rj' ||
    config.apiEndpoint === '/calc/paid_incurred/fit_curve_varj';

  // Przygotuj kolumny tabeli
  const baseLabels = columnLabels.length > 2 
    ? columnLabels.slice(2, preview.length + 2) 
    : preview.map((_, i) => i.toString());
  
  const vectorCols = ["–", ...baseLabels];

  const renderVector = (_: number, col: number) => {
    if (col === 0) {
      return isClassicPaidStyle ? <strong>Initial Selection</strong> : '0';
    }

    const idx = col - 1;
    const raw = preview[idx];
    if (raw === undefined) return "–";

    let selectable = raw > config.thresholdValue;
    
    // Dla r_j wykluczamy wartości równe dokładnie 1.0
    if (config.dataType === 'rJ' && Math.abs(raw - 1.0) < 0.0001) {
      selectable = false;
    }
    
    const selected = selectedIndexes.includes(idx);

    return (
      <span
        onClick={() => onToggleIndex(idx)}
        className={clsx(
          isClassicPaidStyle
            ? 'block text-center px-3 py-2 -mx-3 -my-2'
            : 'px-2 block',
          selectable
            ? isClassicPaidStyle
              ? selected
                ? 'bg-blue-200/70 text-gray-900 ring-1 ring-blue-400/60 cursor-pointer'
                : 'bg-white text-gray-800 hover:bg-gray-100 cursor-pointer'
              : selected
                ? 'bg-green-300 text-black font-semibold cursor-pointer'
                : 'hover:bg-gray-700 cursor-pointer'
            : isClassicPaidStyle
              ? 'bg-white text-gray-500 cursor-not-allowed'
              : 'text-gray-500 cursor-not-allowed'
        )}
      >
        {raw.toFixed(6)}
      </span>
    );
  };

  return (
    <div>
      {!isClassicPaidStyle && (
        <p className="text-sm text-gray-300 mb-2 text-center">
          {config.thresholdMessage}
        </p>
      )}
      {isClassicPaidStyle ? (
        <div className="relative w-full overflow-x-auto rounded-xl">
          <table className="min-w-max border-collapse bg-white text-sm text-gray-800">
            <thead>
              <tr>
                {vectorCols.map((column, index) => (
                  <th
                    key={index}
                    className="border border-gray-300 px-3 py-2 bg-gray-50 text-center"
                  >
                    {column}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr>
                {vectorCols.map((_, colIndex) => (
                  <td
                    key={colIndex}
                    className={clsx(
                      'border border-gray-300 px-3 py-2 text-center',
                      colIndex === 0 && 'sticky left-0 bg-gray-50'
                    )}
                  >
                    {renderVector(0, colIndex)}
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      ) : (
        <GenericTable
          cols={vectorCols}
          rows={1}
          stickyFirstCol
          renderCell={renderVector}
        />
      )}
      {!isClassicPaidStyle && (
        <p className="text-sm text-gray-400 mt-2 text-center">
          Wybrane: {selectedIndexes.length} współczynników {config.displayName}
          {relatedDataInfo && relatedDataInfo.lengths.some(l => l > 0) && (
            <span className="block text-green-400 text-xs mt-1">
              + dane {relatedDataInfo.labels.map((label, i) => 
                `${label}(${relatedDataInfo.lengths[i] || 0})`
              ).join(', ')} będą wysłane razem
            </span>
          )}
        </p>
      )}
    </div>
  );
}