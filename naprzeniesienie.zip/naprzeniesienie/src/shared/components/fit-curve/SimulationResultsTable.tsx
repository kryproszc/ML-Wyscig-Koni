'use client';

import React from 'react';
import clsx from 'clsx';
import { GenericTable } from '@/shared/ui';

interface SimulationResultsTableProps {
  simResults: Record<string, Record<string, number>>;
  title: string;
  useClassicPaidStyle?: boolean;
}

export function SimulationResultsTable({
  simResults,
  title,
  useClassicPaidStyle = false
}: SimulationResultsTableProps) {
  const cols = [
    'Krzywa',
    ...Object.keys(Object.values(simResults)[0]!).map((key) => key.replace('dp: ', 'k:')),
  ];

  const renderCell = (row: number, col: number) => {
    const curveKeys = Object.keys(simResults);
    const curve = curveKeys[row];
    if (!curve) return '–';

    if (col === 0) return <strong>{curve}</strong>;

    const dpKeys = Object.keys(simResults[curve] ?? {});
    const dpKey = dpKeys[col - 1];
    if (!dpKey) return '–';

    const value = simResults[curve]?.[dpKey];
    return value !== undefined ? value.toFixed(6) : '–';
  };

  return (
    <section className={useClassicPaidStyle ? 'w-full rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white' : undefined}>
      {useClassicPaidStyle ? (
        <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
          <h2 className="font-bold text-gray-800 text-lg tracking-tight">{title}</h2>
        </div>
      ) : (
        <h2 className="text-xl font-bold mb-4 text-center">{title}</h2>
      )}

      {useClassicPaidStyle ? (
        <div className="overflow-auto p-4">
          <div className="relative w-full overflow-x-auto rounded-xl">
            <table className="min-w-max border-collapse bg-white text-sm text-gray-800">
              <thead>
                <tr>
                  {cols.map((column, index) => (
                    <th
                      key={index}
                      className="border border-gray-300 px-3 py-2 bg-gray-50 text-center"
                    >
                      {column}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {Array.from({ length: Object.keys(simResults).length }).map((_, row) => (
                  <tr key={row}>
                    {cols.map((_, col) => (
                      <td
                        key={col}
                        className={clsx(
                          'border border-gray-300 px-3 py-2 text-center',
                          col === 0 && 'sticky left-0 bg-gray-50'
                        )}
                      >
                        {renderCell(row, col)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <GenericTable
          cols={cols}
          rows={Object.keys(simResults).length}
          stickyFirstCol
          renderCell={renderCell}
        />
      )}
    </section>
  );
}