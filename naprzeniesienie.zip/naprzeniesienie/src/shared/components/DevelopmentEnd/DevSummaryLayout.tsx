/* ------------------------------------------------------------------ */
/*                        DevSummaryLayout                           */
/* ------------------------------------------------------------------ */

import React, { useMemo, useEffect } from 'react'
import type { DevSummaryProps } from '@/shared/types/developmentEnd'
import { DevSummarySidebar } from './DevSummarySidebar'
import { DevBasicTable } from './DevBasicTable'
import { SimulationTable } from './SimulationTable'
import { FinalTable } from './FinalTable'
import { 
  createDpHeaders, 
  createCombinedDevJ, 
  cleanBlockedOverrides 
} from '@/shared/utils/developmentEndUtils'

export function DevSummaryLayout({
  leftCount,
  setLeftCount,
  selectedCurve,
  setSelectedCurve,
  manualOverrides,
  setManualOverrides,
  sourceSwitches,
  setSourceSwitches,
  devJPreview,
  simResults,
  setCombinedDevJ,
  columnLabels,
  onRemainingDevJHeaders,
  disabledCurves = [],
  tableContext = 'CL', // 🆕 DEFAULT to CL
  storeHook,           // 🆕 Store hook dla dynamic store access
  useClassicStyle = false,
  lockExponentialWeighted = false
}: DevSummaryProps) {

  // Czyścimy ręczne nadpisania, jeśli wpadają do części zablokowanej
  useEffect(() => {
    const filteredOverrides = cleanBlockedOverrides(manualOverrides, leftCount)
    if (Object.keys(filteredOverrides).length !== Object.keys(manualOverrides).length) {
      setManualOverrides(filteredOverrides)
    }
  }, [leftCount, manualOverrides, setManualOverrides])

  // Czyścimy sourceSwitches, jeśli wpadają poza lewą część
  useEffect(() => {
    // Only filter if leftCount is properly set (> 0), otherwise preserve switches
    if (leftCount > 0) {
      const filteredSwitches: Record<number, { curve: string; value: number }> = {}
      Object.entries(sourceSwitches).forEach(([idxStr, switchData]) => {
        const idx = Number(idxStr)
        if (idx < leftCount) {
          filteredSwitches[idx] = switchData
        }
      })
      if (Object.keys(filteredSwitches).length !== Object.keys(sourceSwitches).length) {
        setSourceSwitches(filteredSwitches)
      }
    }
    // If leftCount is 0, don't filter - preserve existing switches
  }, [leftCount, sourceSwitches, setSourceSwitches])

  // Brak danych → nic nie wyświetlamy
  if (!simResults || !devJPreview?.length) {
    return <p className="text-gray-400 text-center">Brak danych do podsumowania.</p>
  }

  // Pomocnicze listy nagłówków dp
  const dpHeaders = useMemo(() => createDpHeaders(simResults), [simResults])

  // Kombinowany devJ
  const combinedDevJ = useMemo(() => 
    createCombinedDevJ(
      devJPreview,
      dpHeaders,
      leftCount,
      selectedCurve,
      simResults,
      manualOverrides,
      sourceSwitches
    ),
    [devJPreview, dpHeaders, leftCount, selectedCurve, simResults, manualOverrides, sourceSwitches]
  )

  // Udostępniamy podsumowanie innym zakładkom
  useEffect(() => {
    setCombinedDevJ(combinedDevJ)
  }, [combinedDevJ, setCombinedDevJ])

  const maxLen = Math.max(devJPreview.length, dpHeaders.length)

  // Callback do obsługi ręcznej edycji w FinalTable
  const handleManualEdit = (index: number) => {
    // Gdy użytkownik ręcznie edytuje wartość w FinalTable,
    // automatycznie odznacz wybór w sourceSwitches (tabela Initial Selection)
    if (sourceSwitches[index]) {
      const updated = { ...sourceSwitches }
      delete updated[index]
      setSourceSwitches(updated)
    }
  }

  return (
    <div className={useClassicStyle ? 'flex w-full h-full gap-6 p-6' : 'flex w-full h-full'}>
      <DevSummarySidebar 
        leftCount={leftCount}
        setLeftCount={setLeftCount}
        useClassicStyle={useClassicStyle}
      />

      <div className={useClassicStyle ? 'flex-1 flex flex-col gap-8 w-full overflow-x-auto' : 'flex-1 flex flex-col gap-10 w-full p-6 overflow-x-auto'}>
        <DevBasicTable
          devJPreview={devJPreview}
          columnLabels={columnLabels}
          leftCount={leftCount}
          sourceSwitches={sourceSwitches}
          setSourceSwitches={setSourceSwitches}
          selectedCurve={selectedCurve}
          simResults={simResults}
          manualOverrides={manualOverrides}
          setManualOverrides={setManualOverrides}
          disableClicks={true}
          useClassicStyle={useClassicStyle}
        />

        <SimulationTable
          simResults={simResults}
          dpHeaders={dpHeaders}
          leftCount={leftCount}
          selectedCurve={selectedCurve}
          setSelectedCurve={setSelectedCurve}
          manualOverrides={manualOverrides}
          setManualOverrides={setManualOverrides}
          sourceSwitches={sourceSwitches}
          setSourceSwitches={setSourceSwitches}
          disabledCurves={disabledCurves}
          isInitialSelection={false}
          useClassicStyle={useClassicStyle}
          lockExponentialWeighted={lockExponentialWeighted}
        />

        <FinalTable
          combinedDevJ={combinedDevJ}
          maxLen={maxLen}
          leftCount={leftCount}
          columnLabels={columnLabels}
          manualOverrides={manualOverrides}
          setManualOverrides={setManualOverrides}
          sourceSwitches={sourceSwitches}
          setSourceSwitches={setSourceSwitches}
          selectedCurve={selectedCurve}
          devJPreview={devJPreview}
          simResults={simResults}
          onHeadersGenerated={onRemainingDevJHeaders}
          onManualEdit={handleManualEdit}
          tableContext={tableContext} // 🆕 PRZEKAŻ KONTEKST
          setCombinedDevJ={setCombinedDevJ} // 🔧 DODAJ setCombinedDevJ dla aktualizacji combinedSigmaSummary
          storeHook={storeHook} // 🆕 Przekaż store hook
          useClassicStyle={useClassicStyle}
        />
      </div>
    </div>
  )
}
