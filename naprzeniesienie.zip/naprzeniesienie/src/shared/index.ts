// Components (domain-specific)
export { TriangleTableView } from './components/TriangleTableView';

// DevelopmentEnd Components
export * from './components/DevelopmentEnd';

// FitCurve Components
export * from './components/fit-curve';

// Symulacje Components (reusable)
export * from './components/Symulacje';

// UI Components (generic/reusable)
export * from './ui';

// Hooks  
export { useIncurredTriangleProcessing } from './hooks/useIncurredTriangleProcessing';
export { useDevSummaryEditing } from './hooks/useDevSummaryEditing';
export { useDataOptions } from './hooks/useDataOptions';
export { usePayloadBuilder } from './hooks/usePayloadBuilder';
export { useExcelExport } from './hooks/useExcelExport';
export { useSummaryDropdownOptions } from './hooks/useSummaryDropdownOptions';
export { useFitCurveData } from './hooks/useFitCurveData';
export * from './hooks';

// Types
export type { TriangleData, TriangleViewProps, TriangleDisplayData } from './types/triangle';
export * from './types/developmentEnd';
export * from './types/summary';
export type { SelectOption, DevJResult, SimResults, UseDataOptionsParams } from './hooks/useDataOptions';
export type { UsePayloadBuilderParams } from './hooks/usePayloadBuilder';
export type { ComparisonTableEntry } from './hooks/useExcelExport';
// USUNIĘTE: nieistniejący typ
// export type { ComparisonTableProps } from './components/ComparisonTable';

// Utils
export * from './utils/developmentEndUtils';
export * from './utils/summaryUtils';
export * from './utils';
