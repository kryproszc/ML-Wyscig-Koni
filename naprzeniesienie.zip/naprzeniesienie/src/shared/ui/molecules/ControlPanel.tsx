import { Button } from "../atoms/Button";
import { InputNumber } from "../atoms/InputNumber";
import { Card } from "../atoms/Card";

type Props = {
  currentVectorLength: number;
  tailCount: number | "";
  onTailChange: (v: number | "") => void;
  onUpdateVector: () => void;
  onSend: () => void;
  disableSend: boolean;
};

export const ControlPanel = ({
  currentVectorLength,
  tailCount,
  onTailChange,
  onUpdateVector,
  onSend,
  disableSend,
}: Props) => (
  <Card className="w-full lg:w-64 h-fit shrink-0">
    <h3 className="text-lg font-semibold mb-4">Panel sterowania</h3>

    <Button
      full
      onClick={onUpdateVector}
      disabled={!currentVectorLength}
      className={`mb-4 py-4 px-5 rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform ${
        currentVectorLength
          ? 'bg-gradient-to-r from-gray-600 to-gray-500 hover:from-gray-700 hover:to-gray-600 text-white'
          : 'bg-gray-600 text-gray-400 cursor-not-allowed'
      }`}
    >
      Zaktualizuj wektor
    </Button>

    <label className="block text-sm mb-1">Ile obserwacji w&nbsp;ogonie:</label>
    <InputNumber
      full
      min={0}
      value={tailCount}
      placeholder="np. 2"
      onChange={(e) =>
        onTailChange(e.target.value === "" ? "" : parseInt(e.target.value, 10))
      }
    />

    <Button
      full
      variant="success"
      onClick={onSend}
      disabled={disableSend}
      className={`mt-3 py-4 px-5 rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform ${
        disableSend
          ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
          : 'bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-700 hover:to-emerald-600 text-white'
      }`}
    >
      Dopasuj krzywe
    </Button>
  </Card>
);
