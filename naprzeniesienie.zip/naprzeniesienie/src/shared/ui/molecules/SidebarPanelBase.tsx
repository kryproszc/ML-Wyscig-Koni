'use client';

import Modal from '@/components/Modal';

export type SidebarPanelBaseProps = {
  volume: number;
  onVolumeChange: (v: number) => void;
  maxVolume?: number;
  showVolume?: boolean;

  onCalculate: () => void;
  onExport   : () => void;
  onReset    : () => void;

  isResetModalOpen       : boolean;
  setResetModalOpen      : (b: boolean) => void;
  isMissingFinalModalOpen: boolean;
  closeMissingFinalModal : () => void;
};

export default function SidebarPanelBase({
  volume,
  onVolumeChange,
  maxVolume,
  showVolume = true,
  onCalculate,
  onExport,
  onReset,
  isResetModalOpen,
  setResetModalOpen,
  isMissingFinalModalOpen,
  closeMissingFinalModal,
}: SidebarPanelBaseProps) {
  return (
    <div className="w-full flex flex-col gap-3">
      {showVolume && (
        <>
          <label className="text-sm text-white">Wybierz volume</label>
          <input
            type="number"
            className="w-full p-3 rounded bg-white text-black font-medium"
            value={volume}
            min={0}
            max={maxVolume}
            onChange={(e) => onVolumeChange(Number(e.target.value))}
          />
        </>
      )}

      <button
        onClick={onCalculate}
        className="w-full py-4 px-5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl font-bold hover:from-emerald-700 hover:to-emerald-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
      >
        Oblicz
      </button>

      <button
        onClick={onExport}
        className="w-full py-4 px-5 bg-gradient-to-r from-amber-600 to-amber-500 text-white rounded-xl font-bold hover:from-amber-700 hover:to-amber-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
      >
        Eksportuj do Excela
      </button>

      <button
        onClick={() => setResetModalOpen(true)}
        className="w-full py-4 px-5 bg-gradient-to-r from-orange-600 to-orange-500 text-white rounded-xl font-bold hover:from-orange-700 hover:to-orange-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
      >
        Reset współczynników
      </button>

      <Modal
        isOpen={isResetModalOpen}
        title="Usunięcie współczynników"
        message="Czy na pewno chcesz usunąć współczynniki CL i wektory dev_j? Ta operacja jest nieodwracalna."
        onCancel={() => setResetModalOpen(false)}
        onConfirm={() => {
          onReset();
          setResetModalOpen(false);
        }}
      />

      <Modal
        isOpen={isMissingFinalModalOpen}
        title="Brak finalnego wektora"
        message="Najpierw wybierz finalny wektor dev_j."
        onConfirm={closeMissingFinalModal}
        onlyOk
      />
    </div>
  );
}
