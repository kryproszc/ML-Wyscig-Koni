import React from "react";
import clsx from "clsx";

export interface InputNumberProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  full?: boolean;
}

export const InputNumber = React.forwardRef<HTMLInputElement, InputNumberProps>(
  ({ full, className, ...rest }, ref) => (
    <input
      ref={ref}
      type="number"
      {...rest}
      className={clsx(
        "bg-gray-700 text-white px-2 py-1 rounded placeholder-gray-400",
        full && "w-full",
        className
      )}
    />
  )
);
InputNumber.displayName = "InputNumber";
