import React from "react";
import clsx from "clsx";

export const Card: React.FC<
  React.HTMLAttributes<HTMLDivElement> & { as?: React.ElementType }
> = ({ as: Comp = "div", className, ...rest }) => (
  <Comp
    {...rest}
    className={clsx("bg-gray-800 p-4 rounded-xl shadow-lg", className)}
  />
);
