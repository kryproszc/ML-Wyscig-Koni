import React, { useMemo } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

type SimResults = Record<string, Record<string, number>>;

type Props = {
  simResults: SimResults | null;
  devJ?: number[];
  dpRange: [number, number];
  selectedCurves: string[];
  isFullscreen?: boolean;
};

export const SimulationChart = ({
  simResults,
  devJ,
  dpRange,
  selectedCurves,
  isFullscreen = false,
}: Props) => {
  const data = useMemo(() => {
    if (!simResults) return [];
    const allDpKeys = Object.keys(simResults?.["Exponential"] ?? {});
    return allDpKeys
      .filter((dpKey) => {
        const n = parseInt(dpKey.replace("dp: ", ""), 10);
        return n >= dpRange[0] && n <= dpRange[1];
      })
      .map((dpKey) => {
        const point: Record<string, number | string> = { dp: dpKey };
        for (const curve in simResults) {
          point[curve] = simResults[curve]?.[dpKey] ?? 0;
        }
        const idx = parseInt(dpKey.replace("dp: ", ""), 10) - 1;
        const devVal = devJ?.[idx];
        if (typeof devVal === "number") point["Initial Selection"] = devVal;
        return point;
      });
  }, [simResults, devJ, dpRange]);

  if (!simResults) return null;

  return (
    <div className={`bg-gray-50 border border-gray-400 rounded-lg shadow-sm p-4 text-gray-900 w-full ${
      isFullscreen ? 'h-[calc(100vh-200px)]' : 'h-[650px]'
    }`}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{ top: 40, right: 60, left: 80, bottom: 100 }}
        >
          <CartesianGrid 
            strokeDasharray="2 2" 
            stroke="#9ca3af" 
            strokeWidth={1}
          />
          <XAxis 
            dataKey="dp" 
            stroke="#374151" 
            interval={0} 
            tick={{ fill: "#374151", fontSize: 14, fontFamily: "serif" }}
            tickLine={{ stroke: '#374151', strokeWidth: 1 }}
            axisLine={{ stroke: '#374151', strokeWidth: 2 }}
            label={{
              value: 'Okres rozwoju (dp)',
              position: 'insideBottom',
              offset: -15,
              style: { textAnchor: 'middle', fontSize: '14px', fontFamily: 'serif', fill: '#374151', fontWeight: '600' }
            }}
          />
          <YAxis 
            stroke="#374151" 
            domain={['auto', 'auto']} 
            tickFormatter={(value) => value.toFixed(2)}
            tick={{ fill: "#374151", fontSize: 14, fontFamily: "serif" }}
            tickLine={{ stroke: '#374151', strokeWidth: 1 }}
            axisLine={{ stroke: '#374151', strokeWidth: 2 }}
            label={{
              value: 'Współczynnik rozwoju',
              angle: -90,
              position: 'insideLeft',
              style: { textAnchor: 'middle', fontSize: '14px', fontFamily: 'serif', fill: '#374151', fontWeight: '600' }
            }}
          />
          <Tooltip
            contentStyle={{ 
              background: "#f9fafb", 
              borderColor: "#6b7280", 
              color: "#111827",
              border: "2px solid #6b7280",
              borderRadius: "8px",
              boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
              fontSize: "14px",
              padding: "12px"
            }}
            labelStyle={{ color: "#374151", fontWeight: "600", fontSize: "14px" }}
            formatter={(value: any, name: string) => [
              typeof value === 'number' ? value.toFixed(4) : value,
              name
            ]}
          />
          <Legend 
            verticalAlign="bottom" 
            height={60} 
            wrapperStyle={{ 
              paddingTop: 25, 
              color: "#374151",
              fontSize: "14px",
              fontFamily: "serif",
              fontWeight: "500"
            }} 
          />

          {selectedCurves.includes("Exponential") && (
            <Line 
              type="monotone" 
              dataKey="Exponential" 
              stroke="#2563eb" 
              strokeWidth={3.5}
              dot={{ fill: "#2563eb", strokeWidth: 1.5, r: 4 }}
              activeDot={{ r: 7, stroke: "#2563eb", strokeWidth: 3, fill: "#ffffff" }}
            />
          )}
          {selectedCurves.includes("Weibull") && (
            <Line 
              type="monotone" 
              dataKey="Weibull" 
              stroke="#059669" 
              strokeWidth={3.5}
              dot={{ fill: "#059669", strokeWidth: 1.5, r: 4 }}
              activeDot={{ r: 7, stroke: "#059669", strokeWidth: 3, fill: "#ffffff" }}
            />
          )}
          {selectedCurves.includes("Power") && (
            <Line 
              type="monotone" 
              dataKey="Power" 
              stroke="#d97706" 
              strokeWidth={3.5}
              dot={{ fill: "#d97706", strokeWidth: 1.5, r: 4 }}
              activeDot={{ r: 7, stroke: "#d97706", strokeWidth: 3, fill: "#ffffff" }}
            />
          )}
          {selectedCurves.includes("Inverse Power") && (
            <Line 
              type="monotone" 
              dataKey="Inverse Power" 
              stroke="#7c3aed" 
              strokeWidth={3.5}
              dot={{ fill: "#7c3aed", strokeWidth: 1.5, r: 4 }}
              activeDot={{ r: 7, stroke: "#7c3aed", strokeWidth: 3, fill: "#ffffff" }}
            />
          )}
          {selectedCurves.includes("Initial Selection") && (
            <Line 
              type="monotone" 
              dataKey="Initial Selection" 
              stroke="#dc2626" 
              strokeWidth={4}
              name="Initial Selection"
              dot={{ fill: "#dc2626", strokeWidth: 2, r: 5 }}
              activeDot={{ r: 8, stroke: "#dc2626", strokeWidth: 3, fill: "#ffffff" }}
            />
          )}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};
