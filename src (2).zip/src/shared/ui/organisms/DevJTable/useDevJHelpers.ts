// src/shared/ui/organisms/DevJTable/useDevJHelpers.ts
export const fmt = (n?: number) =>
  typeof n === 'number' ? n.toFixed(6) : '-';

export function mergePreview(
  base: number[],
  overrides: Record<number, { value: number }>
) {
  const merged = [...base];
  Object.entries(overrides).forEach(([i, c]) => {
    merged[+i] = c.value;
  });
  return merged;
}
