'use client';

import Modal from '@/components/Modal';

export type SidebarPanelBaseProps = {
  volume: number;
  onVolumeChange: (v: number) => void;

  onCalculate: () => void;
  onExport   : () => void;
  onReset    : () => void;

  isResetModalOpen       : boolean;
  setResetModalOpen      : (b: boolean) => void;
  isMissingFinalModalOpen: boolean;
  closeMissingFinalModal : () => void;
};

export default function SidebarPanelBase({
  volume,
  onVolumeChange,
  onCalculate,
  onExport,
  onReset,
  isResetModalOpen,
  setResetModalOpen,
  isMissingFinalModalOpen,
  closeMissingFinalModal,
}: SidebarPanelBaseProps) {
  return (
    <div className="w-full bg-slate-800 rounded-xl p-4 flex flex-col gap-4">
      <label className="text-sm text-white">Wybierz volume</label>
      <input
        type="number"
        className="w-full p-3 mt-1 rounded bg-white text-black font-medium"
        value={volume}
        min={0}
        onChange={(e) => onVolumeChange(Number(e.target.value))}
      />

      <button
        onClick={onCalculate}
        className="w-full py-3 px-4 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors"
      >
        Oblicz
      </button>

      <button
        onClick={onExport}
        className="w-full py-3 px-4 bg-amber-500 text-white rounded-lg font-medium hover:bg-amber-600 transition-colors"
      >
        Eksportuj do Excela
      </button>

      <button
        onClick={() => setResetModalOpen(true)}
        className="w-full py-3 px-4 bg-rose-500 text-white rounded-lg font-medium hover:bg-rose-600 transition-colors"
      >
        Reset współczynników
      </button>

      <Modal
        isOpen={isResetModalOpen}
        title="Usunięcie współczynników"
        message="Czy na pewno chcesz usunąć współczynniki CL i wektory dev_j? Ta operacja jest nieodwracalna."
        onCancel={() => setResetModalOpen(false)}
        onConfirm={() => {
          onReset();
          setResetModalOpen(false);
        }}
      />

      <Modal
        isOpen={isMissingFinalModalOpen}
        title="Brak finalnego wektora"
        message="Najpierw wybierz finalny wektor dev_j."
        onConfirm={closeMissingFinalModal}
        onlyOk
      />
    </div>
  );
}
