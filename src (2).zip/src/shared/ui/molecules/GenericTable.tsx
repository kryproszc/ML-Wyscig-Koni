import React from "react";
import clsx from "clsx";

export type CellRenderer = (row: number, col: number) => React.ReactNode;

export interface GenericTableProps {
  cols: React.ReactNode[];   // nagłówki
  rows: number;              // liczba wierszy
  renderCell: CellRenderer;  // renderer komórki
  stickyFirstCol?: boolean;
  className?: string;
}

export const GenericTable = ({
  cols,
  rows,
  renderCell,
  stickyFirstCol,
  className,
}: GenericTableProps) => (
  <div className="relative w-full overflow-x-auto rounded-xl">
    <table
      className={clsx(
        "min-w-max border-collapse bg-gray-900 text-sm",
        className
      )}
    >
      <thead>
        <tr>
          {cols.map((c, i) => (
            <th
              key={i}
              className="border border-gray-700 px-3 py-2 bg-gray-800 text-center"
            >
              {c}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {Array.from({ length: rows }).map((_, r) => (
          <tr key={r}>
            {cols.map((_, c) => (
              <td
                key={c}
                className={clsx(
                  "border border-gray-700 px-3 py-2 text-center",
                  stickyFirstCol && c === 0 && "sticky left-0 bg-gray-800"
                )}
              >
                {renderCell(r, c)}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);
