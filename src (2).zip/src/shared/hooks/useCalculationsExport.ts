import { useMemo, useState } from 'react';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import type { SelectOption } from './useDataOptions';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useTrainDevideStoreDetIncurred } from '@/stores/trainDevideStoreDeterministycznyIncurred';
import { useTableStore } from '@/stores/tableStore';
import { useLabelsStore } from '@/stores/useLabelsStore';

export interface ExportItem {
  key: string;
  label: string;
  selected: boolean;
}

export interface UseCalculationsExportProps {
  allOptions: SelectOption[];
  simResults: Record<string, any>;
  devJResults: any[];
  combinedDevJSummary: any[];
  finalDevVector: any[];
  buildPayload: (key: string | null) => any | null;
  columnLabels?: string[];
  triangleType?: 'paid' | 'incurred';
  comparisonTables?: Array<{
    data: any[];
    labelA: string;
    labelB: string;
  }>;
  // Add selected volume info for highlighting
  selectedVolume?: number;
  selectedSubIndex?: number;
}

export const useCalculationsExport = ({
  allOptions,
  simResults,
  devJResults,
  combinedDevJSummary,
  finalDevVector,
  buildPayload,
  columnLabels,
  triangleType = 'paid',
  comparisonTables = [],
  selectedVolume,
  selectedSubIndex,
}: UseCalculationsExportProps) => {
  const [exportItems, setExportItems] = useState<ExportItem[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Get remaining dev_j headers from stores
  const paidRemainingDevJHeaders = useTrainDevideStoreDet(s => s.remainingDevJHeaders);
  const incurredRemainingDevJHeaders = useTrainDevideStoreDetIncurred(s => s.remainingDevJHeaders);
  
  // Get input data from stores
  const paidTriangle = useTrainDevideStoreDet(s => s.paidTriangle);
  const incurredTriangle = useTrainDevideStoreDetIncurred(s => s.incurredTriangle);
  const clData = useTableStore(s => s.clData);
  
  // Get CL coefficients data from train divide stores
  const paidTrainDevide = useTrainDevideStoreDet(s => s.trainDevideDet);
  const incurredTrainDevide = useTrainDevideStoreDetIncurred(s => s.trainDevideDetIncurred);

  // + NEW — etykiety dla paid/incurred
const paidRowLabels      = useLabelsStore(s => s.detRowLabels);
const paidColumnLabels   = useLabelsStore(s => s.detColumnLabels);
const incurredRowLabels  = useLabelsStore(s => s.incurredRowLabels);
const incurredColumnLabels = useLabelsStore(s => s.incurredColumnLabels);

// aktywny zestaw etykiet do eksportu (dokładnie tak jak w zakładkach)
const activeRowLabels = useMemo(
  () => triangleType === 'incurred'
    ? (incurredRowLabels?.slice(1) ?? [])   // w UI pomijacie pierwszy "AY"
    : (paidRowLabels ?? []),
  [triangleType, paidRowLabels, incurredRowLabels]
);

const activeColumnLabels = useMemo(
  () => triangleType === 'incurred'
    ? (incurredColumnLabels?.slice(1) ?? [])
    : (paidColumnLabels ?? []),
  [triangleType, paidColumnLabels, incurredColumnLabels]
);


  // Initialize export items when dialog opens
  const initializeExportItems = () => {
    const items = allOptions.map(option => ({
      key: option.key,
      label: option.label,
      selected: false,
    }));

    // Add input data options at the beginning (only for export dialog)
    items.unshift(
      {
        key: 'input-triangle',
        label: 'Trójkąt danych',
        selected: false,
      },
      {
        key: 'input-cl',
        label: 'Współczynniki CL',
        selected: false,
      }
    );

    // Add comparison tables as export options
    if (comparisonTables && comparisonTables.length > 0) {
      comparisonTables.forEach((comparison, index) => {
        items.push({
          key: `comparison-${index}`,
          label: `Porównanie: ${comparison.labelA} vs ${comparison.labelB}`,
          selected: false,
        });
      });
    }

    setExportItems(items);
    setIsDialogOpen(true);
  };

  // Toggle selection for a specific item
  const toggleItemSelection = (key: string) => {
    setExportItems(prev => 
      prev.map(item => 
        item.key === key ? { ...item, selected: !item.selected } : item
      )
    );
  };

  // Select/deselect all items
  const toggleAllSelection = () => {
    const allSelected = exportItems.every(item => item.selected);
    setExportItems(prev => 
      prev.map(item => ({ ...item, selected: !allSelected }))
    );
  };

  // Get data for export based on key
  const getDataByKey = (key: string) => {
    console.log(`🔍 Getting data for key: ${key}`);
    
    // Handle comparison tables
    if (key.startsWith('comparison-')) {
      const index = parseInt(key.replace('comparison-', ''), 10);
      if (comparisonTables && comparisonTables[index]) {
        console.log(`✅ Found comparison table at index ${index}:`, comparisonTables[index]);
        return comparisonTables[index];
      }
    }
    
    // Convert key format for buildPayload if needed
    let payloadKey = key;
    
    // Handle volume keys - convert from "volume-X-Y" to "volume-X" for buildPayload
    if (key.startsWith('volume-') && key.split('-').length === 3) {
      const parts = key.split('-');
      payloadKey = `volume-${parts[1]}`;
      console.log(`🔄 Converting volume key from ${key} to ${payloadKey}`);
    }
    
    // Use buildPayload to get the same formatted data that's sent to API
    const payloadData = buildPayload(payloadKey);
    if (payloadData) {
      console.log(`✅ Found payload data for ${key} (using ${payloadKey}):`, payloadData);
      return payloadData;
    }

    // Fallback to raw data access
    console.log('📊 Available simResults keys:', Object.keys(simResults));
    console.log('📈 devJResults:', devJResults);
    console.log('🔗 combinedDevJSummary:', combinedDevJSummary);
    console.log('🎯 finalDevVector:', finalDevVector);

    // Handle curve keys directly
    if (key.startsWith('curve-')) {
      const curve = key.replace('curve-', '');
      if (simResults[curve]) {
        console.log(`✅ Found curve in simResults:`, simResults[curve]);
        return simResults[curve];
      }
    }

    // Handle volume keys directly
    if (key.startsWith('volume-')) {
      const parts = key.split('-');
      if (parts.length >= 2 && parts[1]) {
        const vol = parseInt(parts[1], 10);
        const subIndex = parts.length > 2 && parts[2] ? parseInt(parts[2], 10) : 0;
        
        const found = devJResults.find((v) => v.volume === vol && (v.subIndex ?? 0) === subIndex);
        if (found) {
          console.log(`✅ Found volume ${vol} subIndex ${subIndex}:`, found);
          return found;
        }
      }
    }

    // Handle input data keys
    if (key === 'input-triangle') {
      const triangleData = triangleType === 'incurred' ? incurredTriangle : paidTriangle;
      console.log(`✅ Input triangle data:`, triangleData);
      return triangleData;
    }
    
    if (key === 'input-cl') {
      const clCoefficientsData = triangleType === 'incurred' ? incurredTrainDevide : paidTrainDevide;
      console.log(`✅ Input CL coefficients data:`, clCoefficientsData);
      return clCoefficientsData;
    }

    // Handle combined dev_j
    if (key === 'final-dev-j') {
      console.log(`✅ combinedDevJSummary:`, combinedDevJSummary);
      return combinedDevJSummary;
    }

    // Handle raw final dev vector
    if (key === 'final-dev-raw') {
      console.log(`✅ finalDevVector:`, finalDevVector);
      return finalDevVector;
    }

    console.log(`❌ No data found for key: ${key}`);
    return null;
  };

  // Export selected calculations to Excel
  const exportSelectedCalculations = () => {
    const selectedItems = exportItems.filter(item => item.selected);
    
    if (selectedItems.length === 0) {
      alert('Wybierz przynajmniej jeden element do eksportu');
      return;
    }

    try {
      console.log('🚀 Starting fresh export with current data...');
      
      const workbook = XLSX.utils.book_new();
      
      // Organize data into categories
      const curves: any[] = [];
      const volumes: any[] = [];
      const comparisons: any[] = [];
      let selectedValue: any = null;
      let inputTriangleData: any = null;
      let inputClData: any = null;

      selectedItems.forEach((item) => {
        // Get fresh data for each item
        console.log(`🔄 Getting fresh data for ${item.key}...`);
        
        let data;
        if (item.key === 'input-triangle' || item.key === 'input-cl' || item.key.startsWith('comparison-')) {
          // For input data and comparison tables, use getDataByKey directly
          data = getDataByKey(item.key);
        } else {
          // For other data, use buildPayload
          data = buildPayload(item.key);
        }
        
        console.log(`🔍 Fresh export data for ${item.key}:`, data);
        
        if (data !== null && data !== undefined) {
          if (item.key === 'input-triangle') {
            // Input triangle data
            inputTriangleData = data;
          } else if (item.key === 'input-cl') {
            // Input CL coefficients data
            inputClData = data;
          } else if (item.key.startsWith('comparison-')) {
            // Comparison table data
            comparisons.push({
              data: data.data,
              labelA: data.labelA,
              labelB: data.labelB,
              index: item.key.replace('comparison-', ''),
            });
          } else if (item.key.startsWith('curve-')) {
            // Curve data
            if (data.curve_name && data.coeffs) {
              curves.push({
                name: data.curve_name,
                coeffs: data.coeffs,
              });
            }
          } else if (item.key.startsWith('volume-') || item.key === 'final-dev-raw') {
            // Volume or raw dev vector data
            if (data.volume && data.values) {
              volumes.push({
                name: `Volume ${data.volume}`,
                values: data.values,
              });
            } else if (item.key === 'final-dev-raw' && data.final_dev_vector) {
              volumes.push({
                name: 'Initial Value',
                values: data.final_dev_vector,
              });
            } else if (Array.isArray(data)) {
              volumes.push({
                name: item.label,
                values: data,
              });
            }
          } else if (item.key === 'final-dev-j') {
            // Selected combined dev_j
            if (data.final_dev_vector) {
              selectedValue = {
                name: 'Selected Values',
                values: data.final_dev_vector,
              };
            } else if (Array.isArray(data)) {
              selectedValue = {
                name: 'Selected Values',
                values: data,
              };
            }
          }
        } else {
          console.warn(`⚠️ No fresh data found for ${item.key}`);
        }
      });

      // Build combined sheet data
      const sheetData: any[][] = [];
      let currentRow = 0;

      // 0. Trójkąty (Input Data) - only if selected by user
      if (inputTriangleData || inputClData) {
        sheetData.push(['=== Trójkąty (dane wejściowe) ===']);
        currentRow++;
        sheetData.push([]);
        currentRow++;

        // Triangle section - only if selected by user
        if (inputTriangleData && inputTriangleData.length > 0) {
          sheetData.push(['1. Trójkąt:']);
          currentRow++;
          
          // Create headers for triangle (year + periods)
const maxCols = Math.max(...inputTriangleData.map((row: any[]) => row.length));
// pierwszy nagłówek nazwijmy "AY" (może być pusty '' jeśli wolisz)
const triangleHeaders = ['', ...activeColumnLabels.slice(0, maxCols)];
sheetData.push(triangleHeaders);
          currentRow++;
          
          // Add triangle data rows with years
inputTriangleData.forEach((row: any[], idx: number) => {
  const ay = activeRowLabels[idx] ?? '';               // np. 1981, 1982… lub dowolny custom
  const dataRow: any[] = [ay, ...row.map(v => v ?? '')];

  // dopadnij do liczby kolumn (nagłówki + 1 na AY)
  while (dataRow.length < triangleHeaders.length) dataRow.push('');
  sheetData.push(dataRow);
});

          sheetData.push([]);
          currentRow++;
        }

        // CL Coefficients section - only if selected by user
        if (inputClData && inputClData.length > 0) {
          sheetData.push(['2. Współczynniki CL:']);
          currentRow++;
          
          // Create headers for CL coefficients - based on the data structure from trainDevide
const maxClCols = Math.max(...inputClData.map((row: any[]) => row.length));
const src = (columnLabels && columnLabels.length) ? columnLabels : activeColumnLabels;

// nagłówki: AY + dp6..dp(N) - using same indexing as Dev podstawowe section
const clHeaders = ['AY', ...src.slice(1, 1 + maxClCols)];
sheetData.push(clHeaders);

// wiersze – bez zmian, ale padding do długości nagłówków
inputClData.forEach((row: any[], idx: number) => {
  const ay = activeRowLabels[idx] ?? '';
  const dataRow: any[] = [ay, ...row.map(v => v ?? '')];
  while (dataRow.length < clHeaders.length) dataRow.push('');
  sheetData.push(dataRow);
});
        }

        // Add separator
        sheetData.push([]);
        sheetData.push([]);
        currentRow += 2;
      }

      // 1. Dev podstawowe (Volumes + Raw finalDevVector)
      if (volumes.length > 0) {
        sheetData.push(['=== 1. Dev podstawowe ===']);
        currentRow++;
        sheetData.push([]);
        currentRow++;

        // Find the maximum number of values across all volumes
        const maxValues = Math.max(...volumes.map(vol => vol.values.length));
        
        // Create header row with development periods - match CL coefficients headers (start from column index 1)
        const src = (columnLabels && columnLabels.length) ? columnLabels : activeColumnLabels;
        const headers = ['Nazwa', ...src.slice(1, 1 + maxValues)];
        sheetData.push(headers);
        currentRow++;
        
        // Add each volume as a row
        volumes.forEach((vol) => {
          const row = [vol.name, ...vol.values];
          // Fill missing values with empty strings if volume has fewer values
          while (row.length < headers.length) {
            row.push('');
          }
          sheetData.push(row);
          currentRow++;
        });

        // Add separator
        sheetData.push([]);
        sheetData.push([]);
        currentRow += 2;
      }

      // 2. Symulacja krzywych CL
      if (curves.length > 0) {
        sheetData.push(['=== 2. Symulacja krzywych CL ===']);
        currentRow++;
        sheetData.push([]);
        currentRow++;

        // Find the maximum number of coefficients across all curves
        const maxCoeffs = Math.max(...curves.map(curve => curve.coeffs.length));
        
        // Create header row with coefficient names
        const headers = ['Krzywa', ...Array.from({ length: maxCoeffs }, (_, i) => `k-${i + 1}`)]; // k-1, k-2, k-3 like in screenshot
        sheetData.push(headers);
        currentRow++;
        
        // Add each curve as a row
        curves.forEach((curve) => {
          const row = [curve.name, ...curve.coeffs];
          // Fill missing coefficients with empty strings if curve has fewer coefficients
          while (row.length < headers.length) {
            row.push('');
          }
          sheetData.push(row);
          currentRow++;
        });

        // Add separator
        sheetData.push([]);
        sheetData.push([]);
        currentRow += 2;
      }

      // 3. Pozostawione dev_j
      if (selectedValue) {
        sheetData.push(['=== 3. Wybrany ostateczny wektor współczynników ===']);
        currentRow++;
        sheetData.push([]);
        currentRow++;
        
        // Use stored headers based on triangle type
        let storedHeaders: string[] = [];
        if (triangleType === 'incurred') {
          storedHeaders = incurredRemainingDevJHeaders;
        } else {
          storedHeaders = paidRemainingDevJHeaders;
        }
        
        console.log('🏷️ Debug stored headers from stores:', {
          triangleType,
          paidHeaders: paidRemainingDevJHeaders,
          incurredHeaders: incurredRemainingDevJHeaders,
          selectedHeaders: storedHeaders
        });
        
        const headers = ['Nazwa'];
        
        if (storedHeaders.length > 0 && storedHeaders.length >= selectedValue.values.length) {
          // Use stored headers from FinalTable
          headers.push(...storedHeaders.slice(0, selectedValue.values.length));
          console.log('✅ Using stored headers from FinalTable:', storedHeaders);
        } else {
          // Fallback to columnLabels logic with offset if no stored headers
          console.log('⚠️ No stored headers found, falling back to columnLabels with offset');
          
          for (let i = 0; i < selectedValue.values.length; i++) {
            console.log(`🔍 Processing column ${i}, checking columnLabels[${i + 1}]:`, columnLabels?.[i + 1]);
            
            if (columnLabels && columnLabels.length > i + 1 && columnLabels[i + 1]) {
              const label = columnLabels[i + 1];
              if (label) {
                headers.push(label);
                console.log(`✅ Using columnLabel: ${label}`);
                continue;
              }
            }
            
            // Final fallback to original hardcoded logic
            let fallbackHeader = '';
            if (i === 0) {
              fallbackHeader = 'P-2';
            } else if (i >= 1 && i <= 2) {
              fallbackHeader = `${i + 2}`; // 3, 4
            } else {
              fallbackHeader = `W-${i + 2}`; // W-5, W-6, W-7, W-8, W-9, W-10, etc.
            }
            headers.push(fallbackHeader);
            console.log(`⚠️ Using final fallback header: ${fallbackHeader}`);
          }
        }
        
        sheetData.push(headers);
        currentRow++;
        
        // Add selected value as a row
        const row = [selectedValue.name, ...selectedValue.values];
        sheetData.push(row);
        currentRow++;
      }

      if (sheetData.length === 0 && comparisons.length === 0) {
        alert('Nie znaleziono żadnych danych do eksportu');
        return;
      }

      // Create main worksheet FIRST if there's data for it
      if (sheetData.length > 0) {
        const worksheet = XLSX.utils.aoa_to_sheet(sheetData);
        
        // Add highlighting for selected volume
        if (selectedVolume !== undefined && volumes.length > 0) {
          // Find the row that contains volume data and apply green background
          let volumeRowStart = -1;
          let volumeHeaderRow = -1;
          
          // Find where Dev podstawowe section starts
          for (let i = 0; i < sheetData.length; i++) {
            const row = sheetData[i];
            if (row && row.length > 0 && row[0] === '=== 1. Dev podstawowe ===') {
              volumeHeaderRow = i + 3; // Skip section header and empty line and headers
              volumeRowStart = i + 4; // Data starts after headers
              break;
            }
          }
          
          if (volumeRowStart > 0 && volumeHeaderRow > 0) {
            // Find the specific volume row
            volumes.forEach((vol, volIndex) => {
              const isSelectedVolume = vol.name.includes(`Volume ${selectedVolume}`);
              if (isSelectedVolume) {
                const rowIndex = volumeRowStart + volIndex;
                
                // Get finalDevJ data to determine selected values
                const finalDevJData = triangleType === 'incurred' 
                  ? useTrainDevideStoreDetIncurred.getState().finalDevJ
                  : useTrainDevideStoreDet.getState().finalDevJ;
                
                const devFinalCustom = triangleType === 'incurred' 
                  ? useTrainDevideStoreDetIncurred.getState().devFinalCustom
                  : useTrainDevideStoreDet.getState().devFinalCustom;
                
                // Function to get displayed value (same logic as in UI)
                const getDisplayed = (j: number) => {
                  const cell = devFinalCustom?.[j];
                  return cell ? cell.value : finalDevJData?.values[j];
                };
                
                // Apply green background to selected cells
                vol.values.forEach((value: number, valueIndex: number) => {
                  const colIndex = valueIndex + 1; // +1 because first column is name
                  const cellAddress = XLSX.utils.encode_cell({ r: rowIndex, c: colIndex });
                  
                  // Check if this value is selected (matches finalDevJ logic)
                  const displayed = getDisplayed(valueIndex);
                  const isSelected = displayed === value;
                  
                  if (isSelected) {
                    // Apply green background color to match UI (bg-green-200)
                    if (!worksheet['!cols']) worksheet['!cols'] = [];
                    if (!worksheet[cellAddress]) worksheet[cellAddress] = { t: 'n', v: value };
                    
                    worksheet[cellAddress].s = {
                      fill: {
                        fgColor: { rgb: "C6F6D5" }, // Light green color to match bg-green-200
                      },
                      font: {
                        color: { rgb: "000000" }, // Black text color
                      }
                    };
                    
                    console.log(`🎨 Applied green highlighting to cell ${cellAddress} (Volume ${selectedVolume}, value: ${value})`);
                  }
                });
              }
            });
          }
        }
        
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Obliczenia');
      }

      // Add comparison tables as separate sheets (after main sheet)
      if (comparisons.length > 0) {
        // Create separate sheets for each comparison
        comparisons.forEach((comparison: any) => {
          // Use the same approach as useExcelExport
          const renamed = comparison.data.map((row: any) => {
            const obj: Record<string, any> = {};
            for (const [k, v] of Object.entries(row)) {
              let newKey = k;
              if (k === 'Projection A') newKey = comparison.labelA;
              if (k === 'Projection B') newKey = comparison.labelB;
              
              // Przekonwertuj stringi liczbowe na liczby
              const parsed =
                typeof v === 'string' && v.match(/^-?\d+([,\.]\d+)?$/)
                  ? parseFloat(v.replace(',', '.'))
                  : v;
              obj[newKey] = parsed;
            }
            return obj;
          });

          // Create worksheet from JSON data
          const comparisonSheet = XLSX.utils.json_to_sheet(renamed);
          
          // Generate safe sheet name
          const baseName = `${comparison.labelA} vs ${comparison.labelB}`
            .replace(/[:\/\\\?\*\[\]]/g, '-')
            .substring(0, 25);

          let sheetName = baseName;
          let sheetIndex = 1;
          while (workbook.SheetNames.includes(sheetName)) {
            sheetName = `${baseName}-${sheetIndex}`;
            sheetIndex++;
          }

          XLSX.utils.book_append_sheet(workbook, comparisonSheet, sheetName || `Porownanie_${comparison.index}`);
        });
      }

      // Save file
      const buffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      saveAs(blob, 'obliczenia_eksport.xlsx');

      //setIsDialogOpen(false);
     // alert('Eksport zakończony pomyślnie!');
    } catch (error) {
      console.error('Błąd podczas eksportu:', error);
      alert(`Wystąpił błąd podczas eksportu pliku: ${error}`);
    }
  };

  const selectedCount = useMemo(() => 
    exportItems.filter(item => item.selected).length, 
    [exportItems]
  );

  return {
    exportItems,
    isDialogOpen,
    selectedCount,
    initializeExportItems,
    toggleItemSelection,
    toggleAllSelection,
    exportSelectedCalculations,
    closeDialog: () => setIsDialogOpen(false),
  };
};
