/* ------------------------------------------------------------------ */
/*                           FinalTable                               */
/* ------------------------------------------------------------------ */

import React, { useCallback, useEffect, useMemo } from 'react'
import type { FinalTableProps } from '@/shared/types/developmentEnd'
import { useDevSummaryEditing } from '@/shared/hooks/useDevSummaryEditing'

type SimResults = Record<string, Record<string, number>>

export function FinalTable({
  combinedDevJ,
  maxLen,
  leftCount,
  columnLabels,
  manualOverrides,
  setManualOverrides,
  sourceSwitches,
  setSourceSwitches,
  selectedCurve,            // string | null
  devJPreview,              // <-- dodane dla oryginalnych wartości Initial Selection
  simResults,               // <-- przekaż z DevSummaryLayout
  onHeadersGenerated,
  onManualEdit,             // <-- nowy callback
  onValuesGenerated,
  decimalPlaces
}: FinalTableProps & { simResults?: SimResults }) {
  const {
    editingIndex,
    editValue,
    setEditValue,
    startEditing,
    stopEditing, // eslint-disable-line @typescript-eslint/no-unused-vars
    saveEdit,
    clearManualOverride
  } = useDevSummaryEditing()

  const curveShort = (name?: string | null): string => {
    if (!name) return ''
    if (name === 'Initial Selection') return '' // nigdy nie prefiksujemy Initial
    switch (name) {
      case 'Exponential': return 'E'
      case 'Weibull': return 'W'
      case 'Power': return 'P'
      case 'Inverse Power': return 'IP'
      default: return name.charAt(0)
    }
  }

  const approxEqual = (a: number, b: number) => {
    if (!Number.isFinite(a) || !Number.isFinite(b)) return false
    if (a.toFixed(decimalPlaces) === b.toFixed(decimalPlaces)) return true
    return Math.abs(a - b) <= 1e-9 * Math.max(1, Math.abs(a), Math.abs(b))
  }

  // ---- helpers dla manualOverrides ----
  const pickOverrideNumber = (ov: unknown): number | undefined => {
    if (ov == null) return undefined
    if (typeof ov === 'number') return Number.isFinite(ov) ? ov : undefined
    if (typeof ov === 'string') {
      const s = ov.trim()
      if (s === '') return undefined
      const n = Number(s)
      return Number.isFinite(n) ? n : undefined
    }
    if (typeof ov === 'object' && 'value' in (ov as any)) {
      const raw = (ov as any).value
      if (typeof raw === 'number') return Number.isFinite(raw) ? raw : undefined
      if (typeof raw === 'string') {
        const s = raw.trim()
        if (s === '') return undefined
        const n = Number(s)
        return Number.isFinite(n) ? n : undefined
      }
    }
    return undefined
  }

  const pickOverrideCurve = (ov: unknown): string | undefined => {
    if (ov && typeof ov === 'object' && 'curve' in (ov as any)) {
      const c = (ov as any).curve
      if (typeof c === 'string' && c.trim() !== '') return c
    }
    return undefined
  }

// Pobierz wartość z danej krzywej dla kolumny idx (dp: idx+1 / k: idx+1 / plain)
const getCurveValue = useCallback((idx: number, curve?: string | null): number | undefined => {
  if (!curve) return undefined

  // Initial Selection = wartości bazowe BEZPOŚREDNIO z devJPreview!
  if (curve === 'Initial Selection') {
    const originalValue = devJPreview?.[idx]
    return originalValue !== undefined && Number.isFinite(originalValue) ? originalValue : undefined
  }

  // spróbuj kilku wariantów klucza kolumny
  const n = idx + 1
  const candidates = [
    `k: ${n}`,      // format z tabeli dopasowanych krzywych - PIERWSZEŃSTWO
    `dp: ${n}`,     // wcześniejszy format
    `${n}`,         // czysty numer jako string
  ]

  const row = simResults?.[curve]
  if (!row) return undefined

  for (const key of candidates) {
    const v = row[key as keyof typeof row]
    if (Number.isFinite(v)) return v as number
  }
  return undefined
}, [devJPreview, simResults])


const effectiveValues = useMemo(
  () =>
    Array.from({ length: maxLen }, (_, i) => {
      const switchedCurve = sourceSwitches?.[i]?.curve
      const overrideCurve = pickOverrideCurve(manualOverrides?.[i])
      const manualValue = pickOverrideNumber(manualOverrides?.[i])
      const isInLeftPart = i < leftCount

      // PRIORYTET 1: Jeśli jest switchedCurve (kliknięto w tabeli krzywych)
      if (switchedCurve) {
        if (switchedCurve === 'Initial Selection') {
          // User explicite wybrał Initial Selection - użyj oryginalnych wartości z devJPreview!
          const originalValue = devJPreview?.[i]
          console.log(`🔍 Initial Selection for index ${i}:`, {
            originalValue,
            devJPreviewLength: devJPreview?.length,
            combinedDevJValue: combinedDevJ[i]
          })
          return originalValue !== undefined && Number.isFinite(originalValue) ? originalValue : NaN
        } else {
          // → ZAWSZE używamy krzywej, ignorujemy ręczne nadpisania
          const fromSwitched = getCurveValue(i, switchedCurve)
          if (fromSwitched !== undefined) return fromSwitched
        }
      }

      // PRIORYTET 2: Ręczna wartość liczbowa (w tym curve: "manual") - MA PRIORYTET NAD KRZYWYMI
      if (manualValue !== undefined && (overrideCurve === 'manual' || !overrideCurve)) {
        return manualValue
      }

      // PRIORYTET 3: Override krzywej z manualOverrides (ale nie manual)
      if (overrideCurve && overrideCurve !== 'manual' && !switchedCurve) {
        const fromOverride = getCurveValue(i, overrideCurve)
        if (fromOverride !== undefined) return fromOverride
      }

      // PRIORYTET 4: Dla prawej części (>= leftCount) - zawsze globalna krzywa
      if (!isInLeftPart && selectedCurve) {
        const fromGlobal = getCurveValue(i, selectedCurve)
        if (fromGlobal !== undefined) return fromGlobal
      }

      // PRIORYTET 5: Initial Selection jest DOMYŚLNE dla lewej części
      // Używaj Initial Selection, chyba że user explicite wybrał krzywą
      const hasNoSourceSwitch = !(i in (sourceSwitches || {}))
      const hasInitialSelectionSwitch = sourceSwitches?.[i]?.curve === 'Initial Selection'
      
      // Dla lewej części - Initial Selection ma priorytet (domyślne zachowanie)
      if (isInLeftPart && (hasNoSourceSwitch || hasInitialSelectionSwitch)) {
        const originalValue = devJPreview?.[i]
        if (originalValue !== undefined && Number.isFinite(originalValue)) {
          console.log(`🔍 Using Initial Selection for index ${i}:`, {
            originalValue,
            hasNoSourceSwitch,
            hasInitialSelectionSwitch
          })
          return originalValue
        }
      }

      // PRIORYTET 6: Globalna krzywa dla lewej części - tylko gdy brak Initial Selection
      if (isInLeftPart && selectedCurve && !hasNoSourceSwitch && !hasInitialSelectionSwitch && !manualValue) {
        const fromGlobal = getCurveValue(i, selectedCurve)
        if (fromGlobal !== undefined) return fromGlobal
      }
      
      // Ostateczny fallback - combinedDevJ
      const base = Number(combinedDevJ[i])
      return Number.isFinite(base) ? base : NaN
    }),
  [maxLen, sourceSwitches, manualOverrides, combinedDevJ, getCurveValue, selectedCurve, leftCount, devJPreview]
)


  const findSourceCurve = useCallback((idx: number, value: number): string | null => {
    if (!simResults) return null
    const dpKey = `dp: ${idx + 1}`
    for (const [curve, dpMap] of Object.entries(simResults)) {
      const v = dpMap?.[dpKey]
      if (Number.isFinite(v) && approxEqual(v as number, value)) return curve
    }
    return null
  }, [simResults])

  const getInitialSelectionIndex = (idx: number): number | undefined => {
    const raw = columnLabels[idx + 2]
    const n = Number(raw)
    return Number.isFinite(n) ? n : undefined
  }

  // Wykryj krzywą dla nagłówka
  const detectPrefCurve = useCallback(
    (idx: number): string => {
      const switched = sourceSwitches?.[idx]?.curve
      const ovCurve  = pickOverrideCurve(manualOverrides?.[idx])
      const manualValue = pickOverrideNumber(manualOverrides?.[idx])
      const isInLeftPart = idx < leftCount
      
      // PRIORYTET 1: switchedCurve (kliknięto w tabeli) - ZAWSZE ma najwyższy priorytet
      if (switched) {
        // Jeśli user explicite wybrał Initial Selection, nie pokazuj prefiksu
        if (switched === 'Initial Selection') return ''
        return switched
      }

      // PRIORYTET 2: ręczne nadpisanie (curve: "manual")
      if (ovCurve === 'manual' && manualValue !== undefined) return 'D'

      // PRIORYTET 3: override krzywej (ale tylko jeśli nie ma switched i nie jest manual)
      if (ovCurve && ovCurve !== 'manual' && !switched) return ovCurve

      // PRIORYTET 4: selectedCurve (globalna) tylko dla prawej części lub gdy nie ma wpisu w sourceSwitches
      if (!isInLeftPart && selectedCurve) return selectedCurve
      if (isInLeftPart && selectedCurve && !(idx in (sourceSwitches || {}))) return selectedCurve

      // PRIORYTET 5: wykryj krzywą na podstawie wartości
      const detected =
        Number.isFinite(effectiveValues[idx])
          ? findSourceCurve(idx, Number(effectiveValues[idx]))
          : null

      return detected ?? ''
    },
    [sourceSwitches, manualOverrides, effectiveValues, findSourceCurve, selectedCurve, leftCount]
  )

  // --------- Nagłówki ----------
  const generatedHeaders = useMemo(() => {
    const headers: string[] = []

    for (let idx = 0; idx < maxLen; idx++) {
      const globalK = idx + 1
      const baseLabel: string = (columnLabels[idx + 2] ?? `j=${idx}`) as string

      const switchedCurve = sourceSwitches[idx]?.curve
      const overrideCurve = pickOverrideCurve(manualOverrides?.[idx])

      // czy user zmienił tę kolumnę?
      const hasUserChange =
        Boolean(switchedCurve) ||
        pickOverrideNumber(manualOverrides?.[idx]) !== undefined ||
        overrideCurve !== undefined

      // domyślny indeks k:<...>
      const initialIdx = getInitialSelectionIndex(idx)
      const kIndex = !hasUserChange && idx < leftCount && initialIdx !== undefined
        ? initialIdx
        : globalK

      const isLeft = idx < leftCount
      const prefCurve = isLeft && !hasUserChange ? '' : detectPrefCurve(idx)
      const pref = curveShort(prefCurve ?? '')

      const label =
        pref
          ? `${pref}:k:${kIndex}`
          : (isLeft ? baseLabel : `k:${kIndex}`)

      headers.push(label)
    }

    return headers
  }, [
    maxLen,
    leftCount,
    columnLabels,
    sourceSwitches,
    manualOverrides,
    effectiveValues,
    selectedCurve,
    detectPrefCurve
  ])

  useEffect(() => {
    onHeadersGenerated?.(generatedHeaders)
  }, [generatedHeaders, onHeadersGenerated])

  useEffect(() => {
    const normalizedValues = effectiveValues.map((value) =>
      Number.isFinite(value) ? Number(value) : '-'
    )
    onValuesGenerated?.(normalizedValues)
  }, [effectiveValues, onValuesGenerated])

  // Wyczyść ręczne nadpisania gdy użytkownik wybierze krzywą lokalnie
  useEffect(() => {
    Object.entries(sourceSwitches).forEach(([indexStr, switchData]) => {
      const index = parseInt(indexStr, 10)
      const override = manualOverrides[index]
      if (override && (override.curve === 'manual' || override.curve !== switchData.curve)) {
        clearManualOverride(index, manualOverrides, setManualOverrides)
      }
    })
  }, [sourceSwitches])

  // Wyczyść ręczne nadpisania gdy zmieni się globalna krzywa
  useEffect(() => {
    if (selectedCurve) {
      Object.entries(manualOverrides).forEach(([indexStr, override]) => {
        const index = parseInt(indexStr, 10)
        const hasLocalChoice = sourceSwitches[index]?.curve || pickOverrideCurve(override)
        // Wyczyść ręczne wartości gdy nie ma lokalnego wyboru
        if (!hasLocalChoice && override.curve === 'manual') {
          clearManualOverride(index, manualOverrides, setManualOverrides)
        }
      })
    }
  }, [selectedCurve])

  const handleCellClick = (idx: number, val: number | string) => {
    if (typeof val === 'string') return
    startEditing(idx, val.toString())
  }

  const handleBlur = () => {
    if (editingIndex !== null) {
      const num = parseFloat(editValue)
      const originalValue = effectiveValues[editingIndex]
      
      if (!Number.isNaN(num)) {
        // Sprawdź czy wartość rzeczywiście się zmieniła
        const hasChanged = Math.abs(num - Number(originalValue)) > 1e-9
        
        if (hasChanged) {
          console.log(`🖊️ EDYCJA RĘCZNA - idx: ${editingIndex}, nowa wartość: ${num}`);
          
          // NAJPIERW zapamiętaj co było wcześniej (PRZED usunięciem!)
          const currentSwitch = sourceSwitches[editingIndex]
          const currentOverride = manualOverrides[editingIndex]
          
          console.log(`📋 Stan PRZED edycją - sourceSwitch:`, currentSwitch);
          console.log(`📋 Stan PRZED edycją - manualOverride:`, currentOverride);
          
          // Ustal previousState na podstawie tego co było
          let previousState: any = undefined;
          
          if (currentSwitch) {
            // Było sourceSwitch - zapamiętaj to
            previousState = {
              wasFromCurve: currentSwitch.curve,
              wasFromSourceSwitch: true,
              wasValue: currentSwitch.value
            };
          } else if (currentOverride && currentOverride.curve !== 'manual') {
            // Było kliknięcie w krzywą (manualOverride ale nie manual)
            previousState = {
              wasFromCurve: currentOverride.curve,
              wasFromSourceSwitch: false, // nie było sourceSwitch
              wasValue: currentOverride.value
            };
          } else if (currentOverride && currentOverride.curve === 'manual' && currentOverride.previousState) {
            // Już było ręczne nadpisanie - ZACHOWAJ oryginalny previousState!
            previousState = currentOverride.previousState;
            console.log(`🔄 Zachowuję oryginalny previousState z poprzedniej edycji`);
          }
          
          console.log(`💾 Obliczony previousState:`, previousState);
          
          // Zapisz edycję z poprzednim stanem  
          const newOverrides = {
            ...manualOverrides,
            [editingIndex]: { 
              curve: "manual", 
              value: num,
              previousState
            }
          }
          console.log(`💾 Zapisuję ręczne nadpisanie:`, newOverrides[editingIndex]);
          setManualOverrides(newOverrides)
          
          // POTEM usuń z sourceSwitches  
          if (sourceSwitches[editingIndex]) {
            const newSwitches = { ...sourceSwitches }
            delete newSwitches[editingIndex]
            console.log(`🗑️ Usuwam z sourceSwitches idx: ${editingIndex}`);
            setSourceSwitches(newSwitches)
          }
          
          // Wywołaj callback
          onManualEdit?.(editingIndex)
        }
      }
      // Zawsze zakończ edycję, nawet jeśli wartość się nie zmieniła
      stopEditing()
    }
  }

  // Funkcja undo - przywraca dokładnie to co było
  const handleUndo = (index: number) => {
    console.log(`↶ UNDO - idx: ${index}`);
    
    const override = manualOverrides[index]
    if (!override || override.curve !== 'manual') {
      console.log(`❌ Brak override lub nie manual:`, override);
      return;
    }
    
    console.log(`📋 Override do cofnięcia:`, override);
    console.log(`🔄 PreviousState:`, override.previousState);
    
    // Usuń ręczne nadpisanie
    const newManualOverrides = { ...manualOverrides }
    delete newManualOverrides[index]
    console.log(`🗑️ Usuwam ręczne nadpisanie idx: ${index}`);
    setManualOverrides(newManualOverrides)
    
    // Przywróć poprzedni stan
    if (override.previousState && override.previousState.wasFromCurve) {
      const { wasFromCurve, wasFromSourceSwitch } = override.previousState;
      const wasValue = override.previousState.wasValue;
      
      if (wasFromSourceSwitch) {
        // Przywróć sourceSwitch
        const restoredSwitch = {
          curve: wasFromCurve, 
          value: wasValue || 0
        };
        console.log(`✅ Przywracam sourceSwitches:`, restoredSwitch);
        setSourceSwitches({
          ...sourceSwitches,
          [index]: restoredSwitch
        })
      } else {
        // Przywróć manualOverride (kliknięcie w krzywą)
        const restoredOverride = {
          curve: wasFromCurve,
          value: wasValue || 0
        };
        console.log(`✅ Przywracam manualOverride:`, restoredOverride);
        setManualOverrides({
          ...newManualOverrides, // już bez obecnego manual
          [index]: restoredOverride
        })
      }
    } else {
      console.log(`ℹ️ Nie było poprzedniego stanu do przywrócenia`);
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      (e.target as HTMLInputElement).blur()
    } else if (e.key === 'Escape') {
      // Anuluj edycję bez zapisywania
      stopEditing()
    }
  }

  return (
    <section className="block w-full rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white">
      <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
        <h2 className="font-bold text-gray-800 text-lg tracking-tight">Tabela współczynników Selected Value</h2>
      </div>
      <div className="overflow-auto p-4">
        <div className="relative w-full max-w-full overflow-x-auto">
        <table className="min-w-max bg-white rounded-xl shadow-md text-sm" style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
          <thead>
            <tr>
              <th className="border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold rounded-tl-xl">-</th>
              {generatedHeaders.map((label, idx) => {
                const isLast = idx === generatedHeaders.length - 1
                return (
                  <th key={idx} className={`border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold ${isLast ? 'rounded-tr-xl' : ''}`}>
                    {label}
                  </th>
                )
              })}
            </tr>
          </thead>
          <tbody>
            {/* Wiersz z wartościami */}
            <tr>
              <td className="border border-gray-300 px-3 py-2 bg-gray-50 text-gray-800 font-medium">Selected Value</td>
              {effectiveValues.map((val, idx) => {
                const isEditing = editingIndex === idx
                const isManuallyOverridden = pickOverrideNumber(manualOverrides?.[idx]) !== undefined
                const isSwitchedFromOriginal = sourceSwitches?.[idx] && sourceSwitches[idx].curve !== 'Initial Selection'
                const hasCustomization = isManuallyOverridden || isSwitchedFromOriginal
                
                return (
                  <td
                    key={idx}
                    className={`border border-gray-300 text-center px-3 py-2 transition-colors ${
                      isEditing 
                        ? 'bg-blue-100 border-blue-400 text-gray-900' 
                        : hasCustomization
                          ? 'bg-gray-100/80 hover:bg-gray-200 cursor-pointer text-gray-900 font-medium' // Customizowane wartości
                          : 'bg-white hover:bg-gray-100 cursor-pointer text-gray-800'
                    }`}
                    onClick={() => handleCellClick(idx, val)}
                    title={
                      isManuallyOverridden 
                        ? `Ręcznie nadpisane: ${val} (kliknij aby edytować)`
                        : isSwitchedFromOriginal
                          ? `Wybrana krzywa: ${sourceSwitches?.[idx]?.curve} (kliknij aby edytować)`
                          : "Kliknij, aby edytować wartość ręcznie"
                    }
                  >
                    {isEditing ? (
                      <input
                        type="number"
                        id={`edit-input-${idx}`}
                        step="any"
                        autoFocus
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        onBlur={handleBlur}
                        onKeyDown={handleKeyDown}
                        className="w-full px-2 py-1 rounded bg-white text-black border border-blue-400 text-sm text-center shadow"
                        onFocus={(e) => e.target.select()} // Automatyczne zaznaczenie tekstu
                      />
                    ) : (
                      typeof val === 'number' ? val.toFixed(decimalPlaces) : val
                    )}
                  </td>
                )
              })}
            </tr>
            
            {/* Wiersz z akcjami undo */}
            <tr>
              <td className="border border-gray-300 px-3 py-2 bg-gray-50 text-gray-600 text-xs font-medium rounded-bl-xl">
                Actions
              </td>
              {effectiveValues.map((_, idx) => {
                const hasManualOverride = manualOverrides?.[idx]?.curve === 'manual'
                const isLast = idx === effectiveValues.length - 1
                
                return (
                  <td
                    key={idx}
                    className={`border border-gray-300 text-center px-3 py-2 bg-gray-50/30 ${isLast ? 'rounded-br-xl' : ''}`}
                  >
                    {hasManualOverride && (
                      <button
                        onClick={() => handleUndo(idx)}
                        className="text-blue-600 hover:text-blue-800 hover:bg-blue-100 rounded px-2 py-1 text-xs transition-colors font-medium"
                        title="Usuń ręczne nadpisanie"
                      >
                        ↶
                      </button>
                    )}
                  </td>
                )
              })}
            </tr>
          </tbody>
        </table>
        </div>
      </div>
    </section>
  )
}
