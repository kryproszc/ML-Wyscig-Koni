/* ------------------------------------------------------------------ */
/*                           FinalTable                               */
/* ------------------------------------------------------------------ */

import React, { useEffect, useMemo } from 'react'
import type { FinalTableProps } from '@/shared/types/developmentEnd'
import { useDevSummaryEditing } from '@/shared/hooks/useDevSummaryEditing'

type SimResults = Record<string, Record<string, number>>

export function FinalTable({
  combinedDevJ,
  maxLen,
  leftCount,
  columnLabels,
  manualOverrides,
  setManualOverrides,
  sourceSwitches,
  selectedCurve,            // string | null
  simResults,               // <-- przekaż z DevSummaryLayout
  onHeadersGenerated
}: FinalTableProps & { simResults?: SimResults }) {
  const {
    editingIndex,
    editValue,
    setEditValue,
    startEditing,
    stopEditing, // eslint-disable-line @typescript-eslint/no-unused-vars
    saveEdit
  } = useDevSummaryEditing()

  const curveShort = (name?: string | null): string => {
    if (!name) return ''
    switch (name) {
      case 'Exponential': return 'E'
      case 'Weibull': return 'W'
      case 'Power': return 'P'
      case 'Inverse Power': return 'IP'
      default: return name.charAt(0)
    }
  }

  const approxEqual = (a: number, b: number) => {
    if (a.toFixed(6) === b.toFixed(6)) return true
    return Math.abs(a - b) <= 1e-9 * Math.max(1, Math.abs(a), Math.abs(b))
  }

  // ---- helpers dla manualOverrides ----
  const pickOverrideNumber = (ov: unknown): number | undefined => {
    if (ov == null) return undefined
    if (typeof ov === 'number') return ov
    if (typeof ov === 'string') {
      const s = ov.trim()
      if (s === '') return undefined
      const n = Number(s)
      return Number.isFinite(n) ? n : undefined
    }
    if (typeof ov === 'object' && 'value' in (ov as any)) {
      const raw = (ov as any).value
      if (typeof raw === 'number') return raw
      if (typeof raw === 'string') {
        const s = raw.trim()
        if (s === '') return undefined
        const n = Number(s)
        return Number.isFinite(n) ? n : undefined
      }
    }
    return undefined
  }

  const pickOverrideCurve = (ov: unknown): string | undefined => {
    if (ov && typeof ov === 'object' && 'curve' in (ov as any)) {
      const c = (ov as any).curve
      if (typeof c === 'string' && c.trim() !== '') return c
    }
    return undefined
  }

  // Wartości efektywne (override ma priorytet)
  const effectiveValues = useMemo(
    () =>
      combinedDevJ.map((v, i) => {
        const ovRaw = manualOverrides?.[i as number]
        const ov = pickOverrideNumber(ovRaw)
        const base = Number(v)
        return Number.isFinite(ov as number) ? (ov as number) : base
      }),
    [combinedDevJ, manualOverrides]
  )

  const findSourceCurve = (idx: number, value: number): string | null => {
    if (!simResults) return null
    const dpKey = `dp: ${idx + 1}`
    for (const [curve, dpMap] of Object.entries(simResults)) {
      const v = dpMap?.[dpKey]
      if (Number.isFinite(v) && approxEqual(v as number, value)) {
        return curve
      }
    }
    return null
  }

  const getInitialSelectionIndex = (idx: number): number | undefined => {
    const raw = columnLabels[idx + 2]
    const n = Number(raw)
    return Number.isFinite(n) ? n : undefined
  }

  // --------- Nagłówki ----------
  const generatedHeaders = useMemo(() => {
    const headers: string[] = []

    for (let idx = 0; idx < maxLen; idx++) {
      const globalK = idx + 1
      const baseLabel: string = (columnLabels[idx + 2] ?? `j=${idx}`) as string

      const switchedCurve = sourceSwitches[idx]?.curve
      const overrideCurve = pickOverrideCurve(manualOverrides?.[idx])

      // czy user zmienił tę kolumnę?
      const hasUserChange =
        Boolean(switchedCurve) ||
        pickOverrideNumber(manualOverrides?.[idx]) !== undefined ||
        overrideCurve !== undefined

      // domyślny indeks k:<...>
      const initialIdx = getInitialSelectionIndex(idx)
      const kIndex = !hasUserChange && idx < leftCount && initialIdx !== undefined
        ? initialIdx
        : globalK

      // prefiks krzywej:
      // - dla lewej części (idx < leftCount) używamy prefiksu TYLKO jeśli user zmienił tę kolumnę
      // - dla prawej części można użyć selectedCurve/detekcji
      let prefCurve: string | null | undefined = null
      if (idx < leftCount) {
        if (hasUserChange) {
          const detectedCurve =
            Number.isFinite(effectiveValues[idx])
              ? findSourceCurve(idx, Number(effectiveValues[idx]))
              : null
          prefCurve = switchedCurve ?? overrideCurve ?? detectedCurve ?? selectedCurve ?? ''
        } else {
          prefCurve = '' // brak prefiksu → zachowaj baseLabel
        }
      } else {
        const detectedCurve =
          Number.isFinite(effectiveValues[idx])
            ? findSourceCurve(idx, Number(effectiveValues[idx]))
            : null
        prefCurve = switchedCurve ?? overrideCurve ?? detectedCurve ?? selectedCurve ?? ''
      }

      const pref = curveShort(prefCurve ?? '')

      const label =
        pref
          ? `${pref}:k:${kIndex}`
          : (idx < leftCount ? baseLabel : `k:${kIndex}`)

      headers.push(label)
    }

    return headers
  }, [
    maxLen,
    leftCount,
    columnLabels,
    sourceSwitches,
    manualOverrides,
    effectiveValues,
    simResults,
    selectedCurve
  ])

  useEffect(() => {
    onHeadersGenerated?.(generatedHeaders)
  }, [generatedHeaders, onHeadersGenerated])

  const handleCellClick = (idx: number, val: number | string) => {
    if (typeof val === 'string') return
    startEditing(idx, val.toString())
  }

  const handleBlur = () => {
    if (editingIndex !== null) {
      saveEdit(editingIndex, manualOverrides, setManualOverrides)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === 'Escape') {
      (e.target as HTMLInputElement).blur()
    }
  }

  return (
    <section>
      <h2 className="text-xl font-bold mb-4 text-center">Tabela współczynników Selected Value</h2>
      <div className="relative w-full max-w-full overflow-x-auto rounded-xl">
        <table className="min-w-max border-collapse bg-gray-900 rounded-xl shadow-md text-sm">
          <thead>
            <tr>
              <th className="border border-gray-700 px-3 py-2 bg-gray-800">-</th>
              {generatedHeaders.map((label, idx) => (
                <th key={idx} className="border border-gray-700 px-3 py-2 bg-gray-800">
                  {label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border border-gray-700 px-3 py-2 bg-gray-800">Selected Value</td>
              {effectiveValues.map((val, idx) => {
                const isEditing = editingIndex === idx
                return (
                  <td
                    key={idx}
                    className={`border border-gray-700 text-center px-3 py-2 ${
                      isEditing ? 'bg-blue-900/50' : 'hover:bg-gray-700/40 cursor-pointer'
                    }`}
                    onClick={() => handleCellClick(idx, val)}
                    title="Kliknij, aby edytować wartość ręcznie"
                  >
                    {isEditing ? (
                      <input
                        type="number"
                        step="any"
                        autoFocus
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        onBlur={handleBlur}
                        onKeyDown={handleKeyDown}
                        className="w-full px-2 py-1 rounded bg-white text-black border border-blue-400 text-sm text-center shadow"
                      />
                    ) : (
                      typeof val === 'number' ? val.toFixed(6) : val
                    )}
                  </td>
                )
              })}
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  )
}
