/* ------------------------------------------------------------------ */
/*                         DevSummarySidebar                         */
/* ------------------------------------------------------------------ */

import React, { useState } from 'react'
import { ConfirmDialog } from '@/shared/components/ConfirmDialog'

interface DevSummarySidebarProps {
  leftCount: number
  setLeftCount: (count: number) => void
  // Info o nadpisaniach
  sourceSwitchesCount?: number
  // Ultimate factors (współczynniki = 1 od określonego indeksu)
  onSetUltimateFactors?: (fromIndex: number) => void
  onResetUltimateFactors?: () => void
  ultimateFromIndex?: number
  setUltimateFromIndex?: (index: number) => void
  maxLength?: number
}

export function DevSummarySidebar({ 
  leftCount, 
  setLeftCount,
  sourceSwitchesCount = 0,
  onSetUltimateFactors,
  onResetUltimateFactors,
  ultimateFromIndex = 1,
  setUltimateFromIndex,
  maxLength = 10
}: DevSummarySidebarProps) {
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean
    action: (() => void) | null
    title: string
    message: string
    variant: 'danger' | 'warning'
  }>({
    isOpen: false,
    action: null,
    title: '',
    message: '',
    variant: 'warning'
  })

  const handleLeftCountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value)
    if (!Number.isNaN(val) && val >= 0) setLeftCount(val)
  }

  const handleUltimateIndexChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value)
    if (!Number.isNaN(val) && val >= 1 && val <= maxLength) {
      if (setUltimateFromIndex) {
        setUltimateFromIndex(val)
      }
    }
  }

  const handleSetUltimateFactors = () => {
    if (onSetUltimateFactors) {
      onSetUltimateFactors(ultimateFromIndex - 1) // Convert to 0-based index
    }
  }

  const showConfirm = (action: () => void, title: string, message: string, variant: 'danger' | 'warning' = 'warning') => {
    setConfirmDialog({ isOpen: true, action, title, message, variant })
  }

  const closeConfirm = () => {
    setConfirmDialog({ isOpen: false, action: null, title: '', message: '', variant: 'warning' })
  }

  const handleConfirm = () => {
    if (confirmDialog.action) {
      confirmDialog.action()
    }
    closeConfirm()
  }

  return (
    <div className="w-64 shrink-0 space-y-4">
      <div className="bg-gray-800 rounded-lg p-4">
        <label className="text-white text-sm font-medium mb-2 block">
          Ilość pozostawionych
        </label>
        <input
          type="number"
          id="left-count-input"
          min={0}
          value={leftCount}
          onChange={handleLeftCountChange}
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      {/* Ultimate Factors */}
      {onSetUltimateFactors && (
        <div className="bg-gray-800 rounded-lg p-4">
          <label className="text-white text-sm font-medium mb-2 block">
            W Selected Value przypisz od kolumny:
          </label>
          <div className="space-y-3">
            <input
              type="number"
              min={1}
              max={maxLength}
              value={ultimateFromIndex}
              onChange={handleUltimateIndexChange}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder={`1-${maxLength}`}
            />
            <button
              onClick={handleSetUltimateFactors}
              disabled={!onSetUltimateFactors}
              className="w-full py-4 px-5 bg-gradient-to-r from-blue-600 to-blue-500 text-white rounded-xl font-bold hover:from-blue-700 hover:to-blue-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
            >
              Przypisz
            </button>
            <button
              onClick={onResetUltimateFactors}
              disabled={!onResetUltimateFactors}
              className="w-full py-4 px-5 bg-gradient-to-r from-orange-600 to-orange-500 text-white rounded-xl font-bold hover:from-orange-700 hover:to-orange-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
            >
              Resetuj wartości
            </button>
          </div>
        </div>
      )}

      <ConfirmDialog
        isOpen={confirmDialog.isOpen}
        onClose={closeConfirm}
        onConfirm={handleConfirm}
        title={confirmDialog.title}
        message={confirmDialog.message}
        variant={confirmDialog.variant}
        confirmText={confirmDialog.title.includes('Ultimate') ? 'Przypisz' : 'Resetuj'}
        cancelText="Anuluj"
      />
    </div>
  )
}
