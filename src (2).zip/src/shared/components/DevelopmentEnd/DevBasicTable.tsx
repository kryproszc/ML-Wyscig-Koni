/* ------------------------------------------------------------------ */
/*                         DevBasicTable                             */
/* ------------------------------------------------------------------ */

import React from 'react'
import type { DevBasicTableProps } from '@/shared/types/developmentEnd'

export function DevBasicTable({ 
  devJPreview, 
  columnLabels, 
  leftCount, 
  sourceSwitches, 
  setSourceSwitches, 
  selectedCurve,
  simResults,
  manualOverrides,
  setManualOverrides
}: DevBasicTableProps) {
  if (!devJPreview) return null

  const handleCellClick = (idx: number) => {
    // Tylko dla komórek w lewej części (< leftCount)
    if (idx >= leftCount) return
    
    // Jeśli nie ma wybranej krzywej, nie można przełączać
    if (!selectedCurve || !simResults) return

    // Przełącz stan sourceSwitches dla tej komórki
    const newSwitches = { ...sourceSwitches }
    const currentSwitch = sourceSwitches[idx]
    
    if (currentSwitch && currentSwitch.curve !== 'Initial Selection') {
      // Jeśli była ustawiona inna krzywa (nie Initial Selection), ustaw na 'Initial Selection'
      const initialValue = devJPreview?.[idx]
      if (initialValue !== undefined) {
        newSwitches[idx] = { curve: 'Initial Selection', value: initialValue }
        console.log(`🔄 DevBasicTable - Ustawiam Initial Selection dla idx ${idx}:`, {
          initialValue,
          previousCurve: currentSwitch.curve
        })
        
        // Usuń ręczne nadpisania gdy przełączamy na Initial Selection
        const newOverrides = { ...manualOverrides }
        if (newOverrides[idx]) {
          delete newOverrides[idx]
          setManualOverrides(newOverrides)
        }
      }
    } else if (currentSwitch && currentSwitch.curve === 'Initial Selection') {
      // Jeśli już jest Initial Selection, przełącz na wybraną krzywą
      const dpKey = `dp: ${idx + 1}`
      const value = simResults[selectedCurve]?.[dpKey]
      if (Number.isFinite(value)) {
        newSwitches[idx] = { curve: selectedCurve, value: value as number }
        console.log(`🔄 DevBasicTable - Ustawiam krzywą ${selectedCurve} dla idx ${idx}:`, {
          value,
          previousCurve: 'Initial Selection'
        })
      }
    } else {
      // Brak wpisu - ustaw krzywą
      const dpKey = `dp: ${idx + 1}`
      const value = simResults[selectedCurve]?.[dpKey]
      if (Number.isFinite(value)) {
        newSwitches[idx] = { curve: selectedCurve, value: value as number }
        console.log(`🔄 DevBasicTable - Ustawiam krzywą ${selectedCurve} dla idx ${idx} (pierwszy raz):`, {
          value
        })
      }
    }
    setSourceSwitches(newSwitches)
  }
  
  return (
    <section>
      <h2 className="text-xl font-bold mb-4 text-center">Tabela współczynników Initial Selection</h2>
      <div className="relative w-full max-w-full overflow-x-auto rounded-xl">
        <table className="min-w-max border-collapse bg-gray-900 rounded-xl shadow-md text-sm">
          <thead>
            <tr>
              <th className="border border-gray-700 px-3 py-2 bg-gray-800">-</th>
              {devJPreview.map((_, idx) => {
                const label = columnLabels.length > idx + 2 
                  ? columnLabels[idx + 2] 
                  : `j=${idx}`
                return (
                  <th key={idx} className="border border-gray-700 px-3 py-2 bg-gray-800">
                    {label}
                  </th>
                )
              })}
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border border-gray-700 px-3 py-2 bg-gray-800">Initial Selection</td>
              {devJPreview.map((val, idx) => {
                const isInLeftPart = idx < leftCount
                const switchedSource = sourceSwitches[idx]
                const canSwitch = isInLeftPart && selectedCurve
                
                // Kolory tła - tylko dla wybranych komórek
                let bgClass = ""
                if (isInLeftPart) {
                  if (switchedSource && switchedSource.curve !== 'Initial Selection') {
                    bgClass = "bg-purple-600/70" // Przełączone na krzywą
                  } else {
                    bgClass = "bg-green-700/70" // Standardowe z dev podstawowego lub Initial Selection
                  }
                } else {
                  bgClass = "" // Brak podświetlenia poza lewą częścią
                }

                return (
                  <td
                    key={idx}
                    onClick={() => handleCellClick(idx)}
                    className={`border border-gray-700 px-3 py-2 text-center transition-colors ${bgClass} ${
                      canSwitch ? "cursor-pointer hover:opacity-80" : ""
                    }`}
                    title={
                      canSwitch
                        ? switchedSource
                          ? switchedSource.curve === 'Initial Selection'
                            ? `Źródło: Initial Selection - kliknij aby użyć krzywej "${selectedCurve}"`
                            : `Źródło: krzywa "${switchedSource.curve}" - kliknij aby przywrócić Initial Selection`
                          : `Źródło: krzywa "${selectedCurve}" - kliknij aby przywrócić Initial Selection`
                        : isInLeftPart && !selectedCurve
                        ? "Wybierz krzywę, aby móc przełączać źródło"
                        : ""
                    }
                  >
                    {val !== undefined ? val.toFixed(6) : "-"}
                  </td>
                )
              })}
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  )
}
