import { create } from 'zustand';

type MultStoreIndependent = {
  trainDevide?: number[][];
  selectedWeights?: number[][];
  selectedWeights_clInitial?: number[][]; // wagi zadane (Paid)
  selectedWeights_clInitialInc?: number[][]; // wagi zadane (Incurred)
  selectedSheetJSON?: any[][];
  selectedSheetName?: string;
  
  // Volume per source
  volume_default: number;
  volume_clInitial: number;

  // Wagi zadane (cl_initial)
  cl_initial?: number[][];
  cl_initial_inc?: number[][];
  setClInitial: (data: number[][]) => void;
  setClInitialInc: (data: number[][]) => void;
  clearClInitial: () => void;
  clearClInitialInc: () => void;

  // Źródło wag
  weightSource: 'default' | 'cl_initial';
  setWeightSource: (source: 'default' | 'cl_initial') => void;
  getEffectiveWeights: () => number[][] | undefined;

  // Manualne overrides
  manualWeightOverrides: Record<string, 0 | 1>;
  manualWeightOverrides_clInitial: Record<string, 0 | 1>;
  manualWeightOverrides_clInitialInc: Record<string, 0 | 1>;
  setManualWeightOverride: (row: number, col: number, value: 0 | 1) => void;
  clearManualWeightOverrides: () => void;

  // Min/Max highlighting
  minMaxHighlighting: boolean;
  minMaxCells: [number, number][];
  minCells: [number, number][];
  maxCells: [number, number][];

  setTrainDevide: (data: number[][]) => void;
  setSelectedWeights: (weights: number[][]) => void;
  setVolume: (volume: number) => void;
  getMaxVolume: () => number;
  getCurrentVolume: () => number;
  resetSelection: () => void;
  resetWeightsToInitial: () => void;
  toggleWeightCell: (row: number, col: number) => void;
  toggleRow: (rowIndex: number) => void;
  hydrateFromTableStore: () => void;
  reset: () => void;
  
  // Min/Max functions
  setMinMaxHighlighting: (enabled: boolean) => void;
  calculateMinMaxCells: () => void;
};

export const useMultStoreIndependent = create<MultStoreIndependent>((set, get) => ({
  trainDevide: undefined,
  selectedWeights: undefined,
  selectedWeights_clInitial: undefined,
  selectedWeights_clInitialInc: undefined,
  selectedSheetJSON: undefined,
  selectedSheetName: undefined,
  
  // Volume per source
  volume_default: 19,
  volume_clInitial: 19,

  // Wagi zadane
  cl_initial: undefined,
  cl_initial_inc: undefined,

  // Źródło wag
  weightSource: 'default',
  manualWeightOverrides: {},
  manualWeightOverrides_clInitial: {},
  manualWeightOverrides_clInitialInc: {},

  // Min/Max state
  minMaxHighlighting: false,
  minMaxCells: [],
  minCells: [],
  maxCells: [],

  setTrainDevide: (data) =>
    set((state) => {
      const rowCount = Array.isArray(data) && data.length > 0 ? data.length : 1;
      const previousRowCount = state.trainDevide?.length ?? 0;
      const isFirstLoad = !state.trainDevide || previousRowCount === 0;
      const rowCountChanged = previousRowCount !== rowCount;

      if (isFirstLoad || rowCountChanged) {
        return {
          trainDevide: data,
          volume_default: rowCount,
          volume_clInitial: rowCount,
        };
      }

      return { trainDevide: data };
    }),
  setSelectedWeights: (weights) => {
    set({ selectedWeights: weights });
    // Auto-recalculate min/max if highlighting is enabled
    if (get().minMaxHighlighting) {
      get().calculateMinMaxCells();
    }
  },

  // ========== VOLUME MANAGEMENT ==========
  getMaxVolume: () => {
    const matrix = get().trainDevide;
    if (!matrix || matrix.length === 0 || !matrix[0]) return 1;
    return matrix.length;
  },

  getCurrentVolume: () => {
    const isClInitial = get().weightSource === 'cl_initial';
    return isClInitial ? get().volume_clInitial : get().volume_default;
  },

  setVolume: (v: number) => {
    const { useTableStore } = require('./tableStore');
    const triangleType = useTableStore.getState().triangleType;
    const matrix = get().trainDevide;
    if (!matrix || matrix.length === 0 || !matrix[0]) return;

    if (!Number.isFinite(v)) return;

    const maxVolume = matrix.length;
    const normalizedV = Math.floor(v);
    const clampedV = Math.min(Math.max(1, normalizedV), maxVolume); // Ogranicz do 1..maxVolume
    
    const isClInitial = get().weightSource === 'cl_initial';
    
    // Ustaw odpowiedni volume
    if (isClInitial) {
      set({ volume_clInitial: clampedV });
    } else {
      set({ volume_default: clampedV });
    }

    const numRows = matrix.length;
    const numCols = matrix[0].length;
    
    // Wybierz odpowiedni override store w zależności od triangleType  
    const { useTableStore: tableStore2 } = require('./tableStore');
    const triangleType2 = tableStore2.getState().triangleType;
    
    const overrides = isClInitial 
      ? (triangleType2 === 'incurred' ? get().manualWeightOverrides_clInitialInc : get().manualWeightOverrides_clInitial)
      : get().manualWeightOverrides;
    
    // Stwórz nową macierz wag
    const weights: number[][] = Array.from({ length: numRows }, () =>
      new Array(numCols).fill(0)
    );

    // Dla każdej kolumny osobno: wybierz deterministycznie clampedV aktywnych od dołu,
    // pomijając ręcznie odznaczone komórki (override = 0)
    for (let col = 0; col < numCols; col++) {
      let selectedCount = 0;
      for (let row = numRows - 1; row >= 0 && selectedCount < clampedV; row--) {
        const val = matrix[row]?.[col];
        if (typeof val === 'number' && val !== 0) {
          const key = `${row}_${col}`;
          const override = overrides[key];

          // Ręczne odznaczenie ma priorytet i nie jest liczone do volume
          if (override === 0) {
            weights[row]![col] = 0;
            continue;
          }

          weights[row]![col] = 1;
          selectedCount++;
        }
      }
    }
    
    if (isClInitial) {
      const targetKey = triangleType === 'incurred' 
        ? 'selectedWeights_clInitialInc' 
        : 'selectedWeights_clInitial';
      set({ [targetKey]: weights });
    } else {
      set({ selectedWeights: weights });
    }
    
    // Recalculate Min/Max
    if (get().minMaxHighlighting) {
      get().calculateMinMaxCells();
    }
  },

  resetSelection: () => {
    const { useTableStore } = require('./tableStore');
    const triangleType = useTableStore.getState().triangleType;
    const isClInitial = get().weightSource === 'cl_initial';
    const matrix = get().trainDevide;
    if (!matrix) return;
    
    let weights: number[][];
    
    if (isClInitial) {
      // Dla źródła "Zadane" - zaznacz tylko tam gdzie cl_initial ma niezerowe wartości
      const clData = triangleType === 'incurred' ? get().cl_initial_inc : get().cl_initial;
      
      if (clData && clData.length > 0) {
        // Generuj wagi na podstawie cl_initial - 1 gdzie są niezerowe wartości, 0 gdzie są zera/null
        weights = matrix.map((row, r) => 
          row.map((cell, c) => {
            const clValue = clData[r]?.[c];
            return (clValue != null && clValue !== 0) ? 1 : 0;
          })
        );
      } else {
        // Fallback jeśli cl_initial nie jest dostępny - wszystko wyłączone
        weights = matrix.map((row) => row.map(() => 0));
      }
      
      const targetKey = triangleType === 'incurred' 
        ? 'selectedWeights_clInitialInc' 
        : 'selectedWeights_clInitial';
      set({ [targetKey]: weights });
    } else {
      // Dla źródła "Domyślne" - wszystko zaznaczone (zachowaj dotychczasowe zachowanie)
      weights = matrix.map((row) => row.map(() => 1));
      set({ selectedWeights: weights });
    }
    
    // Auto-recalculate min/max if highlighting is enabled
    if (get().minMaxHighlighting) {
      get().calculateMinMaxCells();
    }
  },

  hydrateFromTableStore: () => {
    // Import here to avoid circular dependency
    const { useTableStore } = require('./tableStore');
    const table = useTableStore.getState();
    const sheet = table.selectedSheetJSON;
    const name = table.selectedSheetName;

    if (!sheet) return;

    console.log('[MultStoreIndependent] Hydrating from TableStore');

    // NAPRAWIONE: Parsuj selectedSheetJSON do trainDevide matrix
    const trainDevideMatrix: number[][] = [];
    
    for (let i = 1; i < sheet.length; i++) { // Skip header row
      const row = sheet[i];
      if (!row) continue;
      
      const dataRow: number[] = [];
      for (let j = 1; j < row.length; j++) { // Skip header column
        const cell = row[j];
        if (typeof cell === 'number') {
          dataRow.push(cell);
        } else if (typeof cell === 'string' && cell.trim() !== '' && !isNaN(parseFloat(cell))) {
          dataRow.push(parseFloat(cell));
        } else {
          dataRow.push(0); // Empty cells as 0
        }
      }
      if (dataRow.length > 0) {
        trainDevideMatrix.push(dataRow);
      }
    }

    set({
      selectedSheetJSON: sheet,
      selectedSheetName: name,
      trainDevide: trainDevideMatrix, // ⭐ KLUCZOWE: Aktualizuj training matrix
    });
    
    console.log('[MultStoreIndependent] Updated trainDevide matrix', {
      rows: trainDevideMatrix.length,
      cols: trainDevideMatrix[0]?.length || 0
    });
  },

  // ========== WAGI ZADANE ==========
  setClInitial: (data) => {
    set({ cl_initial: data.map(row => [...row]) });
    
    // Jeśli aktualnie używamy źródła cl_initial i triangleType to paid, automatycznie wygeneruj wagi
    const { useTableStore } = require('./tableStore');
    const triangleType = useTableStore.getState().triangleType;
    const isClInitialSource = get().weightSource === 'cl_initial';
    
    if (isClInitialSource && triangleType === 'paid') {
      get().resetSelection(); // To teraz właściwie wygeneruje wagi na podstawie cl_initial
    }
  },
  setClInitialInc: (data) => {
    set({ cl_initial_inc: data.map(row => [...row]) });
    
    // Jeśli aktualnie używamy źródła cl_initial i triangleType to incurred, automatycznie wygeneruj wagi
    const { useTableStore } = require('./tableStore');
    const triangleType = useTableStore.getState().triangleType;
    const isClInitialSource = get().weightSource === 'cl_initial';
    
    if (isClInitialSource && triangleType === 'incurred') {
      get().resetSelection(); // To teraz właściwie wygeneruje wagi na podstawie cl_initial_inc
    }
  },
  clearClInitial: () => set({ cl_initial: undefined }),
  clearClInitialInc: () => set({ cl_initial_inc: undefined }),

  // ========== ŹRÓDŁO WAG ==========
  setWeightSource: (source) => {
    const { useTableStore } = require('./tableStore');
    const triangleType = useTableStore.getState().triangleType;
    
    set({ weightSource: source });
    
    if (source === 'cl_initial') {
      // Przełączamy na 'cl_initial'
      const matrix = get().trainDevide;
      if (!matrix) return;
      
      // Wybierz odpowiednie cl_initial w zależności od triangleType
      const clInitialData = triangleType === 'incurred' 
        ? get().cl_initial_inc 
        : get().cl_initial;
      
      if (clInitialData) {
        // Skopiuj cl_initial jako aktywne wagi
        const targetKey = triangleType === 'incurred' 
          ? 'selectedWeights_clInitialInc' 
          : 'selectedWeights_clInitial';
        
        set({ 
          [targetKey]: clInitialData.map(row => [...row])
        });
        
        // Sprawdź czy użytkownik już ma zapisane manual overrides dla właściwego źródła
        const existingOverrides = triangleType === 'incurred' 
          ? get().manualWeightOverrides_clInitialInc 
          : get().manualWeightOverrides_clInitial;
        const hasExistingOverrides = Object.keys(existingOverrides).length > 0;
        
        // Przepisz wszystkie wartości z cl_initial jako manual overrides TYLKO przy pierwszym przełączeniu
        if (!hasExistingOverrides) {
          const overrides: Record<string, 0 | 1> = {};
          clInitialData.forEach((row, r) => {
            row.forEach((val, c) => {
              if (val === 0 || val === 1) {
                overrides[`${r}_${c}`] = val;
              }
            });
          });
          
          // Ustaw overrides w odpowiednim miejscu w zależności od triangleType
          if (triangleType === 'incurred') {
            set({ manualWeightOverrides_clInitialInc: overrides });
          } else {
            set({ manualWeightOverrides_clInitial: overrides });
          }
        }
      } else {
        // Fallback - wszystko zaznaczone
        const reset = matrix.map((row) => row.map(() => 1));
        const targetKey = triangleType === 'incurred' 
          ? 'selectedWeights_clInitialInc' 
          : 'selectedWeights_clInitial';
        set({ [targetKey]: reset });
      }
      
      // Zastosuj aktualną wartość volume dla cl_initial
      get().setVolume(get().volume_clInitial);
    }
    
    // Przelicz Min/Max po zmianie
    if (get().minMaxHighlighting) {
      setTimeout(() => get().calculateMinMaxCells(), 0);
    }
  },

  getEffectiveWeights: () => {
    const { useTableStore } = require('./tableStore');
    const triangleType = useTableStore.getState().triangleType;
    const isClInitial = get().weightSource === 'cl_initial';
    
    if (isClInitial) {
      return triangleType === 'incurred' 
        ? get().selectedWeights_clInitialInc 
        : get().selectedWeights_clInitial;
    }
    return get().selectedWeights;
  },

  // ========== MANUALNE OVERRIDES ==========
  setManualWeightOverride: (row, col, value) => {
    const key = `${row}_${col}`;
    const { useTableStore: tableStore3 } = require('./tableStore');
    const triangleType3 = tableStore3.getState().triangleType;
    const isClInitial = get().weightSource === 'cl_initial';
    
    if (isClInitial) {
      // Ustaw override w odpowiednim miejscu w zależności od triangleType
      if (triangleType3 === 'incurred') {
        set((state) => ({
          manualWeightOverrides_clInitialInc: {
            ...state.manualWeightOverrides_clInitialInc,
            [key]: value,
          },
        }));
      } else {
        set((state) => ({
          manualWeightOverrides_clInitial: {
            ...state.manualWeightOverrides_clInitial,
            [key]: value,
          },
        }));
      }
    } else {
      set((state) => ({
        manualWeightOverrides: {
          ...state.manualWeightOverrides,
          [key]: value,
        },
      }));
    }
  },

  clearManualWeightOverrides: () => {
    const { useTableStore: tableStore4 } = require('./tableStore');
    const triangleType4 = tableStore4.getState().triangleType;
    const isClInitial = get().weightSource === 'cl_initial';
    
    if (isClInitial) {
      // Wyczyść odpowiedni store w zależności od triangleType
      if (triangleType4 === 'incurred') {
        set({ manualWeightOverrides_clInitialInc: {} });
      } else {
        set({ manualWeightOverrides_clInitial: {} });
      }
    } else {
      set({ manualWeightOverrides: {} });
    }
  },

  // ========== TOGGLE KOMÓRKI ==========
  toggleWeightCell: (r, c) => {
    const { useTableStore } = require('./tableStore');
    const triangleType = useTableStore.getState().triangleType;
    const isClInitial = get().weightSource === 'cl_initial';

    const cur = isClInitial 
      ? (triangleType === 'incurred' ? get().selectedWeights_clInitialInc : get().selectedWeights_clInitial)
      : get().selectedWeights;

    const matrix = get().trainDevide;
    if (!cur) return;
    if (!matrix || !matrix[0]) return;

    const val = matrix[r]?.[c];
    if (!(typeof val === 'number' && val !== 0)) return;

    const newValue: 0 | 1 = cur[r]?.[c] === 1 ? 0 : 1;

    const currentVolume = get().getCurrentVolume();
    const clampedV = Math.min(Math.max(1, Math.floor(currentVolume)), matrix.length);
    const numRows = matrix.length;
    const numCols = matrix[0].length;

    const baseOverrides = isClInitial
      ? (triangleType === 'incurred' ? get().manualWeightOverrides_clInitialInc : get().manualWeightOverrides_clInitial)
      : get().manualWeightOverrides;
    const nextOverrides: Record<string, 0 | 1> = {
      ...baseOverrides,
      [`${r}_${c}`]: newValue,
    };

    const rebuiltWeights: number[][] = Array.from({ length: numRows }, () =>
      new Array(numCols).fill(0)
    );

    // Deterministyczne uzupełnienie do volume od dołu (bez losowości)
    for (let col = 0; col < numCols; col++) {
      let selectedCount = 0;
      for (let row = numRows - 1; row >= 0 && selectedCount < clampedV; row--) {
        const cellVal = matrix[row]?.[col];
        if (typeof cellVal !== 'number' || cellVal === 0) continue;

        const key = `${row}_${col}`;
        const override = nextOverrides[key];
        if (override === 0) {
          rebuiltWeights[row]![col] = 0;
          continue;
        }

        rebuiltWeights[row]![col] = 1;
        selectedCount++;
      }
    }

    if (isClInitial) {
      const targetKey = triangleType === 'incurred' 
        ? 'selectedWeights_clInitialInc' 
        : 'selectedWeights_clInitial';
      const overrideKey = triangleType === 'incurred'
        ? 'manualWeightOverrides_clInitialInc'
        : 'manualWeightOverrides_clInitial';
      set({ [targetKey]: rebuiltWeights, [overrideKey]: nextOverrides });
    } else {
      set({ selectedWeights: rebuiltWeights, manualWeightOverrides: nextOverrides });
    }

    // Jeśli min/max highlighting jest włączone, przelicz ponownie
    if (get().minMaxHighlighting) {
      get().calculateMinMaxCells();
    }
  },

  // ========== TOGGLE WIERSZA ==========
  toggleRow: (r) => {
    const { useTableStore } = require('./tableStore');
    const triangleType = useTableStore.getState().triangleType;
    const isClInitial = get().weightSource === 'cl_initial';

    const cur = isClInitial 
      ? (triangleType === 'incurred' ? get().selectedWeights_clInitialInc : get().selectedWeights_clInitial)
      : get().selectedWeights;

    const trainData = get().trainDevide;
    if (!cur || !trainData) return;

    const dataRow = trainData[r];
    if (!dataRow) return;

    const dataCols: number[] = [];

    for (let j = 0; j < dataRow.length; j++) {
      const cell = dataRow[j];
      const hasData = cell !== null && cell !== undefined && typeof cell === 'number' && cell !== 0;
      if (hasData) {
        dataCols.push(j);
      }
    }

    if (dataCols.length === 0) return;

    const currentVolume = get().getCurrentVolume();
    const clampedV = Math.min(Math.max(1, Math.floor(currentVolume)), trainData.length);
    const numRows = trainData.length;
    const numCols = trainData[0]?.length ?? 0;

    const baseOverrides = isClInitial
      ? (triangleType === 'incurred' ? get().manualWeightOverrides_clInitialInc : get().manualWeightOverrides_clInitial)
      : get().manualWeightOverrides;
    const nextOverrides: Record<string, 0 | 1> = { ...baseOverrides };

    // Checkbox wiersza opiera się na manualnych wykluczeniach:
    // odznaczony tylko gdy istnieje ręczne 0 w tym wierszu.
    const hasManualExclusionInRow = dataCols.some((col) => baseOverrides[`${r}_${col}`] === 0);
    const nextRowValue: 0 | 1 = hasManualExclusionInRow ? 1 : 0;

    for (const col of dataCols) {
      nextOverrides[`${r}_${col}`] = nextRowValue;
    }

    const rebuiltWeights: number[][] = Array.from({ length: numRows }, () =>
      new Array(numCols).fill(0)
    );

    // Deterministyczne uzupełnienie do volume od dołu (bez losowości)
    for (let col = 0; col < numCols; col++) {
      let selectedCount = 0;
      for (let row = numRows - 1; row >= 0 && selectedCount < clampedV; row--) {
        const cellVal = trainData[row]?.[col];
        if (typeof cellVal !== 'number' || cellVal === 0) continue;

        const key = `${row}_${col}`;
        const override = nextOverrides[key];
        if (override === 0) {
          rebuiltWeights[row]![col] = 0;
          continue;
        }

        rebuiltWeights[row]![col] = 1;
        selectedCount++;
      }
    }

    if (isClInitial) {
      const targetKey = triangleType === 'incurred' 
        ? 'selectedWeights_clInitialInc' 
        : 'selectedWeights_clInitial';
      const overrideKey = triangleType === 'incurred'
        ? 'manualWeightOverrides_clInitialInc'
        : 'manualWeightOverrides_clInitial';
      set({ [targetKey]: rebuiltWeights, [overrideKey]: nextOverrides });
    } else {
      set({ selectedWeights: rebuiltWeights, manualWeightOverrides: nextOverrides });
    }

    // Jeśli min/max highlighting jest włączone, przelicz ponownie
    if (get().minMaxHighlighting) {
      get().calculateMinMaxCells();
    }
  },

  // ========== RESET WAG ==========
  resetWeightsToInitial: () => {
    const { useTableStore } = require('./tableStore');
    const triangleType = useTableStore.getState().triangleType;
    const isClInitial = get().weightSource === 'cl_initial';
    
    if (isClInitial) {
      // Dla "Zadane" - resetuj do cl_initial/cl_initial_inc
      const clInitialData = triangleType === 'incurred' 
        ? get().cl_initial_inc 
        : get().cl_initial;
        
      if (clInitialData) {
        // Skopiuj macierz
        const targetKey = triangleType === 'incurred' 
          ? 'selectedWeights_clInitialInc' 
          : 'selectedWeights_clInitial';
        set({ [targetKey]: clInitialData.map(row => [...row]) });
        
        // Przepisz wszystkie wartości z cl_initial jako manual overrides
        const overrides: Record<string, 0 | 1> = {};
        clInitialData.forEach((row, r) => {
          row.forEach((val, c) => {
            if (val === 0 || val === 1) {
              overrides[`${r}_${c}`] = val;
            }
          });
        });
        
        // Ustaw overrides w odpowiednim miejscu w zależności od triangleType
        if (triangleType === 'incurred') {
          set({ manualWeightOverrides_clInitialInc: overrides });
        } else {
          set({ manualWeightOverrides_clInitial: overrides });
        }
      }
    } else {
      // Dla "Domyślne" - resetuj do wszystko włączone
      const matrix = get().trainDevide;
      if (matrix) {
        set({ 
          selectedWeights: matrix.map((row) => row.map(() => 1)),
          manualWeightOverrides: {}
        });
      }
    }
    
    // Przelicz Min/Max po resecie
    if (get().minMaxHighlighting) {
      get().calculateMinMaxCells();
    }
  },

  reset: () => set({
    trainDevide: undefined,
    selectedWeights: undefined,
    selectedWeights_clInitial: undefined,
    selectedWeights_clInitialInc: undefined,
    selectedSheetJSON: undefined,
    selectedSheetName: undefined,
    volume_default: 19,
    volume_clInitial: 19,
    cl_initial: undefined,
    cl_initial_inc: undefined,
    weightSource: 'default',
    manualWeightOverrides: {},
    manualWeightOverrides_clInitial: {},
    manualWeightOverrides_clInitialInc: {},
    minMaxHighlighting: false,
    minMaxCells: [],
    minCells: [],
    maxCells: [],
  }),

  // Min/Max highlighting functions
  setMinMaxHighlighting: (enabled) => {
    console.log('setMinMaxHighlighting (Mult Independent):', enabled);
    set({ minMaxHighlighting: enabled });
    if (enabled) get().calculateMinMaxCells();
    else set({ minMaxCells: [], minCells: [], maxCells: [] });
  },

  calculateMinMaxCells: () => {
    const trainData = get().trainDevide;
    const weights = get().getEffectiveWeights();
    if (!trainData || !weights || trainData.length === 0) return;

    console.log('🔢 calculateMinMaxCells (Mult Independent) started', { 
      trainDataRows: trainData.length, 
      trainDataCols: trainData[0]?.length,
      weightsRows: weights.length, 
      weightsCols: weights[0]?.length 
    });

    const minMaxCells: [number, number][] = [];
    const minCells: [number, number][] = [];
    const maxCells: [number, number][] = [];
    
    // Dla każdej kolumny znajdź min/max spośród zaznaczonych komórek
    const numCols = trainData[0]?.length || 0;
    
    for (let col = 0; col < numCols; col++) {
      const selectedValues: { value: number; row: number }[] = [];
      
      for (let row = 0; row < trainData.length; row++) {
        const cellValue = trainData[row]?.[col];
        const isSelected = weights[row]?.[col] === 1;
        
        if (isSelected && cellValue != null && typeof cellValue === 'number') {
          selectedValues.push({ 
            value: cellValue, 
            row 
          });
        }
      }
      
      console.log(`📊 Mult Independent Kolumna ${col}:`, {
        selectedCount: selectedValues.length,
        values: selectedValues.map(v => `[${v.row}] = ${v.value}`)
      });
      
      if (selectedValues.length > 1) {
        const minItem = selectedValues.reduce((min, curr) => 
          curr.value < min.value ? curr : min
        );
        const maxItem = selectedValues.reduce((max, curr) => 
          curr.value > max.value ? curr : max
        );
        
        // +1 bo w TrainDevideTable mamy nagłówki!
        minCells.push([minItem.row + 1, col + 1]);
        maxCells.push([maxItem.row + 1, col + 1]);
        minMaxCells.push([minItem.row + 1, col + 1]);
        if (minItem.row !== maxItem.row) {
          minMaxCells.push([maxItem.row + 1, col + 1]);
        }
        
        console.log(`✅ Mult Independent Kolumna ${col} - Min: [${minItem.row}]=${minItem.value}, Max: [${maxItem.row}]=${maxItem.value}`);
      } else {
        console.log(`⚠️ Mult Independent Kolumna ${col} - za mało wybranych wartości (${selectedValues.length})`);
      }
    }
    
    console.log('🎯 calculateMinMaxCells (Mult Independent) RESULT:', { 
      minCells: minCells.length, 
      maxCells: maxCells.length,
      minCellsData: minCells,
      maxCellsData: maxCells
    });
    set({ minMaxCells, minCells, maxCells });
  },
}));