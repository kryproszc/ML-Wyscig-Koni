'use client';

import { useEffect } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useUserStore } from '@/app/_components/useUserStore';
import {
  useTrainDevideStoreDet,
} from '@/stores/trainDevideStoreDeterministyczny';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export function usePaidCL() {
  const userId = useUserStore((s) => s.userId);
  const store  = useTrainDevideStoreDet();

  const {
    paidTriangle,
    trainDevideDet,
    selectedCellsDet,
    getCurrentVolume,
    getMaxVolume,
    devJResults,
    setTrainDevideDet,
    setDevJ,
    addDevJResult,
    resetSelectionDet,
    toggleRowDet,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    setMinMaxHighlighting,
    selectedDevJVolume   : selectedVolume,
    selectedDevJSubIndex : selectedSubIndex,
    setSelectedDevJVolume: setSelectedVolume,
    weightSource,
    setWeightSource,
    getEffectiveWeights,
  } = store;

  const volume = getCurrentVolume();

  /* -------- mutation 1 -------- */
  const mTrainDivide = useMutation({
    mutationKey: ['trainDividePaid', volume],
    mutationFn : async () => {
      const triangle = (paidTriangle ?? []);
      const res = await fetch(`${API_URL}/calc/paid/train_devide_paid`, {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ user_id: userId, paid_data_det: triangle }),
      });
      return res.json() as Promise<{ train_devide?: number[][] }>;
    },
    onSuccess: (d) => {
      if (d.train_devide) {
        setTrainDevideDet(d.train_devide);
        // Ustaw wszystkie komórki jako zaznaczone domyślnie
        resetSelectionDet();
      }
    },
  });

  /* -------- mutation 2 -------- */
  const mCL = useMutation({
    mutationKey: ['clPaid', volume],
    mutationFn : async () => {
      const effectiveWeights = getEffectiveWeights();
      const safeWeights =
        effectiveWeights?.map((r) => r.map((c) => (c === 1 ? 1 : 0))) ?? [];
      const res = await fetch(`${API_URL}/calc/paid/cl`, {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({
          user_id      : userId,
          paid_data_det: paidTriangle,
          weights      : safeWeights,
        }),
      });
      return res.json() as Promise<{ 
        message?: string;
        train_devide?: number[][]; 
        dev_j?: number[];
        sd_j?: number[];  // odchylenia standardowe
      }>;
    },
    onSuccess: (d) => {
      console.log("🎯 PEŁNA ODPOWIEDŹ Z BACKENDU (/calc/paid/cl):");
      console.log("📦 Raw response:", d);
      
      console.log("\n📊 SZCZEGÓŁY DANYCH:");
      console.log("   • message:", d.message);
      
      if (d.train_devide) {
        console.log("   • train_devide (macierz współczynników):");
        console.log("     - wymiary:", d.train_devide.length, "x", d.train_devide[0]?.length);
        console.log("     - pierwszy wiersz:", d.train_devide[0]);
        console.log("     - pełna macierz:", d.train_devide);
      }
      
      if (d.dev_j) {
        console.log("   • dev_j (wektor współczynników):");
        console.log("     - długość:", d.dev_j.length);
        console.log("     - wartości:", d.dev_j);
      }
      
      if (d.sd_j) {
        console.log("   • sd_j (odchylenia standardowe):");
        console.log("     - długość:", d.sd_j.length);
        console.log("     - wartości:", d.sd_j);
      }
      
      if (d.train_devide) setTrainDevideDet(d.train_devide);
      if (d.dev_j) {
        setDevJ(d.dev_j);
        addDevJResult(volume, d.dev_j, d.sd_j); // przekazanie sd_j
        setSelectedVolume(volume, undefined);
      }
      // sd_j są teraz zapisane razem z dev_j w devJResults
      // sd_j gotowe do użycia gdy będzie potrzebne
    },
  });

  /* weightSource is now persistent - no auto-reset */

  /* auto-start train_divide */
  useEffect(() => {
    console.log('[usePaidCL] 🔍 useEffect triggered:', {
      paidTriangleLength: paidTriangle?.length || 0,
      trainDevideDetLength: trainDevideDet?.length || 0,
      hasPaidTriangle: !!paidTriangle?.length,
      hasTrainDevide: !!trainDevideDet?.length,
      shouldTrigger: !!(paidTriangle?.length && !trainDevideDet?.length)
    });
    
    if (paidTriangle?.length && !trainDevideDet?.length) {
      console.log('[usePaidCL] 🚀 Triggering mTrainDivide.mutate()');
      mTrainDivide.mutate();
    } else {
      console.log('[usePaidCL] ❌ Warunki nie spełnione - nie triggeru ję train_divide');
    }
  }, [paidTriangle, trainDevideDet]);

  return {
    triangle      : paidTriangle,
    trainDevide   : trainDevideDet,
    weights       : getEffectiveWeights(),
    selectedCells : selectedCellsDet,
    devJResults,
    selectedVolume,
    selectedSubIndex,
    setSelectedVolume,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,
    toggleRowDet,

    runCL      : () => mCL.mutate(),
    isLoading  : mTrainDivide.isPending || mCL.isPending,
  };
}
