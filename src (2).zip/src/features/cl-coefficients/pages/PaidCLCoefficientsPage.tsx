'use client';

import React from 'react';
import { usePaidCL } from '../hooks/usePaidCL';
import SidebarPanelCL from '../components/SidebarPanelCL';
import DevJTableCL from '../components/DevJTableCL';
import { TableDataDet } from '@/components/TableDataDet';
import { useLabelsStore } from '@/stores/useLabelsStore';

export default function PaidCLCoefficientsPage() {
  // Labels from store (JUŻ 1:1 z body — bez rogu)
  const detRowLabels = useLabelsStore((s) => s.detRowLabels);
  const detColumnLabels = useLabelsStore((s) => s.detColumnLabels);

  const {
    triangle,
    trainDevide,
    weights,
    selectedCells,
    devJResults,
    minMaxHighlighting,
    minMaxCells,
    minCells,
    maxCells,

    selectedVolume,
    selectedSubIndex,
    setSelectedVolume,

    runCL,
    isLoading,
  } = usePaidCL();

  // Długość w poziomie dla tablicy współczynników (M-1)
  const maxLen = React.useMemo(
    () => Math.max(...devJResults.map((r) => r.values.length), 0),
    [devJResults]
  );

  if (!triangle?.length) {
    return (
      <div className="p-6 text-yellow-300">
        ⏳ Oczekiwanie na dane wejściowe <code>paidTriangle</code>…
      </div>
    );
  }

  // ---- FIX: nagłówki kolumn dla tabeli współczynników ----
  // Jeśli oryginalny trójkąt ma M kolumn → współczynniki mają M-1 kolumn
  const coeffHeaderLabels =
    detColumnLabels.length > 1
      ? detColumnLabels.slice(1, 1 + (trainDevide?.[0]?.length || 0)) // 2..M
      : Array.from({ length: trainDevide?.[0]?.length || 0 }, (_, i) => String(i + 2));

  // ---- FIX: etykiety wierszy 1:1 (bez +1) ----
  const rowLabelAt = (i: number) =>
    detRowLabels[i] ?? String(i + 1);

  return (
  <div className="flex gap-6 p-6 text-white">
    {/* Panel boczny - stała szerokość, nie kurczy się */}
    <SidebarPanelCL
      onCalculate={runCL}
      devJResults={devJResults}
      className="w-64 shrink-0"
    />

    {/* Główna część - elastyczna, minimalna szerokość 0 */}
    <div className="flex-1 min-w-0">
      <h2 className="text-xl font-bold mb-4">
        Tabela współczynników rok do roku
      </h2>

      {trainDevide?.length ? (
        <>
          <TableDataDet
            data={[
              [''].concat(coeffHeaderLabels),
              ...trainDevide.map((row, i) => [
                rowLabelAt(i),
                ...row.map((c) => (c == null ? '' : c.toString())),
              ]),
            ]}
            weights={weights}
            selectedCells={selectedCells}
            minMaxCells={minMaxHighlighting ? minMaxCells : []}
            minCells={minMaxHighlighting ? minCells : []}
            maxCells={minMaxHighlighting ? maxCells : []}
          />

          {devJResults.length > 0 && (
            <section className="mt-10">
              <h3 className="font-bold mb-2">
                Tabela ważonych uśrednionych współczynników
              </h3>

              <DevJTableCL
                devJResults={devJResults}
                selectedVolume={selectedVolume}
                selectedSubIndex={selectedSubIndex}
                onSelectVolume={setSelectedVolume}
                columnLabels={
                  detColumnLabels.length > 1
                    ? detColumnLabels.slice(1, 1 + maxLen)
                    : undefined
                }
              />
            </section>
          )}
        </>
      ) : (
        <p className="text-yellow-400">Brak wyników 😢</p>
      )}
    </div>
  </div>
);
}