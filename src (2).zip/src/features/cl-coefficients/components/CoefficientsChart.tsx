import React from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  Scatter,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceLine,
} from 'recharts';

interface CoefficientsChartProps {
  title: string;
  data: Array<{
    period: number;
    series: Array<{
      name: string;
      value: number;
      volume: number;
      subIndex?: number;
    }>;
  }>;
  selectedPeriod?: number;
  onPeriodSelect: (period: number) => void;
  referenceValue?: number | null;
  referenceLabel?: string;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-gray-100 border-2 border-gray-500 rounded-md px-3 py-2 shadow-lg">
        <div className="text-gray-900 text-sm font-medium">
          <div>Okres: {label}</div>
          {payload.map((entry: any, index: number) => (
            <div key={index} style={{ color: entry.color }}>
              {entry.dataKey}: {typeof entry.value === 'number' ? entry.value.toFixed(6) : '-'}
            </div>
          ))}
        </div>
      </div>
    );
  }
  return null;
};

// Kolory dla różnych serii
const COLORS = [
  '#dc2626', // czerwony
  '#2563eb', // niebieski  
  '#16a34a', // zielony
  '#ca8a04', // żółty
  '#9333ea', // fioletowy
  '#c2410c', // pomarańczowy
  '#0891b2', // cyan
  '#be123c', // różowy
];

export const CoefficientsChart: React.FC<CoefficientsChartProps> = ({
  title,
  data,
  selectedPeriod,
  onPeriodSelect,
  referenceValue,
  referenceLabel,
}) => {
  console.log('[CoefficientsChart] RENDERED with data:', data);
  
  // Sprawdzenie czy dane istnieją
  if (!data || data.length === 0) {
    return (
      <div className="bg-gray-50 border border-gray-400 rounded-lg shadow-sm p-6 text-gray-900 w-full">
        <h4 className="text-base font-semibold mb-4 text-gray-900 text-center border-b border-gray-300 pb-2">
          {title}
        </h4>
        <div className="text-center text-gray-500">Brak danych do wyświetlenia</div>
      </div>
    );
  }
  
  // Sprawdź czy to dane dla jednej kolumny (wszystkie punkty w jednym "okresie")
  const isSingleColumnView = false; // Zawsze używamy widoku liniowego
  
  let chartData: any[];
  
  // Zawsze używamy formatu liniowego - okresy na X, wartości na Y
  chartData = data.map(item => {
    const point: any = { 
      period: item?.period || 0,
      periodLabel: item?.series?.[0]?.name || `Okres ${item?.period || 0}`
    };
    if (item?.series) {
      item.series.forEach((serie, index) => {
        if (serie?.name) {
          point['value'] = serie.value || 0; // Jedna wartość dla punktu
        }
      });
    }
    return point;
  });

  // Wszystkie serie (linie) - z bezpiecznym dostępem
  const allSeries = (data.length > 0 && data[0]?.series) ? data[0].series : [];

  // Oblicz zakres Y - z bezpiecznym dostępem
  const allValues = data.flatMap(item => 
    (item?.series || []).map(s => s?.value || 0).filter(v => typeof v === 'number' && !isNaN(v))
  );
  
  // Dodaj referenceValue do zakresu jeśli istnieje
  if (referenceValue !== null && referenceValue !== undefined && typeof referenceValue === 'number' && !isNaN(referenceValue)) {
    allValues.push(referenceValue);
  }
  
  if (allValues.length === 0) {
    return (
      <div className="bg-gray-50 border border-gray-400 rounded-lg shadow-sm p-6 text-gray-900 w-full">
        <h4 className="text-base font-semibold mb-4 text-gray-900 text-center border-b border-gray-300 pb-2">
          {title}
        </h4>
        <div className="text-center text-gray-500">Brak prawidłowych danych liczbowych</div>
      </div>
    );
  }
  
  const minY = Math.min(...allValues);
  const maxY = Math.max(...allValues);
  const yRange = maxY - minY;
  const margin = Math.max(yRange * 0.05, 0);
  const yMin = minY - margin;
  const yMax = maxY + margin;

  return (
    <div className="bg-gray-50 border border-gray-400 rounded-lg shadow-sm p-6 text-gray-900 w-full">
      <h4 className="text-base font-semibold mb-4 text-gray-900 text-center border-b border-gray-300 pb-2">
        {title}
      </h4>
      <ResponsiveContainer width="100%" height={420}>
        <ComposedChart
          data={chartData}
          margin={{ top: 30, right: 40, left: 50, bottom: 40 }}
          onClick={(data) => {
            if (data && data.activeLabel) {
              onPeriodSelect(Number(data.activeLabel));
            }
          }}
        >
          <CartesianGrid 
            strokeDasharray="2 2" 
            stroke="#9ca3af" 
            strokeWidth={1}
          />
          
          <XAxis
            dataKey="periodLabel"
            stroke="#374151"
            fontSize={12}
            fontFamily="serif"
            tickLine={{ stroke: '#374151', strokeWidth: 1 }}
            axisLine={{ stroke: '#374151', strokeWidth: 2 }}
            angle={-45}
            textAnchor="end"
            height={80}
            label={{
              value: 'Wiersze tabeli (rozwój w czasie)',
              position: 'insideBottom',
              offset: -25,
              style: { textAnchor: 'middle', fontSize: '12px', fontFamily: 'serif', fill: '#374151' }
            }}
          />
          
          <YAxis
            type="number"
            domain={[yMin, yMax]}
            stroke="#374151"
            fontSize={12}
            fontFamily="serif"
            tickLine={{ stroke: '#374151', strokeWidth: 1 }}
            axisLine={{ stroke: '#374151', strokeWidth: 2 }}
            tickFormatter={(value) => {
              return typeof value === 'number' ? value.toFixed(3) : String(value);
            }}
            label={{
              value: 'Współczynnik rok-do-roku',
              angle: -90,
              position: 'insideLeft',
              style: { textAnchor: 'middle', fontSize: '12px', fontFamily: 'serif', fill: '#374151' }
            }}
          />
          
          <Tooltip content={<CustomTooltip />} />
          
          {/* Linia referencyjna */}
          {referenceValue !== null && referenceValue !== undefined && typeof referenceValue === 'number' && !isNaN(referenceValue) && (
            <ReferenceLine
              y={referenceValue}
              stroke="#dc2626"
              strokeWidth={4}
              strokeDasharray="5 5"
              label={{
                value: referenceLabel ? `${referenceLabel}: ${referenceValue.toFixed(6)}` : referenceValue.toFixed(6),
                position: "top",
                fontSize: 11,
                fill: "#dc2626"
              }}
            />
          )}
          
          {/* Linia z punktami */}
          <Line
            type="monotone"
            dataKey="value"
            dot={{ fill: "#000000", stroke: "#000000", strokeWidth: 2, r: 6 }}
            stroke="#000000"
            strokeWidth={3}
            isAnimationActive={false}
            connectNulls={false}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
};