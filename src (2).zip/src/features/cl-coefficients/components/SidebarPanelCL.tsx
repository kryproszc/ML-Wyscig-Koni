'use client';

import { useState } from 'react';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import SidebarPanelBase from '@/shared/ui/molecules/SidebarPanelBase'
import { exportDevJToExcel } from '@/untils/exportToExcel';
import type { DevJResult } from '@/shared/ui/organisms/DevJTable/DevJTableBase';

type Props = {
  onCalculate: () => void;
  devJResults: DevJResult[];
  className?: string;            // <-- DODAJ
};

export default function SidebarPanelCL({ onCalculate, devJResults, className  }: Props) {
  const store = useTrainDevideStoreDet();
  const [resetOpen, setResetOpen] = useState(false);

  const {
    volume, setVolume,
    clearDevJResults,
    setFinalDevJ,
    clearAllDevFinalValues,
    clearFitCurveData,
    clearDevSummaryData,
    openMissingFinalModal,
    isMissingFinalModalOpen,
    closeMissingFinalModal,
    finalDevJ,
    finalDevVector,
    devFinalCustom,
    minMaxHighlighting,
    setMinMaxHighlighting,
  } = store;

  const overrides = Object.entries(devFinalCustom).map(([idx, c]) => ({
    index: +idx,
    curve: c.curve,
    value: c.value,
  }));

  const handleExport = () => {
    if (!finalDevJ?.values?.length) {
      openMissingFinalModal();
      return;
    }
    exportDevJToExcel(devJResults, finalDevJ, finalDevVector, overrides);
  };

  const handleReset = () => {
    clearDevJResults();
    setFinalDevJ(undefined);
    clearAllDevFinalValues();
    clearFitCurveData();
    clearDevSummaryData();
  };

  const toggleMinMax = () => {
    setMinMaxHighlighting(!minMaxHighlighting);
  };

  return (
    <div className={`w-64 shrink-0 space-y-4 ${className ?? ''}`}>   {/* <-- UŻYJ */}
      <SidebarPanelBase
        volume={volume}
        onVolumeChange={setVolume}
        onCalculate={onCalculate}
        onExport={handleExport}
        onReset={handleReset}
        isResetModalOpen={resetOpen}
        setResetModalOpen={setResetOpen}
        isMissingFinalModalOpen={isMissingFinalModalOpen}
        closeMissingFinalModal={closeMissingFinalModal}
      />
      
      {/* Min/Max Button */}
      <button
        onClick={toggleMinMax}
        className={`w-full py-3 px-4 rounded-lg font-medium transition-colors ${
          minMaxHighlighting
            ? 'bg-yellow-600 hover:bg-yellow-700 text-white'
            : 'bg-gray-600 hover:bg-gray-700 text-white'
        }`}
      >
        {minMaxHighlighting ? '🔍 Ukryj Min/Max' : '🔍 Pokaż Min/Max'}
      </button>
    </div>
  );
}
