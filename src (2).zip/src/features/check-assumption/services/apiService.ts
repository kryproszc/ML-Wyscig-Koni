import type { ResidualsResp, DependenceResp, Dep2Resp } from '../types';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export class CheckAssumptionService {
  static async analyzeResiduals(triangle: any[][], alpha: number): Promise<ResidualsResp> {
    console.log('Sending to analyze-residuals:', { triangle, alpha });
    console.log('Triangle length:', triangle?.length, 'First row:', triangle?.[0]);
    
    const response = await fetch(`${API_BASE_URL}/analyze-residuals`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ triangle, alpha }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('API Error:', response.status, errorText);
      throw new Error(`Błąd pobierania danych z /analyze-residuals: ${response.status} ${errorText}`);
    }

    const result = await response.json();
    console.log('transition_equals_one:', result.transition_equals_one);
    return result;
  }

  static async analyzeDependence(triangle: any[][], ci: number): Promise<DependenceResp> {
    console.log('Sending to analyze-dependence:', { triangle, alpha: 1 - ci });
    
    const response = await fetch(`${API_BASE_URL}/analyze-dependence`, {
      method: 'POST',  
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ triangle, alpha: 1 - ci }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('API Error:', response.status, errorText);
      throw new Error(`Błąd pobierania danych z /analyze-dependence: ${response.status} ${errorText}`);
    }

    return response.json();
  }

  static async analyzeDep2(triangle: any[][], ci: number): Promise<Dep2Resp> {
    console.log('Sending to analyze-dep2:', { triangle, alpha: 1 - ci });
    
    const response = await fetch(`${API_BASE_URL}/analyze-dep2`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ triangle, alpha: 1 - ci }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('API Error:', response.status, errorText);
      throw new Error(`Błąd pobierania danych z /analyze-dep2: ${response.status} ${errorText}`);
    }

    return response.json();
  }
}
