import React, { useMemo } from 'react';
import { TableDataCor } from '@/components/TableDataCor';
import { DensityChart } from './DensityChart';
import type { DependenceResp } from '../types';
import type { CorRowData } from '@/components/TableDataCor';

interface AnalysisTabProps {
  data: DependenceResp | null;
  isLoading: boolean;
  error: string | null;
  ci: number;
  onCiChange: (value: number) => void;
}

export const AnalysisTab: React.FC<AnalysisTabProps> = ({
  data,
  isLoading,
  error,
  ci,
  onCiChange,
}) => {
  const formattedSummary: CorRowData[] = useMemo(() => {
    if (!data) return [];
    return [
      ['T', data.summary.results['T'] ?? null],
      ['E[T]', data.summary.results['E[T]'] ?? null],
      ['Var[T]', data.summary.results['Var[T]'] ?? null],
      ['Lower', data.summary.range.Lower ?? null],
      ['Upper', data.summary.range.Upper ?? null],
    ];
  }, [data]);

  return (
    <div className="flex flex-col items-center gap-8 text-white px-4">
      <h3 className="text-lg font-semibold mb-2">Analiza zależności w trójkącie</h3>
      
      {/* CI slider */}
      <div className="w-full max-w-xl flex flex-col items-center gap-2 mb-6">
        <label htmlFor="ci-range" className="text-sm font-medium">
          Przedział ufności (ci):
        </label>
        <input
          id="ci-range"
          type="range"
          min={0}
          max={1}
          step={0.01}
          value={ci}
          onChange={(e) => onCiChange(parseFloat(e.target.value))}
          className="w-full"
        />
        <span className="text-xs">{Math.round(ci * 100)}%</span>
      </div>

      {/* Error display */}
      {error && <p className="text-destructive">{error}</p>}

      {/* Loading state */}
      {isLoading && <p className="italic">Ładowanie…</p>}

      {/* Content */}
      {data && (
        <>
          <TableDataCor data={formattedSummary} />

          {data.density_plot && (
            <DensityChart
              title="Gęstość rozkładu testu"
              curve={data.density_plot.curve}
              ciArea={data.density_plot.ci_area}
              referenceValue={data.density_plot.T_stat}
              domain={[-1, 1]}
            />
          )}
        </>
      )}
    </div>
  );
};
