import React, { useMemo } from 'react';
import { ResidualChart } from './ResidualChart';
import { CHART_CONFIGS } from '../constants';
import type { ResidualsResp } from '../types';

interface AssumptionsTabProps {
  data: ResidualsResp | null;
  isLoading: boolean;
  error: string | null;
  alpha: number;
  onAlphaChange: (value: number) => void;
}

export const AssumptionsTab: React.FC<AssumptionsTabProps> = ({
  data,
  isLoading,
  error,
  alpha,
  onAlphaChange,
}) => {
  const chartData = useMemo(() => {
    if (!data) return [];
    
    return CHART_CONFIGS.map((cfg) => ({
      ...cfg,
      scatter: data.obs_vs_fitted.map((d) => ({
        x: cfg.xAccessor(d),
        y: d.standard_residuals,
      })),
      lowess: data.lowess_results[cfg.key].map((d) => ({
        x: d.x,
        y: d.lowess,
      })),
    }));
  }, [data]);

  return (
    <div>
      {/* Alpha slider */}
      <div className="mb-4 text-white">
        <label className="mr-2 font-medium">Alpha (dla wag):</label>
        <input
          type="range"
          min="0"
          max="2"
          step="0.01"
          value={alpha}
          onChange={(e) => onAlphaChange(parseFloat(e.target.value))}
          className="w-64"
        />
        <span className="ml-3">{alpha.toFixed(2)}</span>
      </div>

      {/* Error display */}
      {error && <p className="text-destructive mb-4">{error}</p>}

      {/* Loading state */}
      {isLoading && <p className="italic">Ładowanie…</p>}

      {/* Charts */}
      {data && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {chartData.map(({ title, xLabel, scatter, lowess }, idx) => (
            <ResidualChart
              key={idx}
              title={title}
              xLabel={xLabel}
              scatter={scatter}
              lowess={lowess}
            />
          ))}
        </div>
      )}
    </div>
  );
};
