// src/features/check-assumption/components/ModelTab.tsx
import React, { useState, useRef, useCallback } from "react";
import { FileText, X } from "lucide-react";

// ⬇️ USUWAMY ten import, bo nie potrzebujemy całego hooka
// import { useCheckAssumptionData } from "../hooks/useCheckAssumptionData";

import { useTrainDevideStoreDet } from "@/stores/trainDevideStoreDeterministyczny";
import { useTrainDevideStoreDetIncurred } from "@/stores/trainDevideStoreDeterministycznyIncurred";

// ⬇️ DODAJEMY: globalny store typu trójkąta (relatywnie, jak u Ciebie działa)
import { useTriangleType } from "../../../stores/useTriangleType";

export const ModelTab: React.FC = () => {
  const [showPDFModal, setShowPDFModal] = useState(false);
  const [modalSize, setModalSize] = useState({ width: 1200, height: 800 });
  const [modalPosition, setModalPosition] = useState({ x: 0, y: 0 });
  const [isResizing, setIsResizing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const modalRef = useRef<HTMLDivElement>(null);
  const resizeStartRef = useRef({ x: 0, y: 0, width: 0, height: 0 });
  const dragStartRef = useRef({ x: 0, y: 0, startX: 0, startY: 0 });

  // ⬇️ ZAMIANA: zamiast useCheckAssumptionData() bierzemy z globalnego store’a
  const triangleType = useTriangleType((s) => s.triangleType);
  const setTriangleType = useTriangleType((s) => s.setTriangleType);

  const paidTriangle = useTrainDevideStoreDet((s) => s.paidTriangle);
  const incurredTriangle = useTrainDevideStoreDetIncurred((s) => s.incurredTriangle);

  const openPDFModal = () => {
    setShowPDFModal(true);
    setModalPosition({ x: 0, y: 0 }); // reset pozycji
  };

  const closePDFModal = () => setShowPDFModal(false);

  // Dragging functionality
  const handleDragStart = useCallback(
    (e: React.MouseEvent) => {
      if (isResizing) return;
      e.preventDefault();
      setIsDragging(true);

      dragStartRef.current = {
        x: e.clientX,
        y: e.clientY,
        startX: modalPosition.x,
        startY: modalPosition.y,
      };

      const handleMouseMove = (e: MouseEvent) => {
        if (!isDragging) return;

        const deltaX = e.clientX - dragStartRef.current.x;
        const deltaY = e.clientY - dragStartRef.current.y;

        setModalPosition({
          x: dragStartRef.current.startX + deltaX,
          y: dragStartRef.current.startY + deltaY,
        });
      };

      const handleMouseUp = () => {
        setIsDragging(false);
        document.removeEventListener("mousemove", handleMouseMove);
        document.removeEventListener("mouseup", handleMouseUp);
      };

      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
    },
    [isDragging, modalPosition, isResizing]
  );

  const handleResizeStart = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      setIsResizing(true);

      resizeStartRef.current = {
        x: e.clientX,
        y: e.clientY,
        width: modalSize.width,
        height: modalSize.height,
      };

      const handleMouseMove = (e: MouseEvent) => {
        if (!isResizing) return;

        const deltaX = e.clientX - resizeStartRef.current.x;
        const deltaY = e.clientY - resizeStartRef.current.y;

        const newWidth = Math.max(400, resizeStartRef.current.width + deltaX);
        const newHeight = Math.max(300, resizeStartRef.current.height + deltaY);

        setModalSize({ width: newWidth, height: newHeight });
      };

      const handleMouseUp = () => {
        setIsResizing(false);
        document.removeEventListener("mousemove", handleMouseMove);
        document.removeEventListener("mouseup", handleMouseUp);
      };

      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
    },
    [isResizing, modalSize]
  );

  const handleResizeStartBottom = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      setIsResizing(true);

      resizeStartRef.current = {
        x: e.clientX,
        y: e.clientY,
        width: modalSize.width,
        height: modalSize.height,
      };

      const handleMouseMove = (e: MouseEvent) => {
        const deltaY = e.clientY - resizeStartRef.current.y;
        const newHeight = Math.max(300, resizeStartRef.current.height + deltaY);
        setModalSize({ ...modalSize, height: newHeight });
      };

      const handleMouseUp = () => {
        setIsResizing(false);
        document.removeEventListener("mousemove", handleMouseMove);
        document.removeEventListener("mouseup", handleMouseUp);
      };

      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
    },
    [modalSize]
  );

  const handleResizeStartRight = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      setIsResizing(true);

      resizeStartRef.current = {
        x: e.clientX,
        y: e.clientY,
        width: modalSize.width,
        height: modalSize.height,
      };

      const handleMouseMove = (e: MouseEvent) => {
        const deltaX = e.clientX - resizeStartRef.current.x;
        const newWidth = Math.max(400, resizeStartRef.current.width + deltaX);
        setModalSize({ ...modalSize, width: newWidth });
      };

      const handleMouseUp = () => {
        setIsResizing(false);
        document.removeEventListener("mousemove", handleMouseMove);
        document.removeEventListener("mouseup", handleMouseUp);
      };

      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
    },
    [modalSize]
  );

  return (
    <div className="text-white p-6">
      <h3 className="text-2xl font-semibold mb-6"></h3>

{/* Przełącznik Paid/Incurred */}
<div className="flex justify-center mt-2 mb-6">
  <div className="inline-flex flex-col items-center gap-3 rounded-2xl border border-zinc-700/60 bg-slate-900/40 px-6 py-5 shadow-lg max-w-md text-center">
    <div className="text-xs uppercase tracking-wider text-zinc-400">
      Aktywny trójkąt
    </div>

    <p className="text-sm text-zinc-300 mb-2">
      Wybierz, czy chcesz przeprowadzić analizy na wczytanym trójkącie{" "}
      <span className="font-semibold text-white">Paid</span> czy{" "}
      <span className="font-semibold text-white">Incurred</span>.
    </p>

    <div className="flex items-center gap-2 bg-zinc-800/60 rounded-full p-1">
      <button
        type="button"
        onClick={() => setTriangleType("paid")}
        disabled={!paidTriangle || paidTriangle.length === 0}
        className={`px-5 py-2 rounded-full text-sm font-medium transition-colors border
          ${triangleType === "paid"
            ? "bg-white text-black border-white shadow"
            : "bg-transparent text-zinc-200/80 border-zinc-600 hover:bg-zinc-800/60"}
          disabled:opacity-50 disabled:cursor-not-allowed`}
      >
        Paid
      </button>

      <button
        type="button"
        onClick={() => setTriangleType("incurred")}
        disabled={!incurredTriangle || incurredTriangle.length === 0}
        className={`px-5 py-2 rounded-full text-sm font-medium transition-colors border
          ${triangleType === "incurred"
            ? "bg-white text-black border-white shadow"
            : "bg-transparent text-zinc-200/80 border-zinc-600 hover:bg-zinc-800/60"}
          disabled:opacity-50 disabled:cursor-not-allowed`}
      >
        Incurred
      </button>
    </div>

    <div className="text-xs text-zinc-400">
      Aktywny:{" "}
      <span className="font-semibold text-zinc-200">
        {triangleType.toUpperCase()}
      </span>
    </div>
  </div>
</div>



<div className="space-y-6">
  {/* Sekcja wprowadzenia do modelu Macka */}
<div className="bg-gray-800 rounded-lg p-6">
  <h4 className="text-lg font-medium mb-4 text-blue-400">Opis zakładek</h4>

  <p className="text-gray-300 mb-4">
    Aby model Macka (1994) działał poprawnie, muszą być spełnione trzy główne
    założenia:
    <br />
    • <strong>Liniowość rozwoju szkód (CL1)</strong> – rozwój portfela można
    opisać stałymi czynnikami rozwojowymi (age-to-age factors):
    <br />
    <code>E(C<sub>i,k+1</sub> | C<sub>i1</sub>,...,C<sub>ik</sub>) = C<sub>ik</sub> f<sub>k</sub></code>
    <br />
    • <strong>Proporcjonalność wariancji (CL2)</strong> – wariancja obserwacji
    rośnie proporcjonalnie do ich wielkości:
    <br />
    <code>
      Var(C<sub>i,k+1</sub>/C<sub>ik</sub> | C<sub>i1</sub>,...,C<sub>ik</sub>)
      = σ<sub>k</sub><sup>2</sup> / (w<sub>ik</sub> · C<sub>ik</sub><sup>α</sup>)
    </code>
    <br />
    • <strong>Niezależność lat wypadkowych (CL3)</strong> – brak zależności
    między latami, w tym efektów kalendarzowych:
    <br />
    <code>{'{'}C<sub>i1</sub>,...,C<sub>in</sub>{'}'} ⟂ {'{'}C<sub>j1</sub>,...,C<sub>jn</sub>{'}'}, i ≠ j</code>
  </p>

  <p className="text-gray-300 mb-6">
    W kolejnych zakładkach aplikacja zawiera testy sprawdzające, czy powyższe
    warunki są spełnione:
    <br />
    <br />
    <strong>Analiza reszt</strong> – zakładka zawiera cztery wykresy reszt
    standaryzowanych (względem wartości dopasowanych, roku wypadkowego, roku
    kalendarzowego i roku rozwojowego). Dzięki nim można ocenić liniowość,
    proporcjonalność wariancji oraz obecność efektów kalendarzowych. Parametr
    <em> Alpha (dla wag)</em> pozwala ustawić wartość α w wagach regresji
    (np. α = 1 odpowiada klasycznemu założeniu Macka). Jeśli reszty układają się
    losowo wokół zera, przyjęte założenia są spełnione. Trendy lub systematyczne
    wzorce wskazują na ich naruszenie.
    <br />
    <br />
    <strong>Analiza korelacji czynników rozwoju</strong> – zakładka zawiera test
    Spearmana badający zależności między kolejnymi współczynnikami rozwojowymi.
    Pokazywane są: statystyka testu T, jej wartość oczekiwana E[T], wariancja
    Var[T] oraz granice przedziału ufności. Parametr <em>Przedział ufności
    (ci)</em> umożliwia zmianę szerokości przedziału (np. 50%, 90%, 95%). Jeśli
    statystyka T mieści się w przedziale ufności, nie ma podstaw do odrzucenia
    hipotezy o braku korelacji i założenie jest spełnione. Jeśli T wychodzi poza
    przedział, oznacza to, że zależność między czynnikami rozwojowymi może być
    istotna i model Macka nie spełnia CL1/CL2.
    <br />
    <br />
    <strong>Analiza niezależności lat wypadkowych</strong> – zakładka zawiera
    test na efekty kalendarzowe. Widoczne są: statystyka testowa Z, wartość
    oczekiwana E[Z], wariancja Var[Z] i granice przedziału ufności, a także
    wykres gęstości rozkładu testu. Parametr <em>Przedział ufności (ci)</em>
    pozwala ustawić szerokość przedziału. Jeśli wartość Z mieści się wewnątrz
    przedziału, nie ma przesłanek do odrzucenia hipotezy o niezależności lat
    wypadkowych. Wynik poza przedziałem sugeruje obecność efektów kalendarzowych
    i naruszenie CL3.
  </p>
</div>



  {/* Przycisk do PDF */}
  <div className="bg-gray-800 rounded-lg p-6">
    <h4 className="text-lg font-medium mb-4 text-blue-400">Dokumentacja</h4>
    <p className="text-gray-300 mb-4">
      Szczegółowy opis testów przeprowadzanych w tej zakładce znajduje się w
      publikacji Macka (1994), dostępnej poniżej w formie pliku PDF.
    </p>

    <button
      onClick={openPDFModal}
      className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
    >
      <FileText size={20} />
      Otwórz plik PDF z opisem testów
    </button>
  </div>
</div>



      {/* Modal z PDF */}
      {showPDFModal && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
          <div
            ref={modalRef}
            className="bg-white rounded-lg flex flex-col relative select-none shadow-2xl"
            style={{
              width: `${modalSize.width}px`,
              height: `${modalSize.height}px`,
              minWidth: "400px",
              minHeight: "300px",
              maxWidth: "90vw",
              maxHeight: "90vh",
              transform: `translate(${modalPosition.x}px, ${modalPosition.y}px)`,
              cursor: isDragging ? "grabbing" : "default",
            }}
          >
            {/* Header modala */}
            <div
              className="flex items-center justify-between p-4 border-b border-gray-200 cursor-grab active:cursor-grabbing bg-gray-50 rounded-t-lg"
              onMouseDown={handleDragStart}
            >
              <h3 className="text-lg font-semibold text-gray-900 pointer-events-none">
                Dokumentacja modelu
              </h3>
              <button
                onClick={closePDFModal}
                className="text-gray-500 hover:text-gray-700 p-1 z-10 cursor-pointer"
                onMouseDown={(e) => e.stopPropagation()}
              >
                <X size={24} />
              </button>
            </div>

            {/* Zawartość PDF */}
            <div className="flex-1 p-4 overflow-hidden">
              <iframe
                src="/7_Mack_1994.pdf"
                width="100%"
                height="100%"
                className="border-0 rounded"
                title="Dokumentacja modelu"
              >
                <p className="text-gray-600">
                  Twoja przeglądarka nie obsługuje wyświetlania PDF.
                  <a
                    href="/7_Mack_1994.pdf"
                    className="text-blue-600 underline ml-1"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Pobierz plik
                  </a>
                </p>
              </iframe>
            </div>

            {/* Resize handles */}
            <div
              className="absolute bottom-0 right-0 w-4 h-4 cursor-se-resize opacity-60 hover:opacity-100 transition-opacity z-20"
              onMouseDown={handleResizeStart}
              style={{
                background:
                  "linear-gradient(-45deg, transparent 30%, #9ca3af 30%, #9ca3af 35%, transparent 35%, transparent 45%, #9ca3af 45%, #9ca3af 50%, transparent 50%, transparent 60%, #9ca3af 60%, #9ca3af 65%, transparent 65%)",
                borderRadius: "0 0 8px 0",
              }}
              title="Przeciągnij aby zmienić rozmiar"
            />

            <div
              className="absolute bottom-0 left-4 right-4 h-1 cursor-s-resize hover:bg-blue-200 hover:h-2 transition-all opacity-0 hover:opacity-70"
              onMouseDown={handleResizeStartBottom}
              title="Przeciągnij aby zmienić wysokość"
            />

            <div
              className="absolute top-4 right-0 bottom-4 w-1 cursor-e-resize hover:bg-blue-200 hover:w-2 transition-all opacity-0 hover:opacity-70"
              onMouseDown={handleResizeStartRight}
              title="Przeciągnij aby zmienić szerokość"
            />

            <div
              className="absolute bottom-0 left-0 w-4 h-4 cursor-sw-resize opacity-0 hover:opacity-40 hover:bg-blue-200 transition-all"
              onMouseDown={(e) => {
                e.preventDefault();
                setIsResizing(true);

                resizeStartRef.current = {
                  x: e.clientX,
                  y: e.clientY,
                  width: modalSize.width,
                  height: modalSize.height,
                };

                const handleMouseMove = (e: MouseEvent) => {
                  const deltaX = e.clientX - resizeStartRef.current.x;
                  const deltaY = e.clientY - resizeStartRef.current.y;

                  const newWidth = Math.max(400, resizeStartRef.current.width - deltaX);
                  const newHeight = Math.max(300, resizeStartRef.current.height + deltaY);

                  setModalSize({ width: newWidth, height: newHeight });
                  setModalPosition((prev) => ({ ...prev, x: prev.x + deltaX }));
                };

                const handleMouseUp = () => {
                  setIsResizing(false);
                  document.removeEventListener("mousemove", handleMouseMove);
                  document.removeEventListener("mouseup", handleMouseUp);
                };

                document.addEventListener("mousemove", handleMouseMove);
                document.addEventListener("mouseup", handleMouseUp);
              }}
              title="Przeciągnij aby zmienić rozmiar"
            />

            {(isDragging || isResizing) && (
              <div className="absolute inset-0 border-2 border-blue-400 rounded-lg pointer-events-none opacity-50" />
            )}
          </div>
        </div>
      )}
    </div>
  );
};
