import React from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Scatter,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceLine,
} from 'recharts';

interface ResidualChartProps {
  title: string;
  xLabel: string;
  scatter: Array<{ x: number; y: number }>;
  lowess: Array<{ x: number; y: number }>;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const scatterPoint = payload.find((p: any) => p.dataKey === 'y' && p.payload.y !== undefined);
    if (scatterPoint) {
      return (
        <div className="bg-gray-100 border-2 border-gray-500 rounded-md px-3 py-2 shadow-lg">
          <div className="text-gray-900 text-sm font-medium">
            <div>x = {Number(label).toFixed(4)}</div>
            <div>Residual = {Number(scatterPoint.value).toFixed(6)}</div>
          </div>
        </div>
      );
    }
  }
  return null;
};

export const ResidualChart: React.FC<ResidualChartProps> = ({
  title,
  xLabel,
  scatter,
  lowess,
}) => {
  // Oblicz dynamiczny zakres dla osi Y na podstawie danych
  const yValues = scatter.map(point => point.y);
  const minY = Math.min(...yValues);
  const maxY = Math.max(...yValues);
  
  // Dodaj margines 10% z każdej strony
  const yRange = maxY - minY;
  const margin = Math.max(yRange * 0.1, 0.5); // minimum 0.5 marginesu
  const yMin = minY - margin;
  const yMax = maxY + margin;
  
  // Wygeneruj sensowne ticki dla osi Y
  const generateYTicks = () => {
    const range = yMax - yMin;
    let step: number;
    
    if (range <= 2) step = 0.5;
    else if (range <= 5) step = 1;
    else if (range <= 10) step = 2;
    else step = Math.ceil(range / 8);
    
    const ticks: number[] = [];
    const start = Math.floor(yMin / step) * step;
    const end = Math.ceil(yMax / step) * step;
    
    for (let i = start; i <= end; i += step) {
      ticks.push(Math.round(i * 100) / 100); // Zaokrąglij do 2 miejsc po przecinku
    }
    
    return ticks;
  };
  
  const yTicks = generateYTicks();
  return (
    <div className="bg-gray-50 border border-gray-400 rounded-lg shadow-sm p-6 text-gray-900 w-full">
      <h4 className="text-base font-semibold mb-4 text-gray-900 text-center border-b border-gray-300 pb-2">
        {title}
      </h4>
      <ResponsiveContainer width="100%" height={420}>
        <ComposedChart
          data={scatter}
          margin={{ top: 30, right: 40, left: 50, bottom: 40 }}
        >
          <CartesianGrid 
            strokeDasharray="2 2" 
            stroke="#9ca3af" 
            strokeWidth={1}
          />
          
          <XAxis
            type="number"
            dataKey="x"
            stroke="#374151"
            fontSize={12}
            fontFamily="serif"
            tickLine={{ stroke: '#374151', strokeWidth: 1 }}
            axisLine={{ stroke: '#374151', strokeWidth: 2 }}
            tickFormatter={(value) => Number(value).toFixed(1)}
            label={{
              value: xLabel,
              position: 'insideBottom',
              offset: -10,
              style: { textAnchor: 'middle', fontSize: '12px', fontFamily: 'serif', fill: '#374151' }
            }}
          />
          
          <YAxis
            dataKey="y"
            type="number"
            domain={[yMin, yMax]}
            ticks={yTicks}
            stroke="#374151"
            fontSize={12}
            fontFamily="serif"
            tickLine={{ stroke: '#374151', strokeWidth: 1 }}
            axisLine={{ stroke: '#374151', strokeWidth: 2 }}
            tickFormatter={(value) => Number(value).toFixed(1)}
            label={{
              value: 'Reszty standardowe',
              angle: -90,
              position: 'insideLeft',
              style: { textAnchor: 'middle', fontSize: '12px', fontFamily: 'serif', fill: '#374151' }
            }}
          />
          
          <Tooltip content={<CustomTooltip />} />
          
          {/* Linia odniesienia y=0 - tylko jeśli 0 jest w zakresie */}
          {yMin <= 0 && yMax >= 0 && (
            <ReferenceLine 
              y={0} 
              stroke="#6b7280" 
              strokeWidth={2}
              strokeDasharray="6 3"
            />
          )}
          
          {/* Punkty reszt */}
          <Scatter
            data={scatter}
            fill="#1f2937"
            stroke="#374151"
            strokeWidth={0.8}
            r={4}
            fillOpacity={0.7}
          />
          
          {/* Linia LOWESS */}
          <Line
            type="monotone"
            data={lowess}
            dataKey="y"
            dot={false}
            stroke="#dc2626"
            strokeWidth={2.5}
            isAnimationActive={false}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
};
