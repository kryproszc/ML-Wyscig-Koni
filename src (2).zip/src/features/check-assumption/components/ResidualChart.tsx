import React from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Scatter,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceLine,
} from 'recharts';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

interface ResidualChartProps {
  title: string;
  xLabel: string;
  scatter: Array<{ x: number; y: number }>;
  lowess: Array<{ x: number; y: number }>;
}

export const ResidualChart: React.FC<ResidualChartProps> = ({
  title,
  xLabel,
  scatter,
  lowess,
}) => {
  return (
    <Card className="bg-gray-500">
      <CardHeader className="text-base font-medium">{title}</CardHeader>
      <CardContent className="p-6 bg-gray-300">
        <ResponsiveContainer width="100%" height={300}>
          <ComposedChart
            data={scatter}
            margin={{ top: 20, right: 20, bottom: 30, left: 50 }}
          >
            <CartesianGrid
              stroke="#666"
              strokeOpacity={0.5}
              strokeDasharray="3 3"
            />
            <XAxis
              type="number"
              dataKey="x"
              label={{
                value: xLabel,
                position: 'insideBottom',
                offset: -10,
                fill: '#333',
              }}
            />
            <YAxis
              dataKey="y"
              type="number"
              domain={[-2, 2]}
              ticks={[-2, -1, 0, 1, 2]}
              label={{
                value: 'Standardised residuals',
                angle: -90,
                position: 'insideLeft',
                offset: 10,
                fill: '#333',
              }}
              axisLine={{ stroke: '#666' }}
              tick={{ fill: '#333' }}
            />
            <Tooltip
              formatter={(v: number) => v.toFixed(3)}
              contentStyle={{ background: '#e5e7eb' }}
            />
            <Scatter
              name="Residuals"
              data={scatter}
              fill="#000"
              shape="circle"
            />
            <Line
              name="LOWESS"
              type="monotone"
              data={lowess}
              dataKey="y"
              dot={false}
              stroke="#ff5252"
              strokeWidth={2}
            />
            <ReferenceLine y={0} strokeDasharray="4 4" stroke="#555" />
          </ComposedChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};
