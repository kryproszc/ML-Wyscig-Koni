import React from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Scatter,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
} from 'recharts';

interface DevelopmentChartProps {
  title: string;
  xLabel: string;
  scatter: Array<{ 
    x: number; 
    y: number; 
    previousValue?: number | null;
    incrementalDamage?: number | null;
  }>;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const scatterPoint = payload.find((p: any) => p.dataKey === 'y' && p.payload.y !== undefined);
    if (scatterPoint) {
      const pointData = scatterPoint.payload;
      const incrementalDamage = pointData.incrementalDamage;
      
      console.log('[CustomTooltip] pointData:', pointData);
      console.log('[CustomTooltip] incrementalDamage:', incrementalDamage);
      
      return (
        <div className="bg-gray-100 border-2 border-gray-500 rounded-md px-3 py-2 shadow-lg">
          <div className="text-gray-900 text-sm font-medium">
            <div>Okres rozwoju: {Number(label)}</div>
            <div>Szkoda: {Number(scatterPoint.value).toLocaleString('pl-PL')}</div>
            {incrementalDamage !== null && incrementalDamage !== undefined && (
              <div>Szkoda inkrementalna: {Number(incrementalDamage).toLocaleString('pl-PL')}</div>
            )}
          </div>
        </div>
      );
    }
  }
  return null;
};

export const DevelopmentChart: React.FC<DevelopmentChartProps> = ({
  title,
  xLabel,
  scatter,
}) => {
  console.log('[DevelopmentChart] RENDERED for:', title, 'with scatter points:', scatter.length);
  
  // Oblicz minimum i maksimum dla osi Y na podstawie danych
  const yValues = scatter.map(point => point.y);
  const minY = Math.min(...yValues);
  const maxY = Math.max(...yValues);
  
  // Dodaj niewielki margines (5%) z każdej strony
  const yRange = maxY - minY;
  const margin = Math.max(yRange * 0.05, 0);
  const yMin = minY - margin;
  const yMax = maxY + margin;
  
  // Wygeneruj 5-6 ticków równomiernie rozłożonych
  const generateYTicks = () => {
    const tickCount = 5;
    const ticks: number[] = [];
    
    for (let i = 0; i <= tickCount; i++) {
      const value = yMin + (i * (yMax - yMin)) / tickCount;
      
      // Dodaj tylko jeśli wartość nie istnieje już w tablicy
      if (!ticks.includes(value)) {
        ticks.push(value);
      }
    }
    
    // Upewnij się że mamy przynajmniej min i max
    if (!ticks.includes(yMin)) {
      ticks.unshift(yMin);
    }
    if (!ticks.includes(yMax)) {
      ticks.push(yMax);
    }
    
    // Usuń duplikaty i posortuj
    const uniqueTicks = [...new Set(ticks)].sort((a, b) => a - b);
    
    return uniqueTicks;
  };
  
  const yTicks = generateYTicks();

  // Dodaj unikalny identyfikator do każdego punktu
  const scatterWithIds = scatter.map((point, idx) => ({
    ...point,
    id: `${title}-${point.x}-${idx}`,
    key: `point-${idx}`,
    incrementalDamage: point.incrementalDamage
  }));
  
  // Linia danych z unikalnymi ID
  const lineData = scatterWithIds.map(point => ({
    x: point.x,
    y: point.y,
    id: `line-${point.id}`,
    incrementalDamage: point.incrementalDamage
  }));

  return (
    <div className="bg-gray-50 border border-gray-400 rounded-lg shadow-sm p-6 text-gray-900 w-full">
      <h4 className="text-base font-semibold mb-4 text-gray-900 text-center border-b border-gray-300 pb-2">
        {title}
      </h4>
      <ResponsiveContainer width="100%" height={420}>
        <ComposedChart
          data={scatterWithIds}
          margin={{ top: 30, right: 40, left: 50, bottom: 40 }}
        >
          <CartesianGrid 
            strokeDasharray="2 2" 
            stroke="#9ca3af" 
            strokeWidth={1}
          />
          
          <XAxis
            type="number"
            dataKey="x"
            stroke="#374151"
            fontSize={12}
            fontFamily="serif"
            tickLine={{ stroke: '#374151', strokeWidth: 1 }}
            axisLine={{ stroke: '#374151', strokeWidth: 2 }}
            tickFormatter={(value) => Number(value).toFixed(0)}
            allowDuplicatedCategory={false}
            label={{
              value: xLabel,
              position: 'insideBottom',
              offset: -10,
              style: { textAnchor: 'middle', fontSize: '12px', fontFamily: 'serif', fill: '#374151' }
            }}
          />
          
          <YAxis
            type="number"
            domain={[yMin, yMax]}
            ticks={yTicks}
            stroke="#374151"
            fontSize={12}
            fontFamily="serif"
            tickLine={{ stroke: '#374151', strokeWidth: 1 }}
            axisLine={{ stroke: '#374151', strokeWidth: 2 }}
            allowDuplicatedCategory={false}
            tickFormatter={(value) => {
              // Wyświetlaj rzeczywiste wartości z separatorami tysięcy
              return value.toLocaleString('pl-PL', {
                minimumFractionDigits: 0,
                maximumFractionDigits: 0
              });
            }}
            label={{
              value: '',
              angle: -90,
              position: 'insideLeft',
              style: { textAnchor: 'middle', fontSize: '12px', fontFamily: 'serif', fill: '#374151' }
            }}
          />
          
          <Tooltip content={<CustomTooltip />} />
          
          <Line
            type="monotone"
            data={lineData}
            dataKey="y"
            dot={{ fill: '#000000', stroke: '#000000', strokeWidth: 1, r: 5 }}
            stroke="#dc2626"
            strokeWidth={2.5}
            isAnimationActive={false}
          />
          
          <Scatter
            data={scatterWithIds}
            fill="#000000"
            stroke="#000000"
            strokeWidth={1}
            r={5}
            fillOpacity={1}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
};