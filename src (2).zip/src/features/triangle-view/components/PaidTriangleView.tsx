import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { TriangleTableView } from '@/shared';
import dynamic from 'next/dynamic';
import { useEffect } from 'react';

const PaidTriangleDet = dynamic(
  () => import('../../../app/_components/PaidTriangleDet'),
  { ssr: false }
);

export default function PaidTriangleView() {
  const triangle = useTrainDevideStoreDet((s) => s.paidTriangle);
  const detRowLabels = useLabelsStore((s) => s.detRowLabels);
  const detColumnLabels = useLabelsStore((s) => s.detColumnLabels);

  // Dodatkowe logi dla wszystkich labels ze store
  const globalRowLabels = useLabelsStore((s) => s.globalRowLabels);
  const globalColumnLabels = useLabelsStore((s) => s.globalColumnLabels);
  const lastLoadedFile = useLabelsStore((s) => s.lastLoadedFile);

  useEffect(() => {
    console.log('[PaidTriangleView] triangle:', triangle);
    console.log('[PaidTriangleView] triangle structure:');
    if (triangle) {
      console.log('  - Number of rows:', triangle.length);
      console.log('  - First row length:', triangle[0]?.length);
      console.log('  - First row:', triangle[0]);
      console.log(
        '  - Max row length:',
        Math.max(...triangle.map((row) => row?.length || 0))
      );
    }
    console.log('[PaidTriangleView] detRowLabels:', detRowLabels);
    console.log(
      '[PaidTriangleView] detColumnLabels:',
      detColumnLabels,
      'length:',
      detColumnLabels.length
    );
    console.log('[PaidTriangleView] globalRowLabels:', globalRowLabels);
    console.log(
      '[PaidTriangleView] globalColumnLabels:',
      globalColumnLabels,
      'length:',
      globalColumnLabels.length
    );
    console.log('[PaidTriangleView] lastLoadedFile:', lastLoadedFile);
  }, [
    triangle,
    detRowLabels,
    detColumnLabels,
    globalRowLabels,
    globalColumnLabels,
    lastLoadedFile,
  ]);

  // Etykiety już są dopasowane 1:1 do body — NIE przycinamy ich ponownie.
  const actualRowLabels = detRowLabels;
  const actualColumnLabels = detColumnLabels;

  return (
    <TriangleTableView
      title="Wczytany trójkąt danych"
      triangle={triangle}
      noDataMessage="Brak danych do wyświetlenia. Najpierw wczytaj plik poniżej."
      fallbackComponent={PaidTriangleDet}
      withNumericHeaders={false}
      rowLabels={actualRowLabels}
      columnLabels={actualColumnLabels}
    />
  );
}
