/* ---------------------------------------------------------------------- */
/*       src/features/devJ/DevJSelectorIncurred.tsx – CLIENT COMPONENT    */
/* ---------------------------------------------------------------------- */
'use client';

import React, { useEffect, useMemo, useState } from 'react';
import {
  useTrainDevideStoreDetIncurred,
  type TrainDevideStoreDetIncurred,
} from '@/stores/trainDevideStoreDeterministycznyIncurred';
import { useUserStore } from '@/app/_components/useUserStore';
import { useLabelsStore } from '@/stores/useLabelsStore';
const API_URL = process.env.NEXT_PUBLIC_API_URL ?? '';

import {
  ControlPanel,
  GenericTable,
  SimulationChart,
  Modal,
} from '@/shared/ui';

const CALCULATION_DECIMAL_PLACES = 15;

/* ------------------------------------------------------------------ */
/*                              KONTENER                              */
/* ------------------------------------------------------------------ */
export default function DevJSelectorIncurred() {
  /* ---------- store ---------- */
  const {
    devPreviewCandidate,
    setDevPreviewCandidate,
    devJPreview,
    setDevJPreview,

    devFinalCustom,
    finalDevVector,

    selectedDevJIndexes,
    setSelectedDevJIndexes,

    r2Scores,
    setR2Scores,
    simResults,
    setSimResults,
    clearR2Scores,
    clearSimResults,
    clearComparisonTables, // Dodane dla usuwania tabel wyników
    finalDevJ, // Dodane dla odchyleń standardowych
    devJResults, // Dodane dla odchyleń standardowych
    selectedWeightsDetIncurred, // Macierz wag do wysłania na backend
    fittingMethod, // Metoda dopasowania z store
    setFittingMethod, // Setter dla metody dopasowania
    useWeighting, // Ważenie współczynników z store
    setUseWeighting, // Setter dla ważenia
    decimalPlaces, // Liczba miejsc po przecinku
  } = useTrainDevideStoreDetIncurred();

  const userId = useUserStore((s) => s.userId);
  
  // Labels from store
  const incurredColumnLabels = useLabelsStore((s) => s.incurredColumnLabels);

  /* ---------- bieżący wektor ---------- */
  const currentVector = useMemo<number[]>(() => {
    const merged = [...finalDevVector];
    (Object.entries(devFinalCustom ?? {}) as [
      string,
      TrainDevideStoreDetIncurred['devFinalCustom'][number],
    ][]).forEach(([idxStr, cell]) => {
      merged[Number(idxStr)] = cell.value;
    });
    return merged;
  }, [finalDevVector, devFinalCustom]);

  /* ---------- funkcja do pobierania odchyleń standardowych ---------- */
  const getSelectedStandardDeviations = useMemo(() => {
    if (!devJPreview) return [];
    
    const sdArray: (number | undefined)[] = new Array(devJPreview.length);
    
    // Dla każdej pozycji w devJPreview sprawdź czy ma odchylenie standardowe
    for (let j = 0; j < devJPreview.length; j++) {
      const customCell = (devFinalCustom as Record<number, TrainDevideStoreDetIncurred['devFinalCustom'][number]>)?.[j];
      
      if (customCell && customCell.sourceVolume !== undefined) {
        // Znajdź odpowiednie volume w devJResults
        const sourceResult = devJResults.find(
          (result) => 
            result.volume === customCell.sourceVolume && 
            (result.subIndex ?? 0) === (customCell.sourceSubIndex ?? 0)
        );
        sdArray[j] = sourceResult?.sdValues?.[j];
      } else if (finalDevJ?.values[j] === devJPreview[j]) {
        // Dla wartości z finalDevJ
        sdArray[j] = finalDevJ?.sdValues?.[j];
      }
    }
    
    return sdArray;
  }, [devJPreview, devFinalCustom, devJResults, finalDevJ]);

  /* ---------- local state ---------- */
  const [tailCount, setTailCount] = useState<number | ''>('');
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [dpRange, setDpRange] = useState<[number, number]>([1, 13]);
  const [selectedCurves, setSelectedCurves] = useState<string[]>([
    'Exponential',
    'Weibull',
    'Power',
    'Inverse Power',
    'dev_j',
  ]);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [errorModalOpen, setErrorModalOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  /* ---------------- handlers ---------------- */
  const showErrorModal = (message: string) => {
    setErrorMessage(message);
    setErrorModalOpen(true);
  };

  const handleTailCountChange = (value: number | '') => {
    if (value !== '' && value < 0) {
      showErrorModal('Wartość nie może być ujemna. Proszę wprowadzić liczbę większą lub równą 0.');
      return;
    }
    setTailCount(value);
  };

  const handleDpRangeChange = (index: 0 | 1, value: number) => {
    if (value < 0) {
      showErrorModal('Wartość zakresu dp nie może być ujemna. Proszę wprowadzić liczbę większą lub równą 0.');
      return;
    }
    if (index === 0) {
      setDpRange([value, dpRange[1]]);
    } else {
      setDpRange([dpRange[0], value]);
    }
  };

  const openUpdateModal = () => {
    if (!currentVector.length) return;
    setDevPreviewCandidate(currentVector);
    setConfirmOpen(true);
  };

  const confirmUpdate = () => {
    setConfirmOpen(false);
    if (!devPreviewCandidate) return;

    setDevJPreview(devPreviewCandidate);

    const idxs = devPreviewCandidate
      .map((v, i) => (v > 1 ? i : -1))
      .filter((i) => i >= 0);
    setSelectedDevJIndexes(idxs);

    clearSimResults();
    clearR2Scores();
    clearComparisonTables(); // Czyści tabele wyników tak jak "Wyczyść porównania"
  };

  const toggleIndex = (idx: number) => {
    if (!devJPreview || devJPreview[idx]! <= 1) return;

    const next = selectedDevJIndexes.includes(idx)
      ? selectedDevJIndexes.filter((i) => i !== idx)
      : [...selectedDevJIndexes, idx];

    setSelectedDevJIndexes(next);
  };

  const handleSend = () => {
    if (!devJPreview || !userId || !selectedDevJIndexes.length) return;

    const valid = selectedDevJIndexes
      .filter((i: number) => devJPreview[i]! > 1)
      .sort((a, b) => a - b);

    // Pobierz odchylenia standardowe dla całego wektora
    const standardDeviations = getSelectedStandardDeviations;
    
    // Przekształć na tablicę liczb (zastąp undefined przez 0)
    const sdJArray = standardDeviations.map(sd => sd ?? 0);

    // Dane wysyłane na backend
    const requestData = {
      user_id: userId,
      selected_dev_j: valid.map((i) => devJPreview[i]!),
      selected_indexes: valid,
      tail_values: tailCount === '' ? null : [Number(tailCount)],
      full_dev_j: devJPreview,
      sd_j: sdJArray, // odchylenia standardowe zgodnie z klasą backend
      cl_weights: selectedWeightsDetIncurred, // macierz wag
      fitting_method: fittingMethod, // metoda dopasowania
      use_weighting: useWeighting, // ważenie współczynników
    };

    console.log('🚀 DANE WYSYŁANE NA BACKEND (INCURRED):');
    console.log('📍 URL:', `${API_URL}/calc/incurred/selected_dev_j`);
    console.log('📦 Payload:', JSON.stringify(requestData, null, 2));
    console.log('📊 Szczegóły:');
    console.log('   • user_id:', requestData.user_id);
    console.log('   • selected_dev_j:', requestData.selected_dev_j);
    console.log('   • selected_indexes:', requestData.selected_indexes);
    console.log('   • tail_values:', requestData.tail_values);
    console.log('   • full_dev_j (długość):', requestData.full_dev_j?.length);
    console.log('   • full_dev_j (pierwsze 10):', requestData.full_dev_j?.slice(0, 10));
    console.log('   • sd_j (długość):', requestData.sd_j?.length);
    console.log('   • sd_j (pierwsze 10):', requestData.sd_j?.slice(0, 10));
    console.log('   • cl_weights (wymiary):', selectedWeightsDetIncurred ? `${selectedWeightsDetIncurred.length} x ${selectedWeightsDetIncurred[0]?.length || 0}` : 'undefined');
    if (selectedWeightsDetIncurred) {
      console.log('   • cl_weights (tabela):');
      console.table(selectedWeightsDetIncurred);
    }
    console.log('   • fitting_method:', requestData.fitting_method);
    console.log('   • use_weighting:', requestData.use_weighting);

    fetch(`${API_URL}/calc/incurred/selected_dev_j`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(requestData),
    })
      .then((r) => r.json())
      .then(({ simulation_results, r2_scores }) => {
        /* --- symulacje --- */
        const sim: Record<string, Record<string, number>> = {};
        Object.entries(simulation_results).forEach(([dp, curves]) =>
          Object.entries(curves as Record<string, number>).forEach(
            ([curve, v]) => {
              if (!sim[curve]) sim[curve] = {};
              const numericValue = typeof v === 'number' ? v : Number(v);
              if (Number.isFinite(numericValue)) {
                sim[curve][dp] = Number(numericValue.toFixed(CALCULATION_DECIMAL_PLACES));
              }
            },
          ),
        );
        setSimResults(sim);

        /* --- R² --- */
        const r2: Record<string, number> = {};
        Object.entries(r2_scores ?? {}).forEach(([curve, obj]) => {
          const val = (obj as any)['Wartość'];
          const numericValue = typeof val === 'number' ? val : Number(val);
          if (Number.isFinite(numericValue)) {
            r2[curve] = Number(numericValue.toFixed(CALCULATION_DECIMAL_PLACES));
          }
        });
        setR2Scores(r2);
      })
      .catch((e) => console.error('❌ Błąd wysyłki:', e));
  };

  /* ---------- automatyczne ustawienie wektora gdy dostępny ---------- */
  useEffect(() => {
    if (currentVector.length > 0 && !devJPreview) {
      setDevJPreview(currentVector);
      setSelectedDevJIndexes(
        currentVector
          .map((v, i) => (v > 1 ? i : -1))
          .filter((i) => i >= 0)
      );
    }
  }, [currentVector, devJPreview, setDevJPreview, setSelectedDevJIndexes]);

  /* ---------- zakres dp po symulacji ---------- */
  useEffect(() => {
    if (!simResults) return;
    const firstCurve = Object.values(simResults)[0] ?? {};
    const dps = Object.keys(firstCurve)
      .map((k) => parseInt(k.replace('dp: ', ''), 10))
      .filter((n) => !isNaN(n));
    if (dps.length) setDpRange([Math.min(...dps), Math.max(...dps)]);
  }, [simResults]);

  /* ---------- tabela wektora ---------- */
  const vectorCols = useMemo(() => {
    if (!devJPreview) return ['–'];
    
    // Używamy tej samej logiki co w DevJTableCLIncurred.tsx - incurredColumnLabels.slice(1) 
    // żeby mieć dokładnie takie same nazwy kolumn jak w "Tabela wybranych współczynników do dopasowania krzywej"
    const baseLabels = incurredColumnLabels.length > 1 
      ? incurredColumnLabels.slice(1, devJPreview.length + 1)
      : devJPreview.map((_, i) => `j=${i}`);
    
    return ['–', ...baseLabels];
  }, [devJPreview, incurredColumnLabels]);

  const renderVector = (_: number, col: number) => {
    if (!devJPreview) return null;
    if (col === 0) return 'Initial Selection';

    const idx = col - 1;
    const raw = devJPreview[idx];
    if (raw === undefined) return '–';

    const selectable = raw > 1;
    const selected = selectedDevJIndexes.includes(idx);

    return (
      <span
        onClick={() => toggleIndex(idx)}
        className={
          selectable
            ? selected
              ? 'bg-blue-200/70 text-gray-800 cursor-pointer block text-center px-3 py-2 -mx-3 -my-2'
              : 'bg-white text-gray-800 hover:bg-gray-100 cursor-pointer block text-center px-3 py-2 -mx-3 -my-2'
            : 'bg-white text-gray-500 cursor-not-allowed block text-center px-3 py-2 -mx-3 -my-2'
        }
      >
        {raw.toFixed(decimalPlaces)}
      </span>
    );
  };

  /* ------------------------------------------------------------------ */
  return (
    <div className="flex flex-col lg:flex-row gap-8 p-8 text-white overflow-x-hidden">
      {/* PANEL STEROWANIA */}
      <ControlPanel
        currentVectorLength={currentVector.length}
        tailCount={tailCount}
        onTailChange={handleTailCountChange}
        onUpdateVector={openUpdateModal}
        onSend={handleSend}
        disableSend={!selectedDevJIndexes.length}
        fittingMethod={fittingMethod}
        onFittingMethodChange={setFittingMethod}
        useWeighting={useWeighting}
        onUseWeightingChange={setUseWeighting}
      />

      {/* PRAWA KOLUMNA */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* 1. Wektor dev_j */}
        <section className="inline-block rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white mb-8">
          <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
            <h2 className="font-bold text-gray-800 text-lg tracking-tight">
              Tabela współczynników Initial Selection
            </h2>
          </div>
          <div className="overflow-auto p-4">
            {devJPreview ? (
              <GenericTable
                cols={vectorCols}
                rows={1}
                stickyFirstCol
                renderCell={renderVector}
              />
            ) : (
              <p className="text-yellow-600 text-center font-medium">W panelu po lewej wybierz ,,Zaktualizuj wektor"</p>
            )}
          </div>
        </section>

        {/* 2. CL – tabela */}
        {simResults && (
          <section className="inline-block rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white mb-8">
            <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
              <h2 className="font-bold text-gray-800 text-lg tracking-tight">
                Tabela współczynników z dopasowanych krzywych
              </h2>
            </div>
            <div className="overflow-auto p-4">
              <GenericTable
                cols={[
                  'Krzywa',
                  ...Object.keys(Object.values(simResults)[0]!).map(key => key.replace('dp: ', 'k:')),
                ]}
                rows={Object.keys(simResults).length}
                stickyFirstCol
                renderCell={(row, col) => {
                  const curveKeys = Object.keys(simResults);
                  const curve = curveKeys[row];
                  if (!curve) return '–';
                  if (col === 0) return <strong>{curve}</strong>;

                  const dpKeys = Object.keys(simResults[curve] ?? {});
                  const dpKey = dpKeys[col - 1];
                  if (!dpKey) return '–';

                  const value = simResults[curve]?.[dpKey];
                  return value !== undefined ? value.toFixed(decimalPlaces) : '–';
                }}
              />
            </div>
          </section>
        )}

        {/* 3. R² – tabela */}
        {r2Scores && (
          <section className="inline-block rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white mb-8">
            <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
              <h2 className="font-bold text-gray-800 text-lg tracking-tight">
                Tabela R² dla dopasowanych krzywych
              </h2>
            </div>
            <div className="overflow-auto p-4">
              <GenericTable
                cols={['Krzywa', 'R²']}
                rows={Object.keys(r2Scores).length}
                stickyFirstCol
                renderCell={(row, col) => {
                  const sorted = Object.entries(r2Scores).sort(
                    (a, b) => b[1] - a[1],
                  );
                  const pair = sorted[row];
                  if (!pair) return null;
                  const [curve, r2] = pair;

                  return col === 0 ? <strong>{curve}</strong> : r2.toFixed(decimalPlaces);
                }}
              />
            </div>
          </section>
        )}

        {/* 4. Zakres dp */}
        <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white mb-8">
          <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 flex justify-between items-center">
            <h2 className="font-bold text-gray-800 text-lg tracking-tight">
              Wykres dopasowanych krzywych oraz wektora współczynników Initial Selection
            </h2>
            <button
              onClick={() => setIsFullscreen(true)}
              className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 text-white px-5 py-4 rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform flex items-center justify-center gap-2"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
              </svg>
              Pełny ekran
            </button>
          </div>

          <div className="flex flex-col lg:flex-row items-center gap-4 px-5 py-3 bg-white border-b border-gray-300">
            <label className="text-sm font-medium text-gray-800">Zakres dp:</label>
            <input
              type="number"
              min={0}
              value={dpRange[0]}
              onChange={(e) => handleDpRangeChange(0, +e.target.value)}
              className="bg-white border border-gray-400 text-gray-900 px-3 py-1.5 rounded-md w-20 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
            <span className="text-sm text-gray-800">do</span>
            <input
              type="number"
              min={0}
              value={dpRange[1]}
              onChange={(e) => handleDpRangeChange(1, +e.target.value)}
              className="bg-white border border-gray-400 text-gray-900 px-3 py-1.5 rounded-md w-20 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>

          {/* 5. Wybór krzywych */}
          <div className="flex flex-wrap gap-4 items-center text-sm px-5 py-3 bg-white border-b border-gray-300">
            {['Exponential', 'Weibull', 'Power', 'Inverse Power', 'Initial Selection'].map(
              (curve) => (
                <label key={curve} className="flex items-center gap-2 text-gray-800 font-medium cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedCurves.includes(curve)}
                    onChange={() =>
                      setSelectedCurves((prev) =>
                        prev.includes(curve)
                          ? prev.filter((c) => c !== curve)
                          : [...prev, curve],
                      )
                    }
                    className="w-4 h-4 text-indigo-600 bg-white border-gray-400 rounded focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                  />
                  {curve}
                </label>
              ),
            )}
          </div>

          {/* 6. Wykres */}
          <div className="p-6 bg-white">
            <SimulationChart
              simResults={simResults ?? null}
              devJ={devJPreview}
              dpRange={dpRange}
              selectedCurves={selectedCurves}
            />
          </div>
        </div>

        {/* Modal pełnego ekranu */}
        {isFullscreen && (
          <div className="fixed inset-0 bg-gray-50 z-50 flex flex-col">
            {/* Header z przyciskiem zamknij */}
            <div className="flex justify-between items-center px-6 py-4 bg-gray-800 border-b border-gray-700">
              <h1 className="font-bold text-white text-xl tracking-tight">
                Wykres dopasowanych krzywych oraz wektora współczynników Initial Selection
              </h1>
              <button
                onClick={() => setIsFullscreen(false)}
                className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition-all shadow-md hover:shadow-lg flex items-center gap-2"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
                Zamknij pełny ekran
              </button>
            </div>

            {/* Kontrolki */}
            <div className="flex flex-wrap items-center gap-4 px-6 py-4 bg-white border-b border-gray-300">
              {/* Zakres dp */}
              <div className="flex items-center gap-2">
                <label className="text-sm font-medium text-gray-800">Zakres dp:</label>
                <input
                  type="number"
                  min={0}
                  value={dpRange[0]}
                  onChange={(e) => handleDpRangeChange(0, +e.target.value)}
                  className="bg-white border border-gray-400 text-gray-900 px-3 py-1.5 rounded-md w-20 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                />
                <span className="text-sm text-gray-800">do</span>
                <input
                  type="number"
                  min={0}
                  value={dpRange[1]}
                  onChange={(e) => handleDpRangeChange(1, +e.target.value)}
                  className="bg-white border border-gray-400 text-gray-900 px-3 py-1.5 rounded-md w-20 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>

              {/* Wybór krzywych */}
              <div className="flex flex-wrap gap-4 items-center text-sm">
                {['Exponential', 'Weibull', 'Power', 'Inverse Power', 'Initial Selection'].map(
                  (curve) => (
                    <label key={curve} className="flex items-center gap-2 text-gray-800 font-medium cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedCurves.includes(curve)}
                        onChange={() =>
                          setSelectedCurves((prev) =>
                            prev.includes(curve)
                              ? prev.filter((c) => c !== curve)
                              : [...prev, curve],
                          )
                        }
                        className="w-4 h-4 text-indigo-600 bg-white border-gray-400 rounded focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                      />
                      {curve}
                    </label>
                  ),
                )}
              </div>
            </div>

            {/* Wykres pełnoekranowy */}
            <div className="flex-1 p-6 bg-white overflow-auto">
              <div className="w-full h-full">
                <SimulationChart
                  simResults={simResults ?? null}
                  devJ={devJPreview}
                  dpRange={dpRange}
                  selectedCurves={selectedCurves}
                  isFullscreen={true}
                />
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Modal potwierdzający */}
      <Modal
        title="Aktualizacja wektora"
        message="Czy na pewno chcesz zaktualizować wektor?
        Obliczenia w kolejnych zakładkach zostaną utracone."
        isOpen={confirmOpen}
        onCancel={() => setConfirmOpen(false)}
        onConfirm={confirmUpdate}
      />

      {/* Modal błędu */}
      <Modal
        title="Błąd walidacji"
        message={errorMessage}
        isOpen={errorModalOpen}
        onConfirm={() => setErrorModalOpen(false)}
        onlyOk={true}
      />
    </div>
  );
}
