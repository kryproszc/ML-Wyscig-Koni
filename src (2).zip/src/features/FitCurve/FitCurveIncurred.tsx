/* ---------------------------------------------------------------------- */
/*       src/features/devJ/DevJSelectorIncurred.tsx – CLIENT COMPONENT    */
/* ---------------------------------------------------------------------- */
'use client';

import React, { useEffect, useMemo, useState } from 'react';
import {
  useTrainDevideStoreDetIncurred,
  type TrainDevideStoreDetIncurred,
} from '@/stores/trainDevideStoreDeterministycznyIncurred';
import { useUserStore } from '@/app/_components/useUserStore';
import { useLabelsStore } from '@/stores/useLabelsStore';
const API_URL = process.env.NEXT_PUBLIC_API_URL ?? '';

import {
  ControlPanel,
  GenericTable,
  SimulationChart,
  Modal,
} from '@/shared/ui';

/* ------------------------------------------------------------------ */
/*                              KONTENER                              */
/* ------------------------------------------------------------------ */
export default function DevJSelectorIncurred() {
  /* ---------- store ---------- */
  const {
    devPreviewCandidate,
    setDevPreviewCandidate,
    devJPreview,
    setDevJPreview,

    devFinalCustom,
    finalDevVector,

    selectedDevJIndexes,
    setSelectedDevJIndexes,

    r2Scores,
    setR2Scores,
    simResults,
    setSimResults,
    clearR2Scores,
    clearSimResults,
  } = useTrainDevideStoreDetIncurred();

  const userId = useUserStore((s) => s.userId);
  
  // Labels from store
  const incurredColumnLabels = useLabelsStore((s) => s.incurredColumnLabels);

  /* ---------- bieżący wektor ---------- */
  const currentVector = useMemo<number[]>(() => {
    const merged = [...finalDevVector];
    (Object.entries(devFinalCustom ?? {}) as [
      string,
      TrainDevideStoreDetIncurred['devFinalCustom'][number],
    ][]).forEach(([idxStr, cell]) => {
      merged[Number(idxStr)] = cell.value;
    });
    return merged;
  }, [finalDevVector, devFinalCustom]);

  /* ---------- local state ---------- */
  const [tailCount, setTailCount] = useState<number | ''>('');
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [dpRange, setDpRange] = useState<[number, number]>([1, 13]);
  const [selectedCurves, setSelectedCurves] = useState<string[]>([
    'Exponential',
    'Weibull',
    'Power',
    'Inverse Power',
    'dev_j',
  ]);

  /* ---------------- handlers ---------------- */
  const openUpdateModal = () => {
    if (!currentVector.length) return;
    setDevPreviewCandidate(currentVector);
    setConfirmOpen(true);
  };

  const confirmUpdate = () => {
    setConfirmOpen(false);
    if (!devPreviewCandidate) return;

    setDevJPreview(devPreviewCandidate);

    const idxs = devPreviewCandidate
      .map((v, i) => (v > 1 ? i : -1))
      .filter((i) => i >= 0);
    setSelectedDevJIndexes(idxs);

    clearSimResults();
    clearR2Scores();
  };

  const toggleIndex = (idx: number) => {
    if (!devJPreview || devJPreview[idx]! <= 1) return;

    const next = selectedDevJIndexes.includes(idx)
      ? selectedDevJIndexes.filter((i) => i !== idx)
      : [...selectedDevJIndexes, idx];

    setSelectedDevJIndexes(next);
  };

  const handleSend = () => {
    if (!devJPreview || !userId || !selectedDevJIndexes.length) return;

    const valid = selectedDevJIndexes
      .filter((i: number) => devJPreview[i]! > 1)
      .sort((a, b) => a - b);

    fetch(`${API_URL}/calc/incurred/selected_dev_j`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        selected_dev_j: valid.map((i) => devJPreview[i]!),
        selected_indexes: valid,
        tail_values: tailCount === '' ? null : [Number(tailCount)],
        user_id: userId,
        full_dev_j: devJPreview,
      }),
    })
      .then((r) => r.json())
      .then(({ simulation_results, r2_scores }) => {
        /* --- symulacje --- */
        const sim: Record<string, Record<string, number>> = {};
        Object.entries(simulation_results).forEach(([dp, curves]) =>
          Object.entries(curves as Record<string, number>).forEach(
            ([curve, v]) => {
              if (!sim[curve]) sim[curve] = {};
              sim[curve][dp] = v;
            },
          ),
        );
        setSimResults(sim);

        /* --- R² --- */
        const r2: Record<string, number> = {};
        Object.entries(r2_scores ?? {}).forEach(([curve, obj]) => {
          const val = (obj as any)['Wartość'];
          r2[curve] = typeof val === 'number' ? val : Number(val);
        });
        setR2Scores(r2);
      })
      .catch((e) => console.error('❌ Błąd wysyłki:', e));
  };

  /* ---------- zakres dp po symulacji ---------- */
  useEffect(() => {
    if (!simResults) return;
    const firstCurve = Object.values(simResults)[0] ?? {};
    const dps = Object.keys(firstCurve)
      .map((k) => parseInt(k.replace('dp: ', ''), 10))
      .filter((n) => !isNaN(n));
    if (dps.length) setDpRange([Math.min(...dps), Math.max(...dps)]);
  }, [simResults]);

  /* ---------- tabela wektora ---------- */
  const vectorCols = useMemo(() => {
    if (!devJPreview) return ['–'];
    
    // Używamy incurredColumnLabels zaczynając od indeksu 2 (pomijamy pierwsze dwa elementy)
    const baseLabels = incurredColumnLabels.length > 2 
      ? incurredColumnLabels.slice(2, devJPreview.length + 2)
      : devJPreview.map((_, i) => i.toString());
    
    return ['–', ...baseLabels];
  }, [devJPreview, incurredColumnLabels]);

  const renderVector = (_: number, col: number) => {
    if (!devJPreview) return null;
    if (col === 0) return '0';

    const idx = col - 1;
    const raw = devJPreview[idx];
    if (raw === undefined) return '–';

    const selectable = raw > 1;
    const selected = selectedDevJIndexes.includes(idx);

    return (
      <span
        onClick={() => toggleIndex(idx)}
        className={
          selectable
            ? selected
              ? 'bg-green-300 text-black font-semibold cursor-pointer px-2 block'
              : 'hover:bg-gray-700 cursor-pointer px-2 block'
            : 'text-gray-500 cursor-not-allowed px-2 block'
        }
      >
        {raw.toFixed(6)}
      </span>
    );
  };

  /* ------------------------------------------------------------------ */
  return (
    <div className="flex flex-col lg:flex-row gap-6 p-6 text-white overflow-x-hidden">
      {/* PANEL STEROWANIA */}
      <ControlPanel
        currentVectorLength={currentVector.length}
        tailCount={tailCount}
        onTailChange={setTailCount}
        onUpdateVector={openUpdateModal}
        onSend={handleSend}
        disableSend={!selectedDevJIndexes.length}
      />

      {/* PRAWA KOLUMNA */}
      <main className="flex-1 flex flex-col gap-8 overflow-hidden">
        {/* 1. Wektor dev_j */}
        <section>
          <h2 className="text-xl font-bold mb-4 text-center">
            Tabela współczynników Initial Selection
          </h2>
          {devJPreview ? (
            <GenericTable
              cols={vectorCols}
              rows={1}
              stickyFirstCol
              renderCell={renderVector}
            />
          ) : (
            <p className="text-yellow-400 text-center">W panelu po lewej wybierz ,,Zaktualizuj wektor"</p>
          )}
        </section>

        {/* 2. CL – tabela */}
        {simResults && (
          <section>
            <h2 className="text-xl font-bold mb-4 text-center">
              Tabela współczynników z dopasowanych krzywych
            </h2>

            <GenericTable
              cols={[
                'Krzywa',
                ...Object.keys(Object.values(simResults)[0]!).map(key => key.replace('dp: ', 'k:')),
              ]}
              rows={Object.keys(simResults).length}
              stickyFirstCol
              renderCell={(row, col) => {
                const curveKeys = Object.keys(simResults);
                const curve = curveKeys[row];
                if (!curve) return '–';
                if (col === 0) return <strong>{curve}</strong>;

                const dpKeys = Object.keys(simResults[curve] ?? {});
                const dpKey = dpKeys[col - 1];
                if (!dpKey) return '–';

                const value = simResults[curve]?.[dpKey];
                return value !== undefined ? value.toFixed(6) : '–';
              }}
            />
          </section>
        )}

        {/* 3. R² – tabela */}
        {r2Scores && (
          <section>
            <h2 className="text-xl font-bold mb-4 text-center">
             Tabela R² dla dopasowanych krzywych
            </h2>

            <GenericTable
              cols={['Krzywa', 'R²']}
              rows={Object.keys(r2Scores).length}
              stickyFirstCol
              renderCell={(row, col) => {
                const sorted = Object.entries(r2Scores).sort(
                  (a, b) => b[1] - a[1],
                );
                const pair = sorted[row];
                if (!pair) return null;
                const [curve, r2] = pair;

                return col === 0 ? <strong>{curve}</strong> : r2.toFixed(6);
              }}
            />
          </section>
        )}

        {/* 4. Zakres dp */}
        <h2 className="text-xl font-bold mb-4 text-center">
              Wykres dopasowanych krzywych oraz wektora współczynników Initial Selection
        </h2>
        <section className="flex flex-col lg:flex-row items-center gap-4">
          <label className="text-sm font-medium">Zakres dp:</label>
          <input
            type="number"
            min={1}
            value={dpRange[0]}
            onChange={(e) => setDpRange([+e.target.value, dpRange[1]])}
            className="bg-gray-700 text-white px-2 py-1 rounded w-20"
          />
          <span className="text-sm">do</span>
          <input
            type="number"
            min={1}
            value={dpRange[1]}
            onChange={(e) => setDpRange([dpRange[0], +e.target.value])}
            className="bg-gray-700 text-white px-2 py-1 rounded w-20"
          />
        </section>

        {/* 5. Wybór krzywych */}
        <section className="flex flex-wrap gap-4 items-center text-sm">
          {['Exponential', 'Weibull', 'Power', 'Inverse Power', 'Initial Selection'].map(
            (curve) => (
              <label key={curve} className="flex items-center gap-1">
                <input
                  type="checkbox"
                  checked={selectedCurves.includes(curve)}
                  onChange={() =>
                    setSelectedCurves((prev) =>
                      prev.includes(curve)
                        ? prev.filter((c) => c !== curve)
                        : [...prev, curve],
                    )
                  }
                />
                {curve}
              </label>
            ),
          )}
        </section>

        {/* 6. Wykres */}
        <SimulationChart
          simResults={simResults ?? null}
          devJ={devJPreview}
          dpRange={dpRange}
          selectedCurves={selectedCurves}
        />
      </main>

      {/* Modal potwierdzający */}
      <Modal
        title="Aktualizacja wektora"
        message="Czy na pewno chcesz zaktualizować wektor?
        Obliczenia w kolejnych zakładkach zostaną utracone."
        isOpen={confirmOpen}
        onCancel={() => setConfirmOpen(false)}
        onConfirm={confirmUpdate}
      />
    </div>
  );
}
