'use client';

import { useState } from 'react';
import { useTrainDevideStoreDetIncurred } from '@/stores/trainDevideStoreDeterministycznyIncurred';
import { useLabelsStore } from '@/stores/useLabelsStore';
import { ComparisonTable } from '@/shared/components/ComparisonTable';
import { DataSelectionPanel } from './DataSelectionPanel';
import { useDataOptions } from '@/shared/hooks/useDataOptions';
import { usePayloadBuilder } from '@/shared/hooks/usePayloadBuilder';
import { useExcelExport } from '@/shared/hooks/useExcelExport';
import { useCalculationsExport } from '@/shared/hooks/useCalculationsExport';
import { useDataSubmission } from '../hooks/useDataSubmission';
import { CalculationsExportDialog } from '@/shared/components/CalculationsExportDialog';

export default function IncurredResultsPage() {
  const [showModal, setShowModal] = useState(false);

  /* ---------- STORE ---------- */
  const removeComparisonTable = useTrainDevideStoreDetIncurred((s) => s.removeComparisonTable);

  const selectedA = useTrainDevideStoreDetIncurred((s) => s.selectedDataA);
  const selectedB = useTrainDevideStoreDetIncurred((s) => s.selectedDataB);
  const setSelectedA = useTrainDevideStoreDetIncurred((s) => s.setSelectedDataA);
  const setSelectedB = useTrainDevideStoreDetIncurred((s) => s.setSelectedDataB);

  const simResults = useTrainDevideStoreDetIncurred((s) => s.simResults) ?? {};
  const devJResults = useTrainDevideStoreDetIncurred((s) => s.devJResults) ?? [];
  const finalDevVector = useTrainDevideStoreDetIncurred((s) => s.finalDevVector) ?? [];
  const combinedDevJSummary = useTrainDevideStoreDetIncurred((s) => s.combinedDevJSummary) ?? [];

  const comparisonTables = useTrainDevideStoreDetIncurred((s) => s.comparisonTables);
  const addComparisonTable = useTrainDevideStoreDetIncurred((s) => s.addComparisonTable);
  const clearComparisonTables = useTrainDevideStoreDetIncurred((s) => s.clearComparisonTables);
  
  // Get selected volume for color highlighting
  const finalDevJ = useTrainDevideStoreDetIncurred((s) => s.finalDevJ);

  // Labels from store for column headers / rows
  const incurredColumnLabels = useLabelsStore((s) => s.incurredColumnLabels);
  const incurredRowLabels = useLabelsStore((s) => s.incurredRowLabels).slice(1);

  /* ---------- HOOKS ---------- */
  const { allOptions, keyToLabelMap } = useDataOptions({
    simResults,
    devJResults,
    combinedDevJSummary,
    finalDevVector,
  });

  const { buildPayload } = usePayloadBuilder({
    simResults,
    devJResults,
    combinedDevJSummary,
    finalDevVector,
  });

  const { exportToExcel } = useExcelExport();

  const calculationsExport = useCalculationsExport({
    allOptions,
    simResults,
    devJResults,
    combinedDevJSummary,
    finalDevVector,
    buildPayload,
    columnLabels: incurredColumnLabels,
    triangleType: 'incurred',
    comparisonTables,
    selectedVolume: finalDevJ?.volume,
    selectedSubIndex: finalDevJ?.subIndex,
  });

  const { handleSend } = useDataSubmission({
    buildPayload,
    keyToLabelMap,
    getTriangleData: () => useTrainDevideStoreDetIncurred.getState().incurredTriangle ?? [],
    addComparisonTable,
    apiEndpoint: 'incurred',
  });

  /* ---------- HANDLERS ---------- */
  const handleSendData = () => {
    handleSend(selectedA, selectedB, () => setShowModal(true));
  };

  const handleExportToExcel = () => {
    exportToExcel(comparisonTables, 'porownania_incurred.xlsx');
  };

  /* ---------- UI ---------- */
  return (
    <div className="grid grid-cols-[300px_1fr] p-6 gap-10 text-white">
      {/* Lewa kolumna */}
      <DataSelectionPanel
        selectedA={selectedA}
        selectedB={selectedB}
        setSelectedA={setSelectedA}
        setSelectedB={setSelectedB}
        allOptions={allOptions}
        onSendData={handleSendData}
        onClearComparisons={clearComparisonTables}
        onExportToExcel={handleExportToExcel}
        onExportCalculations={calculationsExport.initializeExportItems}
        showModal={showModal}
        setShowModal={setShowModal}
        methodType="Incurred"
      />

      {/* Prawa kolumna */}
      <div className="flex-1 overflow-auto flex flex-col gap-10">
        {comparisonTables.map((entry, idx) => (
          <div key={`${entry.labelA}-${entry.labelB}-${idx}`} className="relative">
            <button
              onClick={() => removeComparisonTable(idx)}
              className="absolute top-0 right-0 text-red-500 hover:text-red-700 text-xl p-2"
              title="Usuń porównanie"
            >
              ❌
            </button>

            <ComparisonTable
              data={entry.data}
              labelA={entry.labelA}
              labelB={entry.labelB}
              rowLabels={incurredRowLabels} 
            />
          </div>
        ))}
      </div>

      {/* Dialog eksportu obliczeń */}
      <CalculationsExportDialog
        isOpen={calculationsExport.isDialogOpen}
        exportItems={calculationsExport.exportItems}
        selectedCount={calculationsExport.selectedCount}
        onClose={calculationsExport.closeDialog}
        onToggleItem={calculationsExport.toggleItemSelection}
        onToggleAll={calculationsExport.toggleAllSelection}
        onExport={calculationsExport.exportSelectedCalculations}
      />
    </div>
  );
}
