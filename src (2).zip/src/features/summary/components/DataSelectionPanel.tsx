import React from 'react';
import Modal from '@/components/Modal';
import type { SelectOption } from '@/shared/hooks/useDataOptions';

export interface DataSelectionPanelProps {
  selectedA: string | null;
  selectedB: string | null;
  setSelectedA: (value: string | null) => void;
  setSelectedB: (value: string | null) => void;
  allOptions: SelectOption[];
  onSendData: () => void;
  onClearComparisons: () => void;
  onExportToExcel: () => void;
  onExportCalculations: () => void;
  showModal: boolean;
  setShowModal: (show: boolean) => void;
  methodType: string; // np. "Paid", "Incurred"
}

export const DataSelectionPanel: React.FC<DataSelectionPanelProps> = ({
  selectedA,
  selectedB,
  setSelectedA,
  setSelectedB,
  allOptions,
  onSendData,
  onClearComparisons,
  onExportToExcel,
  onExportCalculations,
  showModal,
  setShowModal,
  methodType,
}) => {
  return (
    <div className="flex flex-col gap-6 max-w-md w-full">
      <h2 className="text-lg font-semibold">Wybierz dane do analizy</h2>

      <select
        className="bg-gray-700 text-white rounded p-2"
        onChange={(e) => setSelectedA(e.target.value || null)}
        value={selectedA || ''}
      >
        <option value="">Wybierz współczyyniki</option>
        {allOptions.map((o) => (
          <option key={o.key} value={o.key}>
            {o.label}
          </option>
        ))}
      </select>

      <select
        className="bg-gray-700 text-white rounded p-2"
        onChange={(e) => setSelectedB(e.target.value || null)}
        value={selectedB || ''}
      >
        <option value="">Wybierz współczyyniki </option>
        {allOptions.map((o) => (
          <option key={o.key} value={o.key}>
            {o.label}
          </option>
        ))}
      </select>

      <button
        onClick={onSendData}
        className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-700 font-semibold transition"
      >
        Oblicz
      </button>

      <button
        onClick={onClearComparisons}
        className="px-4 py-2 rounded bg-red-600 hover:bg-red-700 font-semibold transition"
      >
        🧹 Wyczyść porównania
      </button>

      <button
        onClick={onExportCalculations}
        className="px-4 py-2 rounded bg-green-600 hover:bg-green-700 font-semibold transition"
      >
        🧮 Eksportuj obliczenia
      </button>

      <Modal
        isOpen={showModal}
        title="Wymagane dane"
        message="Aby wysłać dane, musisz wykonać obliczenia"
        onCancel={() => setShowModal(false)}
        onlyOk
      />

      <div className="text-sm text-gray-300 pt-6">
        Widok: <strong>Metoda {methodType}</strong>, krok: <strong>Wyniki</strong>
      </div>
    </div>
  );
};
