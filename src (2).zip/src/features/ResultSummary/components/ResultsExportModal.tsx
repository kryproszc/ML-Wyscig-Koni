/* ------------------------------------------------------------------ */
/*                     Results Export Modal                            */
/* ------------------------------------------------------------------ */

'use client';

import React, { useState } from 'react';
import Modal from '@/components/Modal';
import { useCombinedResultsExport, type WeightedSummaryData } from '../hooks/useCombinedResultsExport';
import { CombinedExportDialog } from './CombinedExportDialog';

interface ResultsExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  weightedSummaryData?: WeightedSummaryData | null;
}

export const ResultsExportModal: React.FC<ResultsExportModalProps> = ({
  isOpen,
  onClose,
  weightedSummaryData,
}) => {
  const combinedExport = useCombinedResultsExport(weightedSummaryData || undefined);

  const handleCombinedExport = () => {
    combinedExport.initializeExportItems();
  };

  const closeCombinedExportDialog = () => {
    combinedExport.closeDialog();
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-gray-800 rounded-lg p-6 max-w-3xl w-full mx-4 max-h-[80vh] flex flex-col border border-gray-600">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-semibold text-white">📊 Eksport wyników</h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white text-3xl leading-none"
            >
              ×
            </button>
          </div>

          <div className="flex-1 flex flex-col justify-center items-center">
            <div className="bg-gray-700 rounded-lg p-8 max-w-md w-full text-center">
              <div className="mb-6">
                <div className="text-4xl mb-4">📂</div>
                <h3 className="text-xl font-semibold text-white mb-2">
                  Łączny eksport
                </h3>
                <p className="text-gray-300 text-sm mb-2">
                  Eksportuj wszystkie dane z obu metod do jednego pliku Excel
                </p>
                <p className="text-gray-400 text-xs">
                  Plik będzie zawierał oddzielne zakładki dla:
                </p>
                <ul className="text-gray-400 text-xs mt-2 space-y-1">
                  <li>• <span className="text-blue-400">Obliczenia Paid</span></li>
                  <li>• <span className="text-green-400">Obliczenia Incurred</span></li>
                  <li>• <span className="text-blue-400">Paid Porównania</span></li>
                  <li>• <span className="text-green-400">Incurred Porównania</span></li>
                  <li>• <span className= "hover:bg-purple-700"> Podsumowanie ważone</span></li>

                </ul>
              </div>
              
              <button
                onClick={handleCombinedExport}
                className="w-full px-6 py-3 bg-purple-600 hover:bg-purple-700 rounded-lg font-semibold transition text-white"
              >
                📥 Otwórz dialog eksportu
              </button>
            </div>
          </div>

          <div className="flex justify-center mt-6 pt-4 border-t border-gray-600">
            <button
              onClick={onClose}
              className="px-6 py-2 bg-gray-600 hover:bg-gray-500 rounded-lg font-semibold transition text-white"
            >
              Zamknij
            </button>
          </div>
        </div>
      </div>

      {/* ========== COMBINED EXPORT DIALOG ========== */}
      <CombinedExportDialog
        isOpen={combinedExport.isDialogOpen}
        exportItems={combinedExport.exportItems}
        selectedCount={combinedExport.selectedCount}
        onClose={closeCombinedExportDialog}
        onToggleItem={combinedExport.toggleItemSelection}
        onToggleAll={combinedExport.toggleAllSelection}
        onExport={combinedExport.exportSelectedCalculations}
      />
    </>
  );
};
