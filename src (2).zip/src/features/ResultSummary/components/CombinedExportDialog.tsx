/* ------------------------------------------------------------------ */
/*                  Combined Export Dialog Component                   */
/* ------------------------------------------------------------------ */

import React from 'react';
import type { CombinedExportItem } from '../hooks/useCombinedResultsExport';

export interface CombinedExportDialogProps {
  isOpen: boolean;
  exportItems: CombinedExportItem[];
  selectedCount: number;
  onClose: () => void;
  onToggleItem: (key: string) => void;
  onToggleAll: () => void;
  onExport: () => void;
}

export const CombinedExportDialog: React.FC<CombinedExportDialogProps> = ({
  isOpen,
  exportItems,
  selectedCount,
  onClose,
  onToggleItem,
  onToggleAll,
  onExport,
}) => {
  if (!isOpen) return null;

  const allSelected = exportItems.length > 0 && exportItems.every(item => item.selected);
  const someSelected = selectedCount > 0 && selectedCount < exportItems.length;

  // Group items by category and type
  const groupedItems = exportItems.reduce((acc, item) => {
    const key = `${item.category}-${item.type}`;
    if (!acc[key]) {
      acc[key] = [];
    }
    acc[key].push(item);
    return acc;
  }, {} as Record<string, CombinedExportItem[]>);

  const getGroupTitle = (key: string) => {
    const [category, type] = key.split('-');
    if (category === 'calculations') {
      return type === 'paid' ? '📊 Obliczenia Paid' : '📈 Obliczenia Incurred';
    } else if (category === 'comparisons') {
      return type === 'paid' ? '🔍 Paid Porównania' : '🔍 Incurred Porównania';
    } else if (category === 'summary') {
      return '📋 Podsumowanie ważone';
    }
    return 'Inne';
  };

  const getGroupColor = (key: string) => {
    const [category, type] = key.split('-');
    if (category === 'summary') {
      return 'text-purple-600';
    }
    return type === 'paid' ? 'text-blue-600' : 'text-green-600';
  };

  return (
    <div className="fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-gradient-to-br from-gray-50 to-white rounded-2xl p-6 max-w-2xl w-full mx-4 max-h-[80vh] flex flex-col border border-gray-300 shadow-2xl">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-800">📂 Łączny eksport do Excel</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-800 text-2xl leading-none"
          >
            ×
          </button>
        </div>

        <div className="mb-4 p-3 bg-gradient-to-r from-gray-100 to-gray-50 rounded-lg border border-gray-200">
          <p className="text-gray-700 text-sm mb-2 font-medium">
            🗂️ Wszystkie zaznaczone dane zostaną wyeksportowane do jednego pliku Excel z oddzielnymi zakładkami:
          </p>
          <ul className="text-gray-600 text-xs space-y-1">
            <li>• <span className="text-blue-600 font-medium">Obliczenia Paid</span> - trójkąt danych, współczynniki CL i wybrane krzywe</li>
            <li>• <span className="text-green-600 font-medium">Obliczenia Incurred</span> - trójkąt danych, współczynniki CL i wybrane krzywe</li>
            <li>• <span className="text-blue-600 font-medium">Paid Porównania</span> - tabele porównawcze Paid dla różnych współćzynników</li>
            <li>• <span className="text-green-600 font-medium">Incurred Porównania</span> - tabele porównawcze Incurred dla różnych współćzynników</li>
            <li>• <span className="text-purple-600 font-medium">Podsumowanie ważone</span> - tabela końcowa ważonych Paid i Incurred</li>
          </ul>
        </div>

        <div className="mb-4">
          <label className="flex items-center text-gray-800 cursor-pointer">
            <input
              type="checkbox"
              checked={allSelected}
              ref={input => {
                if (input) input.indeterminate = someSelected;
              }}
              onChange={onToggleAll}
              className="mr-2 scale-110"
            />
            <span className="font-medium">
              {allSelected ? 'Odznacz wszystko' : 'Zaznacz wszystko'} 
              {selectedCount > 0 && ` (${selectedCount}/${exportItems.length})`}
            </span>
          </label>
        </div>

        <div className="flex-1 overflow-y-auto mb-4 max-h-96">
          <div className="space-y-4">
            {Object.entries(groupedItems).map(([groupKey, items]) => (
              <div key={groupKey} className="space-y-2">
                <h3 className={`font-semibold ${getGroupColor(groupKey)} border-b border-gray-300 pb-1`}>
                  {getGroupTitle(groupKey)} ({items.filter(item => item.selected).length}/{items.length})
                </h3>
                <div className="space-y-1 pl-4">
                  {items.map((item) => (
                    <label
                      key={item.key}
                      className="flex items-center text-gray-800 cursor-pointer hover:bg-gray-100 p-2 rounded"
                    >
                      <input
                        type="checkbox"
                        checked={item.selected}
                        onChange={() => onToggleItem(item.key)}
                        className="mr-3 scale-110"
                      />
                      <span className="text-sm">{item.label.replace(/^(Paid|Incurred): /, '')}</span>
                    </label>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-3 pt-4 border-t border-gray-300">
          <button
            onClick={onClose}
            className="flex-1 py-4 px-5 bg-gradient-to-r from-gray-600 to-gray-500 hover:from-gray-700 hover:to-gray-600 text-white rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
          >
            Anuluj
          </button>
          <button
            onClick={onExport}
            disabled={selectedCount === 0}
            className="flex-1 py-4 px-5 bg-gradient-to-r from-yellow-600 to-yellow-500 hover:from-yellow-700 hover:to-yellow-600 disabled:bg-gray-400 disabled:cursor-not-allowed text-white rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform disabled:shadow-none disabled:transform-none"
          >
            📥 Eksportuj do Excel ({selectedCount})
          </button>
        </div>
      </div>
    </div>
  );
};
