'use client';

import { useForm } from 'react-hook-form';
import { useState, useEffect } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import ExcelJS from 'exceljs';
import { z } from 'zod';
import { useTestTriangleStore } from '@/stores/useTestTriangleStore';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardFooter,
} from '@/components/ui/card';
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Loader2, Maximize2, X, Minimize2 } from 'lucide-react';
import { VisuallyHidden } from '@/components/ui/visually-hidden';
import { HeadersSelector } from '@/components/HeadersSelector';

// Funkcje konwersji Excel notacji
const colLetterToNumber = (col: string): number => {
  let result = 0;
  for (let i = 0; i < col.length; i++) {
    result = result * 26 + (col.charCodeAt(i) - 'A'.charCodeAt(0) + 1);
  }
  return result;
};

const colNumberToLetter = (num: number): string => {
  let result = '';
  while (num > 0) {
    num--;
    result = String.fromCharCode((num % 26) + 'A'.charCodeAt(0)) + result;
    num = Math.floor(num / 26);
  }
  return result;
};

const parseExcelCell = (cell: string): { row: number; col: number } | null => {
  const match = cell.match(/^([A-Z]+)(\d+)$/);
  if (!match || !match[1] || !match[2]) return null;
  
  const colLetter = match[1];
  const rowNumber = parseInt(match[2], 10);
  
  if (isNaN(rowNumber)) return null;
  
  return {
    row: rowNumber,
    col: colLetterToNumber(colLetter)
  };
};

const getCellDisplayValue = (value: any): string => {
  if (value === null || value === undefined) return '';

  if (typeof value === 'object') {
    if (typeof value.text === 'string') return value.text;
    if (Array.isArray(value.richText)) {
      return value.richText.map((part: any) => part.text ?? '').join('');
    }
    if ('result' in value) return String((value as any).result ?? '');
  }

  return String(value);
};

const isMeaningfulCellValue = (value: any): boolean => {
  const display = getCellDisplayValue(value);
  return display.trim() !== '';
};

const isMissingTriangleValue = (value: any): boolean => {
  const display = getCellDisplayValue(value).trim();
  return display === '' || display === '-';
};

const schema = z.object({
  rowStart: z.union([z.coerce.number().min(1, "Wiersz początkowy musi być co najmniej 1"), z.string()]),
  rowEnd: z.coerce.number().min(1, "Wiersz końcowy musi być co najmniej 1"),
  colStart: z.coerce.number().min(1, "Kolumna początkowa musi być co najmniej 1"),
  colEnd: z.coerce.number().min(1, "Kolumna końcowa musi być co najmniej 1"),
  cellStart: z.string().optional(),
  cellEnd: z.string().optional(),
  rangeMode: z.enum(['numeric', 'excel']),
  file: z.any(),
}).refine((data) => {
  if (data.rangeMode === 'excel') {
    return data.cellStart && data.cellEnd;
  }
  return true;
}, {
  message: "W trybie Excel musisz podać obie komórki (np. A1 i Z99)",
  path: ['cellStart']
});

interface TestFormData {
  file?: FileList | null;
  rowStart: string | number;
  rowEnd: number;
  colStart: number;
  colEnd: number;
  cellStart?: string;
  cellEnd?: string;
  rangeMode: 'numeric' | 'excel';
}

type TriangleValidationResult = {
  isValid: boolean;
  error?: string;
  dataStartRow: number;
  dataStartCol: number;
  dataRows: number;
  dataCols: number;
  dataEndRow: number;
  dataEndCol: number;
};

// Komponent do wyboru arkusza
function SheetSelectTest() {
  const { workbook, selectedSheetName, setSelectedSheetName } = useTestTriangleStore();
  
  if (!workbook) return null;
  
  const wb = workbook as any; // ExcelJS Workbook
  const sheets = wb.worksheets || [];
  
  return (
    <select
      value={selectedSheetName || ''}
      onChange={(e) => setSelectedSheetName(e.target.value)}
      className="bg-slate-700 border border-slate-600 text-white p-2 rounded-lg"
    >
      {sheets.map((sheet: any) => (
        <option key={sheet.name} value={sheet.name}>
          {sheet.name}
        </option>
      ))}
    </select>
  );
}

export function InputDataTabTest() {
  const {
    workbook,
    selectedSheetName,
    uploadedFileName,
    startRow,
    endRow,
    startCol,
    endCol,
    rangeMode: storedRangeMode,
    cellStart: storedCellStart,
    cellEnd: storedCellEnd,
    hasHeaders,
    testData,
    setWorkbook,
    setSelectedSheetName,
    setUploadedFileName,
    setRange,
    setRangeMode: setStoredRangeMode,
    setCellRange,
    setHasHeaders: setStoredHasHeaders,
    setTestData,
  } = useTestTriangleStore();

  const [errorMessage, setErrorMessage] = useState("");
  const [showErrorDialog, setShowErrorDialog] = useState(false);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [fullscreenMode, setFullscreenMode] = useState(false);
  const [isClosing, setIsClosing] = useState(false);
  const [columnHeaders, setColumnHeaders] = useState<string[]>([]);
  const [rowHeaders, setRowHeaders] = useState<string[]>([]);
  const [topLeftHeader, setTopLeftHeader] = useState('');
  const showHeaders = columnHeaders.length > 0 || rowHeaders.length > 0 || topLeftHeader !== '';
  const dataStartRowForDisplay = hasHeaders ? startRow + 1 : startRow;
  const dataStartColForDisplay = hasHeaders ? startCol + 1 : startCol;

  const { setClInitial, cl_initial } = useTrainDevideStoreDet();
  
  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<TestFormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      file: null,
      rowStart: startRow,
      rowEnd: endRow,
      colStart: startCol,
      colEnd: endCol,
      cellStart: storedCellStart,
      cellEnd: storedCellEnd,
      rangeMode: storedRangeMode,
    },
  });

  // 🔧 Funkcje do automatycznej konwersji na wielkie litery w polach Excel
  const handleCellStartChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.toUpperCase();
    setValue('cellStart', value);
  };

  const handleCellEndChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.toUpperCase();
    setValue('cellEnd', value);
  };

  const file = watch('file');
  const watchedRangeMode = watch('rangeMode');
  const watchedRowStart = watch('rowStart');
  const watchedRowEnd = watch('rowEnd');
  const watchedColStart = watch('colStart');
  const watchedColEnd = watch('colEnd');
  const watchedCellStart = watch('cellStart');
  const watchedCellEnd = watch('cellEnd');
  const currentRangeMode = watchedRangeMode || storedRangeMode;
  
  useEffect(() => {
    if (watchedRangeMode && watchedRangeMode !== storedRangeMode) {
      setStoredRangeMode(watchedRangeMode);
    }
  }, [watchedRangeMode, storedRangeMode, setStoredRangeMode]);

  useEffect(() => {
    if (currentRangeMode === 'numeric') {
      const nextStartRow = Number(watchedRowStart);
      const nextEndRow = Number(watchedRowEnd);
      const nextStartCol = Number(watchedColStart);
      const nextEndCol = Number(watchedColEnd);

      if (
        Number.isFinite(nextStartRow) &&
        Number.isFinite(nextEndRow) &&
        Number.isFinite(nextStartCol) &&
        Number.isFinite(nextEndCol)
      ) {
        setRange(nextStartRow, nextEndRow, nextStartCol, nextEndCol);
      }
    }
  }, [
    currentRangeMode,
    watchedRowStart,
    watchedRowEnd,
    watchedColStart,
    watchedColEnd,
    setRange,
  ]);

  useEffect(() => {
    if (currentRangeMode === 'excel') {
      setCellRange(watchedCellStart || '', watchedCellEnd || '');
    }
  }, [currentRangeMode, watchedCellStart, watchedCellEnd, setCellRange]);
  
  // Wczytanie pliku
  const handleFileLoad = async () => {
    const f = file?.[0];
    if (!f) {
      setErrorMessage("Najpierw wybierz plik Excel (.xlsx lub .xls).");
      setShowErrorDialog(true);
      return;
    }

    if (f.size > 10 * 1024 * 1024) {
      setErrorMessage("Plik jest za duży. Maksymalny rozmiar to 10MB.");
      setShowErrorDialog(true);
      return;
    }

    const validExtensions = ['.xlsx', '.xls'];
    const fileName = f.name.toLowerCase();
    const hasValidExtension = validExtensions.some(ext => fileName.endsWith(ext));
    
    if (!hasValidExtension) {
      setErrorMessage("Nieprawidłowy format pliku. Wybierz plik Excel (.xlsx lub .xls).");
      setShowErrorDialog(true);
      return;
    }

    try {
      setIsLoading(true);
      setProgress(0);
      
      const arrayBuffer = await f.arrayBuffer();
      setProgress(50);
      
      const workbook = new ExcelJS.Workbook();
      await workbook.xlsx.load(arrayBuffer);
      
      setProgress(100);
      setWorkbook(workbook as any);
      setSelectedSheetName(workbook.worksheets[0]?.name ?? null);
      setUploadedFileName(f.name);
      
      console.log('✅ Plik wczytany przez ExcelJS!');
      console.log('📋 Dostępne arkusze:', workbook.worksheets.map(ws => ws.name));
      
      setIsLoading(false);
    } catch (err) {
      console.error("Błąd:", err);
      setErrorMessage("Nie można odczytać pliku.");
      setShowErrorDialog(true);
      setIsLoading(false);
    }
  };

  // Wykryj zakres automatycznie
  const handleAutoRange = () => {
    if (!workbook || !selectedSheetName) {
      setErrorMessage("Najpierw wczytaj plik i wybierz arkusz.");
      setShowErrorDialog(true);
      return;
    }

    const sheet = (workbook as any).getWorksheet(selectedSheetName);
    if (!sheet) {
      setErrorMessage("Nie można wykryć zakresu dla tego arkusza.");
      setShowErrorDialog(true);
      return;
    }

    let top = Number.POSITIVE_INFINITY;
    let left = Number.POSITIVE_INFINITY;
    let bottom = 0;
    let right = 0;

    sheet.eachRow({ includeEmpty: false }, (row: any, rowNumber: number) => {
      row.eachCell({ includeEmpty: false }, (cell: any, colNumber: number) => {
        if (!isMeaningfulCellValue(cell.value)) return;

        if (rowNumber < top) top = rowNumber;
        if (rowNumber > bottom) bottom = rowNumber;
        if (colNumber < left) left = colNumber;
        if (colNumber > right) right = colNumber;
      });
    });

    if (!Number.isFinite(top) || bottom === 0 || !Number.isFinite(left) || right === 0) {
      setErrorMessage("Nie można wykryć zakresu na podstawie danych w arkuszu.");
      setShowErrorDialog(true);
      return;
    }

    if (currentRangeMode === 'numeric') {
      setValue('rowStart', top);
      setValue('rowEnd', bottom);
      setValue('colStart', left);
      setValue('colEnd', right);
    } else {
      // Tryb Excel - konwertuj na notację A1 (zawsze wielkie litery)
      const startCell = `${colNumberToLetter(left)}${top}`.toUpperCase();
      const endCell = `${colNumberToLetter(right)}${bottom}`.toUpperCase();
      setValue('cellStart', startCell);
      setValue('cellEnd', endCell);
    }
  };

  const validateTriangleForMode = (
    sheet: any,
    startRow: number,
    endRow: number,
    startCol: number,
    endCol: number,
    modeHasHeaders: boolean
  ): TriangleValidationResult => {
    const dataStartRow = modeHasHeaders ? startRow + 1 : startRow;
    const dataStartCol = modeHasHeaders ? startCol + 1 : startCol;
    let dataRows = endRow - dataStartRow + 1;
    let dataCols = endCol - dataStartCol + 1;
    let dataEndRow = endRow;
    let dataEndCol = endCol;

    if (dataRows <= 0 || dataCols <= 0) {
      return {
        isValid: false,
        error: 'Wybrany zakres nie zawiera obszaru danych po uwzględnieniu ustawienia nagłówków.',
        dataStartRow,
        dataStartCol,
        dataRows,
        dataCols,
        dataEndRow,
        dataEndCol,
      };
    }

    if (dataRows !== dataCols) {
      const canAutoPadWithoutHeaders = !modeHasHeaders && Math.abs(dataRows - dataCols) === 1;

      if (canAutoPadWithoutHeaders) {
        if (dataRows > dataCols) {
          dataCols = dataRows;
          dataEndCol = endCol + 1;
        } else {
          dataRows = dataCols;
          dataEndRow = endRow + 1;
        }
      } else {
        return {
          isValid: false,
          error: `Zakres musi byc kwadratowy. Dla trybu ${modeHasHeaders ? 'z nagłówkami' : 'bez nagłówków'} otrzymano ${dataRows} wierszy × ${dataCols} kolumn.`,
          dataStartRow,
          dataStartCol,
          dataRows,
          dataCols,
          dataEndRow,
          dataEndCol,
        };
      }
    }

    const rowLengths: number[] = [];

    for (let rowIdx = 0; rowIdx < dataRows; rowIdx++) {
      const rowNumber = dataStartRow + rowIdx;
      let lastFilledColIdx = -1;
      let missingInsideRow = false;

      for (let colIdx = 0; colIdx < dataCols; colIdx++) {
        const colNumber = dataStartCol + colIdx;
        const cell = sheet.getRow(rowNumber).getCell(colNumber);
        const hasData = !isMissingTriangleValue(cell.value);

        if (hasData) {
          if (missingInsideRow) {
            return {
              isValid: false,
              error: `Brakuje danych w środku trójkąta (komórka ${colNumberToLetter(colNumber)}${rowNumber}).`,
              dataStartRow,
              dataStartCol,
              dataRows,
              dataCols,
              dataEndRow,
              dataEndCol,
            };
          }
          lastFilledColIdx = colIdx;
        } else if (lastFilledColIdx >= 0) {
          missingInsideRow = true;
        }
      }

      rowLengths.push(lastFilledColIdx + 1);
    }

    const matchesFullTriangle = rowLengths.every(
      (rowLength, rowIdx) => rowLength === Math.max(0, dataCols - rowIdx)
    );

    const matchesTriangleWithoutOneDiagonal = rowLengths.every(
      (rowLength, rowIdx) => rowLength === Math.max(0, dataCols - rowIdx - 1)
    );

    if (!matchesFullTriangle && !matchesTriangleWithoutOneDiagonal) {
      for (let rowIdx = 0; rowIdx < rowLengths.length; rowIdx++) {
        const rowLength = rowLengths[rowIdx] ?? 0;
        const minRequiredForAllowedTriangle = Math.max(0, dataCols - rowIdx - 1);

        if (rowLength < minRequiredForAllowedTriangle) {
          const rowNumber = dataStartRow + rowIdx;
          const colNumber = dataStartCol + rowLength;
          return {
            isValid: false,
            error: `Brakuje danych w komorce ${colNumberToLetter(colNumber)}${rowNumber}.`,
            dataStartRow,
            dataStartCol,
            dataRows,
            dataCols,
            dataEndRow,
            dataEndCol,
          };
        }
      }

      return {
        isValid: false,
        error: 'Ksztalt trojkata jest nieprawidlowy. Dane nie tworzą poprawnego trójkąta ani trójkąta z brakującą jedną przekątną.',
        dataStartRow,
        dataStartCol,
        dataRows,
        dataCols,
        dataEndRow,
        dataEndCol,
      };
    }

    let hasAnyData = false;
    for (let row = dataStartRow; row <= endRow; row++) {
      for (let col = dataStartCol; col <= endCol; col++) {
        const cell = sheet.getRow(row).getCell(col);
        if (isMeaningfulCellValue(cell.value)) {
          hasAnyData = true;
          break;
        }
      }
      if (hasAnyData) break;
    }

    if (!hasAnyData) {
      return {
        isValid: false,
        error: `Wybrany zakres ${startRow}-${endRow} × ${startCol}-${endCol} nie zawiera zadnych danych.`,
        dataStartRow,
        dataStartCol,
        dataRows,
        dataCols,
        dataEndRow,
        dataEndCol,
      };
    }

    return {
      isValid: true,
      dataStartRow,
      dataStartCol,
      dataRows,
      dataCols,
      dataEndRow,
      dataEndCol,
    };
  };
  
  // Przetworzenie danych z odczytem formatowania
  const onSubmit = (data: TestFormData) => {
    console.log('🔍 [onSubmit] START:', data);
    
    if (!workbook || !selectedSheetName) {
      setErrorMessage("Najpierw wczytaj plik i wybierz arkusz.");
      setShowErrorDialog(true);
      return;
    }
    
    const sheet = (workbook as any).getWorksheet(selectedSheetName);
    if (!sheet) {
      setErrorMessage("Nie znaleziono arkusza.");
      setShowErrorDialog(true);
      return;
    }

    let startRow: number, endRow: number, startCol: number, endCol: number;

    if (data.rangeMode === 'excel') {
      const parsedStart = parseExcelCell(data.cellStart?.toUpperCase() || '');
      const parsedEnd = parseExcelCell(data.cellEnd?.toUpperCase() || '');

      if (!parsedStart || !parsedEnd) {
        setErrorMessage("Nieprawidłowy format komórek. Użyj formatu A1, B2 itd.");
        setShowErrorDialog(true);
        return;
      }

      startRow = parsedStart.row;
      startCol = parsedStart.col;
      endRow = parsedEnd.row;
      endCol = parsedEnd.col;
    } else {
      startRow = Number(data.rowStart);
      endRow = Number(data.rowEnd);
      startCol = Number(data.colStart);
      endCol = Number(data.colEnd);
    }

    if (startRow > endRow || startCol > endCol) {
      setErrorMessage("Zakres jest nieprawidłowy. Sprawdź czy początek jest przed końcem.");
      setShowErrorDialog(true);
      return;
    }
    
    console.log('📊 Zakres:', startRow, '-', endRow, '×', startCol, '-', endCol);
    
    setRange(startRow, endRow, startCol, endCol);

    const selectedModeValidation = validateTriangleForMode(
      sheet,
      startRow,
      endRow,
      startCol,
      endCol,
      hasHeaders
    );

    const oppositeModeValidation = validateTriangleForMode(
      sheet,
      startRow,
      endRow,
      startCol,
      endCol,
      !hasHeaders
    );

    if (!selectedModeValidation.isValid && oppositeModeValidation.isValid) {
      setErrorMessage(
        hasHeaders
          ? 'Wybrano tryb "z nagłówkami", ale dane wyglądają na zakres "bez nagłówków". Zmień opcję i kliknij "Wczytaj dane" ponownie.'
          : 'Wybrano tryb "bez nagłówków", ale dane wyglądają na zakres "z nagłówkami". Zmień opcję i kliknij "Wczytaj dane" ponownie.'
      );
      setShowErrorDialog(true);
      return;
    }

    if (!selectedModeValidation.isValid) {
      setErrorMessage(selectedModeValidation.error || 'Wybrany zakres danych jest nieprawidłowy.');
      setShowErrorDialog(true);
      return;
    }

    const {
      dataStartRow,
      dataStartCol,
      dataEndRow,
      dataEndCol,
    } = selectedModeValidation;

    const outputEndRow = hasHeaders ? dataEndRow : dataEndRow + 1;
    const outputEndCol = hasHeaders ? dataEndCol : dataEndCol + 1;
    
    // Odczytaj dane z formatowaniem przez ExcelJS
    const result: any[][] = [];
    const headers: string[] = [];
    const rows: string[] = [];

    if (hasHeaders) {
      const headerRow = sheet.getRow(startRow);
      const topLeftCell = headerRow.getCell(startCol);
      const topLeftValue = getCellDisplayValue(topLeftCell.value);

      for (let col = startCol + 1; col <= endCol; col++) {
        const headerCell = headerRow.getCell(col);
        const headerValue = getCellDisplayValue(headerCell.value);
        headers.push(headerValue || String(col - startCol));
      }

      for (let row = startRow + 1; row <= endRow; row++) {
        const rowHeaderCell = sheet.getRow(row).getCell(startCol);
        const rowHeaderValue = getCellDisplayValue(rowHeaderCell.value);
        rows.push(rowHeaderValue || String(row - startRow));
      }

      setTopLeftHeader(topLeftValue || '');
    } else {
      for (let col = dataStartCol; col <= outputEndCol; col++) {
        const isExtraPaddingCol = col === outputEndCol;
        headers.push(isExtraPaddingCol ? '' : String(col - dataStartCol + 1));
      }

      for (let row = dataStartRow; row <= outputEndRow; row++) {
        const isExtraPaddingRow = row === outputEndRow;
        rows.push(isExtraPaddingRow ? '' : String(row - dataStartRow + 1));
      }

      setTopLeftHeader('');
    }

    setColumnHeaders(headers);
    setRowHeaders(rows);

    for (let row = dataStartRow; row <= outputEndRow; row++) {
      const rowData: any[] = [];
      
      for (let col = dataStartCol; col <= outputEndCol; col++) {
        const isExtraPaddingCell = !hasHeaders && (row === outputEndRow || col === outputEndCol);
        const cell = sheet.getRow(row).getCell(col);
        const value = isExtraPaddingCell ? '' : (cell.value ?? null);
        
        // Odczytaj formatowanie
        const formatting: any = {};
        
        if (!isExtraPaddingCell && cell.font?.strike) {
          formatting.isStrikethrough = true;
        }
        
        if (!isExtraPaddingCell && cell.font?.color) {
          const fontColor = cell.font.color;
          if (fontColor.argb) {
            formatting.fontColor = `#${fontColor.argb.substring(2)}`;
          } else if (fontColor.theme !== undefined) {
            formatting.fontColor = `theme-${fontColor.theme}`;
          }
        }
        
        if (!isExtraPaddingCell && cell.fill && 'fgColor' in cell.fill) {
          const bgColor = (cell.fill as any).fgColor;
          if (bgColor && typeof bgColor === 'object' && 'argb' in bgColor) {
            formatting.backgroundColor = `#${bgColor.argb.substring(2)}`;
          }
        }
        
        rowData.push({
          value,
          formatting: Object.keys(formatting).length > 0 ? formatting : undefined
        });
      }
      
      result.push(rowData);
    }
    
    // Generuj cl_initial: 0 gdzie przekreślenie, 1 gdzie normalne/puste
    const cl_initialMatrix: number[][] = [];
    for (let row = dataStartRow; row <= outputEndRow; row++) {
      const clRow: number[] = [];
      for (let col = dataStartCol; col <= outputEndCol; col++) {
        const isExtraPaddingCell = !hasHeaders && (row === outputEndRow || col === outputEndCol);
        if (isExtraPaddingCell) {
          clRow.push(1);
          continue;
        }
        const cell = sheet.getRow(row).getCell(col);
        const isStrikethrough = cell.font?.strike === true;
        clRow.push(isStrikethrough ? 0 : 1);
      }
      cl_initialMatrix.push(clRow);
    }
    
    setClInitial(cl_initialMatrix);
    setTestData(result);
    console.log('📊 Dane wczytane (wierszy):', result.length);
    console.log('🔢 cl_initial (wierszy):', cl_initialMatrix.length, 'x', cl_initialMatrix[0]?.length || 0);    
    // Pokaż komunikat sukcesu
    setShowSuccessDialog(true);
  };

  // Funkcja do zamykania z animacją
  const handleCloseFullscreen = () => {
    setIsClosing(true);
    // Opóźnienie zamknięcia o czas trwania animacji
    setTimeout(() => {
      setFullscreenMode(false);
      setIsClosing(false);
    }, 300); // 300ms - szybsze zamykanie
  };
  
  return (
    <div>
      <form onSubmit={handleSubmit(onSubmit)} className="p-4 border rounded flex flex-col gap-4">
        <Card className="bg-slate-800 border border-slate-700 shadow-2xl">
          <CardHeader>
            <CardTitle className="text-white font-bold text-sm mb-4 pb-2 border-b-2 border-gray-700">
              Wprowadż dane współczynników rok do roku
            </CardTitle>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {/* SEKCJA 1: Plik i arkusz */}
            <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-600">
              <Label className="text-white text-sm mb-3 block">Wybór pliku i arkusza</Label>
              
              <div className="flex items-center gap-4 mb-4">
                <input
                  type="file"
                  accept=".xlsx,.xls"
                  className="bg-slate-700 border border-slate-600 text-white p-2 rounded-lg file:bg-slate-600 file:border-none file:text-white file:rounded file:px-3 file:py-1 file:mr-2"
                  {...register('file')}
                />
                <button
                  type="button"
                  onClick={handleFileLoad}
                  disabled={!file || file.length === 0 || isLoading}
                  className="py-2 px-4 bg-gradient-to-br from-emerald-600 to-emerald-500 hover:from-emerald-700 hover:to-emerald-600 text-white rounded-xl font-bold shadow-lg hover:shadow-2xl hover:scale-[1.02] transform transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="inline w-4 h-4 mr-2 animate-spin" />
                      Ładowanie...
                    </>
                  ) : (
                    'Załaduj plik'
                  )}
                </button>
                {uploadedFileName && (
                  <span className="text-sm text-green-400 ml-2">
                    Wczytano: <strong>{uploadedFileName}</strong>
                  </span>
                )}
              </div>

              <div>
                <Label className="text-white text-sm">Wybór arkusza</Label>
                <SheetSelectTest />
              </div>
            </div>

            {/* SEKCJA 2: Wybór trybu zakresu */}
            <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-600">
              <Label className="text-white text-sm mb-3 block">Sposób podawania zakresu</Label>
              <div className="flex gap-8 mb-4">
                <div className="flex items-center space-x-3">
                  <input
                    type="radio"
                    id="numeric-mode"
                    checked={currentRangeMode === 'numeric'}
                    onChange={() => {
                      setValue('rangeMode', 'numeric');
                      setStoredRangeMode('numeric');
                    }}
                    className="text-emerald-500 focus:ring-emerald-400 w-4 h-4"
                  />
                  <Label htmlFor="numeric-mode" className="text-white text-sm font-medium cursor-pointer">
                    🔢 Numeryczny (wiersze/kolumny)
                  </Label>
                </div>
                <div className="flex items-center space-x-3">
                  <input
                    type="radio"
                    id="excel-mode"
                    checked={currentRangeMode === 'excel'}
                    onChange={() => {
                      setValue('rangeMode', 'excel');
                      setStoredRangeMode('excel');
                    }}
                    className="text-emerald-500 focus:ring-emerald-400 w-4 h-4"
                  />
                  <Label htmlFor="excel-mode" className="text-white text-sm font-medium cursor-pointer">
                    📊 Excel (A1:Z99)
                  </Label>
                </div>
              </div>

              <div className="mt-6">
                {currentRangeMode === 'numeric' && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-white text-sm">Wiersz początkowy</Label>
                      <Input
                        type="number"
                        placeholder="np. 2"
                        disabled={!workbook}
                        {...register('rowStart')}
                        className="mt-1"
                      />
                      {errors.rowStart && (
                        <p className="text-red-400 text-xs mt-1">{errors.rowStart.message}</p>
                      )}
                    </div>
                    <div>
                      <Label className="text-white text-sm">Wiersz końcowy</Label>
                      <Input
                        type="number"
                        placeholder="np. 11"
                        disabled={!workbook}
                        {...register('rowEnd')}
                        className="mt-1"
                      />
                      {errors.rowEnd && (
                        <p className="text-red-400 text-xs mt-1">{errors.rowEnd.message}</p>
                      )}
                    </div>
                    <div>
                      <Label className="text-white text-sm">Kolumna początkowa</Label>
                      <Input
                        type="number"
                        placeholder="np. 2"
                        disabled={!workbook}
                        {...register('colStart')}
                        className="mt-1"
                      />
                      {errors.colStart && (
                        <p className="text-red-400 text-xs mt-1">{errors.colStart.message}</p>
                      )}
                    </div>
                    <div>
                      <Label className="text-white text-sm">Kolumna końcowa</Label>
                      <Input
                        type="number"
                        placeholder="np. 11"
                        disabled={!workbook}
                        {...register('colEnd')}
                        className="mt-1"
                      />
                      {errors.colEnd && (
                        <p className="text-red-400 text-xs mt-1">{errors.colEnd.message}</p>
                      )}
                    </div>
                  </div>
                )}

                {currentRangeMode === 'excel' && (
                  <div className="flex items-end gap-4">
                    <div className="flex-1">
                      <Label className="text-white text-sm">Od komórki</Label>
                      <Input
                        type="text"
                        placeholder="A1"
                        disabled={!workbook}
                        {...register('cellStart')}
                        onChange={handleCellStartChange}
                        className="uppercase mt-1 text-center font-mono"
                      />
                      {errors.cellStart && (
                        <p className="text-red-400 text-xs mt-1">{errors.cellStart.message}</p>
                      )}
                    </div>
                    <div className="text-emerald-400 font-bold text-2xl pb-6">:</div>
                    <div className="flex-1">
                      <Label className="text-white text-sm">Do komórki</Label>
                      <Input
                        type="text"
                        placeholder="Z99"
                        disabled={!workbook}
                        {...register('cellEnd')}
                        onChange={handleCellEndChange}
                        className="uppercase mt-1 text-center font-mono"
                      />
                      {errors.cellEnd && (
                        <p className="text-red-400 text-xs mt-1">{errors.cellEnd.message}</p>
                      )}
                    </div>
                  </div>
                )}

                <div className="mt-4">
                  <Button
                    type="button"
                    onClick={handleAutoRange}
                    variant="outline"
                    disabled={!workbook}
                    className="bg-slate-700 border-slate-600 text-white hover:bg-slate-600 hover:border-slate-500"
                  >
                    Wykryj zakres automatycznie
                  </Button>
                </div>
              </div>
            </div>

            {/* SEKCJA 3: Ustawienia */}
            <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-600">
              <HeadersSelector 
                hasHeaders={hasHeaders} 
                onHeadersChange={setStoredHasHeaders} 
              />
            </div>
          </CardContent>

          <CardFooter>
            <input type="hidden" {...register('rangeMode')} />
            <div className="flex gap-4">
              <button
                type="submit"
                className="py-2 px-4 bg-gradient-to-br from-emerald-600 to-emerald-500 hover:from-emerald-700 hover:to-emerald-600 text-white rounded-xl font-bold shadow-lg hover:shadow-2xl hover:scale-[1.02] transform transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={!workbook}
              >
                Wczytaj dane
              </button>
              
              {testData && testData.length > 0 && (
                <button
                  type="button"
                  onClick={() => setFullscreenMode(true)}
                  className="py-2 px-4 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 text-white rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform flex items-center gap-2"
                >
                  <Maximize2 className="w-4 h-4" />
                  Podgląd danych
                </button>
              )}
            </div>
          </CardFooter>
        </Card>
      </form>

      {/* AlertDialog dla błędów */}
      <AlertDialog open={showErrorDialog} onOpenChange={setShowErrorDialog}>
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center">
            <VisuallyHidden>
              <AlertDialogTitle>Błąd walidacji</AlertDialogTitle>
            </VisuallyHidden>
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-red-100 mb-4">
              <span className="text-red-600 text-2xl">✕</span>
            </div>
            <AlertDialogDescription className="text-center text-base text-red-600 font-medium">
              {errorMessage}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex justify-center">
            <AlertDialogCancel className="bg-slate-700 text-white hover:bg-slate-600">
              OK
            </AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Sukces (zielony) */}
      <AlertDialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
        <AlertDialogContent>
          <AlertDialogHeader className="flex flex-col items-center">
            <VisuallyHidden>
              <AlertDialogTitle>Powiadomienie</AlertDialogTitle>
            </VisuallyHidden>
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-green-100 mb-4">
              <svg
                className="w-6 h-6 text-green-600"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M5 13l4 4L19 7"
                />
              </svg>
            </div>
            <AlertDialogDescription className="text-center text-green-600 font-medium">
              Dane testowe z formatowaniem zostały pomyślnie wczytane!
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>OK</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Spinner podczas ładowania */}
      {isLoading && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-[1px]">
          <div className="bg-[#1e1e2f] rounded-lg p-8 flex flex-col items-center w-80">
            <Loader2 className="animate-spin h-10 w-10 text-white mb-6" />
            <div className="w-full bg-gray-700 rounded-full h-4 mb-4 overflow-hidden">
              <div
                className="bg-gray-300 h-full transition-all duration-300 ease-in-out"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="text-white text-sm font-medium">
              Ładowanie… {progress}%
            </div>
          </div>
        </div>
      )}

      {/* Overlay pełnoekranowy - wyświetla się NAD wszystkim */}
      {fullscreenMode && (
        <div 
          className="fixed inset-0 bg-gray-900 z-50 flex flex-col transition-all duration-300 ease-out"
          style={{
            animation: isClosing ? 'fadeOut 0.2s ease-in forwards' : 'fadeIn 0.3s ease-out'
          }}
        >
          {/* Górny pasek z przyciskiem zamknięcia */}
          <div 
            className="bg-gray-800 p-4 flex justify-between items-center border-b border-gray-700 transition-all duration-300 ease-out"
            style={{
              animation: isClosing 
                ? 'slideOutToTop 0.25s ease-in forwards' 
                : 'slideInFromTop 0.4s ease-out 0.1s both'
            }}
          >
            <h2 className="text-white text-lg font-medium">Podgląd danych wyłączonych współczynników</h2>
            
            <button
              onClick={handleCloseFullscreen}
              className="py-3 px-4 bg-gradient-to-r from-gray-600 to-gray-500 hover:from-gray-700 hover:to-gray-600 text-white rounded-xl font-bold transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform flex items-center gap-2"
            >
              <Minimize2 className="w-4 h-4" />
              Zamknij pełny ekran
            </button>
          </div>
          
          {/* Tabele zajmujące całą dostępną przestrzeń */}
          <div 
            className="flex-1 p-6 bg-gray-900 transition-all duration-500 ease-out overflow-auto"
            style={{
              animation: isClosing 
                ? 'zoomOut 0.3s ease-in forwards'
                : 'zoomIn 0.5s ease-out 0.2s both'
            }}
          >
            <div className="space-y-8">
              {/* Tabela wyników analizy formatowania */}
              {testData && testData.length > 0 && (
                <div className="bg-gradient-to-br from-gray-50 to-white rounded-2xl border border-gray-300 shadow-2xl overflow-hidden">
                  <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400">
                    <h3 className="font-bold text-gray-800 text-lg tracking-tight">
                      Współczynniki wraz z wyłączeniami
                    </h3>
                  </div>
                  <div className="p-4">
                    <div className="overflow-auto">
                      <table className="min-w-full border-collapse">
                        <thead>
                          <tr>
                            {showHeaders && (
                              <th className="border border-gray-300 px-3 py-2 bg-gray-100 text-gray-700 text-sm font-semibold">
                                {topLeftHeader || ' '}
                              </th>
                            )}
                            {testData[0]?.map((_, colIdx) => (
                              <th
                                key={colIdx}
                                className="border border-gray-300 px-3 py-2 bg-gray-100 text-gray-700 text-sm font-semibold"
                              >
                                {columnHeaders[colIdx] || String(colIdx + 1)}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {testData.map((row, rowIdx) => (
                            <tr key={rowIdx}>
                              {showHeaders && (
                                <td className="border border-gray-300 px-3 py-2 text-left bg-gray-50 text-gray-800 font-semibold whitespace-nowrap">
                                  {rowHeaders[rowIdx] || String(rowIdx + 1)}
                                </td>
                              )}
                              {row.map((cell: any, colIdx) => {
                                const isStrikethrough = cell.formatting?.isStrikethrough;

                                return (
                                  <td
                                    key={colIdx}
                                    className="border border-gray-300 px-3 py-2 text-center bg-white text-gray-800"
                                    style={{
                                      textDecoration: isStrikethrough ? 'line-through' : 'none',
                                    }}
                                  >
                                    {cell.value ?? '–'}
                                  </td>
                                );
                              })}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    
                    <div className="mt-4 p-4 bg-gray-100 rounded-lg border border-gray-300">
                      <h4 className="text-gray-800 font-semibold mb-2">Legenda:</h4>
                      <ul className="text-sm text-gray-600 space-y-1">
                        <li><span className="line-through">Przekreślone</span> = komórka z przekreśleniem w Excelu</li>
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              {/* Macierz cl_initial */}
              {cl_initial && cl_initial.length > 0 && (
                <div className="bg-gradient-to-br from-gray-50 to-white rounded-2xl border border-gray-300 shadow-2xl overflow-hidden">
                  <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400">
                    <h3 className="font-bold text-gray-800 text-lg tracking-tight">
                      Macierz Wag
                    </h3>
                    <p className="text-gray-600 text-sm mt-2">
                      0 = komórka przekreślona (wykluczona), 1 = komórka normalna/pusta (uwzględniona)
                    </p>
                  </div>
                  <div className="p-4">
                    <div className="overflow-auto">
                      <table className="min-w-full border-collapse">
                        <thead>
                          <tr>
                            {showHeaders && (
                              <th className="border border-gray-300 px-3 py-2 bg-gray-100 text-gray-700 text-sm font-semibold">
                                {topLeftHeader || ' '}
                              </th>
                            )}
                            {cl_initial[0]?.map((_, colIdx) => (
                              <th
                                key={colIdx}
                                className="border border-gray-300 px-3 py-2 bg-gray-100 text-gray-700 text-sm font-semibold"
                              >
                                {columnHeaders[colIdx] || String(colIdx + 1)}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {cl_initial.map((row, rowIdx) => (
                            <tr key={rowIdx}>
                              {showHeaders && (
                                <td className="border border-gray-300 px-3 py-2 text-left bg-gray-50 text-gray-800 font-semibold whitespace-nowrap">
                                  {rowHeaders[rowIdx] || String(rowIdx + 1)}
                                </td>
                              )}
                              {row.map((value, colIdx) => (
                                <td
                                  key={colIdx}
                                  className={`border border-gray-300 px-3 py-2 text-center font-semibold ${
                                    value === 0 
                                      ? 'bg-red-100 text-red-700' 
                                      : 'bg-green-100 text-green-700'
                                  }`}
                                >
                                  {value}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          {/* Style animacji - otwieranie i zamykanie */}
          <style jsx>{`
            @keyframes fadeIn {
              from {
                opacity: 0;
              }
              to {
                opacity: 1;
              }
            }

            @keyframes fadeOut {
              from {
                opacity: 1;
              }
              to {
                opacity: 0;
              }
            }

            @keyframes slideInFromTop {
              from {
                transform: translateY(-100%);
                opacity: 0;
              }
              to {
                transform: translateY(0);
                opacity: 1;
              }
            }

            @keyframes slideOutToTop {
              from {
                transform: translateY(0);
                opacity: 1;
              }
              to {
                transform: translateY(-100%);
                opacity: 0;
              }
            }

            @keyframes zoomIn {
              from {
                transform: scale(0.9);
                opacity: 0;
              }
              to {
                transform: scale(1);
                opacity: 1;
              }
            }

            @keyframes zoomOut {
              from {
                transform: scale(1);
                opacity: 1;
              }
              to {
                transform: scale(0.9);
                opacity: 0;
              }
            }
          `}</style>
        </div>
      )}
    </div>
  );
}
