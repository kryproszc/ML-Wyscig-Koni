
export type RowData = (string | number)[];
//export type RowData = Record<string, any>;
