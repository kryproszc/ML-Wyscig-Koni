// Test przykład dla funkcji convertIncrementalToCumulative

/*
Przykład użycia:

DANE WEJŚCIOWE (inkrementalne):
[
  ["", "Q1", "Q2", "Q3", "Q4"],      // nagłówek
  ["2020", 100, 50, 30, 20],        // pierwszy wiersz danych
  ["2021", 80, 40, 25, 15]          // drugi wiersz danych
]

DANE WYJŚCIOWE (skumulowane):
[
  ["", "Q1", "Q2", "Q3", "Q4"],      // nagłówek bez zmian
  ["2020", 100, 150, 180, 200],     // 100, 100+50, 150+30, 180+20
  ["2021", 80, 120, 145, 160]       // 80, 80+40, 120+25, 145+15
]

Logika:
- Pierwszy wiersz (indeks 0) to nagłówek - nie zmieniamy
- Pierwsza kolumna to etykiety - nie zmieniamy  
- Każda kolejna kolumna = poprzednia kolumna + bieżąca wartość
- Kolumna[i] = Kolumna[i-1] + OryginalnaWartość[i]
*/

import { convertIncrementalToCumulative } from '../utils/dataConversion';

// Przykładowe dane do testowania
export const testIncrementalData = [
  ["", "Q1", "Q2", "Q3", "Q4"],
  ["2020", 100, 50, 30, 20],
  ["2021", 80, 40, 25, 15],
  ["2022", 90, 45, 35, 25]
];

export const expectedCumulativeData = [
  ["", "Q1", "Q2", "Q3", "Q4"],
  ["2020", 100, 150, 180, 200],  // 100, 100+50, 150+30, 180+20
  ["2021", 80, 120, 145, 160],   // 80, 80+40, 120+25, 145+15  
  ["2022", 90, 135, 170, 195]    // 90, 90+45, 135+35, 170+25
];

// Funkcja testowa - można uruchomić w konsoli przeglądarki
export function testConversion() {
  console.log('🧪 Testowanie konwersji danych...');
  console.log('📥 Dane wejściowe (inkrementalne):', testIncrementalData);
  
  const result = convertIncrementalToCumulative(testIncrementalData);
  
  console.log('📤 Dane wyjściowe (skumulowane):', result);
  console.log('✅ Oczekiwane dane:', expectedCumulativeData);
  
  // Porównanie wyników
  const isCorrect = JSON.stringify(result) === JSON.stringify(expectedCumulativeData);
  console.log(isCorrect ? '✅ Test PASSED' : '❌ Test FAILED');
  
  return { result, expected: expectedCumulativeData, passed: isCorrect };
}
