type ConvertOptions = {
  hasHeaders?: boolean;
};

const parseNumericValue = (value: unknown): number | null => {
  if (value === null || value === undefined) return null;
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (trimmed === '' || trimmed === '-') return null;
    const parsed = Number(trimmed.replace(',', '.'));
    return Number.isFinite(parsed) ? parsed : null;
  }
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : null;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
};

export function convertIncrementalToCumulative(data: any[][], options: ConvertOptions = {}): any[][] {
  const hasHeaders = options.hasHeaders ?? true;
  if (!data || data.length === 0) return data;

  // Kopiujemy dane, żeby nie modyfikować oryginału
  const result = data.map(row => [...row]);

  const rowStartIndex = hasHeaders ? 1 : 0;
  const valueStartIndex = hasHeaders ? 1 : 0;

  // Przetwarzamy każdy wiersz oprócz nagłówka (indeks 0)
  for (let rowIndex = rowStartIndex; rowIndex < result.length; rowIndex++) {
    const row = result[rowIndex];
    if (!row) continue; // Sprawdzenie bezpieczeństwa
    if (row.length <= valueStartIndex) continue;
    
    // Znajdź koniec "schodka" - ostatnią niepustą wartość w wierszu
    let lastNonEmptyIndex = -1;
    for (let i = row.length - 1; i >= valueStartIndex; i--) {
      if (parseNumericValue(row[i]) !== null) {
        lastNonEmptyIndex = i;
        break;
      }
    }

    if (lastNonEmptyIndex < valueStartIndex) continue;

    let runningTotal = parseNumericValue(row[valueStartIndex]);
    if (runningTotal === null) continue;
    
    // Kumuluj tylko do końca schodka i tylko dla rzeczywistych wartości liczbowych
    for (let colIndex = valueStartIndex + 1; colIndex <= lastNonEmptyIndex; colIndex++) {
      const currentValue = parseNumericValue(row[colIndex]);
      if (currentValue === null) {
        break;
      }

      runningTotal += currentValue;
      row[colIndex] = runningTotal;
    }
  }

  return result;
}
