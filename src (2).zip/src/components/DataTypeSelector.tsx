import React from 'react';
import { Label } from '@/components/ui/label';

export type DataType = 'cumulative' | 'incremental';

interface DataTypeSelectorProps {
  dataType: DataType;
  onDataTypeChange: (type: DataType) => void;
}

export const DataTypeSelector: React.FC<DataTypeSelectorProps> = ({
  dataType,
  onDataTypeChange,
}) => {
  return (
    <div className="space-y-3 mt-4">
      <Label className="text-white text-sm">Typ danych</Label>
      <div className="flex flex-col space-y-3">
        <label className="flex items-center space-x-3 cursor-pointer">
          <input
            type="radio"
            name="dataType"
            value="cumulative"
            checked={dataType === 'cumulative'}
            onChange={(e) => onDataTypeChange(e.target.value as DataType)}
            className="w-4 h-4 text-blue-500 bg-gray-700 border-gray-500 focus:ring-blue-400 focus:ring-2"
          />
          <span className="text-sm text-white">
            📊 Skumulowane
          </span>
        </label>
        <label className="flex items-center space-x-3 cursor-pointer">
          <input
            type="radio"
            name="dataType"
            value="incremental"
            checked={dataType === 'incremental'}
            onChange={(e) => onDataTypeChange(e.target.value as DataType)}
            className="w-4 h-4 text-blue-500 bg-gray-700 border-gray-500 focus:ring-blue-400 focus:ring-2"
          />
          <span className="text-sm text-white">
            📈 Inkrementalne
          </span>
        </label>
      </div>
    </div>
  );
};
