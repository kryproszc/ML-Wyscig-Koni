'use client';
import { ChangeEvent } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';

export interface Range { rowStart: number; rowEnd: number; colStart: number; colEnd: number; }

interface Props {
  value: Range;
  onChange: (next: Range) => void;
  onAutoDetect?: () => void;
  disabled?: boolean;
}

export function RangeSelector({ value, onChange, onAutoDetect, disabled }: Props) {
  const set = (k: keyof Range) => (e: ChangeEvent<HTMLInputElement>) =>
    onChange({ ...value, [k]: Number(e.target.value) });

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        {(['rowStart','rowEnd','colStart','colEnd'] as (keyof Range)[]).map((k) => (
          <div key={k}>
            <Label>{k}</Label>
            <Input type="number" value={value[k]} onChange={set(k)} disabled={disabled} />
          </div>
        ))}
      </div>
      {onAutoDetect && (
        <Button
          type="button"
          onClick={onAutoDetect}
          disabled={disabled}
          className="bg-blue-500 text-white"
          variant="outline"
        >
          Wykryj zakres automatycznie
        </Button>
      )}
    </div>
  );
}
