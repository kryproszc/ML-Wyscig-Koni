'use client';

import { useState, useMemo, useEffect, useRef } from 'react';
import type { ChangeEvent } from 'react';
import clsx from 'clsx';
import * as XLSX from 'xlsx';
import Modal from '@/components/Modal';

// ────────────────────────────────────────────
// Types
// ────────────────────────────────────────────

type Row = {
  paid: number;
  incurred: number;
};

type Weight = {
  wPaid: number;
  wInc: number;
};

type EnrichedRow = Row & Weight & { sum: number };

/**
 * Struktura wierszy eksportowanych do Excela (używa etykiet kolumnowych).
 */
interface ExcelRow {
  Paid: number | string;
  'Waga paid': number | string;
  Incurred: number | string;
  'Waga incurred': number | string;
  Sum: number | string;
}

interface Props {
  rows: Row[];
  onChange?: (rows: EnrichedRow[], grandTotal: number) => void;
  /** Opcjonalna nazwa pliku XLSX, domyślnie `weighted_table.xlsx` */
  fileName?: string;
  /** Współczynniki CL do eksportu (np. [3.245785, 3.401558]) */
  clCoefficients?: number[];
  /** Opcjonalny nagłówek sekcji CL, np. 'Paid' lub 'Incurred' */
  clLabel?: string;
}

// ────────────────────────────────────────────
// Component
// ────────────────────────────────────────────

function WeightedTable({
  rows,
  onChange,
  fileName = 'weighted_table.xlsx',
  clCoefficients,
  clLabel,
}: Props) {
  const [weights, setWeights] = useState<Weight[]>(() =>
    rows.map(() => ({ wPaid: 1, wInc: 0 }))
  );

  // Modal do błędów zakresu 0–1
  const [showModal, setShowModal] = useState(false);

  // Używamy useRef do śledzenia poprzednich wartości
  const prevEnrichedRowsRef = useRef<EnrichedRow[]>([]);
  const prevGrandTotalRef = useRef<number>(0);

  // ▸ Synchronizuj długość tablic przy zmianie `rows` - tylko gdy rzeczywiście się zmieniła
  useEffect(() => {
    if (rows.length !== weights.length) {
      setWeights((prev) => rows.map((_, i) => prev[i] ?? { wPaid: 1, wInc: 0 }));
    }
  }, [rows.length, weights.length]);

  // ▸ Zmiana wag z auto-uzupełnianiem komplementu (1 - wpisana_waga)
  const handleWeightChange = (
    rowIdx: number,
    field: keyof Weight,
    e: ChangeEvent<HTMLInputElement>
  ) => {
    const num = parseFloat(e.target.value.replace(',', '.')); // dopuszczamy przecinek

    // walidacja 0–1 i czy liczba
    if (!Number.isFinite(num) || num < 0 || num > 1) {
      setShowModal(true);
      return;
    }

    const comp = +(1 - num).toFixed(4); // komplement z lekkim zaokrągleniem

    setWeights((prev) => {
      const next = [...prev];
      next[rowIdx] =
        field === 'wPaid'
          ? { wPaid: num, wInc: comp }
          : { wPaid: comp, wInc: num };
      return next;
    });
  };

  // ▸ Walidacja wag - sprawdź czy suma wag w każdym wierszu = 1
  const validationErrors = useMemo(() => {
    const errors: Array<{ rowIndex: number; message: string }> = [];
    weights.forEach((weight, index) => {
      const sum = weight.wPaid + weight.wInc;
      if (Math.abs(sum - 1) > 0.001) {
        errors.push({
          rowIndex: index,
          message: 'Suma wag musi być równa 1',
        });
      }
    });
    return errors;
  }, [weights]);

  // ▸ Enrichment + total
  const { enrichedRows, grandTotal } = useMemo(() => {
    const merged: EnrichedRow[] = rows.map((row, i) => {
      const { wPaid, wInc } = weights[i] ?? { wPaid: 1, wInc: 0 };
      const sum = row.paid * wPaid + row.incurred * wInc;
      return { ...row, wPaid, wInc, sum };
    });
    const total = merged.reduce((acc, r) => acc + r.sum, 0);
    return { enrichedRows: merged, grandTotal: total };
  }, [rows, weights]);

  // ▸ Callback do rodzica - tylko gdy wartości rzeczywiście się zmieniają
  useEffect(() => {
    if (!onChange) return;

    const rowsChanged =
      enrichedRows.length !== prevEnrichedRowsRef.current.length ||
      enrichedRows.some((row, index) => {
        const prevRow = prevEnrichedRowsRef.current[index];
        return (
          !prevRow ||
          row.paid !== prevRow.paid ||
          row.incurred !== prevRow.incurred ||
          row.wPaid !== prevRow.wPaid ||
          row.wInc !== prevRow.wInc ||
          row.sum !== prevRow.sum
        );
      });

    const totalChanged = Math.abs(grandTotal - prevGrandTotalRef.current) > 0.001;

    if (rowsChanged || totalChanged) {
      onChange(enrichedRows, grandTotal);
      prevEnrichedRowsRef.current = [...enrichedRows];
      prevGrandTotalRef.current = grandTotal;
    }
  }, [enrichedRows, grandTotal, onChange]);

  // ──────────────────────────────────────
  // Excel export ↓↓↓
  // ──────────────────────────────────────
  const handleExport = () => {
    // 1. Dane → ExcelRow[]
    const data: ExcelRow[] = enrichedRows.map(({ paid, wPaid, incurred, wInc, sum }) => ({
      Paid: paid,
      'Waga paid': wPaid,
      Incurred: incurred,
      'Waga incurred': wInc,
      Sum: sum,
    }));

    // 2. Dodaj wiersz z sumą ważoną
    data.push({ Paid: '', 'Waga paid': '', Incurred: '', 'Waga incurred': 'TOTAL', Sum: grandTotal });

    // 3. Dodaj sekcję "5. Współczynniki CL"
    if (clCoefficients && clCoefficients.length > 0) {
      // Separator
      data.push({ Paid: '', 'Waga paid': '', Incurred: '', 'Waga incurred': '', Sum: '' });
      data.push({
        Paid: `=== 5. Współczynniki CL${clLabel ? ` (${clLabel})` : ''} ===`,
        'Waga paid': '',
        Incurred: '',
        'Waga incurred': '',
        Sum: '',
      });
      data.push({ Paid: 'Indeks', 'Waga paid': '', Incurred: 'Współczynnik', 'Waga incurred': '', Sum: '' });
      clCoefficients.forEach((coef, idx) => {
        data.push({ Paid: `Indeks ${idx + 1}`, 'Waga paid': '', Incurred: coef, 'Waga incurred': '', Sum: '' });
      });
    }

    // 4. SheetJS
    const ws = XLSX.utils.json_to_sheet(data, {
      header: ['Paid', 'Waga paid', 'Incurred', 'Waga incurred', 'Sum'],
    });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'WeightedTable');
    XLSX.writeFile(wb, fileName);
  };

  // ──────────────────────────────────────
  // UI
  // ──────────────────────────────────────
  const TABLE_HEADERS = ['Paid', 'Waga paid', 'Incurred', 'Waga incurred', 'Sum'];

  return (
    <div className="overflow-x-auto rounded-lg shadow-md">
      {/* Modal z komunikatem o błędnych wagach */}
      <Modal
        isOpen={showModal}
        title="Błąd wag"
        message="Wagi muszą być w przedziale 0–1 i sumować się do 1."
        onCancel={() => setShowModal(false)}
        onlyOk
      />

      {/* ▸ Komunikaty błędów walidacji */}
      {validationErrors.length > 0 && (
        <div className="mb-4 p-3 bg-red-900/50 border border-red-600 rounded-lg">
          <div className="text-red-300 text-sm font-semibold mb-2">
            ⚠️ Błędy walidacji wag:
          </div>
          {validationErrors.map((error, index) => (
            <div key={index} className="text-red-200 text-sm">
              • Wiersz {error.rowIndex + 1}: {error.message}
            </div>
          ))}
        </div>
      )}

      {/* ▸ Przycisk eksportu */}
      <div className="flex justify-end mb-2">
        <button
          onClick={handleExport}
          className="px-4 py-2 bg-green-600 hover:bg-green-700 rounded font-semibold transition"
        >
          ⬇️ Eksportuj Excel
        </button>
      </div>

      <table className="min-w-full border-collapse border border-gray-700 rounded-lg">
        <thead className="bg-gray-800 text-gray-300 uppercase text-xs tracking-wider divide-x divide-gray-700">
          <tr>
            {TABLE_HEADERS.map((h) => (
              <th
                key={h}
                scope="col"
                className="px-4 py-2 text-center border border-gray-700"
              >
                {h}
              </th>
            ))}
          </tr>
        </thead>

        <tbody className="divide-y divide-gray-700">
          {enrichedRows.map((row, i) => {
            const hasError = validationErrors.some((err) => err.rowIndex === i);
            return (
              <tr
                key={i}
                className={clsx(
                  i % 2 ? 'bg-gray-700/40' : 'bg-gray-700/20',
                  'hover:bg-gray-600/40 transition-colors',
                  hasError && 'bg-red-900/20 border-red-600'
                )}
              >
                {/* Paid */}
                <td className="px-4 py-2 text-right tabular-nums border border-gray-700">
                  {row.paid.toLocaleString()}
                </td>

                {/* Waga paid */}
                <td className="px-4 py-2 border border-gray-700">
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    max={1}
                    value={row.wPaid}
                    onChange={(e) => handleWeightChange(i, 'wPaid', e)}
                    className={clsx(
                      'w-24 bg-gray-800 rounded px-2 py-1 text-right border focus:outline-none focus:ring-1',
                      hasError ? 'border-red-500 focus:ring-red-500' : 'border-gray-600 focus:ring-blue-500'
                    )}
                  />
                </td>

                {/* Incurred */}
                <td className="px-4 py-2 text-right tabular-nums border border-gray-700">
                  {row.incurred.toLocaleString()}
                </td>

                {/* Waga incurred */}
                <td className="px-4 py-2 border border-gray-700">
                  <input
                    type="number"
                    step="0.01"
                    min={0}
                    max={1}
                    value={row.wInc}
                    onChange={(e) => handleWeightChange(i, 'wInc', e)}
                    className={clsx(
                      'w-24 bg-gray-800 rounded px-2 py-1 text-right border focus:outline-none focus:ring-1',
                      hasError ? 'border-red-500 focus:ring-red-500' : 'border-gray-600 focus:ring-blue-500'
                    )}
                  />
                </td>

                {/* Sum */}
                <td className="px-4 py-2 text-right tabular-nums font-semibold border border-gray-700">
                  {row.sum.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                </td>
              </tr>
            );
          })}
        </tbody>

        <tfoot>
          <tr className="bg-gray-800 text-gray-300 font-semibold border-t border-gray-700">
            <td colSpan={4} className="px-4 py-2 text-right border border-gray-700">
              Suma ważona
            </td>
            <td className="px-4 py-2 text-right tabular-nums border border-gray-700">
              {grandTotal.toLocaleString(undefined, { maximumFractionDigits: 2 })}
            </td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
}

export default WeightedTable;
