import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { SheetSelect } from '@/components/SheetSelect';
import { DataTypeSelector, type DataType } from '@/components/DataTypeSelector';
import { TriangleTypeSelector, type TriangleType } from '@/components/TriangleTypeSelector';
import { HeadersSelector } from '@/components/HeadersSelector';
import type { UseFormRegister } from 'react-hook-form';

interface FormField {
  rowStart: number;
  rowEnd: number;
  colStart: number;
  colEnd: number;
  file?: any;
}
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  CardFooter,
} from "@/components/ui/card";
interface FileUploadSectionProps {
  register: UseFormRegister<FormField>;
  onFileLoad: () => void;
  hasFile: boolean;
  uploadedFileName?: string;
  sheetSelectComponent?: React.ReactNode;
}

export const FileUploadSection: React.FC<FileUploadSectionProps> = ({
  register,
  onFileLoad,
  hasFile,
  uploadedFileName,
  sheetSelectComponent,
}) => {
  return (
    <>
      <div className="flex items-center gap-4">
        <input
          type="file"
          accept=".xlsx, .xls"
          className="border p-2 rounded-lg"
          {...register("file")}
        />
        <Button
          type="button"
          onClick={onFileLoad}
          disabled={!hasFile}
          className="bg-blue-500 text-white"
        >
          Załaduj plik
        </Button>
        {uploadedFileName && (
          <span className="text-sm text-green-400 ml-2">
            Wczytano: <strong>{uploadedFileName}</strong>
          </span>
        )}
      </div>
      <div>
        <Label>Wybór arkusza</Label>
        {sheetSelectComponent || <SheetSelect />}
      </div>
    </>
  );
};

interface RangeInputSectionProps {
  register: UseFormRegister<FormField>;
  onAutoRange: () => void;
  workbookExists: boolean;
  dataType: DataType;
  onDataTypeChange: (type: DataType) => void;
  triangleType: TriangleType;
  onTriangleTypeChange: (type: TriangleType) => void;
  hasHeaders: boolean;
  onHeadersChange: (hasHeaders: boolean) => void;
}

export const RangeInputSection: React.FC<RangeInputSectionProps> = ({
  register,
  onAutoRange,
  workbookExists,
  dataType,
  onDataTypeChange,
  triangleType,
  onTriangleTypeChange,
  hasHeaders,
  onHeadersChange,
}) => {
  return (
    <>
      <TriangleTypeSelector 
        triangleType={triangleType} 
        onTriangleTypeChange={onTriangleTypeChange} 
      />
      <HeadersSelector 
        hasHeaders={hasHeaders} 
        onHeadersChange={onHeadersChange} 
      />
                <CardHeader>
            <CardTitle> Podaj zakres danych, które chcesz wczytać.</CardTitle>
          </CardHeader>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Wiersz początkowy</Label>
          <Input type="number" disabled={!workbookExists} {...register("rowStart")} />
        </div>
        <div>
          <Label>Wiersz końcowy</Label>
          <Input type="number" disabled={!workbookExists} {...register("rowEnd")} />
        </div>
        <div>
          <Label>Kolumna początkowa</Label>
          <Input type="number" disabled={!workbookExists} {...register("colStart")} />
        </div>
        <div>
          <Label>Kolumna końcowa</Label>
          <Input type="number" disabled={!workbookExists} {...register("colEnd")} />
        </div>
      </div>
      <Button
        type="button"
        onClick={onAutoRange}
        variant="outline"
        disabled={!workbookExists}
        className="bg-blue-500 text-white"
      >
        Wykryj zakres automatycznie
      </Button>
      <DataTypeSelector dataType={dataType} onDataTypeChange={onDataTypeChange} />
    </>
  );
};
