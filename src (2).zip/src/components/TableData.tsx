import type { RowData } from '@/types/table';

interface Props {
  data: RowData[];
  selected?: RowData[];
  onClick?: (x: number, y: number) => void;
  variant?: 'dark' | 'light';
  decimals?: number;
}

export function TableData({ data, selected, onClick, variant = 'dark', decimals = 0 }: Props) {
  const isLight = variant === 'light';
  
  return (
    <div className={`rounded-2xl ${isLight ? 'border border-gray-300' : 'border border-slate-700'}`}>
      <table className="min-w-full table-auto" style={{ minWidth: 'max-content', borderCollapse: 'separate', borderSpacing: 0 }}>
        <tbody className={`text-sm ${isLight ? 'text-gray-900' : 'text-slate-200'}`}>
          {data.map((row, i) => {
            const isFirstRow = i === 0;
            const isLastRow = i === data.length - 1;
            
            return (
            <tr
              key={i}
              className={`transition-colors duration-200 ${isLight ? 'hover:bg-gray-100/50' : 'hover:bg-slate-800/30'}`}
            >
              {row.map((cell, j) => {
                const isAY = j === 0;
                const isHeader = i === 0;
                const isEmpty = cell === null || cell === undefined || cell === '' || cell === '-';
                const isSelected = !isEmpty && selected?.[i]?.[j] === 1;
                const isFirstCol = j === 0;
                const isLastCol = j === row.length - 1;

                // Zaokrąglone rogi
                const cornerRadius = 
                  isFirstRow && isFirstCol ? 'rounded-tl-xl' :
                  isFirstRow && isLastCol ? 'rounded-tr-xl' :
                  isLastRow && isFirstCol ? 'rounded-bl-xl' :
                  isLastRow && isLastCol ? 'rounded-br-xl' :
                  '';

                const content =
                  typeof cell === 'number'
                    ? new Intl.NumberFormat('pl-PL', { 
                        minimumFractionDigits: decimals,
                        maximumFractionDigits: decimals 
                      }).format(cell)
                    : isEmpty
                    ? '-'
                    : cell;

                const lightStyles = isHeader
                  ? "bg-gray-200 text-gray-900 font-semibold"
                  : isAY
                  ? "bg-gray-200 font-bold text-gray-700"
                  : isEmpty
                  ? "bg-gray-200 text-gray-500"
                  : selected === undefined
                  ? "bg-white text-gray-900"
                  : isSelected
                  ? "bg-white text-gray-900"
                  : "bg-gray-300 text-gray-500";

                const darkStyles = isHeader
                  ? "bg-slate-800 text-white font-semibold"
                  : isAY
                  ? "bg-slate-800 font-bold text-slate-400"
                  : isEmpty
                  ? "bg-slate-700 text-slate-500"
                  : isSelected
                  ? "bg-indigo-700 border border-indigo-500 shadow-inner"
                  : "bg-slate-800/90";

                const borderStyles = isEmpty && !isHeader && !isAY
                  ? "border-transparent"
                  : isLight 
                  ? "border-gray-300" 
                  : "border-slate-600";

                return (
                    <td
                      key={j}
                      className={`px-4 py-2 border ${borderStyles} ${cornerRadius} whitespace-nowrap transition-colors duration-200
                        ${isLight ? lightStyles : darkStyles}
                        cursor-pointer
                      `}
                      onClick={() => onClick?.(i, j)}
                    >
                      {content}
                    </td>
                );
              })}
            </tr>
          )})}
        </tbody>
      </table>
    </div>
  );
}
