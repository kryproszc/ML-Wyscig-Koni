import React from "react";

export type CorRowData = (string | number | null)[];

interface Props {
  data: CorRowData[];
}

export function TableDataCor({ data }: Props) {
  return (
    <div className="overflow-auto rounded-xl border border-gray-300 shadow-md">
      <table className="min-w-full table-auto border-collapse">
        <tbody className="text-sm text-gray-800">
          {data.map((row, i) => (
            <tr key={i} className="hover:bg-gray-50 transition-colors duration-200">
              {row.map((cell, j) => {
                const isAY = j === 0;
                const isEmpty = cell === null || cell === undefined || cell === '' || cell === '-';

                const content =
                  typeof cell === 'number'
                    ? new Intl.NumberFormat('pl-PL', { maximumFractionDigits: 6 }).format(cell)
                    : isEmpty
                    ? '-'
                    : String(cell);

                return (
                  <td
                    key={j}
                    className={`px-4 py-2 border border-gray-300 whitespace-nowrap transition-colors duration-200 font-mono
                      ${
                        isAY
                          ? "bg-gray-100 font-bold text-gray-800"
                          : "bg-white text-gray-800"
                      }
                    `}
                  >
                    {content}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
