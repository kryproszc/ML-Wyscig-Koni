import React from 'react';
import { Label } from '@/components/ui/label';

export type TriangleType = 'paid' | 'incurred';

interface TriangleTypeSelectorProps {
  triangleType: TriangleType;
  onTriangleTypeChange: (type: TriangleType) => void;
}

export const TriangleTypeSelector: React.FC<TriangleTypeSelectorProps> = ({
  triangleType,
  onTriangleTypeChange,
}) => {
  return (
    <div className="space-y-3">
      <Label className="text-base font-medium">Jaki trójkąt został wczytany?</Label>
      <div className="flex gap-6">
        <div className="flex items-center space-x-2">
          <input
            type="radio"
            id="paid"
            name="triangleType"
            value="paid"
            checked={triangleType === 'paid'}
            onChange={() => onTriangleTypeChange('paid')}
            className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500"
          />
          <Label htmlFor="paid" className="cursor-pointer">
            Paid
          </Label>
        </div>
        <div className="flex items-center space-x-2">
          <input
            type="radio"
            id="incurred"
            name="triangleType"
            value="incurred"
            checked={triangleType === 'incurred'}
            onChange={() => onTriangleTypeChange('incurred')}
            className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500"
          />
          <Label htmlFor="incurred" className="cursor-pointer">
            Incurred
          </Label>
        </div>
      </div>
    </div>
  );
};
