import React from 'react';
import { Label } from '@/components/ui/label';

export type TriangleType = 'paid' | 'incurred';

interface TriangleTypeSelectorProps {
  triangleType: TriangleType;
  onTriangleTypeChange: (type: TriangleType) => void;
}

export const TriangleTypeSelector: React.FC<TriangleTypeSelectorProps> = ({
  triangleType,
  onTriangleTypeChange,
}) => {
  return (
    <div className="space-y-3">
      <Label className="text-white text-sm">Jaki trójkąt został wczytany?</Label>
      <div className="flex gap-8">
        <div className="flex items-center space-x-3">
          <input
            type="radio"
            id="paid"
            name="triangleType"
            value="paid"
            checked={triangleType === 'paid'}
            onChange={() => onTriangleTypeChange('paid')}
            className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 focus:ring-blue-500"
          />
          <Label htmlFor="paid" className="text-white text-sm cursor-pointer">
            Paid
          </Label>
        </div>
        <div className="flex items-center space-x-3">
          <input
            type="radio"
            id="incurred"
            name="triangleType"
            value="incurred"
            checked={triangleType === 'incurred'}
            onChange={() => onTriangleTypeChange('incurred')}
            className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 focus:ring-blue-500"
          />
          <Label htmlFor="incurred" className="text-white text-sm cursor-pointer">
            Incurred
          </Label>
        </div>
      </div>
    </div>
  );
};
