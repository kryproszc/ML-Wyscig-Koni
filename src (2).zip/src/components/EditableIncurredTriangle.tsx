'use client';


import React, { useState, useEffect, useImperativeHandle, forwardRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import Modal from '@/components/Modal';
import { useTrainDevideStoreDetIncurred } from '@/stores/trainDevideStoreDeterministycznyIncurred';
import { useLabelsStore } from '@/stores/useLabelsStore';

// 🎨 Funkcja formatowania liczb z separatorami tysięcy (spacje)
const formatNumber = (value: number | null): string => {
  if (value === null || value === undefined) return '';
  if (!Number.isFinite(value)) return '';
  
  return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
};

// 🔢 Funkcja parsowania sformatowanej liczby
const parseFormattedNumber = (formattedValue: string): number | null => {
  if (!formattedValue || formattedValue.trim() === '') return null;
  
  const numericValue = formattedValue.replace(/\s/g, '');
  const parsed = Number(numericValue);
  
  return Number.isFinite(parsed) ? parsed : null;
};

type EditableIncurredTriangleProps = {
  onSave?: (editedData: (number | null)[][]) => void;
  onCancel?: () => void;
  onFinalSave?: (editedData: (number | null)[][]) => void; // Zapis do store przy zamknięciu
  hasExistingCalculations?: () => boolean; // Sprawdzanie obliczeń
};

export const EditableIncurredTriangle = forwardRef<
  { handleClose: () => void },
  EditableIncurredTriangleProps
>(({ onSave, onCancel, onFinalSave, hasExistingCalculations }, ref) => {
  // Store data
  const incurredTriangle = useTrainDevideStoreDetIncurred((s) => s.incurredTriangle);
  const incurredRowLabels = useLabelsStore((s) => s.incurredRowLabels);
  const incurredColumnLabels = useLabelsStore((s) => s.incurredColumnLabels);

  // Local state
  const [editableData, setEditableData] = useState<(number | null)[][]>([]);
  const [originalData, setOriginalData] = useState<(number | null)[][]>([]);
  const [hasChanges, setHasChanges] = useState(false);
  const [showCloseWarning, setShowCloseWarning] = useState(false);
  const [showCalculationsWarning, setShowCalculationsWarning] = useState(false);

  // Initialize data from store
  useEffect(() => {
    if (incurredTriangle && incurredTriangle.length > 0) {
      console.log('🔄 [EditableIncurredTriangle] Inicjalizuję dane z incurredTriangle:', incurredTriangle.length, 'wierszy');
      
      const dataCopy = incurredTriangle.map(row => [...row]);
      setEditableData(dataCopy);
      setOriginalData(dataCopy.map(row => [...row])); // Deep copy for comparison
      setHasChanges(false);
    }
  }, [incurredTriangle]);

  // Handle cell value change
  const handleCellChange = (rowIndex: number, colIndex: number, value: string) => {
    // Check if cell is below diagonal (shouldn't be editable)
    const isBelowDiagonal = rowIndex + colIndex >= editableData.length;
    if (isBelowDiagonal) {
      console.log('⚠️ Próba edycji komórki pod przekątną - zablokowana');
      return;
    }

    // Parse the value
    const parsedValue = value === '' ? null : parseFormattedNumber(value);
    
    // Validate
    if (value !== '' && parsedValue === null) {
      console.log('❌ Nieprawidłowa wartość:', value);
      return; // Invalid value, don't update
    }

    console.log(`🔄 Zmieniam komórkę [${rowIndex},${colIndex}] na:`, parsedValue);

    // Update the data
    const newData = [...editableData];
    if (newData[rowIndex]) {
      newData[rowIndex] = [...newData[rowIndex]];
      newData[rowIndex][colIndex] = parsedValue;
    }
    
    setEditableData(newData);
    
    // Check if there are changes
    const hasAnyChanges = newData.some((row, rIdx) => 
      row.some((cell, cIdx) => {
        const isBelowDiag = rIdx + cIdx >= newData.length;
        if (isBelowDiag) return false;
        return cell !== originalData[rIdx]?.[cIdx];
      })
    );
    
    setHasChanges(hasAnyChanges);
  };

  // Save changes locally (not to store yet)
  const handleSave = () => {
    console.log('💾 [EditableIncurredTriangle] Zapisuję zmiany LOKALNIE (nie do store jeszcze):', editableData);
    
    // Reset change tracking - zmiany są "zapisane" lokalnie
    setOriginalData(editableData.map(row => [...row]));
    setHasChanges(false);
  };

  // Handle close attempt
  const handleClose = () => {
    if (hasChanges) {
      // Są niezapisane zmiany lokalnie
      console.log('⚠️ [EditableIncurredTriangle] Użytkownik próbuje zamknąć z niezapisanymi zmianami lokalnie');
      setShowCloseWarning(true);
      return;
    }
    
    // 🆕 NOWA LOGIKA: Sprawdź czy dane różnią się od oryginalnych z store (incurredTriangle)
    const hasAnyChangesFromStore = editableData.some((row, rIdx) => 
      row.some((cell, cIdx) => {
        const isBelowDiag = rIdx + cIdx >= editableData.length;
        if (isBelowDiag) return false;
        return cell !== incurredTriangle?.[rIdx]?.[cIdx];
      })
    );
    
    if (!hasAnyChangesFromStore) {
      // 1. BRAK ZMIAN - zamknij bez modalów
      console.log('✅ [EditableIncurredTriangle] BRAK ZMIAN - zamykam bez modalów');
      if (onCancel) {
        onCancel();
      }
      return;
    }
    
    // 2. UŻYTKOWNIK DOKONAŁ ZMIAN - sprawdź czy istnieją obliczenia
    console.log('🔍 [EditableIncurredTriangle] Użytkownik dokonał zmian - sprawdzam obliczenia');
    const hasCalculations = hasExistingCalculations ? hasExistingCalculations() : false;
    
    if (hasCalculations) {
      // 2.1 ISTNIEJĄ OBLICZENIA - pokaż modal ostrzeżenia
      console.log('⚠️ [EditableIncurredTriangle] Istnieją obliczenia - pokazuję modal ostrzeżenia');
      setShowCalculationsWarning(true);
    } else {
      // 2.2 BRAK OBLICZEŃ - zapisz zmiany i zamknij
      console.log('✅ [EditableIncurredTriangle] Brak obliczeń - zapisuję zmiany i zamykam');
      if (onFinalSave) {
        onFinalSave(editableData);
      }
      // Modal zostanie zamknięty przez onFinalSave w rodzicu
    }
  };

  // Expose handleClose to parent
  useImperativeHandle(ref, () => ({
    handleClose
  }));

  // Confirm close without saving
  const handleConfirmClose = () => {
    console.log('🚫 [EditableIncurredTriangle] Potwierdzono zamknięcie bez zapisywania');
    setShowCloseWarning(false);
    
    // Restore original data before closing
    setEditableData(originalData.map(row => [...row]));
    setHasChanges(false);
    
    if (onCancel) {
      onCancel();
    }
  };

  // Cancel close warning
  const handleCancelClose = () => {
    console.log('🔄 [EditableIncurredTriangle] Anulowano zamknięcie - kontynuowanie edycji');
    setShowCloseWarning(false);
  };

  // Confirm close and save to store (this will trigger calculations warning in parent)
  const handleConfirmCloseAndSave = () => {
    console.log('✅ [EditableIncurredTriangle] Potwierdzono zamknięcie - zapisuję do store');
    setShowCalculationsWarning(false);
    
    // Zapisz dane do store (do analizy)
    if (onFinalSave) {
      onFinalSave(editableData);
    }
    
    // Zamknij modal
    if (onCancel) {
      onCancel();
    }
  };

  // Cancel calculations warning
  const handleCancelCalculationsWarning = () => {
    console.log('🔄 [EditableIncurredTriangle] Anulowano - pozostają przy obecnych danych');
    setShowCalculationsWarning(false);
  };

  // Count modified cells
  const modifiedCellsCount = editableData.reduce((count, row, rowIndex) => {
    if (!row) return count;
    return count + row.reduce((rowCount: number, cell, colIndex) => {
      const isBelowDiagonal = rowIndex + colIndex >= editableData.length;
      if (isBelowDiagonal) return rowCount;
      
      const originalValue = originalData[rowIndex]?.[colIndex];
      return originalValue !== cell ? rowCount + 1 : rowCount;
    }, 0);
  }, 0);

  // If no data, show message
  if (!editableData || editableData.length === 0) {
    return (
      <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white">
        <div className="p-4">
          <p className="text-gray-600">Brak danych trójkąta incurred do edycji. Najpierw wczytaj dane.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white">
      <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-gray-800 text-lg tracking-tight">✏️ Edycja trójkąta danych incurred</h3>
          <div className="flex gap-2">
            {hasChanges && (
              <button 
                onClick={handleSave}
                className="py-3 px-4 bg-gradient-to-br from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 text-white rounded-xl font-bold shadow-lg hover:shadow-2xl hover:scale-[1.02] transform transition-all duration-200"
              >
                ✅ Zapisz zmiany
              </button>
            )}
          </div>
        </div>
      </div>
      
      <div className="p-4">
        {hasChanges && (
          <div className="mb-4 p-3 bg-gradient-to-r from-yellow-50 to-orange-50 border-2 border-yellow-400 rounded-xl text-yellow-900 text-sm shadow-md">
            ⚠️ <strong>Masz {modifiedCellsCount} niezapisanych zmian.</strong> 
            Zmodyfikowane komórki są podświetlone na pomarańczowo. 
            Kliknij "✅ Zapisz zmiany" aby je zachować.
          </div>
        )}
        
        <div className="overflow-auto border-2 border-gray-300 rounded-xl shadow-lg max-h-[calc(100vh-200px)]">
          <table className="min-w-full text-sm text-gray-800" style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
            <thead className="sticky top-0 z-20">
              <tr>
                <th className="bg-gradient-to-r from-gray-100 to-gray-50 px-3 py-2 font-semibold text-left border-b-2 border-r border-gray-300 sticky left-0 z-30">
                  AY
                </th>
                {incurredColumnLabels.map((colLabel, colIndex) => (
                  <th 
                    key={colIndex} 
                    className="bg-gradient-to-r from-gray-100 to-gray-50 px-3 py-2 font-semibold text-center border-b-2 border-r border-gray-300 min-w-[120px] last:border-r-0"
                  >
                    {colLabel}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {editableData.map((row, rowIndex) => (
                <tr key={rowIndex}>
                  <td className="bg-gray-50 px-3 py-2 text-left text-gray-700 font-medium border-b border-r border-gray-300 sticky left-0 z-10">
                    {incurredRowLabels[rowIndex] || `${1981 + rowIndex}`}
                  </td>
                  {row.map((cell, colIndex) => {
                    const isBelowDiagonal = rowIndex + colIndex >= editableData.length;
                    
                    return (
                      <td key={colIndex} className={`border-b border-r border-gray-300 p-0 last:border-r-0 ${isBelowDiagonal ? 'bg-gray-100' : 'bg-white'}`}>
                        {isBelowDiagonal ? (
                          <div className="px-3 py-2 text-center text-gray-400">-</div>
                        ) : (() => {
                          // Check if cell is modified
                          const originalValue = originalData[rowIndex]?.[colIndex];
                          const currentValue = cell;
                          const isModified = originalValue !== currentValue;
                          
                          return (
                            <input
                              type="text"
                              value={formatNumber(cell)}
                              onChange={(e) => handleCellChange(rowIndex, colIndex, e.target.value)}
                              className={`w-full px-3 py-2 text-center text-sm border-0 outline-0 focus:text-gray-900 transition-colors focus:ring-2 focus:ring-blue-400 ${
                                isModified 
                                  ? 'bg-orange-100 text-orange-900 focus:bg-orange-50' 
                                  : 'bg-transparent text-gray-800 focus:bg-blue-50'
                              }`}
                              placeholder=""
                              onFocus={(e) => e.target.select()}
                            />
                          );
                        })()}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-4 text-sm text-gray-600">
          <p>💡 Wskazówka: Możesz edytować wartości w trójkącie. Puste komórki oznaczają brak danych.</p>
          <p>Pamiętaj o kliknięciu "✅ Zapisz zmiany" aby zastosować modyfikacje w analizie.</p>
        </div>
      </div>

      {/* Modal ostrzeżenia o niezapisanych zmianach */}
      <Modal
        title="Ostrzeżenie"
        message={`Masz ${modifiedCellsCount} niezapisanych zmian w trójkącie. Czy na pewno chcesz wyjść bez zapisywania? Wszystkie zmiany zostaną utracone.`}
        isOpen={showCloseWarning}
        onConfirm={handleConfirmClose}
        onCancel={handleCancelClose}
      />

      {/* Modal ostrzeżenia o utracie obliczeń */}
      <Modal
        title="Ostrzeżenie"
        message="Aplikowanie edytowanych danych spowoduje utratę wszystkich obecnych obliczeń i wyników analizy. Czy na pewno chcesz kontynuować?"
        isOpen={showCalculationsWarning}
        onConfirm={handleConfirmCloseAndSave}
        onCancel={handleCancelCalculationsWarning}
      />
    </div>
  );
});

EditableIncurredTriangle.displayName = 'EditableIncurredTriangle';
