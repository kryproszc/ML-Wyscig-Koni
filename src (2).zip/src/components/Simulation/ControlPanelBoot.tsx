'use client';

import { useBootStore } from '@/stores/useBootStore';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';
import { useState } from 'react';

type ControlPanelProps = {
  onRun: () => void;
  onQuantileClick: () => void;
  onPercentileClick: (source: 'sim' | 'diff') => void;
  onExport: () => void;
  isLoading: boolean;
  isSigmaReestimated: boolean;
  setIsSigmaReestimated: (val: boolean) => void;
  valueSigma: number;
  setValueSigma: (val: number) => void;
};

export function ControlPanelBoot({
  onRun,
  onQuantileClick,
  onPercentileClick,
  onExport,
  isLoading,
  isSigmaReestimated,
  setIsSigmaReestimated,
  valueSigma,
  setValueSigma,
}: ControlPanelProps) {
  const {
    rawQuantileInput,
    setRawQuantileInput,
    setQuantileInput,
    percentileInputSim,
    setPercentileInputSim,
    percentileInputDiff,
    setPercentileInputDiff,
    sim_total,
    setSimTotal,
  } = useBootStore();

  return (
    <div className="w-64 shrink-0 space-y-4">
      <div className="bg-gray-800 rounded-lg p-4">
        <label className="text-white text-sm font-medium mb-2 block">Liczba symulacji</label>
        <input
          type="number"
          value={Number.isNaN(sim_total) ? '' : sim_total}
          onChange={(e) => {
            const parsed = parseInt(e.target.value);
            setSimTotal(Number.isNaN(parsed) ? 0 : parsed);
          }}
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      <button 
        onClick={onRun} 
        className="w-full py-4 px-5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl font-bold hover:from-emerald-700 hover:to-emerald-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform disabled:opacity-50 disabled:cursor-not-allowed" 
        disabled={isLoading}
      >
        {isLoading ? (
          <div className="flex items-center justify-center gap-2" aria-label="Spinner symulacji">
            <Loader2 className="animate-spin w-4 h-4" />
            <span>Symuluję...</span>
          </div>
        ) : (
          'Wykonaj symulację'
        )}
      </button>

      <div className="bg-gray-800 rounded-lg p-4">
        <label className="text-white text-sm font-medium mb-2 block">Kwantyle (np. 0.1, 0.5, 0.9)</label>
        <input
          type="text"
          value={rawQuantileInput}
          onChange={(e) => {
            const raw = e.target.value;
            setRawQuantileInput(raw);
            const cleaned = raw
              .split(',')
              .map((q) => parseFloat(q.trim()))
              .filter((q) => !isNaN(q) && q >= 0 && q <= 1);
            const uniqueSorted = Array.from(new Set(cleaned)).sort((a, b) => a - b);
            setQuantileInput(uniqueSorted.join(','));
          }}
          disabled={isLoading}
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      <button 
        onClick={onQuantileClick} 
        className="w-full py-4 px-5 bg-gradient-to-r from-blue-600 to-blue-500 text-white rounded-xl font-bold hover:from-blue-700 hover:to-blue-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform disabled:opacity-50 disabled:cursor-not-allowed" 
        disabled={isLoading}
      >
        Wyświetl kwantyle
      </button>

      <div className="bg-gray-800 rounded-lg p-4">
        <label className="text-white text-sm font-medium mb-2 block">Wartość dla symulacji (sim_results)</label>
        <input
          type="number"
          value={percentileInputSim}
          onChange={(e) => setPercentileInputSim(e.target.value)}
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          disabled={isLoading}
        />
      </div>

      <button 
        onClick={() => onPercentileClick('sim')} 
        className="w-full py-4 px-5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl font-bold hover:from-emerald-700 hover:to-emerald-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform disabled:opacity-50 disabled:cursor-not-allowed" 
        disabled={isLoading}
      >
        Przelicz percentyl (sim)
      </button>

      <div className="bg-gray-800 rounded-lg p-4">
        <label className="text-white text-sm font-medium mb-2 block">Wartość dla różnic (sim_diff)</label>
        <input
          type="number"
          value={percentileInputDiff}
          onChange={(e) => setPercentileInputDiff(e.target.value)}
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          disabled={isLoading}
        />
      </div>

      <button 
        onClick={() => onPercentileClick('diff')} 
        className="w-full py-4 px-5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl font-bold hover:from-emerald-700 hover:to-emerald-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform disabled:opacity-50 disabled:cursor-not-allowed" 
        disabled={isLoading}
      >
        Przelicz percentyl (diff)
      </button>

      <button 
        onClick={onExport} 
        className="w-full py-4 px-5 bg-gradient-to-r from-amber-600 to-amber-500 text-white rounded-xl font-bold hover:from-amber-700 hover:to-amber-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform disabled:opacity-50 disabled:cursor-not-allowed" 
        disabled={isLoading}
      >
        Eksport do Excela
      </button>
    </div>
  );
}
