import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

export type UserSession = {
  userId: string;
  loginTime: string;
  logoutTime?: string;
};

type UserStore = {
  userId: string | null;
  loginTime: string | null;
  sessionHistory: UserSession[];
  setUserId: (id: string | null) => void;
  startSession: (id: string) => void;
  endSession: () => void;
  clearHistory: () => void;
};

export const useUserStore = create<UserStore>()(
  persist(
    (set, get) => {
      // Załaduj historię z localStorage przy inicjalizacji
      const savedHistory = typeof window !== 'undefined' 
        ? localStorage.getItem('session-history') 
        : null;
      const initialHistory = savedHistory ? JSON.parse(savedHistory) : [];
      
      return {
        userId: null,
        loginTime: null,
        sessionHistory: initialHistory,
      
      setUserId: (id) => set({ userId: id }),
      
      startSession: (id) => {
        const now = new Date().toISOString();
        const newSession: UserSession = {
          userId: id,
          loginTime: now,
        };
        
        // Pobierz historię z localStorage
        const savedHistory = localStorage.getItem('session-history');
        const history = savedHistory ? JSON.parse(savedHistory) : [];
        const updatedHistory = [...history, newSession];
        
        // Zapisz historię do localStorage
        localStorage.setItem('session-history', JSON.stringify(updatedHistory));
        
        set({ 
          userId: id, 
          loginTime: now,
          sessionHistory: updatedHistory
        });
      },
      
      endSession: () => {
        const { userId: currentUser, loginTime } = get();
        if (currentUser && loginTime) {
          const now = new Date().toISOString();
          
          // Pobierz historię z localStorage
          const savedHistory = localStorage.getItem('session-history');
          const history = savedHistory ? JSON.parse(savedHistory) : [];
          
          const updatedHistory = history.map((session: UserSession) => 
            session.loginTime === loginTime && session.userId === currentUser
              ? { ...session, logoutTime: now }
              : session
          );
          
          // Zapisz zaktualizowaną historię
          localStorage.setItem('session-history', JSON.stringify(updatedHistory));
          
          set({ 
            userId: null, 
            loginTime: null,
            sessionHistory: updatedHistory
          });
        } else {
          set({ userId: null, loginTime: null });
        }
      },
      
      clearHistory: () => {
        localStorage.removeItem('session-history');
        set({ sessionHistory: [] });
      },
    };
    },
    {
      name: 'user-storage',
      storage: createJSONStorage(() => sessionStorage), // Zamknięcie przeglądarki = wylogowanie
      partialize: (state) => ({ 
        userId: state.userId, 
        loginTime: state.loginTime 
      }), // Tylko userId i loginTime w sessionStorage
    }
  )
);
