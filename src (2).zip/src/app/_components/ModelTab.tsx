import React from 'react';
import { useModelDataStore } from '@/stores/modelDataStore';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export function ModelTab() {
  const { selectedType, setSelectedType } = useModelDataStore();

  return (
    <Card className="max-w-xl mx-auto mt-8">
      <CardHeader>
        <CardTitle>Wybierz typ danych do analizy</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="flex gap-4">
          <Button
            variant={selectedType === 'paid' ? 'default' : 'outline'}
            onClick={() => setSelectedType('paid')}
          >
            Paid (wczytane w InputDataTabDet)
          </Button>
          <Button
            variant={selectedType === 'incurred' ? 'default' : 'outline'}
            onClick={() => setSelectedType('incurred')}
          >
            Incurred (wczytane w InputDataTabDetIncurred)
          </Button>
        </div>
        <div className="mt-4 text-sm text-gray-400">
          Aktualnie wybrany typ danych: <span className="font-bold text-white">{selectedType}</span>
        </div>
      </CardContent>
    </Card>
  );
}
