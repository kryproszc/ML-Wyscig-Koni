import { PaidTabs, MultStoch, BootParam } from "./PaidTabs";
import { ChooseDataStoch } from "./ChooseDataStoch";

interface DeterministicTabsProps {
  activeTab: "choosedata" | "bootstrap" | "multiplikatywna" | "parametryczny";
  setActiveTab: (tab: "choosedata" | "bootstrap" | "multiplikatywna" | "parametryczny") => void;
  bootstrapNieparTab: string;
  setBootstrapNieparTab: (tab: string) => void;
  multiplikatywnaTab: string;
  setMultiplikatywnaTab: (tab: string) => void;
  bootstrapParamTab: string;
  setBootstrapParamTab: (tab: string) => void;
  chooseDataActiveType: 'paid' | 'incurred';
  setChooseDataActiveType: (type: 'paid' | 'incurred') => void;
}

export function DeterministicTabs({ 
  activeTab, 
  setActiveTab,
  bootstrapNieparTab,
  setBootstrapNieparTab,
  multiplikatywnaTab,
  setMultiplikatywnaTab,
  bootstrapParamTab,
  setBootstrapParamTab,
  chooseDataActiveType,
  setChooseDataActiveType,
}: DeterministicTabsProps) {

  return (
    <div className="w-full text-white">
      {/* Zakładki na górze - Poziom 1 (główne) */}
      <div className="flex space-x-1 mb-6 border-b border-slate-700">
        <button
          onClick={() => setActiveTab("choosedata")}
          className={`px-6 py-3 text-base font-medium transition-all rounded-t-lg ${
            activeTab === "choosedata"
              ? "bg-slate-800 border-t border-l border-r border-slate-600 border-b-2 border-b-blue-400 text-blue-400 shadow-lg"
              : "text-slate-300 hover:text-blue-300 hover:bg-slate-800/30"
          }`}
        >
          Informacje i wybór danych
        </button>
        <button
          onClick={() => setActiveTab("bootstrap")}
          className={`px-6 py-3 text-base font-medium transition-all rounded-t-lg ${
            activeTab === "bootstrap"
              ? "bg-slate-800 border-t border-l border-r border-slate-600 border-b-2 border-b-blue-400 text-blue-400 shadow-lg"
              : "text-slate-300 hover:text-blue-300 hover:bg-slate-800/30"
          }`}
        >
          Bootstrap nieparametryczny
        </button>
        <button
          onClick={() => setActiveTab("multiplikatywna")}
          className={`px-6 py-3 text-base font-medium transition-all rounded-t-lg ${
            activeTab === "multiplikatywna"
              ? "bg-slate-800 border-t border-l border-r border-slate-600 border-b-2 border-b-blue-400 text-blue-400 shadow-lg"
              : "text-slate-300 hover:text-blue-300 hover:bg-slate-800/30"
          }`}
        >
          Multiplikatywna stochastyczna
        </button>
        <button
          onClick={() => setActiveTab("parametryczny")}
          className={`px-6 py-3 text-base font-medium transition-all rounded-t-lg ${
            activeTab === "parametryczny"
              ? "bg-slate-800 border-t border-l border-r border-slate-600 border-b-2 border-b-blue-400 text-blue-400 shadow-lg"
              : "text-slate-300 hover:text-blue-300 hover:bg-slate-800/30"
          }`}
        >
          Bootstrap parametryczny
        </button>
      </div>

      {/* Treść aktywnej zakładki */}
       {activeTab === "choosedata" && <ChooseDataStoch activeType={chooseDataActiveType} setActiveType={setChooseDataActiveType} />}
      {activeTab === "bootstrap" && <PaidTabs activeTab={bootstrapNieparTab} setActiveTab={setBootstrapNieparTab} />}
      {activeTab === "multiplikatywna" && <MultStoch activeTab={multiplikatywnaTab} setActiveTab={setMultiplikatywnaTab} />}
      {activeTab === "parametryczny" && <BootParam activeTab={bootstrapParamTab} setActiveTab={setBootstrapParamTab} />}
    </div>
  );
}
