'use client';

import { useUserStore, type UserSession } from './useUserStore';
import { Button } from '@/components/ui/button';
import { Download, Trash2, Users } from 'lucide-react';

export function AdminPanel() {
  const { sessionHistory, clearHistory } = useUserStore();

  const formatDate = (isoString: string) => {
    const date = new Date(isoString);
    return date.toLocaleString('pl-PL', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  const getSessionDuration = (session: UserSession) => {
    const start = new Date(session.loginTime);
    const end = session.logoutTime 
      ? new Date(session.logoutTime) 
      : new Date(); // jeśli nie ma logout, liczy do teraz
    
    const diffMs = end.getTime() - start.getTime();
    const minutes = Math.floor(diffMs / (1000 * 60));
    
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}min`;
  };

  const exportToCSV = () => {
    // Nagłówki CSV
    const headers = ['Data logowania', 'Godzina logowania', 'Użytkownik', 'Data wylogowania', 'Godzina wylogowania', 'Czas w aplikacji'];
    
    // Dane
    const rows = sessionHistory.map(session => {
      const loginDate = new Date(session.loginTime);
      const logoutDate = session.logoutTime ? new Date(session.logoutTime) : null;
      
      return [
        loginDate.toLocaleDateString('pl-PL'),
        loginDate.toLocaleTimeString('pl-PL'),
        session.userId,
        logoutDate ? logoutDate.toLocaleDateString('pl-PL') : 'Aktywny',
        logoutDate ? logoutDate.toLocaleTimeString('pl-PL') : '-',
        getSessionDuration(session),
      ];
    });

    // Łączenie w CSV
    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    // Pobieranie pliku
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `user_activity_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Statystyki
  const uniqueUsers = new Set(sessionHistory.map(s => s.userId)).size;
  const activeSessions = sessionHistory.filter(s => !s.logoutTime).length;
  const totalSessions = sessionHistory.length;

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-blue-400 mb-2">Panel Administratora</h1>
          <p className="text-gray-400">Przeglądaj aktywność użytkowników aplikacji ResLab</p>
        </div>
        <div className="flex gap-3">
          <Button
            onClick={exportToCSV}
            disabled={sessionHistory.length === 0}
            className="bg-green-600 hover:bg-green-700 flex items-center gap-2"
          >
            <Download size={16} />
            Pobierz CSV
          </Button>
          <Button
            onClick={() => {
              if (confirm('Czy na pewno chcesz wyczyścić całą historię?')) {
                clearHistory();
              }
            }}
            variant="destructive"
            disabled={sessionHistory.length === 0}
            className="flex items-center gap-2"
          >
            <Trash2 size={16} />
            Wyczyść historię
          </Button>
        </div>
      </div>

      {/* Statystyki */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#1e293b] border border-gray-700 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-2">
            <Users className="text-blue-400" size={24} />
            <h3 className="text-gray-400 text-sm">Unikalnych użytkowników</h3>
          </div>
          <p className="text-3xl font-bold text-white">{uniqueUsers}</p>
        </div>
        
        <div className="bg-[#1e293b] border border-gray-700 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <h3 className="text-gray-400 text-sm">Aktywne sesje</h3>
          </div>
          <p className="text-3xl font-bold text-white">{activeSessions}</p>
        </div>
        
        <div className="bg-[#1e293b] border border-gray-700 rounded-lg p-6">
          <div className="flex items-center gap-3 mb-2">
            <h3 className="text-gray-400 text-sm">Wszystkich sesji</h3>
          </div>
          <p className="text-3xl font-bold text-white">{totalSessions}</p>
        </div>
      </div>

      {/* Tabela */}
      <div className="bg-[#1e293b] border border-gray-700 rounded-lg overflow-hidden">
        <div className="p-6">
          <h2 className="text-xl font-bold text-white mb-4">Historia logowań</h2>
          
          {sessionHistory.length === 0 ? (
            <p className="text-gray-400 text-center py-8">Brak danych do wyświetlenia</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-700">
                    <th className="text-left py-3 px-4 text-gray-300 font-semibold">Status</th>
                    <th className="text-left py-3 px-4 text-gray-300 font-semibold">Użytkownik</th>
                    <th className="text-left py-3 px-4 text-gray-300 font-semibold">Logowanie</th>
                    <th className="text-left py-3 px-4 text-gray-300 font-semibold">Wylogowanie</th>
                    <th className="text-left py-3 px-4 text-gray-300 font-semibold">Czas w aplikacji</th>
                  </tr>
                </thead>
                <tbody>
                  {[...sessionHistory].reverse().map((session, idx) => (
                    <tr
                      key={idx}
                      className="border-b border-gray-700/50 hover:bg-slate-800/30 transition"
                    >
                      <td className="py-3 px-4">
                        {session.logoutTime ? (
                          <span className="text-gray-500 text-xs">Zakończona</span>
                        ) : (
                          <span className="flex items-center gap-1 text-green-400 text-xs">
                            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                            Aktywna
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-white font-medium">
                        {session.userId}
                      </td>
                      <td className="py-3 px-4 text-gray-300 text-sm">
                        {formatDate(session.loginTime)}
                      </td>
                      <td className="py-3 px-4 text-gray-300 text-sm">
                        {session.logoutTime ? formatDate(session.logoutTime) : '-'}
                      </td>
                      <td className="py-3 px-4 text-blue-400 text-sm font-semibold">
                        {getSessionDuration(session)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
