'use client';

import { useEffect, useMemo, useRef } from 'react';
import { TableData } from '@/components/TableData';
import { useMultStochStore } from '@/stores/multStochStore';
import { useTableStore } from '@/stores/tableStore';
import { useMutation } from '@tanstack/react-query';
import { useTrainDevideStore } from '@/stores/trainDevideStore';
import { useUserStore } from '@/app/_components/useUserStore';
const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export function PaidViewMultStoch() {
  const userId = useUserStore((s) => s.userId);
  
  // Bezpieczne nasłuchiwanie głównego store
  const mainSheetJSON = useTableStore((state) => state.selectedSheetJSON);
  const mainSheetName = useTableStore((state) => state.selectedSheetName);
  
  // Ref do śledzenia poprzednich wartości
  const prevDataRef = useRef<{ json: any; name: string | undefined }>({ json: null, name: undefined });

  const {
    selectedCells,
    selectedSheetJSON: sheetJSON,
    selectedSheetName: sheetName,
    hydrateFromTableStore,
  } = useMultStochStore();

  // Sprawdź czy dane się zmieniły i zaktualizuj tylko wtedy
  useEffect(() => {
    const currentData = { json: mainSheetJSON, name: mainSheetName };
    const prevData = prevDataRef.current;
    
    // Sprawdź czy dane rzeczywiście się zmieniły
    if (mainSheetJSON && (
      prevData.json !== currentData.json || 
      prevData.name !== currentData.name
    )) {
      hydrateFromTableStore();
      console.log('[PaidViewMultStoch] Aktualizacja danych z głównego store');
      prevDataRef.current = currentData;
    }
  }, [mainSheetJSON, mainSheetName, hydrateFromTableStore]);

  const { setTrainDevide } = useTrainDevideStore();

  const mutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${API_URL}/calc/mult_stoch`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_id: userId,
          paid_weights: selectedCells,
          paid_data: sheetJSON,
          cl_data: [],
          cl_weights: [],
          triangle_raw: sheetJSON,
          cl_weights_raw: selectedCells,
        }),
      });

      if (!res.ok) throw new Error('Błąd backendu');
      return res.json();
    },
    onSuccess: (data) => {
      console.log('✅ MultStoch OK', data);
      if (data.train_devide) {
        setTrainDevide(data.train_devide);
      }
    },
    onError: (err) => console.error('❌ MultStoch error:', err),
  });

  if (!sheetJSON) {
    return <div className="text-red-400">Brak danych arkusza</div>;
  }

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex gap-6">


        {/* Tabela danych */}
        <div className="flex-1">
          <h3 className="text-lg font-bold mb-4 text-white">Wczytany trójkąt danych</h3>
          <TableData data={sheetJSON} /> {/* 👈 bez columns, identycznie jak w BootParam */}
        </div>
      </div>
    </div>
  );
}
