'use client';

import { useEffect, useMemo, useRef } from 'react';
import { TableData } from '@/components/TableData';
import { useBootParamStore } from '@/stores/bootParamStore';
import { useTableStore } from '@/stores/tableStore';
import { useMutation } from '@tanstack/react-query';
import { useUserStore } from '@/app/_components/useUserStore';
const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export function PaidViewBootParam() {
  const userId = useUserStore((s) => s.userId);

  // Bezpieczne nasłuchiwanie głównego store
  const mainSheetJSON = useTableStore((state) => state.selectedSheetJSON);
  const mainSheetName = useTableStore((state) => state.selectedSheetName);
  
  // Ref do śledzenia poprzednich wartości
  const prevDataRef = useRef<{ json: any; name: string | undefined }>({ json: null, name: undefined });

  const {
    selectedCells,
    selectedSheetJSON: sheetJSON,
    selectedSheetName: sheetName,
    hydrateFromTableStore,
  } = useBootParamStore();

  // Sprawdź czy dane się zmieniły i zaktualizuj tylko wtedy
  useEffect(() => {
    const currentData = { json: mainSheetJSON, name: mainSheetName };
    const prevData = prevDataRef.current;
    
    // Sprawdź czy dane rzeczywiście się zmieniły
    if (mainSheetJSON && (
      prevData.json !== currentData.json || 
      prevData.name !== currentData.name
    )) {
      hydrateFromTableStore();
      console.log('[PaidViewBootParam] Aktualizacja danych z głównego store');
      prevDataRef.current = currentData;
    }
  }, [mainSheetJSON, mainSheetName, hydrateFromTableStore]);

  const mutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${API_URL}/calc/wspolczynniki_boot`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_id: userId,
          wagi_boot: selectedCells,
          paid_data: sheetJSON,
        }),
      });

      if (!res.ok) throw new Error('Błąd backendu');
      return res.json();
    },
    onSuccess: (data) => {
      console.log('✅ BootParam OK', data);
    },
    onError: (err) => console.error('❌ BootParam error:', err),
  });

  if (!sheetJSON) {
    return <div className="text-red-400">Brak danych arkusza</div>;
  }

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex gap-6">


        {/* Tabela danych */}
        <div className="flex-1">
          <h3 className="text-lg font-bold mb-4 text-white">Wczytany trójkąt danych</h3>
          <TableData data={sheetJSON} />
        </div>
      </div>
    </div>
  );
}
