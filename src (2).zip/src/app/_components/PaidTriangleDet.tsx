'use client';

import { useEffect } from 'react';
import { useDetailTableStore } from '@/stores/useDetailTableStore';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { TableData } from '@/components/TableData';

export default function PaidTriangleDet() {
  console.log('[PaidTriangleDet] 🔥 COMPONENT RENDER START');
  
  const isValid = useDetailTableStore((s) => s.isValid);
  const json = useDetailTableStore((s) => s.selectedSheetJSON);
  const dataGenerationId = useDetailTableStore((s) => s.dataGenerationId);

  const paidTriangle = useTrainDevideStoreDet((s) => s.paidTriangle);
  const setPaidTriangle = useTrainDevideStoreDet((s) => s.setPaidTriangle);

  console.log('[PaidTriangleDet] 🔍 Component state:', {
    isValid,
    jsonLength: json?.length,
    dataGenerationId,
    paidTriangleLength: paidTriangle?.length
  });

  // Dodaj listener na zmiany dataGenerationId żeby wymusić przeliczenie
  useEffect(() => {
    console.log('[PaidTriangleDet] dataGenerationId changed:', dataGenerationId);
    
    // Jeśli mamy dane i dataGenerationId > 0, wymusimy przeliczenie
    if (dataGenerationId > 0 && isValid && json) {
      console.log('[PaidTriangleDet] Forcing recalculation due to dataGenerationId change');
      const numericData = json
        .slice(1)
        .map((row) =>
          row
            .slice(1)
            .map((cell) => {
              const num = typeof cell === 'string' ? parseFloat(cell) : cell;
              return isNaN(num) ? null : num;
            })
        );
      
      setPaidTriangle(numericData);
      localStorage.setItem('paidTriangleCache', JSON.stringify(numericData));
      console.log('[PaidTriangleDet] Force update completed');
    }
  }, [dataGenerationId]);

  // Dodaj listener na zmiany w store żeby debugować
  useEffect(() => {
    console.log('[PaidTriangleDet] paidTriangle changed:', {
      triangleType: Array.isArray(paidTriangle) ? 'array' : typeof paidTriangle,
      length: paidTriangle?.length,
      isEmpty: !paidTriangle || paidTriangle.length === 0
    });
  }, [paidTriangle]);

useEffect(() => {
  console.log('[PaidTriangleDet] 🎯 useEffect triggered:', { 
    isValid, 
    jsonLength: json?.length, 
    paidTriangleLength: paidTriangle?.length,
    dataGenerationId,
    hasJson: !!json,
    jsonFirstRow: json?.[0]?.slice(0, 3) // pierwsze 3 elementy pierwszego wiersza
  });
  
  if (isValid && json) {
    console.log('[PaidTriangleDet] ✅ Warunki spełnione - konwertuję dane...');
    
    const numericData = json
      .slice(1) // pomijamy pierwszy wiersz (nagłówki kolumn)
      .map((row) =>
        row
          .slice(1) // pomijamy pierwszą kolumnę (etykiety wierszy)
          .map((cell) => {
            const num = typeof cell === 'string' ? parseFloat(cell) : cell;
            return isNaN(num) ? null : num;
          })
      );

    console.log('[PaidTriangleDet] 🔢 Numeric data sample:', {
      length: numericData.length,
      firstRowLength: numericData[0]?.length,
      firstRowSample: numericData[0]?.slice(0, 3)
    });

    // Sprawdź czy dane faktycznie się zmieniły przed aktualizacją
    const currentDataString = JSON.stringify(paidTriangle);
    const newDataString = JSON.stringify(numericData);
    
    console.log('[PaidTriangleDet] 🔍 Data comparison:', {
      currentLength: paidTriangle?.length || 0,
      newLength: numericData.length,
      areEqual: currentDataString === newDataString,
      paidTriangleEmpty: !paidTriangle || paidTriangle.length === 0,
      dataGenerationId
    });
    
    // Aktualizuj jeśli dane się zmieniły LUB triangle jest pusty (po czyszczeniu)
    const shouldUpdate = currentDataString !== newDataString || !paidTriangle || paidTriangle.length === 0;
    
    if (shouldUpdate) {
      console.log('[PaidTriangleDet] 🚀 Updating paidTriangle...');
      setPaidTriangle(numericData);
      localStorage.setItem('paidTriangleCache', JSON.stringify(numericData));
      console.log('[PaidTriangleDet] ✅ setPaidTriangle completed');
    } else {
      console.log('[PaidTriangleDet] ❌ Dane są identyczne - nie aktualizuję');
    }
  } else {
    console.log('[PaidTriangleDet] ❌ Warunki nie spełnione:', {
      isValid,
      hasJson: !!json,
      reason: !isValid ? 'isValid=false' : 'json=undefined'
    });
  }
}, [isValid, json, setPaidTriangle, paidTriangle, dataGenerationId]); // Dodano dataGenerationId


  if (!isValid || !json) {
    return (
      <p className="text-gray-400">
        Brak danych – wczytaj plik i kliknij <strong>Wybierz</strong> w zakładce Paid.
      </p>
    );
  }

  const table = json.map((row) => row.map((c) => (c === '' ? '' : c)));

  return (
    <div className="p-6 text-white">
      <h2 className="text-xl font-bold mb-4">Trójkąt Paid – wczytane dane</h2>
      <TableData data={table} />
    </div>
  );
}
