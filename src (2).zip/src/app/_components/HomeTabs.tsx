'use client';

import { useState, useEffect } from "react";
import { DeterministicTabs } from "./DeterministicTabs";
import { DeterministicMethodsTab } from "./DeterministicMethodsTab";
import { Folder, Calculator, Home, BarChart, Shield, LogOut } from "lucide-react";
import { DataTabs } from "./DataTabs";
import { CheckAssumption } from '@/features/check-assumption';
import { useUserStore } from './useUserStore';
import { AdminPanel } from './AdminPanel';
import { useTriangleType } from '@/stores/useTriangleType';

export function HomeTabs() {
  const userId = useUserStore((s) => s.userId);
  const endSession = useUserStore((s) => s.endSession);
  const isAdmin = userId === 'adminKS';
  
  // Automatycznie kończy sesję przy zamknięciu okna
  useEffect(() => {
    const handleBeforeUnload = () => {
      if (userId && !isAdmin) {
        endSession();
      }
    };
    
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [userId, isAdmin, endSession]);
  
  const [selectedTab, setSelectedTab] = useState<"start" | "input" | "asumption" |"stoch" | "deterministic" | "admin">("start");
  
  const handleLogout = () => {
    endSession();
  };

  // ─── Stan dla DataTabs (Wprowadź dane) ───
  const [dataTabsActive, setDataTabsActive] = useState("paid");

  // ─── Stan dla DeterministicMethodsTab ───
  const [detMethod, setDetMethod] = useState<'paid' | 'incurred' | 'summary'>('paid');
  const [detPaidStep, setDetPaidStep] = useState(0);
  const [detIncurredStep, setDetIncurredStep] = useState(0);

  // ─── Stan dla DeterministicTabs (Metody stochastyczne) ───
  const [stochTab, setStochTab] = useState<"choosedata" | "bootstrap" | "multiplikatywna" | "parametryczny">("choosedata");
  
  // ─── Stany wewnętrzne dla każdej metody stochastycznej ───
  const [bootstrapNieparTab, setBootstrapNieparTab] = useState("triangle");
  const [multiplikatywnaTab, setMultiplikatywnaTab] = useState("triangle");
  const [bootstrapParamTab, setBootstrapParamTab] = useState("triangle");
  
  // ─── Stan dla ChooseDataStoch (Paid/Incurred) ───
  const [chooseDataActiveType, setChooseDataActiveType] = useState<'paid' | 'incurred'>('paid');

  // ─── Stan dla CheckAssumption ───
  const [checkAssumptionTab, setCheckAssumptionTab] = useState<'model' | 'assumptions' | 'analysis' | 'summary'>('model');
  
  // Używamy globalnego store'a zamiast lokalnego state
  const checkAssumptionTriangleType = useTriangleType((s) => s.triangleType);
  const setCheckAssumptionTriangleType = useTriangleType((s) => s.setTriangleType);

  const renderContent = () => {
    switch (selectedTab) {
      case "start":
        return <StartPage />;
      case "input":
        return <DataTabs activeTab={dataTabsActive} setActiveTab={setDataTabsActive} />;
      case "asumption":
        return <CheckAssumption 
          activeTab={checkAssumptionTab}
          setActiveTab={setCheckAssumptionTab}
          triangleType={checkAssumptionTriangleType}
          setTriangleType={setCheckAssumptionTriangleType}
        />;
      case "stoch":
        return <DeterministicTabs 
          activeTab={stochTab} 
          setActiveTab={setStochTab}
          bootstrapNieparTab={bootstrapNieparTab}
          setBootstrapNieparTab={setBootstrapNieparTab}
          multiplikatywnaTab={multiplikatywnaTab}
          setMultiplikatywnaTab={setMultiplikatywnaTab}
          bootstrapParamTab={bootstrapParamTab}
          setBootstrapParamTab={setBootstrapParamTab}
          chooseDataActiveType={chooseDataActiveType}
          setChooseDataActiveType={setChooseDataActiveType}
        />;
      case "deterministic":
        return <DeterministicMethodsTab 
          method={detMethod} 
          setMethod={setDetMethod}
          paidStep={detPaidStep}
          setPaidStep={setDetPaidStep}
          incurredStep={detIncurredStep}
          setIncurredStep={setDetIncurredStep}
        />;
      case "admin":
        return <AdminPanel />;
      default:
        return null;
    }
  };

  return (
    <div className="flex min-h-screen bg-[#0f172a]">
      {/* Sidebar */}
      <aside className="w-64 bg-[#1e293b] text-gray-100 flex flex-col py-6 px-4 border-r border-gray-700 sticky top-0 h-screen">
        {/* Logo / nagłówek */}
        <div className="flex flex-col justify-center items-center mb-8">
          <h1 className="text-2xl font-extrabold tracking-wider text-blue-400">
            UPZ
          </h1>
          <p className="text-xs text-gray-400 mt-1 text-center leading-tight">
            Uniwersytet Pomocy<br />Zagubionym
          </p>
        </div>

        <nav className="flex flex-col gap-2 flex-1">
          <SidebarItem 
            icon={<Home size={20} />} 
            label="Start" 
            isActive={selectedTab === "start"} 
            onClick={() => setSelectedTab("start")} 
          />
          <SidebarItem 
            icon={<Folder size={20} />} 
            label="Wprowadź dane" 
            isActive={selectedTab === "input"} 
            onClick={() => setSelectedTab("input")} 
          />
          <SidebarItem 
            icon={<Calculator size={20} />} 
            label="Sprawdzanie założeń" 
            isActive={selectedTab === "asumption"} 
            onClick={() => setSelectedTab("asumption")} 
          />
          <SidebarItem 
            icon={<BarChart size={20} />} 
            label="Metody deterministyczne" 
            isActive={selectedTab === "deterministic"} 
            onClick={() => setSelectedTab("deterministic")} 
          />
          <SidebarItem 
            icon={<Calculator size={20} />} 
            label="Metody stochastyczne" 
            isActive={selectedTab === "stoch"} 
            onClick={() => setSelectedTab("stoch")} 
          />
          
          {isAdmin && (
            <SidebarItem 
              icon={<Shield size={20} />} 
              label="Panel admina" 
              isActive={selectedTab === "admin"} 
              onClick={() => setSelectedTab("admin")} 
            />
          )}
        </nav>

        {/* Wylogowanie - tylko dla admina */}
        {isAdmin && (
          <div className="mb-4 p-3 bg-slate-800/50 rounded-lg border border-gray-700">
            <div className="text-xs text-gray-400 mb-1">Zalogowany:</div>
            <div className="text-sm font-semibold text-blue-400 mb-2">{userId}</div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 w-full p-2 text-sm text-red-400 hover:bg-red-900/20 rounded-lg transition border border-red-500/30 hover:border-red-500/50"
            >
              <LogOut size={16} />
              Wyloguj się
            </button>
          </div>
        )}

        {/* Stopka w sidebarze */}
        <div className="mt-auto pt-4 border-t border-gray-700">
          <p className="text-xs text-center text-gray-400 leading-relaxed">
            <span className="font-semibold text-blue-400">ResLab</span> v1.1.0<br />
            Analiza rezerw ubezpieczeniowych<br />
            <span className="text-gray-500">© 2026</span>
          </p>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 bg-[#0f172a] p-8 overflow-auto">
        {renderContent()}
      </main>
    </div>
  );
}

function SidebarItem({ icon, label, isActive, onClick }: { 
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-3 p-3 transition-all text-left
        ${isActive 
          ? "bg-slate-800 text-blue-400 font-semibold shadow-lg border-l-4 border-l-blue-400 rounded-r-lg border-t border-r border-b border-slate-600"
          : "hover:bg-slate-800/30 hover:text-blue-300 rounded-lg"}`}
    >
      {icon}
      <span className="text-base">{label}</span>
    </button>
  );
}

function StartPage() {
  return (
    <div className="flex flex-col items-center justify-center h-full text-gray-100 animate-fade-in">
      <div className="bg-gradient-to-b from-[#0f172a] to-[#1e293b] p-12 rounded-xl shadow-2xl flex flex-col items-center w-full max-w-4xl">
        <img 
          src="/Grafika_powitalna.png" 
          alt="Grafika powitalna"
          className="w-full max-w-2xl mb-4 rounded-lg shadow-lg"
        />
        
        <p className="text-xs text-gray-500 mb-10">
          Źródło: <a href="https://www.insurtechexpress.com/" target="_blank" rel="noopener noreferrer" className="underline hover:text-gray-400">
            www.insurtechexpress.com
          </a>
        </p>

        <h1 className="text-5xl font-bold mb-6 text-center">Witaj w ResLab!</h1>
        <p className="text-xl text-gray-400 text-center max-w-2xl">
          Rozpocznij pracę z symulacjami stochastycznymi rezerw ubezpieczeniowych. Wprowadź dane i wyciągaj wnioski z przeprowadzonych analiz.
        </p>
      </div>
    </div>
  );
}
