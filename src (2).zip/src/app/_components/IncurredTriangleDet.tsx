'use client';

import { useEffect } from 'react';
import { useIncurredTableStore } from '@/stores/useIncurredTableStore';
import { useDetailTableStore } from '@/stores/useDetailTableStore';
import { useTrainDevideStoreDetIncurred } from '@/stores/trainDevideStoreDeterministycznyIncurred';
import { TableData } from '@/components/TableData';

export default function IncurredTriangleDet() {
  const isValid = useIncurredTableStore((s) => s.isValid);
  const json = useIncurredTableStore((s) => s.selectedSheetJSON);
  
  // Dodaj dataGenerationId z useDetailTableStore dla synchronizacji
  const dataGenerationId = useDetailTableStore((s) => s.dataGenerationId);

  const incurredTriangle = useTrainDevideStoreDetIncurred((s) => s.incurredTriangle);
  const setIncurredTriangle = useTrainDevideStoreDetIncurred((s) => s.setIncurredTriangle);

  // Dodaj listener na zmiany dataGenerationId żeby wymusić przeliczenie
  useEffect(() => {
    console.log('[IncurredTriangleDet] dataGenerationId changed:', dataGenerationId);
    
    // Jeśli mamy dane i dataGenerationId > 0, wymusimy przeliczenie
    if (dataGenerationId > 0 && isValid && json) {
      console.log('[IncurredTriangleDet] Forcing recalculation due to dataGenerationId change');
      const numericData = json
        .slice(1)
        .map((row) =>
          row
            .slice(1)
            .map((cell) => {
              const num = typeof cell === 'string' ? parseFloat(cell) : cell;
              return isNaN(num) ? null : num;
            })
        );
      
      setIncurredTriangle(numericData);
      localStorage.setItem('incurredTriangleCache', JSON.stringify(numericData));
      console.log('[IncurredTriangleDet] Force update completed');
    }
  }, [dataGenerationId]);

  useEffect(() => {
    console.log('[IncurredTriangleDet] useEffect triggered:', { 
      isValid, 
      jsonLength: json?.length, 
      incurredTriangleLength: incurredTriangle?.length,
      dataGenerationId 
    });
    
    if (isValid && json) {
      const numericData = json
        .slice(1) // pomijamy pierwszy wiersz (nagłówki kolumn)
        .map((row) =>
          row
            .slice(1) // pomijamy pierwszą kolumnę (etykiety wierszy)
            .map((cell) => {
              const num = typeof cell === 'string' ? parseFloat(cell) : cell;
              return isNaN(num) ? null : num;
            })
        );

      // Sprawdź czy dane faktycznie się zmieniły przed aktualizacją
      const currentDataString = JSON.stringify(incurredTriangle);
      const newDataString = JSON.stringify(numericData);
      
      console.log('[IncurredTriangleDet] Data comparison:', {
        currentLength: incurredTriangle?.length || 0,
        newLength: numericData.length,
        areEqual: currentDataString === newDataString,
        incurredTriangleEmpty: !incurredTriangle || incurredTriangle.length === 0,
        dataGenerationId
      });
      
      // Aktualizuj jeśli dane się zmieniły LUB triangle jest pusty (po czyszczeniu)
      if (currentDataString !== newDataString || !incurredTriangle || incurredTriangle.length === 0) {
        setIncurredTriangle(numericData);
        localStorage.setItem('incurredTriangleCache', JSON.stringify(numericData));
        console.log('[IncurredTriangleDet] setIncurredTriangle → Dane zaktualizowane (forced by empty triangle)');
      } else {
        console.log('[IncurredTriangleDet] Dane są identyczne - nie aktualizuję');
      }
    }
  }, [isValid, json, setIncurredTriangle, incurredTriangle, dataGenerationId]); // Dodano dataGenerationId

  if (!isValid || !json) {
    return (
      <p className="text-gray-400">
        Brak danych – wczytaj plik i kliknij <strong>Wybierz</strong> w zakładce Incurred.
      </p>
    );
  }

  const table = json.map((row) => row.map((c) => (c === '' ? '' : c)));

  return (
    <div className="p-6 text-white">
      <h2 className="text-xl font-bold mb-4">Trójkąt Incurred – wczytane dane</h2>
      <TableData data={table} />
    </div>
  );
}
