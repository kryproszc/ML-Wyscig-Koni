import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"
import { PaidView } from "./PaidView"
import { CLTab } from "./CLTab"
import { ModelTab } from "./ModelTab"
import { useModelDataStore } from '@/stores/modelDataStore';
import { PaidViewMultStoch } from "./PaidViewMultStoch"
import { PaidViewBootParam } from "./PaidViewBootParam"
import WspolczynnikiMultiplikatywna from "./WspolczynnikiMultiplikatywna";
import WspolczynnikiBootParam from "./WspolczynnikiBootParam";
import  {UltimateTab} from "./UltimateTab"
import UltimateTab_boot from './UltimateTab_boot';
import  UltimateTab_stoch from "./UltimateTab_stoch"


const tabClass = `
  flex-1 text-center px-3 py-2 text-sm transition-all border-r border-slate-700
  text-blue-200
  hover:bg-slate-700
  data-[state=active]:bg-[#0f172a] 
  data-[state=active]:text-white 
  data-[state=active]:border-b-4
  data-[state=active]:border-b-blue-400
  data-[state=active]:font-medium
`;

interface TabsProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export function PaidTabs({ activeTab, setActiveTab }: TabsProps) {
  return (
    <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
      <TabsList className="flex w-full rounded overflow-hidden border border-slate-700 bg-[#1e293b] mb-4">
        <TabsTrigger value="triangle" className={tabClass}>1. Trójkąt</TabsTrigger>
        <TabsTrigger value="cl" className={tabClass}>2. Reszty</TabsTrigger>
        <TabsTrigger value="ultimate" className={tabClass}>3. Wyniki symulacji</TabsTrigger>
      </TabsList>
      <TabsContent value="triangle">
        <PaidView />
      </TabsContent>
      <TabsContent value="cl">
        <CLTab />
      </TabsContent>
      <TabsContent value="ultimate">
        <UltimateTab />
      </TabsContent>
    </Tabs>
  );
}


export function MultStoch({ activeTab, setActiveTab }: TabsProps) {
  return (
    <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
      <TabsList className="flex w-full rounded overflow-hidden border border-slate-700 bg-[#1e293b] mb-4">
        <TabsTrigger value="triangle" className={tabClass}>1. Trójkąt</TabsTrigger>
        <TabsTrigger value="wspolczynniki_mult" className={tabClass}>2. Parametry modelu</TabsTrigger>
        <TabsTrigger value="ultimate_mult" className={tabClass}>3. Wyniki symulacji</TabsTrigger>
      </TabsList>
      <TabsContent value="triangle">
        <PaidViewMultStoch />
      </TabsContent>
      <TabsContent value="wspolczynniki_mult">
        <WspolczynnikiMultiplikatywna />
      </TabsContent>
      <TabsContent value="ultimate_mult">
        <UltimateTab_stoch />
      </TabsContent>
    </Tabs>
  );
}


export function BootParam({ activeTab, setActiveTab }: TabsProps) {
  return (
    <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
      <TabsList className="flex w-full rounded overflow-hidden border border-slate-700 bg-[#1e293b] mb-4">
        <TabsTrigger value="triangle" className={tabClass}>1. Trójkąt</TabsTrigger>
        <TabsTrigger value="wspolczynniki_boot" className={tabClass}>2. Parametry modelu</TabsTrigger>
        <TabsTrigger value="ultimate_boot" className={tabClass}>3. Wyniki symulacji</TabsTrigger>
      </TabsList>
      <TabsContent value="triangle">
        <PaidViewBootParam />
      </TabsContent>
      <TabsContent value="wspolczynniki_boot">
        <WspolczynnikiBootParam />
      </TabsContent>
      <TabsContent value="ultimate_boot">
        <UltimateTab_boot />
      </TabsContent>
    </Tabs>
  );
}
