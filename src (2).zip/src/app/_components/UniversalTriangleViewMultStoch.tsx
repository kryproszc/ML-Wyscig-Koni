'use client';

import { useTableStore } from '@/stores/tableStore';
import { PaidViewMultStoch } from './PaidViewMultStoch';
import { IncurredViewMultStoch } from './IncurredViewMultStoch';

export function UniversalTriangleViewMultStoch() {
  const activeType = useTableStore((s) => s.activeStochTriangle ?? 'paid');

  if (activeType === 'incurred') {
    return <IncurredViewMultStoch />;
  }

  return <PaidViewMultStoch />;
}