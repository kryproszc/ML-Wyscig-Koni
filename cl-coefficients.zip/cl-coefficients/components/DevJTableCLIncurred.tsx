'use client';

import React from 'react';

import DevJTableBase from '@/shared/ui/organisms/DevJTable/DevJTableBase';
import type { DevJResult } from '@/shared/ui/organisms/DevJTable/DevJTableBase';

import { fmt, mergePreview } from '@/shared/ui/organisms/DevJTable/useDevJHelpers';

import { useTrainDevideStoreDetIncurred } from '@/stores/trainDevideStoreDeterministycznyIncurred';
import type { CustomCell } from '@/stores/trainDevideStoreDeterministycznyIncurred';

type Props = {
  devJResults: DevJResult[];
  selectedVolume?: number;
  selectedSubIndex?: number;
  onSelectVolume: (v: number, subIndex?: number) => void;
  columnLabels?: string[]; // opcjonalne etykiety kolumn
};

export default function DevJTableCLIncurred({
  devJResults,
  selectedVolume,
  selectedSubIndex,
  onSelectVolume,
  columnLabels,
}: Props) {
  /* --------------------- store selectors -------------------- */
  const {
    finalDevJ,
    setFinalDevJ,
    devFinalCustom,
    setDevFinalValue,
    clearDevFinalValue,
    clearAllDevFinalValues,
    setDevPreviewCandidate,

    isConfirmModalOpen,
    openConfirmModal,
    closeConfirmModal,
    confirmFinalDevJ,
    
    decimalPlaces, // dodane dla formatowania
  } = useTrainDevideStoreDetIncurred();

  /* --------------------- helpers ---------------------------- */
  const maxLen = React.useMemo(
    () => Math.max(...devJResults.map((r) => r.values.length)),
    [devJResults]
  );

  // Funkcja formatowania z uwzględnieniem decimalPlaces ze store
  const formatNumber = React.useCallback((n?: number) => {
    if (typeof n !== 'number') return '-';
    return n.toFixed(decimalPlaces);
  }, [decimalPlaces]);

  const displayed = (j: number) => {
    const cell = (devFinalCustom as Record<number, CustomCell>)?.[j];
    return cell ? cell.value : finalDevJ?.values[j];
  };

  const handleCell = (j: number, v: number) => {
    const sel = displayed(j) === v;
    if (sel && devFinalCustom?.[j]?.curve === 'dev_j') clearDevFinalValue(j);
    else setDevFinalValue(j, 'dev_j', v);
  };

  const handleSelectFinal = (v: number, subIndex?: number) => {
    onSelectVolume(v, subIndex);

    const res = devJResults.find((r) => r.volume === v && (r.subIndex ?? 0) === (subIndex ?? 0));
    if (!res) return;

    if (Object.keys(devFinalCustom ?? {}).length) {
      openConfirmModal(res);
    } else {
      clearAllDevFinalValues();
      setFinalDevJ(res);
    }
  };

  const onConfirmFinal = () => {
    confirmFinalDevJ();
    closeConfirmModal();
  };

  const onCancelConfirm = () => {
    closeConfirmModal();
  };

  /* preview update */
  React.useEffect(() => {
    if (!finalDevJ?.values) return;
    setDevPreviewCandidate(
      mergePreview(finalDevJ.values, devFinalCustom as any)
    );
  }, [finalDevJ, devFinalCustom, setDevPreviewCandidate]);

  /* --------------------- render ------------------------------ */
  return (
    <>
      <DevJTableBase
        results={devJResults}
        maxLength={maxLen}
        columnLabels={columnLabels}
        displayed={displayed}
        selectedVolume={selectedVolume}
        selectedSubIndex={selectedSubIndex}
        onSelectVolume={handleSelectFinal}
        onCellToggle={handleCell}
        isConfirmModalOpen={isConfirmModalOpen}
        onConfirmFinal={onConfirmFinal}
        onCancelConfirm={onCancelConfirm}
        formatNumber={formatNumber} // przekazanie funkcji formatowania
      />

      {finalDevJ && (
  <div className="mt-6">
    <h3 className="text-white font-bold mb-2">
      Tabela wybranych współczynników do dopasowania krzywej
    </h3>

    {/* wrapper z poziomym scrollem */}
    <div className="w-full overflow-x-auto">
      <table className="w-full min-w-max whitespace-nowrap border-collapse border border-gray-700 text-white">
        <thead>
          <tr>
            <th className="border border-gray-600 px-3 py-1 bg-slate-800 text-left"></th>
            {Array.from({ length: maxLen }).map((_, j) => (
              <th
                key={j}
                className="border border-gray-600 px-3 py-1 bg-slate-800 text-center"
              >
                {columnLabels && columnLabels.length > j ? columnLabels[j] : `j=${j}`}
              </th>
            ))}
          </tr>
        </thead>

        <tbody>
          <tr>
            <td className="border border-gray-600 px-3 py-1 bg-slate-800 font-bold">
              Initial Selection
            </td>
            {Array.from({ length: maxLen }).map((_, j) => (
              <td
                key={j}
                className="border border-gray-600 px-3 py-1 text-center bg-slate-900 font-mono"
              >
                {formatNumber(displayed(j))}
              </td>
            ))}
          </tr>
        </tbody>
      </table>
    </div>
  </div>
)}

    </>
  );
}
