'use client';

import { useMemo } from 'react';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';

interface Props {
  data: (string | number)[][];
  weights?: number[][];
  selectedCells?: [number, number][];
  minMaxCells?: [number, number][];
  minCells?: [number, number][];
  maxCells?: [number, number][];
  onClick?: (i: number, j: number) => void;
  onToggleRow?: (rowIndex: number) => void;
  showRowToggle?: boolean;
  disableWeightEditing?: boolean; // nowy prop
}

export function TableDataDet({ 
  data, 
  weights, 
  selectedCells = [], 
  minMaxCells = [], 
  minCells = [], 
  maxCells = [], 
  onClick,
  onToggleRow,
  showRowToggle = false,
  disableWeightEditing = false
}: Props) {
  const toggleWeight = useTrainDevideStoreDet((s) => s.toggleWeightCellDet);
  const decimalPlaces = useTrainDevideStoreDet((s) => s.decimalPlaces);
  const weightSource = useTrainDevideStoreDet((s) => s.weightSource);
  const manualWeightOverrides = useTrainDevideStoreDet((s) => s.manualWeightOverrides);
  const manualWeightOverridesClInitial = useTrainDevideStoreDet((s) => s.manualWeightOverrides_clInitial);
  const effectiveOverrides = weightSource === 'cl_initial' ? manualWeightOverridesClInitial : manualWeightOverrides;

  // Funkcja formatowania liczb
  const formatNumber = (cell: string | number): string => {
    if (typeof cell === 'number') {
      return cell.toFixed(decimalPlaces);
    }
    if (typeof cell === 'string' && !isNaN(Number(cell)) && cell !== '') {
      return Number(cell).toFixed(decimalPlaces);
    }
    return String(cell);
  };

  // Debug - sprawdźmy co otrzymujemy
  console.log('🎯 TableDataDet received:', { 
    minCells: minCells.length, 
    maxCells: maxCells.length,
    minCellsData: minCells,
    maxCellsData: maxCells,
    weightsLength: weights?.length || 0,
    dataLength: data?.length || 0
  });

  const handleCellClick = (i: number, j: number) => {
    if (i === 0 || j === 0) return; // Nie pozwalamy kliknąć w nagłówki
    if (disableWeightEditing) return; // Nie pozwalamy edytować gdy używamy cl_initial
    
    // Sprawdzamy czy komórka ma liczbową wartość (nie pustą)
    const cell = data[i]?.[j];
    if (cell === null || cell === undefined || cell === '') return;

    console.log(`Kliknięto komórkę [${i}, ${j}]`);
    toggleWeight(i - 1, j - 1); // Odejmujemy 1 bo nagłówki dodają offset
    
    if (onClick) {
      onClick(i, j);
    }
  };

  const handleRowToggle = (rowIndex: number) => {
    if (rowIndex === 0 || !onToggleRow) return; // Nie pozwalamy na nagłówek
    if (disableWeightEditing) return; // Nie pozwalamy edytować gdy używamy cl_initial

    onToggleRow(rowIndex - 1); // Odejmujemy 1 bo nagłówki dodają offset
  };

  // Checkbox wiersza: odznaczamy tylko przy ręcznym 0 w którymkolwiek polu wiersza
  const rowSelectionStates = useMemo(() => {
    if (!data) return new Map<number, boolean>();
    
    const states = new Map<number, boolean>();
    
    for (let i = 1; i < data.length; i++) { // Zaczynamy od 1 bo 0 to nagłówek
      const dataRow = data[i];
      
      if (!dataRow) {
        states.set(i, false);
        continue;
      }

      let hasAnyData = false;
      let hasManualExclusion = false;
      
      for (let j = 1; j < dataRow.length; j++) { // Zaczynamy od 1 bo 0 to nagłówek
        const cell = dataRow[j];
        const hasData = cell !== null && cell !== undefined && cell !== '' && typeof cell !== 'undefined';
        
        if (hasData) {
          hasAnyData = true;
          if (effectiveOverrides[`${i - 1}_${j - 1}`] === 0) {
            hasManualExclusion = true;
            break;
          }
        }
      }
      
      states.set(i, hasAnyData && !hasManualExclusion);
    }
    
    return states;
  }, [data, effectiveOverrides]);

  // Sprawdzamy czy cały wiersz jest zaznaczony - teraz używa memoizowanego stanu
  const isRowSelected = (rowIndex: number): boolean => {
    if (rowIndex === 0) return false;
    return rowSelectionStates.get(rowIndex) || false;
  };

  return (
    <div className="overflow-x-auto bg-white rounded-lg border border-gray-300">
      <table className="min-w-full text-sm border-collapse">
        <tbody>
          {data.map((row, i) => (
            <tr key={i}>
              {/* Kolumna z checkbox dla wierszy (tylko jeśli showRowToggle jest true) */}
              {showRowToggle && (
                <td className="p-2 text-center bg-gray-100 border border-gray-300">
                  {i === 0 ? (
                    <span className="text-gray-800 font-semibold text-xs">Cały wiersz</span>
                  ) : (
                    (() => {
                      const canToggleRow = !disableWeightEditing;

                      return (
                    <input
                      type="checkbox"
                      checked={isRowSelected(i)}
                      onChange={() => handleRowToggle(i)}
                      disabled={!canToggleRow}
                      className={`w-4 h-4 text-blue-600 bg-white border-gray-400 rounded focus:ring-blue-500 focus:ring-2 ${
                        canToggleRow ? 'cursor-pointer' : 'cursor-not-allowed opacity-50'
                      }`}
                    />
                      );
                    })()
                  )}
                </td>
              )}
              
              {row.map((cell, j) => {
                const isHeaderRow = i === 0;
                const isHeaderCol = j === 0;
                const isHeader = isHeaderRow || isHeaderCol;
                
                // Sprawdzamy czy komórka ma dane liczbowe (nie pusta)
                const hasData = !isHeader && cell !== null && cell !== undefined && cell !== '';

                const canToggleCell = hasData && !disableWeightEditing;
                
                // Sprawdzamy czy komórka jest minimum lub maksimum
                const isMin = minCells?.some(([minI, minJ]) => minI === i && minJ === j);
                const isMax = maxCells?.some(([maxI, maxJ]) => maxI === i && maxJ === j);

                // Debug tylko dla min/max
                if (isMin || isMax) {
                  console.log(`🔍 Min/Max komórka [${i}, ${j}]:`, { isMin, isMax, cell, hasData });
                }

                const cellStyle = isHeader
                  ? 'bg-gray-200 text-gray-900 font-semibold'
                  : hasData
                  ? weights?.[i - 1]?.[j - 1] === 1
                    ? isMin
                      ? 'bg-green-50 text-gray-900 shadow-md' // 🟢 minimum - jasnozielone tło
                      : isMax
                      ? 'bg-red-50 text-gray-900 shadow-md' // 🔴 maksimum - jasnoczerwone tło
                      : 'bg-white text-gray-900' // ✅ aktywne wagi - białe tło
                    : 'bg-gray-300 text-gray-500' // ❌ nieaktywna/wyłączona
                  : 'bg-gray-200 text-gray-500'; // 🚫 pusta komórka

                // Dynamiczne obramowanie - priorytet dla min/max
                const borderStyle = isMin
                  ? 'border-2 border-green-500' // 🟢 zielone obramowanie dla minimum
                  : isMax
                  ? 'border-2 border-red-500' // 🔴 czerwone obramowanie dla maksimum
                  : 'border border-gray-300'; // ⚪ standardowe obramowanie

                return (
                  <td
                    key={j}
                    className={`
                      p-2 text-center transition-all duration-200
                      ${cellStyle}
                      ${borderStyle}
                      ${isHeaderCol ? 'whitespace-nowrap' : ''}
                      ${canToggleCell ? 'cursor-pointer hover:bg-opacity-80' : 'cursor-default'}
                    `}
                    onClick={canToggleCell ? () => handleCellClick(i, j) : undefined}
                  >
                    {isHeader ? cell : formatNumber(cell)}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}