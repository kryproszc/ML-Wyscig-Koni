import { create } from "zustand";
import * as XLSX from "xlsx";
import { validateDataValues, ValidationPresets } from "@/utils/dataValidation";
import type { RowData } from "@/types/table";
import { parseRange, toExcelRange, colLetterToNumber } from "@/utils/parseTableRange";

/* -------------------------------------------------------------------- */
/* Typ stanu                                                            */
/* -------------------------------------------------------------------- */
export type IncurredTableState = {
  /* plik / workbook */
  table?: File;
  isHydrated: boolean;
  workbook?: XLSX.WorkBook;

  /* arkusz */
  selectedSheet?: XLSX.WorkSheet;
  selectedSheetName?: string;
  sheetRange?: string;
  selectedSheetJSON?: RowData[];
  selectedCells?: number[][];

  // 🆕 Indywidualne ustawienia typu danych dla zakładki "Incurred"
  triangleType: 'paid' | 'incurred';
  setTriangleType: (type: 'paid' | 'incurred') => void;
  dataType: 'cumulative' | 'incremental';
  setDataType: (type: 'cumulative' | 'incremental') => void;

  // 🆕 Ustawienie czy dane zawierają podpisy kolumn i wierszy
  hasHeaders: boolean;
  setHasHeaders: (hasHeaders: boolean) => void;

  // 🆕 Tryb podawania zakresu (numeric/excel)
  rangeMode?: 'numeric' | 'excel';
  setRangeMode: (mode: 'numeric' | 'excel') => void;

  // 🆕 Ostatnie zatwierdzone ustawienia dla sprawdzania zmian
  lastApprovedSettings?: {
    sheetName: string | null;
    rowStart: number;
    rowEnd: number;
    colStart: number;
    colEnd: number;
    hasHeaders: boolean;
    dataType: 'cumulative' | 'incremental';
  };
  setLastApprovedSettings: (settings: {
    sheetName: string | null;
    rowStart: number;
    rowEnd: number;
    colStart: number;
    colEnd: number;
    hasHeaders: boolean;
    dataType: 'cumulative' | 'incremental';
  }) => void;

  /* poprzedni widok – do porównania */
  previousSheetJSON?: RowData[];
  setPreviousSheetJSON: (d: RowData[]) => void;

  /* zakres */
  startRow: number;
  endRow: number;
  startCol: number;
  endCol: number;
  setStartRow: (n: number) => void;
  setEndRow: (n: number) => void;
  setStartCol: (n: number) => void;
  setEndCol: (n: number) => void;
  setRangeAndUpdate: (p: {
    startRow: number;
    endRow: number;
    startCol: number;
    endCol: number;
  }) => void;
  getDefaultRange: () =>
    | { startRow: number; startCol: number; endRow: number; endCol: number }
    | undefined;

  /* upload */
  uploadedFileName?: string;
  setUploadedFileName: (name: string) => void;

  /* przetworzone dane (opcjonalnie) */
  processedData?: RowData[];
  setProcessedData: (d: RowData[]) => void;

  /* walidacja */
  isValid?: boolean;
  validationErrorReason?: string;

  /* api ogólne */
  setIsHydrated: (b: boolean) => void;
  setWorkbook: (wb?: XLSX.WorkBook) => void;
  setSelectedSheetName: (name: string | undefined) => void;
  updateSheetJSON: () => void;
  resetData: () => void;
  getSheetNames: () => string[] | undefined;
  setSelectedCells: (cells: number[][]) => void;
};

/* -------------------------------------------------------------------- */
/* Walidator specyficzny dla Incurred – używa uniwersalnej funkcji      */
/* -------------------------------------------------------------------- */
function validateIncurred(json: any[][], hasHeaders: boolean = true) {
  // 🆕 UPROSZCZONA WALIDACJA - tylko podstawowe sprawdzenia
  // Walidacja struktury trójkąta jest teraz w processFormData DOPO czyszczenia
  const validationOptions = {
    ...ValidationPresets.incurred(),
    validateTriangleStructure: false, // ❌ Wyłączamy starą walidację - nowa jest w processFormData
    hasHeaders: hasHeaders,
    enableLogging: false, // Wyłączamy logi
  };
  
  const result = validateDataValues(json, validationOptions);
  
  if (!result.isValid) {
    return { isValid: false, reason: result.reason || 'Błąd walidacji danych Incurred.' };
  }

  return { isValid: true };
}

/* -------------------------------------------------------------------- */
/* GŁÓWNY HOOK                                                          */
/* -------------------------------------------------------------------- */
export const useIncurredTableStore = create<IncurredTableState>((set, get) => ({
  /* --- state --- */
  isHydrated: false,

  startRow: 1,
  endRow: 1,
  startCol: 1,
  endCol: 1,

  // 🆕 Ustawienia typu danych - domyślne dla zakładki incurred
  triangleType: 'incurred',
  setTriangleType: (type) => set({ triangleType: type }),
  dataType: 'cumulative',
  setDataType: (type) => set({ dataType: type }),

  // 🆕 Ustawienie czy dane zawierają podpisy - domyślnie TRUE
  hasHeaders: true,
  setHasHeaders: (hasHeaders: boolean) => {
    console.log('🔧 [IncurredTableStore] setHasHeaders:', hasHeaders);
    
    // ✅ TYLKO ustaw wartość hasHeaders - NIE RUSZAJ ZAKRESU!
    set({ hasHeaders });
  },

  // 🆕 Tryb podawania zakresu - domyślnie numeric
  rangeMode: 'numeric',
  setRangeMode: (mode) => set({ rangeMode: mode }),

  // 🆕 Ostatnie zatwierdzone ustawienia - początkowo undefined
  lastApprovedSettings: undefined,
  setLastApprovedSettings: (settings) => set({ lastApprovedSettings: settings }),

  /* --- upload / processed --- */
  uploadedFileName: undefined,
  processedData: undefined,
  setProcessedData: (d) => set({ processedData: d }),

  previousSheetJSON: undefined,
  setPreviousSheetJSON: (d) => set({ previousSheetJSON: d }),

  /* --- zakres --- */
  setStartRow: (n) => set({ startRow: n }),
  setEndRow: (n) => set({ endRow: n }),
  setStartCol: (n) => set({ startCol: n }),
  setEndCol: (n) => set({ endCol: n }),

  setRangeAndUpdate: (r) => {
    set({
      startRow: r.startRow,
      endRow: r.endRow,
      startCol: r.startCol,
      endCol: r.endCol,
    });
    get().updateSheetJSON();
  },

  getDefaultRange: () => {
    const sheet = get().selectedSheet;
    if (!sheet) return;
    
    let minRow = Infinity, maxRow = -Infinity;
    let minCol = Infinity, maxCol = -Infinity;
    let hasData = false;
    
    // Iteruj przez WSZYSTKIE komórki w arkuszu
    Object.keys(sheet).forEach(cellAddress => {
      if (cellAddress[0] === '!') return; // Pomiń metadane (!ref, !margins etc)
      
      const cell = sheet[cellAddress];
      // Sprawdź czy komórka ma wartość (nie pusta)
      if (cell && cell.v !== null && cell.v !== undefined && cell.v !== '') {
        const match = cellAddress.match(/^([A-Z]+)(\d+)$/);
        if (match && match[1] && match[2]) {
          const col = colLetterToNumber(match[1]);
          const row = parseInt(match[2], 10);
          
          minRow = Math.min(minRow, row);
          maxRow = Math.max(maxRow, row);
          minCol = Math.min(minCol, col);
          maxCol = Math.max(maxCol, col);
          hasData = true;
        }
      }
    });
    
    if (!hasData) return;
    
    return {
      startRow: minRow,
      endRow: maxRow,
      startCol: minCol,
      endCol: maxCol
    };
  },

  /* --- init / reset --- */
  setIsHydrated: (b) => set({ isHydrated: b }),

  setWorkbook: (wb) => {
    const first = wb?.SheetNames[0];
    const sheet = first ? wb?.Sheets[first] : undefined;
    set({
      workbook: wb,
      selectedSheetName: first,
      sheetRange: sheet ? sheet["!ref"] : undefined,
    });
  },

  setSelectedSheetName: (name) => {
    // Reset tylko danych z tego store'a (nie wszystkich store'ów)
    get().resetData();

    if (!name) {
      set({
        selectedSheetName: undefined,
        selectedSheet: undefined,
        selectedSheetJSON: undefined,
        isValid: undefined,
        validationErrorReason: undefined,
      });
      return;
    }

    const sheet = get().workbook?.Sheets[name];
    if (!sheet || !sheet["!ref"]) {
      set({
        selectedSheetName: undefined,
        selectedSheet: undefined,
        selectedSheetJSON: undefined,
        isValid: undefined,
        validationErrorReason: undefined,
      });
      return;
    }

    set({
      selectedSheetName: name,
      selectedSheet: sheet,
      sheetRange: sheet["!ref"],
    });
  },

  /* --- konwersja + walidacja --- */
  updateSheetJSON: () => {
    const name = get().selectedSheetName;
    if (!name) return;

    const sheet = get().workbook?.Sheets[name];
    if (!sheet) return;

    const { startRow, endRow, startCol, endCol } = get();
    
    // Walidacja zakresu - sprawdź czy wartości są logiczne
    if (startRow > endRow) {
      set({
        isValid: false,
        validationErrorReason: "Wiersz początkowy nie może być większy od wiersza końcowego.",
        selectedSheetJSON: undefined,
        selectedCells: undefined,
      });
      return;
    }
    
    if (startCol > endCol) {
      set({
        isValid: false,
        validationErrorReason: "Kolumna początkowa nie może być większa od kolumny końcowej.",
        selectedSheetJSON: undefined,
        selectedCells: undefined,
      });
      return;
    }

    const range = toExcelRange({
      startRow,
      endRow,
      startCol,
      endCol,
    });

    const tempSheet = { ...sheet, ["!ref"]: range } as XLSX.WorkSheet;
    const json = XLSX.utils.sheet_to_json<RowData>(tempSheet, {
      header: 1,
      blankrows: true,
      defval: "",
    });

    // Sprawdź czy arkusz ma jakiekolwiek dane
    if (!json || json.length === 0) {
      set({
        isValid: false,
        validationErrorReason: "Wybrany zakres nie zawiera żadnych danych. Sprawdź czy zakres jest poprawny.",
        selectedSheetJSON: undefined,
        selectedCells: undefined,
      });
      return;
    }

    const validation = validateIncurred(json, get().hasHeaders);
    if (!validation.isValid) {
      set({
        isValid: false,
        validationErrorReason: validation.reason,
        selectedSheetJSON: undefined,
        selectedCells: undefined,
      });
      return;
    }

    const selectedCells = json.map((row) =>
      row.map((cell) => {
        const n = typeof cell === "number" ? cell : Number(cell);
        return isNaN(n) ? 0 : 1;
      }),
    );

    set({
      previousSheetJSON: get().selectedSheetJSON,
      selectedSheetJSON: json,
      selectedCells,
      isValid: true,
      validationErrorReason: undefined,
    });
  },

  resetData: () =>
    set({
      selectedSheetJSON: undefined,
      selectedCells: undefined,
      isValid: undefined,
      validationErrorReason: undefined,
      processedData: undefined,
    }),

  /* --- helpers --- */
  getSheetNames: () => get().workbook?.SheetNames,
  setSelectedCells: (cells) => set({ selectedCells: cells }),
  setUploadedFileName: (name) => set({ uploadedFileName: name }),
}));
