import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import * as XLSX from 'xlsx';

/* ──────────────────────────── TYPY ──────────────────────────── */

export type SourceType = 'base' | 'curve' | 'custom';

export type DevJResult = {
  volume: number;
  subIndex?: number;
  values: number[];
  sdValues?: number[];
  coeffCounts?: number[];
};

export interface CustomCell {
  curve: string;
  value: number;
  sourceVolume?: number; // volume z którego pochodzi wartość
  sourceSubIndex?: number; // subIndex z którego pochodzi wartość
  sourceCoeffCount?: number; // liczba współczynników użyta do obliczenia wartości
}

export type ComparisonEntry = {
  data: any[];
  labelA: string;
  labelB: string;
  areDifferentVectors?: boolean;
};

/* ─────────────────── INTERFEJS STANU (pełny) ─────────────────── */

export type TrainDevideStoreDetIncurred = {
  /* ————— Loader PaidTriangleDetIncurred ————— */
  workbookDetIncurred?: XLSX.WorkBook;
  setWorkbookDetIncurred: (wb: XLSX.WorkBook) => void;

  uploadedFileNameDetIncurred?: string;
  setUploadedFileNameDetIncurred: (n: string) => void;

  selectedSheetNameDetIncurred?: string;
  setSelectedSheetNameDetIncurred: (n: string) => void;

  /* zakres */
  startRowDetIncurred: number;
  endRowDetIncurred: number;
  startColDetIncurred: number;
  endColDetIncurred: number;
  setRangeAndUpdateDetIncurred: (r: {
    startRow: number;
    endRow: number;
    startCol: number;
    endCol: number;
  }) => void;
  getDefaultRangeDetIncurred: () =>
    | { startRow: number; endRow: number; startCol: number; endCol: number }
    | undefined;

  /* JSON + walidacja */
  selectedSheetDetIncurred?: (string | number)[][];
  previousSheetDetIncurred?: (string | number)[][];
  isValidDetIncurred: boolean;
  validationErrorReasonDetIncurred?: string;

  /* ————— Pozostałe pola aplikacji ————— */
  removeComparisonTable: (index: number) => void;

  comparisonTables: ComparisonEntry[];
  addComparisonTable: (entry: ComparisonEntry) => void;
  clearComparisonTables: () => void;

  comparisonLabels: { labelA: string; labelB: string };
  setComparisonLabels: (l: { labelA: string; labelB: string }) => void;

  comparisonTable: any[];
  setComparisonTable: (d: any[]) => void;

  selectedDataA: string | null;
  selectedDataB: string | null;
  setSelectedDataA: (k: string | null) => void;
  setSelectedDataB: (k: string | null) => void;
  incurredTriangle?: (number | null)[][];
  originalIncurredTriangle?: (number | null)[][];
  setIncurredTriangle: (d: (number | null)[][]) => void;
  restoreOriginalIncurredTriangle: () => void;
  clearOriginalIncurredTriangle: () => void;

  /* ————— CL Initial Incurred - maska formatowania ————— */
  cl_initial_inc?: number[][];
  setClInitialInc: (data: number[][]) => void;
  clearClInitialInc: () => void;

  combinedDevJSummary: (number | string)[];
  setCombinedDevJSummary: (v: (number | string)[]) => void;

  remainingDevJHeaders: string[];
  setRemainingDevJHeaders: (headers: string[]) => void;

  leftCountSummary: number;
  setLeftCountSummary: (n: number) => void;

  selectedCurveSummary: string | null;
  setSelectedCurveSummary: (c: string | null) => void;

  manualOverridesSummary: Record<number, { 
    curve: string; 
    value: number;
    previousState?: {
      wasFromCurve?: string;
      wasFromSourceSwitch?: boolean;
      wasValue?: number;
    };
  }>;
  setManualOverridesSummary: (
    o: Record<number, { 
      curve: string; 
      value: number;
      previousState?: {
        wasFromCurve?: string;
        wasFromSourceSwitch?: boolean;
        wasValue?: number;
      };
    }>
  ) => void;

  // Nowy stan dla przełączania źródła współczynników
  sourceSwitchesSummary: Record<number, { curve: string; value: number }>;
  setSourceSwitchesSummary: (switches: Record<number, { curve: string; value: number }>) => void;

  // Indeks początkowy dla Ultimate Factors
  ultimateFromIndexSummary: number;
  setUltimateFromIndexSummary: (n: number) => void;

  updateDevJAt: (idx: number, value: number) => void;

  selectedDevJVolume?: number;
  selectedDevJSubIndex?: number;
  setSelectedDevJVolume: (v: number, subIndex?: number) => void;

  /* ===== PREVIEW ===== */
  devPreviewCandidate?: number[];
  setDevPreviewCandidate: (v: number[]) => void;
  clearDevPreviewCandidate: () => void;

  /* ===== UI / CONFIG ===== */
  retainedCoeffCount: number;
  setRetainedCoeffCount: (val: number) => void;

  selectedCurve: string;
  setSelectedCurve: (name: string) => void;

  /* ===== Final vectors & custom overrides ===== */
  finalDevVector: number[];
  setFinalDevVector: (v: number[]) => void;

  devFinalCustom: Record<number, CustomCell>;
  setDevFinalValue: (idx: number, curve: string, value: number, sourceVolume?: number, sourceSubIndex?: number, sourceCoeffCount?: number) => void;
  clearDevFinalValue: (idx: number) => void;
  clearAllDevFinalValues: () => void;

  /* ===== Dane do obliczeń dev_j ===== */
  trainDevideDetIncurred?: number[][];
  selectedWeightsDetIncurred?: number[][];
  selectedWeightsDetIncurred_clInitial?: number[][];
  manualWeightOverrides: Record<string, 0 | 1>;
  manualWeightOverrides_clInitial: Record<string, 0 | 1>;
  volume_default: number;
  volume_clInitial: number;
  selectedCellsDetIncurred: [number, number][];

  r2Scores?: Record<string, number>;
  setR2Scores: (r: Record<string, number>) => void;
  clearR2Scores: () => void;

  tailCount?: number | '';
  setTailCountGlobal: (n: number | '') => void;

  devJ?: number[];
  devJPending?: number[];
  setDevJ: (d: number[]) => void;
  setDevJPending: (d: number[]) => void;

  devJResults: DevJResult[];
  addDevJResult: (vol: number, values: number[], sdValues?: number[], coeffCounts?: number[]) => void;
  clearDevJResults: () => void;

  finalDevJ?: DevJResult;
  setFinalDevJ: (d: DevJResult | undefined) => void;

  devJPreview?: number[];
  setDevJPreview: (v: number[]) => void;
  clearDevJPreview: () => void;

  /* ===== MODALE ===== */
  isConfirmModalOpen: boolean;
  pendingFinalDevJ?: DevJResult;
  openConfirmModal: (d: DevJResult) => void;
  closeConfirmModal: () => void;
  confirmFinalDevJ: () => void;

  isMissingFinalModalOpen: boolean;
  openMissingFinalModal: () => void;
  closeMissingFinalModal: () => void;

  /* ===== HELPERY / UI ===== */
  setVolume: (v: number) => void;
  getMaxVolume: () => number;
  getCurrentVolume: () => number;
  setTrainDevideDetIncurred: (d: number[][] | undefined) => void;
  setSelectedWeightsDetIncurred: (w: number[][]) => void;
  toggleCellDetIncurred: (r: number, c: number) => void;
  toggleWeightCellDetIncurred: (r: number, c: number) => void;
  toggleRowDetIncurred: (r: number) => void;
  setManualWeightOverride: (row: number, col: number, value: 0 | 1) => void;
  clearManualWeightOverrides: () => void;
  resetWeightsToInitial: () => void;
  clearAllWeightsDetIncurred: () => void;
  resetSelectionDetIncurred: () => void;
  resetDetIncurred: () => void;

  selectedDevJIndexes: number[];
  setSelectedDevJIndexes: (i: number[]) => void;

  simResults?: Record<string, Record<string, number>>;
  setSimResults: (r: Record<string, Record<string, number>>) => void;
  clearSimResults: () => void;

  /* ===== CLEAR FIT CURVE ===== */
  clearFitCurveData: () => void;

  /* ===== CLEAR DEVELOPMENT END SUMMARY ===== */
  clearDevSummaryData: () => void;

  /* ===== MIN/MAX HIGHLIGHTING ===== */
  minMaxHighlighting: boolean;
  minMaxCells: [number, number][];
  minCells: [number, number][];
  maxCells: [number, number][];
  setMinMaxHighlighting: (enabled: boolean) => void;
  calculateMinMaxCells: () => void;

  /* ===== DECIMAL PLACES ===== */
  decimalPlaces: number;
  setDecimalPlaces: (places: number) => void;

  /* ===== CHART SETTINGS ===== */
  chartSelectedColumn: number;
  chartReferenceType: string;
  setChartSelectedColumn: (column: number) => void;
  setChartReferenceType: (type: string) => void;

  /* ===== CURVE FITTING SETTINGS ===== */
  fittingMethod: "log_regression" | "least_squares";
  useWeighting: boolean;
  setFittingMethod: (method: "log_regression" | "least_squares") => void;
  setUseWeighting: (value: boolean) => void;

  /* ===== WEIGHT SOURCE SELECTION ===== */
  weightSource: 'default' | 'cl_initial';
  setWeightSource: (source: 'default' | 'cl_initial') => void;
  getEffectiveWeights: () => number[][] | undefined;
};

/* ───────────────────────  STORE  ─────────────────────── */

export const useTrainDevideStoreDetIncurred = create(
  persist<TrainDevideStoreDetIncurred>(
    (set, get) => ({
      /* ——— INITIAL STATE ——— */
      workbookDetIncurred: undefined,
      uploadedFileNameDetIncurred: undefined,
      selectedSheetNameDetIncurred: undefined,

      startRowDetIncurred: 1,
      endRowDetIncurred: 1,
      startColDetIncurred: 1,
      endColDetIncurred: 1,

      selectedSheetDetIncurred: undefined,
      previousSheetDetIncurred: undefined,
      isValidDetIncurred: false,
      validationErrorReasonDetIncurred: undefined,

      comparisonTables: [],
      comparisonLabels: { labelA: 'Projection A', labelB: 'Projection B' },
      comparisonTable: [],

      selectedDataA: null,
      selectedDataB: null,

incurredTriangle: undefined,
      originalIncurredTriangle: undefined,

      cl_initial_inc: undefined,

      combinedDevJSummary: [],
      remainingDevJHeaders: [],
      leftCountSummary: 0,
      selectedCurveSummary: null,
      manualOverridesSummary: {},
      sourceSwitchesSummary: {},
      ultimateFromIndexSummary: 1,

      selectedDevJVolume: undefined,
      selectedDevJSubIndex: undefined,

      devPreviewCandidate: undefined,
      retainedCoeffCount: 0,
      selectedCurve: '',

      finalDevVector: [],
      devFinalCustom: {},

      trainDevideDetIncurred: undefined,
      selectedWeightsDetIncurred: undefined,
      selectedWeightsDetIncurred_clInitial: undefined,
      manualWeightOverrides: {},
      manualWeightOverrides_clInitial: {},
      volume_default: 19,
      volume_clInitial: 19,
      selectedCellsDetIncurred: [],

      r2Scores: undefined,
      tailCount: '',

      devJ: undefined,
      devJPending: undefined,
      devJResults: [],
      finalDevJ: undefined,
      devJPreview: undefined,

      isConfirmModalOpen: false,
      pendingFinalDevJ: undefined,
      isMissingFinalModalOpen: false,

      selectedDevJIndexesIncurred: [],

      simResults: undefined,

      selectedDevJIndexes: [],

      minMaxHighlighting: false,
      minMaxCells: [],
      minCells: [],
      maxCells: [],

      decimalPlaces: 6, // domyślnie 6 miejsc po przecinku - LIMIT 0-100!
      chartSelectedColumn: 0, // domyślnie pierwsza kolumna
      chartReferenceType: 'none', // domyślnie brak linii odniesienia      
      fittingMethod: "log_regression", // domyślnie Log Regression
      useWeighting: false, // domyślnie bez ważenia
      
      weightSource: 'default', // domyślnie wagi domyślne
      
      /* ——— SETTERS & ACTIONS ——— */

      /* Loader PaidTriangleDetIncurred */
      setWorkbookDetIncurred: (wb) => {
        set({ workbookDetIncurred: wb });

        const first = wb.SheetNames[0];
        if (first && get().selectedSheetNameDetIncurred !== first) {
          get().setSelectedSheetNameDetIncurred(first);
        }
      },

      setUploadedFileNameDetIncurred: (n) =>
        set({ uploadedFileNameDetIncurred: n }),

      setSelectedSheetNameDetIncurred: (name) => {
        if (get().selectedSheetNameDetIncurred === name) return;

        const wb = get().workbookDetIncurred;
        if (!wb || !wb.Sheets[name]) return;

        const json = XLSX.utils.sheet_to_json(
          wb.Sheets[name] as XLSX.WorkSheet,
          { header: 1, raw: false }
        ) as (string | number)[][];

        set({
          selectedSheetNameDetIncurred: name,
          previousSheetDetIncurred: get().selectedSheetDetIncurred,
          selectedSheetDetIncurred: json,
          isValidDetIncurred: json.length > 0,
          validationErrorReasonDetIncurred:
            json.length > 0 ? undefined : 'Pusty arkusz',
          startRowDetIncurred: 1,
          endRowDetIncurred: json.length,
          startColDetIncurred: 1,
          endColDetIncurred: json[0]?.length ?? 1,
        });
      },

      getDefaultRangeDetIncurred: () => {
        const sheet = get().selectedSheetDetIncurred;
        if (!sheet || sheet.length === 0) return undefined;

        const firstRow = sheet[0] ?? [];

        return {
          startRow: 1,
          endRow: sheet.length,
          startCol: 1,
          endCol: firstRow.length,
        };
      },

      setRangeAndUpdateDetIncurred: ({
        startRow,
        endRow,
        startCol,
        endCol,
      }) => {
        const wb = get().workbookDetIncurred;
        const sheetName = get().selectedSheetNameDetIncurred;
        if (!wb || !sheetName) return;

        const ws = wb.Sheets[sheetName];
        if (!ws) return;

        const json: (string | number)[][] = XLSX.utils.sheet_to_json(
          ws as XLSX.WorkSheet,
          {
            header: 1,
            raw: false,
          }
        );

        const sliced = json
          .slice(startRow - 1, endRow)
          .map((r) => r.slice(startCol - 1, endCol));

        const isValid = sliced.length > 0;

        set({
          startRowDetIncurred: startRow,
          endRowDetIncurred: endRow,
          startColDetIncurred: startCol,
          endColDetIncurred: endCol,
          previousSheetDetIncurred: get().selectedSheetDetIncurred,
          selectedSheetDetIncurred: sliced,
          isValidDetIncurred: isValid,
          validationErrorReasonDetIncurred: isValid
            ? undefined
            : 'Niepoprawny format',
        });
      },

      /* Comparison tables */
      removeComparisonTable: (idx) =>
        set((s) => ({
          comparisonTables: s.comparisonTables.filter((_, i) => i !== idx),
        })),
      addComparisonTable: (e) =>
        set((s) => ({ comparisonTables: [...s.comparisonTables, e] })),
      clearComparisonTables: () => set({ comparisonTables: [] }),

      setComparisonLabels: (l) => set({ comparisonLabels: l }),
      setComparisonTable: (d) => set({ comparisonTable: d }),

      setSelectedDataA: (k) => set({ selectedDataA: k }),
      setSelectedDataB: (k) => set({ selectedDataB: k }),

setIncurredTriangle: (d) => {
        const currentOriginal = get().originalIncurredTriangle;
        set({ 
          incurredTriangle: d,
          // Zapisz oryginał tylko jeśli jeszcze go nie ma
          originalIncurredTriangle: currentOriginal || (d && d.length > 0 ? d.map(row => [...row]) : undefined)
        });
      },

      restoreOriginalIncurredTriangle: () => {
        const original = get().originalIncurredTriangle;
        if (original && original.length > 0) {
          set({ incurredTriangle: original.map(row => [...row]) });
        }
      },

      clearOriginalIncurredTriangle: () => {
        set({ originalIncurredTriangle: undefined });
      },

      /* CL Initial Incurred - maska formatowania */
      setClInitialInc: (data) => set({ cl_initial_inc: data.map(row => [...row]) }),
      clearClInitialInc: () => set({ cl_initial_inc: undefined }),

      /* Summaries */
      setCombinedDevJSummary: (v) =>
        set({ combinedDevJSummary: [...v] }),
      setRemainingDevJHeaders: (headers) => set({ remainingDevJHeaders: [...headers] }),
      setLeftCountSummary: (n) => set({ leftCountSummary: n }),
      setSelectedCurveSummary: (c) => set({ selectedCurveSummary: c }),
      setManualOverridesSummary: (o) =>
        set({ manualOverridesSummary: { ...o } }),
      setSourceSwitchesSummary: (switches) =>
        set({ sourceSwitchesSummary: { ...switches } }),
      setUltimateFromIndexSummary: (n) => set({ ultimateFromIndexSummary: n }),

      /* Preview candidate */
      setDevPreviewCandidate: (v) =>
        set({ devPreviewCandidate: [...v] }),
      clearDevPreviewCandidate: () =>
        set({ devPreviewCandidate: undefined }),

      /* UI / config */
      setRetainedCoeffCount: (v) => set({ retainedCoeffCount: v }),
      setSelectedCurve: (n) => set({ selectedCurve: n }),

      /* Final vectors & overrides */
      setFinalDevVector: (v) => set({ finalDevVector: [...v] }),
      setDevFinalValue: (idx, curve, value, sourceVolume, sourceSubIndex, sourceCoeffCount) =>
        set((s) => {
          const upd = { 
            ...s.devFinalCustom, 
            [idx]: { curve, value, sourceVolume, sourceSubIndex, sourceCoeffCount } 
          };
          const vec = [...s.finalDevVector];
          vec[idx] = value;
          return { devFinalCustom: upd, finalDevVector: vec };
        }),
      clearDevFinalValue: (idx) =>
        set((s) => {
          const copy = { ...s.devFinalCustom };
          delete copy[idx];
          const vec = [...s.finalDevVector];
          if (s.devJPreview && s.devJPreview[idx] !== undefined)
            vec[idx] = s.devJPreview[idx]!;
          return { devFinalCustom: copy, finalDevVector: vec };
        }),
      clearAllDevFinalValues: () =>
        set((s) => ({
          devFinalCustom: {},
          finalDevVector: s.devJPreview
            ? [...s.devJPreview]
            : [...s.finalDevVector],
        })),

      /* Dev_J dane */
      setTrainDevideDetIncurred: (d) => {
        // Przy czyszczeniu danych wyzeruj parametr volume i stany wag,
        // aby nie dziedziczyć wartości ze starych obliczeń.
        if (!d || d.length === 0 || !d[0]) {
          set({
            trainDevideDetIncurred: undefined,
            selectedWeightsDetIncurred: undefined,
            selectedWeightsDetIncurred_clInitial: undefined,
            manualWeightOverrides: {},
            manualWeightOverrides_clInitial: {},
            volume_default: 1,
            volume_clInitial: 1,
          });
          return;
        }

        const numRows = d.length;
        set({
          trainDevideDetIncurred: d,
          volume_default: numRows,
          volume_clInitial: numRows,
          selectedWeightsDetIncurred: undefined,
          selectedWeightsDetIncurred_clInitial: undefined,
          manualWeightOverrides: {},
          manualWeightOverrides_clInitial: {},
        });
      },
      setSelectedWeightsDetIncurred: (w) => {
        const isClInitial = get().weightSource === 'cl_initial';
        if (isClInitial) {
          set({ selectedWeightsDetIncurred_clInitial: w });
        } else {
          set({ selectedWeightsDetIncurred: w });
        }
      },

      getMaxVolume: () => {
        const matrix = get().trainDevideDetIncurred;
        if (!matrix || matrix.length === 0 || !matrix[0]) return 19;
        return matrix.length;
      },

      getCurrentVolume: () => {
        const isClInitial = get().weightSource === 'cl_initial';
        return isClInitial ? get().volume_clInitial : get().volume_default;
      },

      setVolume: (v) => {
        const matrix = get().trainDevideDetIncurred;
        if (!matrix || matrix.length === 0 || !matrix[0]) return;

        if (!Number.isFinite(v)) return;
        
        const maxVolume = matrix.length;
        const normalizedV = Math.floor(v);
        const clampedV = Math.min(Math.max(1, normalizedV), maxVolume); // Ogranicz do 1..maxVolume
        
        const isClInitial = get().weightSource === 'cl_initial';
        
        // Ustaw odpowiedni volume
        if (isClInitial) {
          set({ volume_clInitial: clampedV });
        } else {
          set({ volume_default: clampedV });
        }

        const numRows = matrix.length;
        const numCols = matrix[0].length;
        const overrides = isClInitial ? get().manualWeightOverrides_clInitial : get().manualWeightOverrides;
        
        // Stwórz nową macierz wag
        const weights: number[][] = Array.from({ length: numRows }, () =>
          new Array(numCols).fill(0)
        );

        // Dla każdej kolumny osobno: wybierz deterministycznie clampedV aktywnych od dołu,
        // pomijając ręcznie odznaczone komórki (override = 0)
        for (let col = 0; col < numCols; col++) {
          let selectedCount = 0;
          for (let row = numRows - 1; row >= 0 && selectedCount < clampedV; row--) {
            const val = matrix[row]?.[col];
            if (typeof val === 'number' && val !== 0) {
              const key = `${row}_${col}`;
              const override = overrides[key];

              if (override === 0) {
                weights[row]![col] = 0;
                continue;
              }

              weights[row]![col] = 1;
              selectedCount++;
            }
          }
        }

        if (isClInitial) {
          set({ selectedWeightsDetIncurred_clInitial: weights });
        } else {
          set({ selectedWeightsDetIncurred: weights });
        }
        
        // 🎯 Przelicz Min/Max po zmianie volume jeśli jest włączone
        if (get().minMaxHighlighting) {
          get().calculateMinMaxCells();
        }
      },

      toggleCellDetIncurred: (r, c) => {
        const sel = get().selectedCellsDetIncurred;
        const idx = sel.findIndex(
          ([row, col]) => row === r && col === c
        );
        if (idx >= 0)
          set({
            selectedCellsDetIncurred: sel.filter(
              ([row, col]) => !(row === r && col === c)
            ),
          });
        else
          set({
            selectedCellsDetIncurred: [...sel, [r, c]],
          });
      },

      toggleWeightCellDetIncurred: (r, c) => {
        const isClInitial = get().weightSource === 'cl_initial';
        const cur = isClInitial ? get().selectedWeightsDetIncurred_clInitial : get().selectedWeightsDetIncurred;
        const matrix = get().trainDevideDetIncurred;
        if (!cur) return;
        if (!matrix || !matrix[0]) return;

        const val = matrix[r]?.[c];
        if (!(typeof val === 'number' && val !== 0)) return;

        const newValue: 0 | 1 = cur[r]?.[c] === 1 ? 0 : 1;

        const currentVolume = get().getCurrentVolume();
        const clampedV = Math.min(Math.max(1, Math.floor(currentVolume)), matrix.length);
        const numRows = matrix.length;
        const numCols = matrix[0].length;

        const baseOverrides = isClInitial ? get().manualWeightOverrides_clInitial : get().manualWeightOverrides;
        const nextOverrides: Record<string, 0 | 1> = {
          ...baseOverrides,
          [`${r}_${c}`]: newValue,
        };

        const rebuiltWeights: number[][] = Array.from({ length: numRows }, () =>
          new Array(numCols).fill(0)
        );

        // Deterministyczne uzupełnienie do volume od dołu (bez losowości)
        for (let col = 0; col < numCols; col++) {
          let selectedCount = 0;
          for (let row = numRows - 1; row >= 0 && selectedCount < clampedV; row--) {
            const cellVal = matrix[row]?.[col];
            if (typeof cellVal !== 'number' || cellVal === 0) continue;

            const key = `${row}_${col}`;
            const override = nextOverrides[key];
            if (override === 0) {
              rebuiltWeights[row]![col] = 0;
              continue;
            }

            rebuiltWeights[row]![col] = 1;
            selectedCount++;
          }
        }

        if (isClInitial) {
          set({ 
            selectedWeightsDetIncurred_clInitial: rebuiltWeights,
            manualWeightOverrides_clInitial: nextOverrides,
          });
        } else {
          set({ 
            selectedWeightsDetIncurred: rebuiltWeights,
            manualWeightOverrides: nextOverrides,
          });
        }
        
        // Jeśli min/max highlighting jest włączone, przelicz ponownie
        if (get().minMaxHighlighting) {
          get().calculateMinMaxCells();
        }
      },

      toggleRowDetIncurred: (r) => {
        const isClInitial = get().weightSource === 'cl_initial';
        const cur = isClInitial ? get().selectedWeightsDetIncurred_clInitial : get().selectedWeightsDetIncurred;
        const trainData = get().trainDevideDetIncurred;
        if (!cur || !trainData) return;

        // Sprawdzamy czy cały wiersz jest zaznaczony
        const dataRow = trainData[r];
        if (!dataRow) return;

        const dataCols: number[] = [];

        for (let j = 0; j < dataRow.length; j++) {
          const cell = dataRow[j];
          const hasData = cell !== null && cell !== undefined && typeof cell === 'number' && cell !== 0;

          if (hasData) {
            dataCols.push(j);
          }
        }

        if (dataCols.length === 0) return;

        const currentVolume = get().getCurrentVolume();
        const clampedV = Math.min(Math.max(1, Math.floor(currentVolume)), trainData.length);
        const numRows = trainData.length;
        const numCols = trainData[0]?.length ?? 0;

        const baseOverrides = isClInitial ? get().manualWeightOverrides_clInitial : get().manualWeightOverrides;
        const nextOverrides: Record<string, 0 | 1> = { ...baseOverrides };

        // Checkbox wiersza opiera się na manualnych wykluczeniach:
        // odznaczony tylko gdy istnieje ręczne 0 w tym wierszu.
        const hasManualExclusionInRow = dataCols.some((col) => baseOverrides[`${r}_${col}`] === 0);
        const nextRowValue: 0 | 1 = hasManualExclusionInRow ? 1 : 0;

        for (const col of dataCols) {
          nextOverrides[`${r}_${col}`] = nextRowValue;
        }

        const rebuiltWeights: number[][] = Array.from({ length: numRows }, () =>
          new Array(numCols).fill(0)
        );

        // Deterministyczne uzupełnienie do volume od dołu (bez losowości)
        for (let col = 0; col < numCols; col++) {
          let selectedCount = 0;
          for (let row = numRows - 1; row >= 0 && selectedCount < clampedV; row--) {
            const cellVal = trainData[row]?.[col];
            if (typeof cellVal !== 'number' || cellVal === 0) continue;

            const key = `${row}_${col}`;
            const override = nextOverrides[key];
            if (override === 0) {
              rebuiltWeights[row]![col] = 0;
              continue;
            }

            rebuiltWeights[row]![col] = 1;
            selectedCount++;
          }
        }

        if (isClInitial) {
          set({ 
            selectedWeightsDetIncurred_clInitial: rebuiltWeights,
            manualWeightOverrides_clInitial: nextOverrides,
          });
        } else {
          set({ 
            selectedWeightsDetIncurred: rebuiltWeights,
            manualWeightOverrides: nextOverrides,
          });
        }
        
        // Jeśli min/max highlighting jest włączone, przelicz ponownie
        if (get().minMaxHighlighting) {
          get().calculateMinMaxCells();
        }
      },

      setManualWeightOverride: (row, col, value) => {
        const isClInitial = get().weightSource === 'cl_initial';
        const key = `${row}_${col}`;
        
        if (isClInitial) {
          set((state) => ({
            manualWeightOverrides_clInitial: {
              ...state.manualWeightOverrides_clInitial,
              [key]: value,
            },
          }));
        } else {
          set((state) => ({
            manualWeightOverrides: {
              ...state.manualWeightOverrides,
              [key]: value,
            },
          }));
        }
      },

      clearManualWeightOverrides: () => {
        const isClInitial = get().weightSource === 'cl_initial';
        if (isClInitial) {
          set({ manualWeightOverrides_clInitial: {} });
        } else {
          set({ manualWeightOverrides: {} });
        }
      },

      resetWeightsToInitial: () => {
        const isClInitial = get().weightSource === 'cl_initial';
        
        if (isClInitial) {
          // Dla "Zadane" - resetuj do cl_initial_inc
          const clInitialInc = get().cl_initial_inc;
          if (clInitialInc) {
            // Skopiuj macierz
            set({ selectedWeightsDetIncurred_clInitial: clInitialInc.map(row => [...row]) });
            
            // Przepisz wszystkie wartości z cl_initial_inc jako manual overrides
            const overrides: Record<string, 0 | 1> = {};
            clInitialInc.forEach((row, r) => {
              row.forEach((val, c) => {
                if (val === 0 || val === 1) {
                  overrides[`${r}_${c}`] = val;
                }
              });
            });
            set({ manualWeightOverrides_clInitial: overrides });
          }
        } else {
          // Dla "Domyślne" - resetuj do wszystko włączone
          const matrix = get().trainDevideDetIncurred;
          if (matrix) {
            set({ 
              selectedWeightsDetIncurred: matrix.map((row) => row.map(() => 1)),
              manualWeightOverrides: {}
            });
          }
        }
        
        // Przelicz Min/Max po resecie
        if (get().minMaxHighlighting) {
          get().calculateMinMaxCells();
        }
      },

      clearAllWeightsDetIncurred: () => {
        const isClInitial = get().weightSource === 'cl_initial';
        const cur = isClInitial ? get().selectedWeightsDetIncurred_clInitial : get().selectedWeightsDetIncurred;
        if (cur) {
          const cleared = cur.map((r) => r.map(() => 0));
          if (isClInitial) {
            set({ selectedWeightsDetIncurred_clInitial: cleared });
          } else {
            set({ selectedWeightsDetIncurred: cleared });
          }
        }
      },

      resetSelectionDetIncurred: () => {
        const isClInitial = get().weightSource === 'cl_initial';
        const matrix = get().trainDevideDetIncurred;
        if (!matrix) return;
        const reset = matrix.map((row) => row.map(() => 1));
        if (isClInitial) {
          set({ selectedWeightsDetIncurred_clInitial: reset });
        } else {
          set({ selectedWeightsDetIncurred: reset });
        }
      },

      /* Dev_J & preview */
      setDevJ: (d) => set({ devJ: d }),
      setDevJPending: (d) =>
        set({ devJPending: [...d] }),
      setDevJPreview: (v) =>
        set(() => ({
          devJPreview: [...v],
          finalDevVector: [...v],
        })),
      clearDevJPreview: () => set({ devJPreview: undefined }),

      addDevJResult: (volume, values, sdValues, coeffCounts) => {
        const curr = get().devJResults;
        const same = curr.filter((e) => e.volume === volume);
        const subIndex = same.length ? same.length : undefined;
        const entry: DevJResult = {
          volume,
          values: [...values],
          ...(subIndex !== undefined && { subIndex }),
          ...(sdValues && { sdValues: [...sdValues] }),
          ...(coeffCounts && { coeffCounts: [...coeffCounts] }),
        };
        set({ devJResults: [...curr, entry] });
      },
      clearDevJResults: () => set({ devJResults: [] }),

      setFinalDevJ: (d) =>
        set({
          finalDevJ: d,
          devFinalCustom: {},
          finalDevVector: d ? [...d.values] : [],
        }),

      updateDevJAt: (idx, value) =>
        set((s) => {
          if (!Array.isArray(s.devJPreview)) return {};
          const prev = [...s.devJPreview];
          prev[idx] = value;
          const vec = [...s.finalDevVector];
          vec[idx] = value;
          return {
            devJPreview: prev,
            finalDevVector: vec,
            devFinalCustom: {
              ...s.devFinalCustom,
              [idx]: { curve: 'manual', value },
            },
          };
        }),

      /* Modal handlers */
      openConfirmModal: (pending) =>
        set({
          isConfirmModalOpen: true,
          pendingFinalDevJ: pending,
        }),
      closeConfirmModal: () =>
        set({
          isConfirmModalOpen: false,
          pendingFinalDevJ: undefined,
        }),
      confirmFinalDevJ: () => {
        const pending = get().pendingFinalDevJ;
        if (!pending) return;
        set({
          finalDevJ: pending,
          devFinalCustom: {},
          finalDevVector: [...pending.values],
          isConfirmModalOpen: false,
          pendingFinalDevJ: undefined,
        });
      },

      openMissingFinalModal: () =>
        set({ isMissingFinalModalOpen: true }),
      closeMissingFinalModal: () =>
        set({ isMissingFinalModalOpen: false }),

      /* Simulations / R2 */
      setR2Scores: (r) => set({ r2Scores: r }),
      clearR2Scores: () => set({ r2Scores: undefined }),
      setSimResults: (r) => set({ simResults: r }),
      clearSimResults: () => set({ simResults: undefined }),

      /* Clear FitCurve data */
      clearFitCurveData: () => set({
        devPreviewCandidate: undefined,
        devJPreview: undefined,
        finalDevVector: [],
        devFinalCustom: {},
        selectedDevJIndexes: [],
        r2Scores: undefined,
        simResults: undefined,
      }),

      /* Clear Development End Summary data */
      clearDevSummaryData: () => set({
        leftCountSummary: 0,
        selectedCurveSummary: null,
        manualOverridesSummary: {},
        sourceSwitchesSummary: {},
        ultimateFromIndexSummary: 1,
        combinedDevJSummary: [],
        remainingDevJHeaders: [],
        comparisonTables: [],
        selectedDataA: null,
        selectedDataB: null,
      }),

      /* Dev_J index selection */
      setSelectedDevJIndexes: (i) =>
        set({ selectedDevJIndexes: i }),

      /* Comparison volume */
      setSelectedDevJVolume: (v, subIndex) => set({ selectedDevJVolume: v, selectedDevJSubIndex: subIndex }),

      /* Tail count */
      setTailCountGlobal: (n) => set({ tailCount: n }),

      /* Min/Max highlighting */
      setMinMaxHighlighting: (enabled) => {
        set({ minMaxHighlighting: enabled });
        if (enabled) get().calculateMinMaxCells();
        else set({ minMaxCells: [], minCells: [], maxCells: [] });
      },

      calculateMinMaxCells: () => {
        const trainData = get().trainDevideDetIncurred;
        const weights = get().getEffectiveWeights();
        if (!trainData || !weights || trainData.length === 0) return;

        console.log('🔢 calculateMinMaxCells Incurred started', { 
          trainDataRows: trainData.length, 
          trainDataCols: trainData[0]?.length,
          weightsRows: weights.length, 
          weightsCols: weights[0]?.length 
        });

        const minMaxCells: [number, number][] = [];
        const minCells: [number, number][] = [];
        const maxCells: [number, number][] = [];
        
        // Dla każdej kolumny znajdź min/max spośród zaznaczonych komórek
        const numCols = trainData[0]?.length || 0;
        
        for (let col = 0; col < numCols; col++) {
          const selectedValues: { value: number; row: number }[] = [];
          
          for (let row = 0; row < trainData.length; row++) {
            const cellValue = trainData[row]?.[col];
            const isSelected = weights[row]?.[col] === 1;
            
            if (isSelected && cellValue != null && typeof cellValue === 'number') {
              selectedValues.push({ 
                value: cellValue, 
                row 
              });
            }
          }
          
          console.log(`📊 Incurred Kolumna ${col}:`, {
            selectedCount: selectedValues.length,
            values: selectedValues.map(v => `[${v.row}] = ${v.value}`)
          });
          
          if (selectedValues.length > 1) {
            const minItem = selectedValues.reduce((min, curr) => 
              curr.value < min.value ? curr : min
            );
            const maxItem = selectedValues.reduce((max, curr) => 
              curr.value > max.value ? curr : max
            );
            
            // +1 bo w TableDataDetIncurred mamy nagłówki!
            minCells.push([minItem.row + 1, col + 1]);
            maxCells.push([maxItem.row + 1, col + 1]);
            minMaxCells.push([minItem.row + 1, col + 1]);
            if (minItem.row !== maxItem.row) {
              minMaxCells.push([maxItem.row + 1, col + 1]);
            }
            
            console.log(`✅ Incurred Kolumna ${col} - Min: [${minItem.row}]=${minItem.value}, Max: [${maxItem.row}]=${maxItem.value}`);
          } else {
            console.log(`⚠️ Incurred Kolumna ${col} - za mało wybranych wartości (${selectedValues.length})`);
          }
        }
        
        console.log('🎯 calculateMinMaxCells Incurred RESULT:', { 
          minCells: minCells.length, 
          maxCells: maxCells.length,
          minCellsData: minCells,
          maxCellsData: maxCells
        });
        set({ minMaxCells, minCells, maxCells });
      },

      /* Decimal places */
      setDecimalPlaces: (places) => {
        set({ decimalPlaces: Math.max(0, Math.min(100, places)) }); // ograniczenie 0-100 miejsc
      },

      /* Chart settings */
      setChartSelectedColumn: (column) => {
        set({ chartSelectedColumn: column });
      },
      setChartReferenceType: (type) => {
        set({ chartReferenceType: type });
      },

      /* Curve fitting settings */
      setFittingMethod: (method) => {
        set({ fittingMethod: method });
      },
      setUseWeighting: (value) => {
        set({ useWeighting: value });
      },

      /* Weight source selection */
      setWeightSource: (source) => {
        const prevSource = get().weightSource;
        set({ weightSource: source });
        
        if (source === 'cl_initial') {
          // Przełączamy na 'cl_initial'
          // Jeśli selectedWeightsDetIncurred_clInitial jest undefined, zainicjuj z cl_initial_inc
          if (!get().selectedWeightsDetIncurred_clInitial) {
            const clInitialInc = get().cl_initial_inc;
            if (clInitialInc) {
              // Skopiuj macierz
              set({ selectedWeightsDetIncurred_clInitial: clInitialInc.map(row => [...row]) });
              
              // Przepisz wszystkie wartości z cl_initial_inc jako manual overrides
              const overrides: Record<string, 0 | 1> = {};
              clInitialInc.forEach((row, r) => {
                row.forEach((val, c) => {
                  if (val === 0 || val === 1) {
                    overrides[`${r}_${c}`] = val;
                  }
                });
              });
              set({ manualWeightOverrides_clInitial: overrides });
            }
          }
          // Nie czyścimy overrides - zachowujemy poprzednie edycje użytkownika
        } else {
          // Przełączamy na 'default'
          // Jeśli selectedWeightsDetIncurred jest undefined, zainicjuj przez volume
          if (!get().selectedWeightsDetIncurred) {
            const currentVolume = get().getCurrentVolume();
            get().setVolume(currentVolume);
          }
          // Nie czyścimy overrides - zachowujemy poprzednie edycje użytkownika
        }
        
        // Przelicz Min/Max po zmianie
        if (get().minMaxHighlighting) {
          setTimeout(() => get().calculateMinMaxCells(), 0);
        }
      },

      getEffectiveWeights: () => {
        const isClInitial = get().weightSource === 'cl_initial';
        return isClInitial ? get().selectedWeightsDetIncurred_clInitial : get().selectedWeightsDetIncurred;
      },

      /* RESET ALL */
      resetDetIncurred: () =>
        set({
          workbookDetIncurred: undefined,
          uploadedFileNameDetIncurred: undefined,
          selectedSheetNameDetIncurred: undefined,
          startRowDetIncurred: 1,
          endRowDetIncurred: 1,
          startColDetIncurred: 1,
          endColDetIncurred: 1,
          selectedSheetDetIncurred: undefined,
          previousSheetDetIncurred: undefined,
          isValidDetIncurred: false,
          validationErrorReasonDetIncurred: undefined,

          incurredTriangle: undefined,
          originalIncurredTriangle: undefined,
          cl_initial_inc: undefined,
          trainDevideDetIncurred: undefined,
          selectedWeightsDetIncurred: undefined,
          selectedWeightsDetIncurred_clInitial: undefined,
          manualWeightOverrides: {},
          manualWeightOverrides_clInitial: {},
          selectedCellsDetIncurred: [],
          devJ: undefined,
          devJPending: undefined,
          devJResults: [],
          finalDevJ: undefined,
          devFinalCustom: {},
          devJPreview: undefined,
          isConfirmModalOpen: false,
          pendingFinalDevJ: undefined,
          isMissingFinalModalOpen: false,
          chartSelectedColumn: 0,
          chartReferenceType: 'none',
          volume_default: 1,
          volume_clInitial: 1,
        }),
    }),
    {
      name: 'train-devide-det-incurred',
      storage: {
        getItem: (n) => {
          const i = sessionStorage.getItem(n);
          return i ? JSON.parse(i) : null;
        },
        setItem: (n, v) =>
          sessionStorage.setItem(n, JSON.stringify(v)),
        removeItem: (n) => sessionStorage.removeItem(n),
      },
    }
  )
);
