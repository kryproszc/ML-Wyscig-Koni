'use client';

import { useEffect, useMemo, useRef } from 'react';
import { TableData } from '@/components/TableData';
import { useTableStore } from '@/stores/tableStore';
import { useMutation } from '@tanstack/react-query';
import { useUserStore } from '@/app/_components/useUserStore';
const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export function IncurredViewMultStoch() {
  const userId = useUserStore((s) => s.userId);
  
  // Używamy tableStore dla danych stochastycznych
  const {
    selectedSheetJSON: sheetJSON,
    selectedSheetName: sheetName,
    selectedCells,
  } = useTableStore();

  const mutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${API_URL}/calc/mult_stoch_incurred`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_id: userId,
          incurred_weights: selectedCells,
          incurred_data: sheetJSON,
          cl_data: [],
          cl_weights: [],
          triangle_raw: sheetJSON,
          cl_weights_raw: selectedCells,
        }),
      });

      if (!res.ok) throw new Error('Błąd backendu');
      return res.json();
    },
    onSuccess: (data) => {
      console.log('✅ MultStoch Incurred OK', data);
    },
    onError: (err) => console.error('❌ MultStoch Incurred error:', err),
  });

  if (!sheetJSON) {
    return <div className="text-red-400">Brak danych arkusza</div>;
  }

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex gap-6">


        {/* Tabela danych */}
        <div className="flex-1">
          <h3 className="text-lg font-bold mb-4 text-white">Trójkąt Incurred – wczytane dane</h3>
          <TableData data={sheetJSON} /> {/* 👈 bez columns, identycznie jak w BootParam */}
        </div>
      </div>
    </div>
  );
}