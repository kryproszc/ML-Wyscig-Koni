'use client';

import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useUserStore } from '@/app/_components/useUserStore';
import { useBootParamStore } from '@/stores/bootParamStore';
import { useBootParamResultsStore } from '@/stores/useBootParamResultsStore';
import { TrainDevideTable } from '@/components/TrainDevideTable';
import { useBootResultsStore } from '@/stores/useBootResultsStore';
import { useTableStore } from '@/stores/tableStore';

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export default function WspolczynnikiBootParam(): React.ReactElement {
  const userId = useUserStore((s) => s.userId);
  const triangleType = useTableStore((s) => s.triangleType);
  
  const {
    trainDevide,
    selectedWeights: selectedCells,
    selectedSheetJSON,
    setTrainDevide,
    setSelectedWeights: setSelectedCells,
    getCurrentVolume,
    getMaxVolume,
    setVolume,
    hydrateFromTableStore,
    minMaxHighlighting,
    minCells,
    maxCells,
    minMaxCells,
    setMinMaxHighlighting,
    calculateMinMaxCells,
    resetSelection,
    weightSource,
    setWeightSource,
    getEffectiveWeights,
    cl_initial,
    cl_initial_inc,
    toggleWeightCell,
    toggleRow,
    resetWeightsToInitial,
  } = useBootParamStore();
  
  const volume = getCurrentVolume();
  const maxVolume = getMaxVolume();
  
  const {
    dev,
    sd,
    sigma,
    decimalPlaces,
    setDev,
    setSd,
    setSigma,
    setDecimalPlaces,
  } = useBootParamResultsStore();

  const [version, setVersion] = useState(0);
  const hasInitializedRef = useRef(false);
  
  // Przechowuj oryginalne, niezaokrąglone wartości
  const [originalTrainDevide, setOriginalTrainDevide] = useState<number[][] | null>(null);
  const [originalDev, setOriginalDev] = useState<number[]>([]);
  const [originalSd, setOriginalSd] = useState<number[]>([]);
  const [originalSigma, setOriginalSigma] = useState<number[]>([]);

  // Funkcja do zaokrąglania
  const formatNumber = useCallback((num: number): number => {
    return Number(num.toFixed(decimalPlaces));
  }, [decimalPlaces]);

  const rowHeaders = selectedSheetJSON?.slice(1).map((row) => row[0] ?? "") ?? [];
  const colHeaders = selectedSheetJSON?.[0]?.slice(2).map((cell) => cell ?? "") ?? [];

  useEffect(() => {
    // Zsynchronizuj dane z TableStore przy pierwszym załadowaniu
    if (!hasInitializedRef.current) {
      hydrateFromTableStore();
    }
  }, [hydrateFromTableStore]);

  useEffect(() => {
    const fetchTrainDevide = async () => {
      if (!selectedSheetJSON) return;
      const res = await fetch(`${API_URL}/calc/mult_stoch`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userId,
          paid_weights: [],
          paid_data: selectedSheetJSON,
          cl_data: [],
          cl_weights: [],
          triangle_raw: selectedSheetJSON,
          cl_weights_raw: [],
        }),
      });

      const json = await res.json();

      if (json.train_devide) {
        let matrix: number[][] = json.train_devide;
        const lastRow = matrix.at(-1);
        if (lastRow && lastRow.every((val) => val === 1)) {
          matrix = matrix.slice(0, -1);
        }
        
        // Zapisz oryginalne dane
        setOriginalTrainDevide(matrix);
        
        // Zaokrąglij dane w trójkącie przy pierwszym ładowaniu
        const roundedMatrix = matrix.map(row => 
          row.map(val => typeof val === 'number' ? formatNumber(val) : val)
        );
        
        setTrainDevide(roundedMatrix);
        setVolume(roundedMatrix.length);
        if (!selectedCells) {
          const selected = roundedMatrix.map((row) => row.map(() => 1));
          setSelectedCells(selected);
        }
      }
    };

    if (!hasInitializedRef.current && selectedSheetJSON) {
      fetchTrainDevide();
      hasInitializedRef.current = true;
    }
  }, [selectedSheetJSON, selectedCells, setSelectedCells, formatNumber, userId, setTrainDevide, triangleType]);

  // Gdy zmienią się dane arkusza, wymuś ponowną inicjalizację i przeliczenie volume
  useEffect(() => {
    hasInitializedRef.current = false;
  }, [selectedSheetJSON]);

  // NAPRAWIONE: Resetuj inicjalizację gdy zmienia się triangleType
  useEffect(() => {
    hasInitializedRef.current = false;
  }, [triangleType]);

  // Automatycznie aktualizuj współczynniki gdy zmieni się decimalPlaces
  useEffect(() => {
    if (originalDev.length > 0) {
      setDev(originalDev);
      setSd(originalSd);
      setSigma(originalSigma);
    }
  }, [decimalPlaces, originalDev, originalSd, originalSigma, setDev, setSd, setSigma]);

  if (!trainDevide || !selectedCells) {
    return <div className="text-red-400 p-6 text-center text-lg">Brak danych w arkuszu...</div>;
  }

  // Handler Min/Max
  const handleMinMaxHighlighting = () => {
    setMinMaxHighlighting(!minMaxHighlighting);
  };

  // Handler resetowania wykluczeń
  const handleResetWeights = () => {
    setVolume(getMaxVolume());
    resetWeightsToInitial();
  };

  // Sprawdź dostępność cl_initial dla aktywnego trójkąta
  const hasClInitial = triangleType === 'incurred' 
    ? (cl_initial_inc && cl_initial_inc.length > 0)
    : (cl_initial && cl_initial.length > 0);

  const handleSubmit = async () => {
    if (!selectedSheetJSON) {
      alert("Brakuje danych do wysłania.");
      return;
    }

    try {
      const effectiveWeights = getEffectiveWeights();
      const safeWeights = effectiveWeights?.map((r) => r.map((c) => (c === 1 ? 1 : 0))) ?? [];
      
      const res = await fetch(`${API_URL}/calc/wspolczynniki_boot`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userId,
          wagi_boot: safeWeights,
          paid_data: selectedSheetJSON,
          triangle: selectedSheetJSON,
        }),
      });

      const data = await res.json();

      // Zapisz oryginalne wartości
      setOriginalDev(data.dev || []);
      setOriginalSd(data.sd || []);
      setOriginalSigma(data.sigma || []);

      // Ustaw oryginalne wartości (bez zaokrąglania)
      setDev(data.dev || []);
      setSd(data.sd || []);
      setSigma(data.sigma || []);

      const { setDev: setBootDev, setSd: setBootSd, setSigma: setBootSigma } = useBootResultsStore.getState();
      setBootDev(data.dev || []);
      setBootSd(data.sd || []);
      setBootSigma(data.sigma || []);

      setVersion((v) => v + 1);
    } catch (err) {
      console.error('❌ Błąd podczas wysyłania:', err);
    }
  };


  return (
    <div className="flex gap-8 p-8">
      {/* Panel boczny */}
      <div className="w-64 shrink-0 space-y-4">
        {/* Kontrolka miejsc po przecinku */}
        <div className="bg-gray-800 rounded-lg p-4">
          <label className="text-white text-sm font-medium mb-2 block">Miejsca po przecinku</label>
          <input
            type="number"
            min="0"
            max="100"
            value={decimalPlaces}
            onChange={(e) => {
              const newDecimalPlaces = parseInt(e.target.value) || 0;
              setDecimalPlaces(newDecimalPlaces);
              
              // Funkcja do zaokrąglania z nową precyzją
              const formatWithNewPrecision = (num: number) => Number(num.toFixed(newDecimalPlaces));
              
              // Zaokrąglij dane w trójkącie współczynników z oryginalnych wartości
              if (originalTrainDevide && originalTrainDevide.length > 0) {
                const roundedTriangle = originalTrainDevide.map(row => 
                  row.map(val => typeof val === 'number' ? formatWithNewPrecision(val) : val)
                );
                setTrainDevide(roundedTriangle);
              }
              
              // Współczynniki będą automatycznie zaktualizowane przez useEffect
            }}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        
        {/* Kontrolka Volume */}
        <div className="bg-gray-800 rounded-lg p-4">
          <label className="text-white text-sm font-medium mb-2 block">Volume</label>
          <input
            type="number"
            min="1"
            max={maxVolume}
            value={volume}
            onChange={(e) => {
              const val = parseInt(e.target.value);
              if (!isNaN(val) && val >= 1 && val <= maxVolume) {
                setVolume(val);
              }
            }}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <div className="text-xs text-gray-400 mt-1">
            Max: {maxVolume} | Aktywne: {triangleType} | Źródło: {weightSource}
          </div>
        </div>
        
        {/* Wybór źródła wag */}
        <div className="bg-gray-800 rounded-lg p-4">
          <label className="text-white text-sm font-medium mb-2 block">
            Wagi współczynników
          </label>
          <div className="space-y-2">
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="weightSource"
                value="default"
                checked={weightSource === 'default'}
                onChange={(e) => setWeightSource(e.target.value as 'default' | 'cl_initial')}
                className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 focus:ring-blue-500 focus:ring-2"
              />
              <span className="ml-2 text-white text-sm">Domyślne</span>
            </label>
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="weightSource"
                value="cl_initial"
                checked={weightSource === 'cl_initial'}
                onChange={(e) => setWeightSource(e.target.value as 'default' | 'cl_initial')}
                className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 focus:ring-blue-500 focus:ring-2"
                disabled={!hasClInitial}
              />
              <span className={`ml-2 text-sm ${!hasClInitial ? 'text-gray-500' : 'text-white'}`}>
                Zadane ({triangleType})
                {!hasClInitial && ' (brak danych)'}
              </span>
            </label>
          </div>
        </div>
        
        {/* 1. Pokaż Min/Max Button */}
        <button
          onClick={handleMinMaxHighlighting}
          className="w-full py-4 px-5 bg-gradient-to-r from-gray-600 to-gray-500 text-white rounded-xl font-bold hover:from-gray-700 hover:to-gray-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
        >
          {minMaxHighlighting ? '🔍 Ukryj Min/Max' : '🔍 Pokaż Min/Max'}
        </button>
        
        {/* 2. Reset wykluczeń */}
        <button
          onClick={handleResetWeights}
          className="w-full py-4 px-5 bg-gradient-to-r from-orange-600 to-orange-500 text-white rounded-xl font-bold hover:from-orange-700 hover:to-orange-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
        >
          Reset wykluczeń
        </button>
        
        {/* 3. Oblicz */}
        <button
          onClick={handleSubmit}
          className="w-full py-4 px-5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl font-bold hover:from-emerald-700 hover:to-emerald-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
        >
          Wyznacz współczynniki
        </button>
        
        {/* Legenda Min/Max */}
        {minMaxHighlighting && (
          <div className="bg-gray-800 rounded-lg p-4">
            <h5 className="text-white text-sm font-medium mb-3">Legenda Min/Max</h5>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-green-50 border-2 border-green-500 rounded flex-shrink-0"></div>
                <span className="text-gray-300">Minimum</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-red-50 border-2 border-red-500 rounded flex-shrink-0"></div>
                <span className="text-gray-300">Maximum</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-yellow-100 border-2 border-yellow-500 rounded flex-shrink-0"></div>
                <span className="text-gray-300">Min & Max</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Tabela */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white mb-6">
          <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
            <h3 className="font-bold text-gray-800 text-lg tracking-tight">Trójkąt współczynników rok do roku</h3>
          </div>
          <div className="overflow-auto p-4" style={{ maxHeight: 'calc(100vh - 400px)' }}>
            <TrainDevideTable
              data={trainDevide}
              rowHeaders={rowHeaders}
              colHeaders={colHeaders}
              selected={getEffectiveWeights()}
              onClick={toggleWeightCell}
              onToggleRow={toggleRow}
              showRowToggle={true}
              decimalPlaces={decimalPlaces}
              minCells={minMaxHighlighting ? minCells : []}
              maxCells={minMaxHighlighting ? maxCells : []}
              minMaxCells={minMaxHighlighting ? minMaxCells : []}
            />
          </div>
        </div>

        {(dev.length || sd.length || sigma.length) > 0 && (
          <div key={version} className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white">
            <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
              <h4 className="font-bold text-gray-800 text-lg tracking-tight">Współczynniki</h4>
            </div>
            <div className="overflow-x-auto p-4">
              <table className="min-w-max bg-white rounded-xl shadow-md text-sm" style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
                <thead>
                  <tr>
                    <th className="border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold text-left w-48 rounded-tl-xl">Rodzaj</th>
                    {colHeaders.map((header, i) => {
                      const isLast = i === colHeaders.length - 1;
                      const cellWidth = Math.max(120, 80 + decimalPlaces * 12);
                      return (
                        <th
                          key={i}
                          style={{ width: `${cellWidth}px` }}
                          className={`border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold text-center ${isLast ? 'rounded-tr-xl' : ''}`}
                        >
                          {header}
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody>
                  {[
                    { label: 'Dev', data: dev, setter: setDev },
                    { label: 'SD', data: sd, setter: setSd },
                    { label: 'σ', data: sigma, setter: setSigma },
                  ].map((row, i) => {
                    const isLastRow = i === 2;
                    return (
                      <tr key={i} className="hover:bg-gray-50">
                        <td className={`border border-gray-300 px-3 py-2 bg-gray-50 font-medium w-48 text-gray-900 ${isLastRow ? 'rounded-bl-xl' : ''}`}>{row.label}</td>
                        {row.data.map((val, j) => {
                          const isLastCell = j === row.data.length - 1;
                          const cellWidth = Math.max(120, 80 + decimalPlaces * 12);
                          return (
                            <td
                              key={j}
                              style={{ width: `${cellWidth}px` }}
                              className={`border border-gray-300 px-3 py-2 text-center bg-white text-gray-900 ${isLastRow && isLastCell ? 'rounded-br-xl' : ''}`}
                            >
                              <input
                                type="text"
                                value={val.toFixed(decimalPlaces)}
                                onChange={(e) => {
                                  const newValue = parseFloat(e.target.value);
                                  if (!isNaN(newValue)) {
                                    const updatedData = [...row.data];
                                    updatedData[j] = newValue;
                                    row.setter(updatedData);
                                  }
                                }}
                                className="bg-transparent text-center w-full px-1 outline-none focus:bg-gray-100 rounded text-gray-900"
                              />
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
