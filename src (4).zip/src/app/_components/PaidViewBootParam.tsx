'use client';

import { useEffect, useMemo, useRef } from 'react';
import { TableData } from '@/components/TableData';
import { useBootParamStore } from '@/stores/bootParamStore';
import { useTableStore } from '@/stores/tableStore';
import { useMutation } from '@tanstack/react-query';
import { useUserStore } from '@/app/_components/useUserStore';
const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export function PaidViewBootParam() {
  const userId = useUserStore((s) => s.userId);

  // Bezpieczne nasłuchiwanie głównego store
  const mainSheetJSON = useTableStore((state) => state.selectedSheetJSON);
  const mainSheetName = useTableStore((state) => state.selectedSheetName);
  const activeStochTriangle = useTableStore((state) => state.activeStochTriangle);
  
  // Dynamiczny tytuł
  const triangleType = activeStochTriangle ?? 'paid';
  const title = triangleType === 'paid' ? 'Trójkąt Paid – wczytane dane' : 'Trójkąt Incurred – wczytane dane';
  
  // Ref do śledzenia poprzednich wartości
  const prevDataRef = useRef<{ json: any; name: string | undefined }>({ json: null, name: undefined });

  const {
    selectedWeights: selectedCells,
    selectedSheetJSON: sheetJSON,
    selectedSheetName: sheetName,
    hydrateFromTableStore,
  } = useBootParamStore();

  // Sprawdź czy dane się zmieniły i zaktualizuj tylko wtedy
  useEffect(() => {
    const currentData = { json: mainSheetJSON, name: mainSheetName };
    const prevData = prevDataRef.current;
    
    // Sprawdź czy dane rzeczywiście się zmieniły
    if (mainSheetJSON && (
      prevData.json !== currentData.json || 
      prevData.name !== currentData.name
    )) {
      hydrateFromTableStore();
      console.log('[PaidViewBootParam] Aktualizacja danych z głównego store');
      prevDataRef.current = currentData;
    }
  }, [mainSheetJSON, mainSheetName, hydrateFromTableStore]);

  const mutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${API_URL}/calc/wspolczynniki_boot`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_id: userId,
          wagi_boot: selectedCells,
          paid_data: sheetJSON,
        }),
      });

      if (!res.ok) throw new Error('Błąd backendu');
      return res.json();
    },
    onSuccess: (data) => {
      console.log('✅ BootParam OK', data);
    },
    onError: (err) => console.error('❌ BootParam error:', err),
  });

  if (!sheetJSON) {
    return <div className="text-red-400">Brak danych arkusza</div>;
  }

  return (
    <div className="flex gap-8 p-8">
      {/* Tabela */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white">
          <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
            <h3 className="font-bold text-gray-800 text-lg tracking-tight">{title}</h3>
          </div>
          <div className="overflow-auto p-4" style={{ maxHeight: 'calc(100vh - 300px)' }}>
            <TableData data={sheetJSON} variant="light" />
          </div>
        </div>
      </div>
    </div>
  );
}
