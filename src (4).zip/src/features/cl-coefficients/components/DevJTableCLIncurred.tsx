'use client';

import React from 'react';
import { CoefficientsChart } from './CoefficientsChart';

import DevJTableBase from '@/shared/ui/organisms/DevJTable/DevJTableBase';
import type { DevJResult } from '@/shared/ui/organisms/DevJTable/DevJTableBase';

import { fmt, mergePreview } from '@/shared/ui/organisms/DevJTable/useDevJHelpers';

import { useTrainDevideStoreDetIncurred } from '@/stores/trainDevideStoreDeterministycznyIncurred';
import type { CustomCell } from '@/stores/trainDevideStoreDeterministycznyIncurred';

type Props = {
  devJResults: DevJResult[];
  selectedVolume?: number;
  selectedSubIndex?: number;
  onSelectVolume: (v: number, subIndex?: number) => void;
  columnLabels?: string[]; // opcjonalne etykiety kolumn
  externalShowChart?: boolean; // prop do kontrolowania wykresu z zewnątrz
  onScrollToChart?: () => void; // callback po kliknięciu przycisku wykresu
};

export default function DevJTableCLIncurred({
  devJResults,
  selectedVolume,
  selectedSubIndex,
  onSelectVolume,
  columnLabels,
  externalShowChart = false,
  onScrollToChart,
}: Props) {
  /* --------------------- store selectors -------------------- */
  const {
    finalDevJ,
    setFinalDevJ,
    devFinalCustom,
    setDevFinalValue,
    clearDevFinalValue,
    clearAllDevFinalValues,
    setDevPreviewCandidate,

    isConfirmModalOpen,
    openConfirmModal,
    closeConfirmModal,
    confirmFinalDevJ,
    
    decimalPlaces, // dodane dla formatowania
    trainDevideDetIncurred, // dla wykresów
    
    // Stany wykresu z store
    chartSelectedColumn,
    chartReferenceType,
    setChartSelectedColumn,
    setChartReferenceType,
  } = useTrainDevideStoreDetIncurred();

  /* --------------------- chart states ---------------------- */
  const [showChart, setShowChart] = React.useState(false);
  // Usunięte lokalne stany - teraz używamy store
  // const [selectedColumnForChart, setSelectedColumnForChart] = React.useState(0);
  // const [selectedReferenceType, setSelectedReferenceType] = React.useState('none');
  
  // Wartość zewnętrzna lub wewnętrzna
  const effectiveShowChart = externalShowChart || showChart;
  
  // Ref do scrollowania
  const chartRef = React.useRef<HTMLDivElement>(null);

  /* --------------------- helpers ---------------------------- */
  const maxLen = React.useMemo(() => {
    if (trainDevideDetIncurred && trainDevideDetIncurred.length > 0) {
      return Math.max(...trainDevideDetIncurred.map((row: number[]) => row.length));
    }
    return Math.max(...devJResults.map((r) => r.values.length));
  }, [devJResults, trainDevideDetIncurred]);

  // Lista dostępnych kolumn do wyboru
  const availableColumns = React.useMemo(() => {
    return Array.from({ length: maxLen }, (_, j) => ({
      index: j,
      label: (columnLabels && columnLabels.length > j ? columnLabels[j] : `j=${j}`) || `col-${j}`
    }));
  }, [maxLen, columnLabels]);

  // Dostępne volume do linii odniesienia
  const availableVolumes = React.useMemo(() => {
    return devJResults.map((result, index) => ({
      index,
      label: `Volume ${result.volume}${result.subIndex ? `.${result.subIndex}` : ''}`,
      result
    }));
  }, [devJResults]);

  // Funkcja formatowania z uwzględnieniem decimalPlaces ze store
  const formatNumber = React.useCallback((n?: number) => {
    if (typeof n !== 'number') return '-';
    return n.toFixed(decimalPlaces);
  }, [decimalPlaces]);

  const displayed = (j: number) => {
    const cell = (devFinalCustom as Record<number, CustomCell>)?.[j];
    return cell ? cell.value : finalDevJ?.values[j];
  };

  // Funkcja do znajdowania odpowiedniego odchylenia standardowego dla wybranego współczynnika
  const getSelectedStandardDeviation = (j: number) => {
    const selectedValue = displayed(j);
    if (selectedValue === undefined) return undefined;

    // Sprawdź czy to custom value z informacją o źródle
    const customCell = (devFinalCustom as Record<number, CustomCell>)?.[j];
    if (customCell && customCell.sourceVolume !== undefined) {
      // Znajdź odpowiednie volume w devJResults
      const sourceResult = devJResults.find(
        (result) => 
          result.volume === customCell.sourceVolume && 
          (result.subIndex ?? 0) === (customCell.sourceSubIndex ?? 0)
      );
      return sourceResult?.sdValues?.[j];
    }

    // Dla wartości z finalDevJ
    if (finalDevJ?.values[j] === selectedValue) {
      return finalDevJ?.sdValues?.[j];
    }

    return undefined;
  };

  // Funkcja do pobierania precyzyjnych selekcji (nie wszystkich o tej samej wartości)
  const getCustomSelections = () => {
    const selections: Record<number, { sourceVolume: number; sourceSubIndex?: number }> = {};
    
    // Dodaj custom selections z devFinalCustom
    Object.entries(devFinalCustom ?? {}).forEach(([j, cell]) => {
      if (cell.sourceVolume !== undefined) {
        selections[Number(j)] = {
          sourceVolume: cell.sourceVolume,
          sourceSubIndex: cell.sourceSubIndex,
        };
      }
    });
    
    // Dodaj selections z finalDevJ (jeśli nie ma custom override)
    if (finalDevJ) {
      Array.from({ length: maxLen }).forEach((_, j) => {
        if (selections[j]) return; // skip jeśli już ma custom selection
        
        const value = finalDevJ.values[j];
        if (value !== undefined) {
          selections[j] = {
            sourceVolume: finalDevJ.volume,
            sourceSubIndex: finalDevJ.subIndex,
          };
        }
      });
    }
    
    return selections;
  };

  // Transformacja danych dla wykresu - wybrana kolumna vs wszystkie wolumy (z tabeli współczynników)
  const transformDataForChart = React.useCallback(() => {
    if (!trainDevideDetIncurred || trainDevideDetIncurred.length === 0 || chartSelectedColumn >= maxLen) return [];
    
    const chartData: Array<{
      volumeLabel: string;
      volume: number;
      value: number;
    }> = [];
    
    trainDevideDetIncurred.forEach((row, rowIndex) => {
      const value = row[chartSelectedColumn];
      // Tylko rzeczywiste liczby - pomijamy null, undefined, NaN
      if (typeof value === 'number' && !isNaN(value) && isFinite(value)) {
        chartData.push({
          volumeLabel: `Wiersz ${rowIndex + 1}`,
          volume: rowIndex + 1, // używamy indeksu wiersza jako volume
          value: value
        });
      }
    });
    
    console.log('[DevJTableCLIncurred] Chart data for column', chartSelectedColumn, ':', chartData);
    
    return chartData;
  }, [trainDevideDetIncurred, chartSelectedColumn, maxLen]);

  // Funkcja do pobierania wartości referencyjnej
  const getReferenceValue = React.useCallback(() => {
    if (!trainDevideDetIncurred || chartReferenceType === 'none') return null;
    
    if (chartReferenceType === 'initial') {
      // Initial Selection - z finalDevJ lub devJResults
      if (finalDevJ && finalDevJ.values.length > chartSelectedColumn) {
        return finalDevJ.values[chartSelectedColumn];
      }
    } else if (chartReferenceType.startsWith('volume_')) {
      // Volume z numerem - znajdź odpowiedni result w devJResults
      const parts = chartReferenceType.split('_');
      if (parts.length >= 2 && parts[1]) {
        const volumeNum = parseInt(parts[1]);
        const subIndex = parts.length > 2 && parts[2] ? parseInt(parts[2]) : 0;
        
        // Znajdź odpowiedni result w devJResults
        const result = devJResults.find(
          r => r.volume === volumeNum && (r.subIndex ?? 0) === subIndex
        );
        
        if (result && result.values.length > chartSelectedColumn) {
          const value = result.values[chartSelectedColumn];
          return typeof value === 'number' && !isNaN(value) ? value : null;
        }
      }
    }
    
    return null;
  }, [trainDevideDetIncurred, chartReferenceType, chartSelectedColumn, finalDevJ, devJResults]);

  const chartData = transformDataForChart();
  const referenceValue = getReferenceValue();

  // Automatyczne przewijanie do wykresu gdy externalShowChart się włącza
  React.useEffect(() => {
    if (externalShowChart && chartRef.current) {
      // Małe opóźnienie żeby wykres się wyrenderował
      setTimeout(() => {
        chartRef.current?.scrollIntoView({ 
          behavior: 'smooth', 
          block: 'start' 
        });
      }, 100);
    }
  }, [externalShowChart]);

  const handleCell = (j: number, v: number, sourceVolume: number, sourceSubIndex?: number, sourceCoeffCount?: number) => {
    const resolvedSourceCoeffCount = sourceCoeffCount ?? devJResults.find(
      (r) => r.volume === sourceVolume && (r.subIndex ?? 0) === (sourceSubIndex ?? 0)
    )?.coeffCounts?.[j];

    // Sprawdź czy kliknięto na dokładnie tę samą komórkę (volume + subIndex + wartość)
    const customCell = (devFinalCustom as Record<number, CustomCell>)?.[j];
    const isExactSameCell = customCell && 
      customCell.value === v && 
      customCell.sourceVolume === sourceVolume && 
      (customCell.sourceSubIndex ?? 0) === (sourceSubIndex ?? 0) &&
      customCell.sourceCoeffCount === resolvedSourceCoeffCount;
    
    if (isExactSameCell) {
      // Klik na dokładnie tę samą komórkę - odznacz
      clearDevFinalValue(j);
    } else {
      // Zaznacz nową komórkę
      setDevFinalValue(j, 'dev_j', v, sourceVolume, sourceSubIndex, resolvedSourceCoeffCount);
    }
  };

  const handleSelectFinal = (v: number, subIndex?: number) => {
    onSelectVolume(v, subIndex);
    // Usunięte automatyczne ustawianie Final? - użytkownik wybiera to ręcznie
  };

  const handleSelectAsBaseFinal = (v: number, subIndex?: number) => {
    const res = devJResults.find((r) => r.volume === v && (r.subIndex ?? 0) === (subIndex ?? 0));
    if (!res) return;

    if (Object.keys(devFinalCustom ?? {}).length) {
      openConfirmModal(res);
    } else {
      clearAllDevFinalValues();
      setFinalDevJ(res);
    }
  };

  /* auto-select first volume for display, but Final? is user choice */
  React.useEffect(() => {
    // Automatycznie wybierz pierwszy wiersz do podglądu Initial Selection
    if (devJResults.length > 0 && !finalDevJ) {
      const firstResult = devJResults[0];
      if (firstResult) {
        clearAllDevFinalValues();
        setFinalDevJ(firstResult); // Potrzebne dla tabeli Initial Selection
        onSelectVolume(firstResult.volume, firstResult.subIndex);
      }
    }
  }, [devJResults, finalDevJ, setFinalDevJ, clearAllDevFinalValues, onSelectVolume]);

  /* preview update */
  React.useEffect(() => {
    if (!finalDevJ?.values) return;
    setDevPreviewCandidate(
      mergePreview(finalDevJ.values, devFinalCustom as any)
    );
  }, [finalDevJ, devFinalCustom, setDevPreviewCandidate]);

  /* --------------------- render ------------------------------ */
  return (
    <>
      <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white mb-8">
        <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
          <h3 className="font-bold text-gray-800 text-lg tracking-tight">
            Tabela ważonych uśrednionych współczynników
          </h3>
        </div>
        <div className="overflow-auto p-4">
          <DevJTableBase
            results={devJResults}
            maxLength={maxLen}
            columnLabels={columnLabels}
            displayed={displayed}
            selectedVolume={selectedVolume}
            selectedSubIndex={selectedSubIndex}
            onSelectVolume={handleSelectFinal}
            finalSelectedVolume={finalDevJ?.volume}
            finalSelectedSubIndex={finalDevJ?.subIndex}
            onSelectFinal={handleSelectAsBaseFinal}
            onCellToggle={handleCell}
            isConfirmModalOpen={isConfirmModalOpen}
            onConfirmFinal={confirmFinalDevJ}
            onCancelConfirm={closeConfirmModal}
            formatNumber={formatNumber} // przekazanie funkcji formatowania
            customSelections={getCustomSelections()} // precyzyjne podświetlanie
          />
        </div>
      </div>

      {/* Tabela odchylen standardowych */}
      {devJResults.length > 0 && (
        <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white mb-8">
          <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
            <h3 className="font-bold text-gray-800 text-lg tracking-tight">
              Tabela ważonych uśrednionych odchyleń standardowych
            </h3>
          </div>
          
          {/* wrapper: pełna szerokość + poziomy scroll */}
          <div className="overflow-auto p-4">
            <div className="relative w-full max-w-full overflow-x-auto">
            <table className="min-w-max bg-white rounded-xl shadow-md text-sm" style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
              <thead>
                <tr>
                  <th className="border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold text-left w-48 rounded-tl-xl">Volume</th>
                  {Array.from({ length: maxLen }).map((_, j) => {
                    const isLast = j === maxLen - 1
                    return (
                      <th
                        key={j}
                        className={`border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold text-center w-24 ${isLast ? 'rounded-tr-xl' : ''}`}
                      >
                        {columnLabels && columnLabels.length > j ? columnLabels[j] : `j=${j}`}
                      </th>
                    )
                  })}
                </tr>
              </thead>

              <tbody>
                {devJResults.map((result, rowIdx) => {
                  const isLastRow = rowIdx === devJResults.length - 1
                  return (
                  <tr
                    key={`${result.volume}-${result.subIndex ?? 0}`}
                    className={
                      selectedVolume === result.volume && 
                      selectedSubIndex === (result.subIndex ?? 0)
                        ? "bg-blue-100" // podswietlenie aktualnie wybranego volume
                        : "hover:bg-gray-50"
                    }
                  >
                    <td className={`border border-gray-300 px-3 py-2 bg-gray-50 text-gray-900 font-medium w-48 ${isLastRow ? 'rounded-bl-xl' : ''}`}>
                      Volume {result.volume}{result.subIndex !== undefined ? `.${result.subIndex}` : ''}
                    </td>
                    {Array.from({ length: maxLen }).map((_, j) => {
                      const sdValue = result.sdValues?.[j];
                      
                      // Sprawdź czy to konkretnie ta komórka została wybrana (nie tylko ta sama wartość)
                      const customCell = (devFinalCustom as Record<number, CustomCell>)?.[j];
                      const isThisSpecificCellSelected = customCell && 
                        customCell.sourceVolume === result.volume && 
                        (customCell.sourceSubIndex ?? 0) === (result.subIndex ?? 0);
                      
                      // Sprawdź czy wybrana jest komórka z finalDevJ dla tego volume
                      const isFinalDevJSelected = !customCell && 
                        finalDevJ?.volume === result.volume && 
                        (finalDevJ?.subIndex ?? 0) === (result.subIndex ?? 0) &&
                        displayed(j) !== undefined;
                      
                      const isSelected = isThisSpecificCellSelected || isFinalDevJSelected;
                      const isLastCell = j === maxLen - 1
                      
                      return (
                        <td
                          key={j}
                          className={`border border-gray-300 px-3 py-2 text-center transition-colors w-24 ${isLastRow && isLastCell ? 'rounded-br-xl' : ''} ${
                            result.sdValues?.[j] !== undefined
                              ? isSelected 
                                ? "bg-blue-200/70 text-gray-800 cursor-pointer"
                                : "bg-white text-gray-800 hover:bg-gray-100 cursor-pointer"
                              : "bg-gray-200 text-gray-500"
                          }`}
                          onClick={() => {
                            // Klik na odchylenie standardowe automatycznie wybiera odpowiedni współczynnik
                            if (result.values[j] !== undefined) {
                              handleCell(j, result.values[j], result.volume, result.subIndex, result.coeffCounts?.[j]);
                            }
                          }}
                        >
                          {sdValue !== undefined ? formatNumber(sdValue) : "–"}
                        </td>
                      );
                    })}
                  </tr>
                )})}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {finalDevJ && (
  <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white mb-8">
    <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
      <h3 className="font-bold text-gray-800 text-lg tracking-tight">
        Tabela wybranych współczynników do dopasowania krzywej
      </h3>
    </div>

    {/* wrapper z poziomym scrollem */}
    <div className="overflow-auto p-4">
      <div className="relative w-full max-w-full overflow-x-auto">
      <table className="min-w-max bg-white rounded-xl shadow-md text-sm" style={{ borderCollapse: 'separate', borderSpacing: 0 }}>
        <thead>
          <tr>
            <th className="border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold text-left w-48 rounded-tl-xl"></th>
            {Array.from({ length: maxLen }).map((_, j) => {
              const isLast = j === maxLen - 1
              return (
                <th
                  key={j}
                  className={`border border-gray-300 px-3 py-2 bg-gradient-to-r from-gray-100 to-gray-50 text-gray-800 font-semibold text-center w-24 ${isLast ? 'rounded-tr-xl' : ''}`}
                >
                  {columnLabels && columnLabels.length > j ? columnLabels[j] : `j=${j}`}
                </th>
              )
            })}
          </tr>
        </thead>

        <tbody>
          <tr>
            <td className={`border border-gray-300 px-3 py-2 bg-gray-50 font-medium w-48 text-gray-900 ${devJResults.length === 0 ? 'rounded-bl-xl' : ''}`}>
              Initial Selection
            </td>
            {Array.from({ length: maxLen }).map((_, j) => {
              const isLast = j === maxLen - 1
              return (
                <td
                  key={j}
                  className={`border border-gray-300 px-3 py-2 text-center bg-white text-gray-900 w-24 ${devJResults.length === 0 && isLast ? 'rounded-br-xl' : ''}`}
                >
                  {formatNumber(displayed(j))}
                </td>
              )
            })}
          </tr>
          {devJResults.length > 0 && (
            <tr>
              <td className="border border-gray-300 px-3 py-2 bg-gray-50 font-medium w-48 text-gray-900 rounded-bl-xl">
                Odchyl. Standardowe
              </td>
              {Array.from({ length: maxLen }).map((_, j) => {
                // Sprawdź czy komórka j jest wybrana
                const isSelected = displayed(j) !== undefined;
                // Znajdź odpowiednie odchylenie dla wybranego współczynnika
                const sdValue = isSelected ? getSelectedStandardDeviation(j) : undefined;
                const isLast = j === maxLen - 1
                
                return (
                  <td
                    key={j}
                    className={`border border-gray-300 px-3 py-2 text-center bg-white text-gray-900 w-24 ${isLast ? 'rounded-br-xl' : ''}`}
                  >
                    {sdValue !== undefined ? formatNumber(sdValue) : "–"}
                  </td>
                );
              })}
            </tr>
          )}
        </tbody>
      </table>
      </div>
    </div>
  </div>
)}

{/* Wykres współczynników rozwoju - pod tabelą Initial Selection */}
{externalShowChart && chartData.length > 0 && (
  <div className="rounded-2xl border border-gray-300 shadow-2xl overflow-hidden bg-gradient-to-br from-gray-50 to-white mb-8" ref={chartRef}>
    <div className="bg-gradient-to-r from-gray-100 to-gray-50 px-5 py-4 border-b-2 border-gray-400 rounded-t-2xl">
      <h3 className="font-bold text-gray-800 text-lg tracking-tight">
        Współczynniki rok do roku
      </h3>
    </div>
    <div className="p-4">
    
    {/* Kontrolki wykresu */}
    <div className="mb-6 p-6 bg-gray-100 rounded-lg border border-gray-300">
      <div className="flex flex-wrap items-start gap-6">
        <div className="flex flex-col gap-2">
          <label className="text-gray-700 font-semibold text-sm">Wybierz kolumnę:</label>
          <select
            value={chartSelectedColumn}
            onChange={(e) => {
              const newColumn = Number(e.target.value);
              console.log('[DevJTableCLIncurred] Changing column to:', newColumn);
              setChartSelectedColumn(newColumn);
            }}
            size={5}
            className="px-4 py-2 bg-white text-gray-800 border border-gray-300 rounded-md focus:border-indigo-500 focus:outline-none min-w-[120px] text-sm shadow-sm"
          >
            {availableColumns.map((col) => (
              <option key={col.index} value={col.index}>
                {col.label}
              </option>
            ))}
          </select>
        </div>
        
        <div className="flex flex-col gap-2">
          <label className="text-gray-700 font-semibold text-sm">Średni współczynnik:</label>
          <select
            value={chartReferenceType}
            onChange={(e) => {
              setChartReferenceType(e.target.value);
            }}
            size={5}
            className="px-4 py-2 bg-white text-gray-800 border border-gray-300 rounded-md focus:border-indigo-500 focus:outline-none min-w-[140px] text-sm shadow-sm"
          >
            <option value="none">Brak</option>
            {availableVolumes.map((vol) => (
              <option key={`volume_${vol.result.volume}_${vol.result.subIndex ?? 0}`} value={`volume_${vol.result.volume}_${vol.result.subIndex ?? 0}`}>
                {vol.label}
              </option>
            ))}
            <option value="initial">Initial Selection</option>
          </select>
        </div>
        
        <div className="flex flex-col gap-2 justify-end">
          <span className="text-gray-600 text-sm font-medium">
            Dane: {chartData.length} punkt{chartData.length !== 1 ? 'y' : ''}
            {referenceValue !== null && referenceValue !== undefined && (
              <span className="block">Ref: {referenceValue.toFixed(6)}</span>
            )}
          </span>
        </div>
      </div>
    </div>
    
    <CoefficientsChart
      title={`Współczynniki rok-do-roku dla kolumny: ${availableColumns[chartSelectedColumn]?.label || chartSelectedColumn}`}
      data={chartData.map((item, index) => ({
        period: index + 1,
        series: [{
          name: item.volumeLabel,
          value: item.value,
          volume: item.volume
        }]
      }))}
      selectedPeriod={undefined}
      onPeriodSelect={() => {}}
      referenceValue={referenceValue}
      referenceLabel={chartReferenceType === 'none' ? undefined : 
        chartReferenceType === 'initial' ? 'Initial Selection' :
        chartReferenceType.startsWith('volume_') ? (() => {
          const parts = chartReferenceType.split('_');
          if (parts.length >= 2 && parts[1]) {
            const volumeNum = parseInt(parts[1]);
            const subIndex = parts.length > 2 && parts[2] ? parseInt(parts[2]) : undefined;
            return availableVolumes.find(v => v.result.volume === volumeNum && (v.result.subIndex ?? 0) === (subIndex ?? 0))?.label || `Volume ${volumeNum}`;
          }
          return 'Unknown Volume';
        })() : undefined}
    />
    </div>
  </div>
)}

    </>
  );
}
