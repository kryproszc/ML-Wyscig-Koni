/* ------------------------------------------------------------------ */
/*                      Sigma Summary Configuration                   */
/* ------------------------------------------------------------------ */

import type { SummaryConfig } from '@/shared/types/summaryConfig'

export const sigmaSummaryConfig: SummaryConfig = {
  tableContext: 'Sigma',
  
  // Store selectors - leftCount
  leftCountSelector: (s) => s.leftCountSigma,
  setLeftCountSelector: (s) => s.setLeftCountSigma,
  
  // Store selectors - selectedCurve  
  selectedCurveSelector: (s) => s.selectedCurveSigma,
  setSelectedCurveSelector: (s) => s.setSelectedCurveSigma,
  
  // Store selectors - manualOverrides
  manualOverridesSelector: (s) => s.manualOverridesSigma,
  setManualOverridesSelector: (s) => s.setManualOverridesSigma,
  
  // Store selectors - sourceSwitches
  sourceSwitchesSelector: (s) => s.sourceSwitchesSigma,
  setSourceSwitchesSelector: (s) => s.setSourceSwitchesSigma,
  
  // Store selectors - dane bazowe
  baseDataSelector: (s) => s.sigmaPreview,
  simResultsSelector: (s) => s.simResultsSigma,
  
  // Store selectors - kombinowane dane
  setCombinedDataSelector: (s) => s.setCombinedSigmaSummary,
  
  // Store selectors - pozostałe
  setRemainingHeadersSelector: (s) => s.setRemainingDevJHeaders,
  
  // Brak transformacji dla Sigma - dane używane bezpośrednio
  disabledCurves: [], // Wszystkie krzywe odblokowane dla Sigma
  debugLabel: 'PaidSigmaSummaryTab - selectedCurve (Sigma)'
}