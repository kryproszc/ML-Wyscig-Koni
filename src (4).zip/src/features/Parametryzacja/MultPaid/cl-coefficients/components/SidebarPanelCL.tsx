'use client';

import { useState } from 'react';
import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useDisplaySettingsPaidStore } from '@/stores/useDisplaySettingsPaidStore';
import SidebarPanelBase from '@/shared/ui/molecules/SidebarPanelBase'
import { exportDevJToExcel } from '@/untils/exportToExcel';
import { Button } from '@/components/ui/button';
import { Maximize2, Plus, Minus } from 'lucide-react';

type Props = {
  onCalculate: () => void;
  className?: string;
};

export default function SidebarPanelCL({ onCalculate, className  }: Props) {
  const store = useTrainDevideStoreDet();
  const [resetOpen, setResetOpen] = useState(false);

  // Display settings for fullscreen and scale
  const fullscreenMode = useDisplaySettingsPaidStore((s) => s.fullscreenMode);
  const tableScale = useDisplaySettingsPaidStore((s) => s.tableScale);
  const setFullscreenMode = useDisplaySettingsPaidStore((s) => s.setFullscreenMode);
  const increaseScale = useDisplaySettingsPaidStore((s) => s.increaseScale);
  const decreaseScale = useDisplaySettingsPaidStore((s) => s.decreaseScale);

  const {
    volume, setVolume,
    clearDevJResults,
    setFinalDevJ,
    clearAllDevFinalValues,
    clearSigmaResults,
    setFinalSigma,
    clearAllSigmaFinalValues,
    clearFitCurveData,
    clearDevSummaryData,
    clearAllWeightsDet,
    openMissingFinalModal,
    isMissingFinalModalOpen,
    closeMissingFinalModal,
    finalDevJ,
    finalDevVector,
    devFinalCustom,
    devJResults,
    minMaxHighlighting,
    setMinMaxHighlighting,
    decimalPlaces,
    setDecimalPlaces,
    selectedWeightsDet,
    trainDevideDet,
    safeWeights,
  } = store;

  const overrides = Object.entries(devFinalCustom).map(([idx, c]) => ({
    index: +idx,
    curve: c.curve,
    value: c.value,
  }));

  const handleExport = () => {
    if (!finalDevJ?.values?.length) {
      openMissingFinalModal();
      return;
    }
    exportDevJToExcel(devJResults, finalDevJ, finalDevVector, overrides);
  };

  const handleReset = () => {
    clearDevJResults();
    setFinalDevJ(undefined);
    clearAllDevFinalValues();
    clearSigmaResults();
    setFinalSigma(undefined);
    clearAllSigmaFinalValues();
    clearFitCurveData();
    clearDevSummaryData();
    clearAllWeightsDet(); // Resetuj zaznaczenia w tabeli współczynników rok do roku
  };

  const toggleMinMax = () => {
    setMinMaxHighlighting(!minMaxHighlighting);
  };

  const logSafeWeights = () => {
    if (!safeWeights) {
      console.log('❌ Brak safeWeights w store - wywołaj store.calculateSafeWeights()');
      return;
    }

    console.log('🟦 === SAFEWEIGHTS ZE STORE ===');
    safeWeights.forEach((row, i) => {
      console.log(`Wiersz ${i}:`, row);
    });
    
    console.log('📊 Statystyki safeWeights ze store:', {
      rows: safeWeights.length,
      cols: safeWeights[0]?.length || 0,
      totalSelected: safeWeights.flat().filter(w => w === 1).length,
      totalZeros: safeWeights.flat().filter(w => w === 0).length,
      source: 'STORE'
    });
  };

  // Komponent kontrolek rozmiaru - używany w panelu bocznym
  const ScaleControls = () => (
    <div className="flex items-center gap-2">
      <Button
        onClick={decreaseScale}
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
        disabled={tableScale <= 0.5}
      >
        <Minus className="w-4 h-4" />
      </Button>
      
      <span className="text-white text-sm min-w-[3rem] text-center">
        {Math.round(tableScale * 100)}%
      </span>
      
      <Button
        onClick={increaseScale}
        variant="outline"
        size="sm"
        className="w-8 h-8 p-0 text-white border-gray-600 hover:bg-gray-700"
        disabled={tableScale >= 2.0}
      >
        <Plus className="w-4 h-4" />
      </Button>
    </div>
  );

  return (
    <div className={`w-64 shrink-0 space-y-4 ${className ?? ''}`}>   {/* <-- UŻYJ */}
      {/* Kontrolka zaokrąglania - na górze */}
      <div className="bg-gray-800 rounded-lg p-4">
        <label className="text-white text-sm font-medium mb-2 block">
          Miejsca po przecinku
        </label>
        <input
          type="number"
          min="0"
          max="10"
          value={decimalPlaces}
          onChange={(e) => setDecimalPlaces(Number(e.target.value))}
          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
        <div className="text-xs text-gray-400 mt-1">
          Współczynniki będą zaokrąglone do {decimalPlaces} miejsc
        </div>
      </div>

      <SidebarPanelBase
        volume={volume}
        onVolumeChange={setVolume}
        onCalculate={onCalculate}
        onExport={handleExport}
        onReset={handleReset}
        isResetModalOpen={resetOpen}
        setResetModalOpen={setResetOpen}
        isMissingFinalModalOpen={isMissingFinalModalOpen}
        closeMissingFinalModal={closeMissingFinalModal}
      />

      {/* Min/Max Button */}
      <button
        onClick={toggleMinMax}
        className={`w-full py-3 px-4 rounded-lg font-medium transition-colors ${
          minMaxHighlighting
            ? 'bg-yellow-600 hover:bg-yellow-700 text-white'
            : 'bg-gray-600 hover:bg-gray-700 text-white'
        }`}
      >
        {minMaxHighlighting ? '🔍 Ukryj Min/Max' : '🔍 Pokaż Min/Max'}
      </button>

      {/* Debug: Show SafeWeights Button */}
      <button
        onClick={logSafeWeights}
        className="w-full py-3 px-4 rounded-lg font-medium transition-colors bg-blue-600 hover:bg-blue-700 text-white"
      >
        🟦 SafeWeights ze Store
      </button>

      {/* Ustawienia wyświetlania */}
      <div className="bg-gray-800 rounded-lg p-4">
        <div className="text-white text-lg font-medium mb-4">
          Ustawienia wyświetlania
        </div>
        
        <div className="space-y-4">
          <div>
            <label className="text-white text-sm font-medium mb-2 block">
              Rozmiar tabeli
            </label>
            <ScaleControls />
          </div>
          
          <Button
            onClick={() => setFullscreenMode(true)}
            variant="destructive"
            size="sm"
            className="w-full"
          >
            <Maximize2 className="w-4 h-4 mr-2" />
            Pełny ekran
          </Button>
        </div>
      </div>
    </div>
  );
}