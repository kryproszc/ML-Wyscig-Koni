/* ------------------------------------------------------------------ */
/*                     IncurredDevSummaryTab.tsx                     */
/* ------------------------------------------------------------------ */
"use client"

import React, { useEffect, useMemo } from 'react'
import { useTrainDevideStoreDetIncurred } from '@/stores/trainDevideStoreDeterministycznyIncurred'
import { useLabelsStore } from '@/stores/useLabelsStore'
import { DevSummaryLayout } from '@/shared/components/DevelopmentEnd'

export default function IncurredDevSummaryTab() {
  // Store selectors
  const leftCount = useTrainDevideStoreDetIncurred(s => s.leftCountSummary)
  const setLeftCount = useTrainDevideStoreDetIncurred(s => s.setLeftCountSummary)
  const selectedCurve = useTrainDevideStoreDetIncurred(s => s.selectedCurveSummary)
  const setSelectedCurve = useTrainDevideStoreDetIncurred(s => s.setSelectedCurveSummary)
  const manualOverrides = useTrainDevideStoreDetIncurred(s => s.manualOverridesSummary)
  const setManualOverrides = useTrainDevideStoreDetIncurred(s => s.setManualOverridesSummary)
  const sourceSwitches = useTrainDevideStoreDetIncurred(s => s.sourceSwitchesSummary)
  const setSourceSwitches = useTrainDevideStoreDetIncurred(s => s.setSourceSwitchesSummary)
  const devJPreview = useTrainDevideStoreDetIncurred(s => s.devJPreview)
  const simResults = useTrainDevideStoreDetIncurred(s => s.simResults)
  const setCombinedDevJSummary = useTrainDevideStoreDetIncurred(s => s.setCombinedDevJSummary)
  const ultimateFromIndexSummary = useTrainDevideStoreDetIncurred(s => s.ultimateFromIndexSummary)
  const setUltimateFromIndexSummary = useTrainDevideStoreDetIncurred(s => s.setUltimateFromIndexSummary)
  const decimalPlaces = useTrainDevideStoreDetIncurred(s => s.decimalPlaces)

  // Labels from store
  const rawIncurredColumnLabels = useLabelsStore(s => s.incurredColumnLabels)
  
  const incurredColumnLabels = useMemo(
    () => ["", ...rawIncurredColumnLabels],
    [rawIncurredColumnLabels]
  )

  // Callback to save remaining dev_j headers
  const setRemainingDevJHeaders = useTrainDevideStoreDetIncurred(s => s.setRemainingDevJHeaders)

  useEffect(() => {
    if (!devJPreview || devJPreview.length === 0) return

    if (leftCount <= 0 || leftCount > devJPreview.length) {
      setLeftCount(devJPreview.length)
    }
  }, [devJPreview, leftCount, setLeftCount])

  return (
    <DevSummaryLayout
      leftCount={leftCount}
      setLeftCount={setLeftCount}
      selectedCurve={selectedCurve}
      setSelectedCurve={setSelectedCurve}
      manualOverrides={manualOverrides}
      setManualOverrides={setManualOverrides}
      sourceSwitches={sourceSwitches}
      setSourceSwitches={setSourceSwitches}
      devJPreview={devJPreview}
      simResults={simResults}
      setCombinedDevJ={setCombinedDevJSummary}
      columnLabels={incurredColumnLabels}
      ultimateFromIndex={ultimateFromIndexSummary}
      setUltimateFromIndex={setUltimateFromIndexSummary}
      onRemainingDevJHeaders={setRemainingDevJHeaders}
      decimalPlaces={decimalPlaces}
    />
  )
}
