/* ------------------------------------------------------------------ */
/*                      Results Summary Page                           */
/* ------------------------------------------------------------------ */

'use client';

import { useCallback, useState } from 'react';
import Modal from '@/components/Modal';
import WeightedTable from '@/components/WeightedTable';

import { useTrainDevideStoreDet } from '@/stores/trainDevideStoreDeterministyczny';
import { useTrainDevideStoreDetIncurred } from '@/stores/trainDevideStoreDeterministycznyIncurred';
import { useTrainDevideStoreSummary } from '@/stores/trainDevideStoreSummary';

import { buildPayload } from '@/shared/utils/summaryUtils';
import { useSummaryDropdownOptions } from '@/shared/hooks/useSummaryDropdownOptions';
import { ResultsExportModal } from '../components/ResultsExportModal';

const API = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000';

export default function ResultsSummaryPage() {
  /* ----- store Paid ----- */
  const simPaid = useTrainDevideStoreDet(s => s.simResults) ?? {};
  const devJPaid = useTrainDevideStoreDet(s => s.devJResults) ?? [];
  const finalPaid = useTrainDevideStoreDet(s => s.finalDevVector) ?? [];
  const combPaid = useTrainDevideStoreDet(s => s.combinedDevJSummary) ?? [];

  /* ----- store Incurred ----- */
  const simInc = useTrainDevideStoreDetIncurred(s => s.simResults) ?? {};
  const devJInc = useTrainDevideStoreDetIncurred(s => s.devJResults) ?? [];
  const finalInc = useTrainDevideStoreDetIncurred(s => s.finalDevVector) ?? [];
  const combInc = useTrainDevideStoreDetIncurred(s => s.combinedDevJSummary) ?? [];

  /* ----- Summary store ----- */
  const {
    selectedPaid,
    selectedIncurred,
    setSelectedPaid,
    setSelectedIncurred,
    comparisonRows,
    setComparisonRows,
  } = useTrainDevideStoreSummary();

  /* ----- modal ----- */
  const [showModal, setShowModal] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  
  /* ----- WeightedTable data ----- */
  const [weightedTableData, setWeightedTableData] = useState<{
    enrichedRows: Array<{
      paid: number;
      wPaid: number;
      incurred: number;
      wInc: number;
      sum: number;
    }>;
    grandTotal: number;
  } | null>(null);

  /* ----- dropdown options using shared hook ----- */
  const paidOptions = useSummaryDropdownOptions(
    simPaid, 
    devJPaid, 
    combPaid, 
    finalPaid, 
    'Paid'
  );

  const incurredOptions = useSummaryDropdownOptions(
    simInc, 
    devJInc, 
    combInc, 
    finalInc, 
    'Incurred'
  );

  /* ----- wysyłka ----- */
  const handleSend = useCallback(async () => {
    if (!selectedPaid || !selectedIncurred) {
      setShowModal(true);
      return;
    }

    const paidTriangle = useTrainDevideStoreDet.getState().paidTriangle ?? [];
    const incTriangle = useTrainDevideStoreDetIncurred.getState().incurredTriangle ?? [];

    const paidCoeff = buildPayload(selectedPaid, simPaid, devJPaid, finalPaid, combPaid);
    const incCoeff = buildPayload(selectedIncurred, simInc, devJInc, finalInc, combInc);

    if (!paidCoeff || !incCoeff) {
      console.error('❌ Nie udało się zbudować zestawów współczynników.');
      return;
    }

    const payload = {
      paid_data_det: paidTriangle,
      incurred_data_det: incTriangle,
      paid_coeff_set: paidCoeff,
      incurred_coeff_set: incCoeff,
    };

    try {
      const res = await fetch(`${API}/calc/summary/save_vector`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error(`status ${res.status}`);

      const json = await res.json();
      if (json.comparison) setComparisonRows(json.comparison);
    } catch (e) {
      console.error('❌ Błąd wysyłki:', e);
    }
  }, [
    selectedPaid, selectedIncurred,
    simPaid, devJPaid, finalPaid, combPaid,
    simInc, devJInc, finalInc, combInc,
    setComparisonRows,
  ]);

  /* ----- WeightedTable callback ----- */
  const handleWeightedTableChange = useCallback((enrichedRows: any[], grandTotal: number) => {
    setWeightedTableData({ enrichedRows, grandTotal });
  }, []);

  /* ====================== UI ====================== */
  return (
    <div className="grid grid-cols-[300px_1fr] gap-10 p-6 text-white">
      {/* ────── lewa kolumna ────── */}
      <div className="flex flex-col gap-6 w-full max-w-md">
        <h2 className="text-lg font-semibold">Podsumowanie Paid + Incurred</h2>

        {/* select Paid */}
        <select
          className="bg-gray-700 rounded p-2"
          value={selectedPaid ?? ''}
          onChange={e => setSelectedPaid(e.target.value || null)}
        >
          <option value="">-- Wybierz Paid --</option>
          {paidOptions.map(o => (
            <option key={o.key} value={o.key}>{o.label}</option>
          ))}
        </select>

        {/* select Incurred */}
        <select
          className="bg-gray-700 rounded p-2"
          value={selectedIncurred ?? ''}
          onChange={e => setSelectedIncurred(e.target.value || null)}
        >
          <option value="">-- Wybierz Incurred --</option>
          {incurredOptions.map(o => (
            <option key={o.key} value={o.key}>{o.label}</option>
          ))}
        </select>

        {/* przycisk wyslij */}
        <button
          onClick={handleSend}
          className="w-full py-4 px-5 bg-gradient-to-r from-emerald-600 to-emerald-500 text-white rounded-xl font-bold hover:from-emerald-700 hover:to-emerald-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
        >
          📤 Oblicz
        </button>

        {/* przycisk eksport wyników */}
        <button
          onClick={() => setShowExportModal(true)}
          className="w-full py-4 px-5 bg-gradient-to-r from-amber-600 to-amber-500 text-white rounded-xl font-bold hover:from-amber-700 hover:to-amber-600 transition-all duration-200 shadow-lg hover:shadow-2xl hover:scale-[1.02] transform"
        >
          📊 Eksport wyników
        </button>

        <Modal
          isOpen={showModal}
          title="Wymagane dane"
          message="Musisz wskazać jeden zestaw Paid oraz jeden Incurred."
          onCancel={() => setShowModal(false)}
          onlyOk
        />

        <ResultsExportModal
          isOpen={showExportModal}
          onClose={() => setShowExportModal(false)}
          weightedSummaryData={weightedTableData}
        />
      </div>

      {/* ────── prawa kolumna ────── */}
      <div className="flex-1 overflow-auto">
        {comparisonRows.length > 0 && (
          <WeightedTable
            rows={comparisonRows.map(r => ({
              paid: Number((r as any).Paid ?? r.paid),
              incurred: Number((r as any).Incurred ?? r.incurred),
            }))}
            onChange={handleWeightedTableChange}
          />
        )}
      </div>
    </div>
  );
}
