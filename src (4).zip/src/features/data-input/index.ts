// Eksport komponentów wczytywania danych
export { InputDataTab } from './InputDataTabRefactored';
export { InputDataTabDet } from './InputDataTabDet';
export { InputDataTabIncurred } from './InputDataTabDetIncurred';
export { InputDataTabTest } from './InputDataTabTest';
export { InputDataTabTestIncurred } from './InputDataTabTestIncurred';
// Re-eksport dla kompatybilności wstecznej
export { InputDataTab as InputDataTabRefactored } from './InputDataTabRefactored';
