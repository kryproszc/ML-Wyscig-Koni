export { useCheckAssumptionData } from './useCheckAssumptionData';
