/* ------------------------------------------------------------------ */
/*                  Combined Export Dialog Component                   */
/* ------------------------------------------------------------------ */

import React from 'react';
import type { CombinedExportItem } from '../hooks/useCombinedResultsExport';

export interface CombinedExportDialogProps {
  isOpen: boolean;
  exportItems: CombinedExportItem[];
  selectedCount: number;
  onClose: () => void;
  onToggleItem: (key: string) => void;
  onToggleAll: () => void;
  onExport: () => void;
}

export const CombinedExportDialog: React.FC<CombinedExportDialogProps> = ({
  isOpen,
  exportItems,
  selectedCount,
  onClose,
  onToggleItem,
  onToggleAll,
  onExport,
}) => {
  if (!isOpen) return null;

  const allSelected = exportItems.length > 0 && exportItems.every(item => item.selected);
  const someSelected = selectedCount > 0 && selectedCount < exportItems.length;

  // Group items by category and type
  const groupedItems = exportItems.reduce((acc, item) => {
    const key = `${item.category}-${item.type}`;
    if (!acc[key]) {
      acc[key] = [];
    }
    acc[key].push(item);
    return acc;
  }, {} as Record<string, CombinedExportItem[]>);

  const getGroupTitle = (key: string) => {
    const [category, type] = key.split('-');
    if (category === 'calculations') {
      return type === 'paid' ? '📊 Obliczenia Paid' : '📈 Obliczenia Incurred';
    } else if (category === 'comparisons') {
      return type === 'paid' ? '🔍 Paid Porównania' : '🔍 Incurred Porównania';
    } else if (category === 'summary') {
      return '📋 Podsumowanie ważone';
    }
    return 'Inne';
  };

  const getGroupColor = (key: string) => {
    const [category, type] = key.split('-');
    if (category === 'summary') {
      return 'text-purple-400';
    }
    return type === 'paid' ? 'text-blue-400' : 'text-green-400';
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
      <div className="bg-gray-700 rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[80vh] flex flex-col border border-gray-600">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-white">📂 Łączny eksport do Excel</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white text-2xl leading-none"
          >
            ×
          </button>
        </div>

        <div className="mb-4 p-3 bg-gray-800 rounded-lg">
          <p className="text-gray-300 text-sm mb-2">
            🗂️ Wszystkie zaznaczone dane zostaną wyeksportowane do jednego pliku Excel z oddzielnymi zakładkami:
          </p>
          <ul className="text-gray-400 text-xs space-y-1">
            <li>• <span className="text-blue-400">Obliczenia Paid</span> - trójkąt danych, współczynniki CL i wybrane krzywe</li>
            <li>• <span className="text-green-400">Obliczenia Incurred</span> - trójkąt danych, współczynniki CL i wybrane krzywe</li>
            <li>• <span className="text-blue-400">Paid Porównania</span> - tabele porównawcze Paid dla różnych współćzynników</li>
            <li>• <span className="text-green-400">Incurred Porównania</span> - tabele porównawcze Incurred dla różnych współćzynników</li>
            <li>• <span className="text-purple-400">Podsumowanie ważone</span> - tabela końcowa ważonych Paid i Incurred</li>
          </ul>
        </div>

        <div className="mb-4">
          <label className="flex items-center text-white cursor-pointer">
            <input
              type="checkbox"
              checked={allSelected}
              ref={input => {
                if (input) input.indeterminate = someSelected;
              }}
              onChange={onToggleAll}
              className="mr-2 scale-110"
            />
            <span className="font-medium">
              {allSelected ? 'Odznacz wszystko' : 'Zaznacz wszystko'} 
              {selectedCount > 0 && ` (${selectedCount}/${exportItems.length})`}
            </span>
          </label>
        </div>

        <div className="flex-1 overflow-y-auto mb-4 max-h-96">
          <div className="space-y-4">
            {Object.entries(groupedItems).map(([groupKey, items]) => (
              <div key={groupKey} className="space-y-2">
                <h3 className={`font-semibold ${getGroupColor(groupKey)} border-b border-gray-600 pb-1`}>
                  {getGroupTitle(groupKey)} ({items.filter(item => item.selected).length}/{items.length})
                </h3>
                <div className="space-y-1 pl-4">
                  {items.map((item) => (
                    <label
                      key={item.key}
                      className="flex items-center text-white cursor-pointer hover:bg-gray-700 p-2 rounded"
                    >
                      <input
                        type="checkbox"
                        checked={item.selected}
                        onChange={() => onToggleItem(item.key)}
                        className="mr-3 scale-110"
                      />
                      <span className="text-sm">{item.label.replace(/^(Paid|Incurred): /, '')}</span>
                    </label>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-3 pt-4 border-t border-gray-600">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2 bg-gray-600 hover:bg-gray-500 rounded font-semibold transition text-white"
          >
            Anuluj
          </button>
          <button
            onClick={onExport}
            disabled={selectedCount === 0}
            className="flex-1 px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-500 disabled:cursor-not-allowed rounded font-semibold transition text-white"
          >
            📥 Eksportuj do Excel ({selectedCount})
          </button>
        </div>
      </div>
    </div>
  );
};
