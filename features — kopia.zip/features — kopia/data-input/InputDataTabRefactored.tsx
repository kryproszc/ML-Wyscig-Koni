'use client';

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useState } from "react";
import { useTableStore } from "@/stores/tableStore";
import { useLabelsStore } from "@/stores/useLabelsStore";
import { resetAllStores } from "@/lib/resetAllStores";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Card, CardHeader, CardTitle,
  CardContent, CardFooter
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Zrefaktoryzowane komponenty i hooki
import { useFileUpload } from "@/hooks/useFileUpload";
import { validateDataValues } from "@/utils/dataValidation";
import { convertIncrementalToCumulative } from "@/utils/dataConversion";
import { CustomAlertDialog } from "@/components/CustomAlertDialog";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import Modal from "@/components/Modal";
import { FileUploadSection, RangeInputSection } from "@/components/InputFormSections";

const schema = z.object({
  rowStart: z.coerce.number().min(1),
  rowEnd: z.coerce.number().min(1),
  colStart: z.coerce.number().min(1),
  colEnd: z.coerce.number().min(1),
  file: z.any()
});

type FormField = z.infer<typeof schema>;

type AlertState = {
  show: boolean;
  variant: 'error' | 'warning' | 'success' | 'info';
  title: string;
  message: string;
};

export function InputDataTab() {
  // Stany alertów
  const [alertState, setAlertState] = useState<AlertState>({
    show: false,
    variant: 'info',
    title: '',
    message: ''
  });

  // Stan modala ostrzeżenia
  const [showWarningModal, setShowWarningModal] = useState(false);
  const [pendingFormData, setPendingFormData] = useState<FormField | null>(null);

  // Hook do uploadu plików
  const { isLoading, progress, handleFileLoad } = useFileUpload();

  // Store'y
  const {
    workbook,
    isValid,
    selectedSheetJSON,
    previousSheetJSON,
    validationErrorReason,
    getDefaultRange,
    setRangeAndUpdate,
    uploadedFileName,
    selectedSheetName,
    setSelectedSheetName,
    getSheetNames,
  } = useTableStore();

  const { 
    rowLabels, 
    columnLabels, 
    setRowLabels, 
    setColumnLabels,
    globalRowLabels,
    globalColumnLabels,
    lastLoadedFile
  } = useLabelsStore();

  // Store dla ustawień input'a - używamy indywidualnych ustawień z tableStore
  const {
    triangleType,
    dataType,
    setTriangleType,
    setDataType,
    hasHeaders,
    setHasHeaders,
  } = useTableStore();

  // Formularz
  const {
    register,
    handleSubmit,
    watch,
    setValue,
  } = useForm<FormField>({
    resolver: zodResolver(schema),
    defaultValues: {
      rowStart: 1,
      rowEnd: 1,
      colStart: 1,
      colEnd: 1,
    }
  });

  const file = watch("file");

  // Synchronizacja formularza z store'em
  useEffect(() => {
    const { startRow, endRow, startCol, endCol } = useTableStore.getState();
    setValue("rowStart", startRow);
    setValue("rowEnd", endRow);
    setValue("colStart", startCol);
    setValue("colEnd", endCol);
  }, [setValue]);

  useEffect(() => {
    const unsubscribe = useTableStore.subscribe((state) => {
      setValue("rowStart", state.startRow);
      setValue("rowEnd", state.endRow);
      setValue("colStart", state.startCol);
      setValue("colEnd", state.endCol);
    });
    return unsubscribe;
  }, [setValue]);

  // 🆕 Reagowanie na zmianę ustawienia hasHeaders - odświeżenie nazw
  useEffect(() => {
    const { selectedSheetJSON } = useTableStore.getState();
    if (selectedSheetJSON && selectedSheetJSON.length > 0) {
      let rowNames: string[];
      let colNames: string[];
      
      if (hasHeaders) {
        // ZAWIERA podpisy - zczytujemy nazwy z pierwszej kolumny/wiersza
        rowNames = selectedSheetJSON.map((row, index) => 
          row[0] ? String(row[0]) : `Wiersz ${index + 1}`
        );
        
        colNames = selectedSheetJSON[0]?.map((cell, index) => 
          cell ? String(cell) : `Kolumna ${index + 1}`
        ) || [];
      } else {
        // NIE ZAWIERA podpisów - indeksujemy numerycznie od 0 
        rowNames = selectedSheetJSON.map((_, index) => `${index}`);
        colNames = selectedSheetJSON[0]?.map((_, index) => `${index}`) || [];
      }
      
      setRowLabels(rowNames);
      setColumnLabels(colNames);
      
      console.log('🔄 Odświeżono nazwy (hasHeaders:', hasHeaders, '):', { rowNames, colNames });
    }
  }, [hasHeaders, setRowLabels, setColumnLabels]);

  // Funkcje pomocnicze
  const showAlert = (variant: AlertState['variant'], title: string, message: string) => {
    setAlertState({ show: true, variant, title, message });
  };

  const hideAlert = () => {
    setAlertState(prev => ({ ...prev, show: false }));
  };

  const handleAutoRange = () => {
    const range = getDefaultRange();
    if (!range) return;
    setValue("rowStart", range.startRow);
    setValue("rowEnd", range.endRow);
    setValue("colStart", range.startCol);
    setValue("colEnd", range.endCol);
  };

  const onSubmit = async (data: FormField) => {
    hideAlert();

    // Sprawdź czy już są wczytane dane
    const hasExistingData = selectedSheetJSON && selectedSheetJSON.length > 0;
    
    if (hasExistingData) {
      // Zapisz dane formularza i pokaż modal ostrzeżenia
      setPendingFormData(data);
      setShowWarningModal(true);
      return;
    }

    // Jeśli nie ma danych, wykonaj normalnie
    processFormData(data);
  };

  // Funkcja do przetwarzania danych formularza
  const processFormData = (data: FormField) => {
    // Reset wszystkich store'ów przy wczytywaniu nowych danych
    resetAllStores();
    
    setRangeAndUpdate({
      startRow: data.rowStart,
      endRow: data.rowEnd,
      startCol: data.colStart,
      endCol: data.colEnd
    });

    setTimeout(() => {
      let { isValid, selectedSheetJSON, previousSheetJSON } = useTableStore.getState();
      
      // Zapisz nazwy kolumn i wierszy w zależności od ustawienia hasHeaders
      if (selectedSheetJSON && selectedSheetJSON.length > 0) {
        let rowNames: string[];
        let colNames: string[];
        
        if (hasHeaders) {
          // ZAWIERA podpisy - zczytujemy nazwy z pierwszej kolumny/wiersza
          rowNames = selectedSheetJSON.map((row, index) => 
            row[0] ? String(row[0]) : `Wiersz ${index + 1}`
          );
          
          colNames = selectedSheetJSON[0]?.map((cell, index) => 
            cell ? String(cell) : `Kolumna ${index + 1}`
          ) || [];
        } else {
          // NIE ZAWIERA podpisów - indeksujemy numerycznie od 0 
          rowNames = selectedSheetJSON.map((_, index) => `${index}`);
          colNames = selectedSheetJSON[0]?.map((_, index) => `${index}`) || [];
        }
        
        setRowLabels(rowNames);
        setColumnLabels(colNames);
        
        console.log('📝 Zapisano nazwy (hasHeaders:', hasHeaders, '):', { rowNames, colNames });
        console.log('🔺 Wybrany typ trójkąta:', triangleType);
      }
      
      // Jeśli wybrano dane inkrementalne, konwertuj je na skumulowane
      if (dataType === 'incremental' && selectedSheetJSON) {
        console.log('🔄 Konwertuję dane inkrementalne na skumulowane...');
        const convertedData = convertIncrementalToCumulative(selectedSheetJSON);
        
        // Aktualizuj store z przekonwertowanymi danymi
        useTableStore.setState({ selectedSheetJSON: convertedData });
        selectedSheetJSON = convertedData;
        
        console.log('✅ Dane przekonwertowane:', convertedData);
      }

      const isSameData = JSON.stringify(selectedSheetJSON) === JSON.stringify(previousSheetJSON);

      if (!isValid) {
        showAlert('error', 'Błąd danych', validationErrorReason || "Dane wejściowe nie spełniają określonego formatu. Sprawdź dane!");
      } else if (isSameData) {
        showAlert('info', 'Informacja', "Nie dokonano żadnych zmian w danych.");
      } else {
        const validData = validateDataValues(selectedSheetJSON || []);
        if (!validData) {
          showAlert('warning', 'Ostrzeżenie', "Dane są w poprawnym formacie, ale występują w nich braki lub niedozwolone wartości.");
        } else {
          const dataTypeMessage = dataType === 'incremental' 
            ? "Dane inkrementalne zostały przekonwertowane na skumulowane i poprawnie wczytane."
            : "Dane skumulowane zostały poprawnie wczytane.";
          showAlert('success', 'Powiadomienie', dataTypeMessage);
        }
      }
    }, 0);
  };

  // Obsługa potwierdzenia w modalu
  const handleConfirmDataReplace = () => {
    setShowWarningModal(false);
    
    if (pendingFormData) {
      processFormData(pendingFormData);
      setPendingFormData(null);
    }
  };

  // Obsługa anulowania w modalu
  const handleCancelDataReplace = () => {
    setShowWarningModal(false);
    setPendingFormData(null);
  };

  // Obsługa zmiany arkusza (bez modala - modal jest przy kliknięciu "Wybierz")
  const handleSheetChange = (newSheetName: string) => {
    if (!newSheetName) return;
    setSelectedSheetName(newSheetName);
  };

  // Komponent SheetSelect z modalem ostrzeżenia
  const SheetSelectWithModal = () => {
    const sheetNames = getSheetNames();
    
    return (
      <Select 
        onValueChange={handleSheetChange} 
        value={selectedSheetName ?? ""}
      >
        <SelectTrigger className="w-[200px]">
          <SelectValue placeholder="Wybierz arkusz" />
        </SelectTrigger>
        <SelectContent>
          {sheetNames?.map((name) => (
            <SelectItem key={name} value={name}>
              {name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    );
  };

  return (
    <div>
      {/* FORMULARZ */}
      <form onSubmit={handleSubmit(onSubmit)} className="p-4 border rounded flex flex-col gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Wprowadź dane, które wykorzystasz w zakładce ,,Sprawdzanie założeń" oraz ,,Metody stochastyczne"</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <FileUploadSection
              register={register}
              onFileLoad={() => handleFileLoad(file?.[0])}
              hasFile={file && file.length > 0}
              uploadedFileName={uploadedFileName}
              sheetSelectComponent={<SheetSelectWithModal />}
            />
            <RangeInputSection
              register={register}
              onAutoRange={handleAutoRange}
              workbookExists={!!workbook}
              dataType={dataType}
              onDataTypeChange={setDataType}
              triangleType={triangleType}
              onTriangleTypeChange={setTriangleType}
              hasHeaders={hasHeaders}
              onHeadersChange={setHasHeaders}
            />
          </CardContent>
          <CardFooter>
            <Button
              type="submit"
              className="bg-blue-500 text-white"
              disabled={!workbook}
            >
              Wybierz
            </Button>
          </CardFooter>
        </Card>
      </form>

      {/* UNIFIED ALERT DIALOG */}
      <CustomAlertDialog
        open={alertState.show}
        onOpenChange={hideAlert}
        variant={alertState.variant}
        title={alertState.title}
        message={alertState.message}
        buttonText={alertState.variant === 'error' ? 'Zamknij' : 'OK'}
      />

      {/* LOADING SPINNER */}
      {isLoading && <LoadingSpinner progress={progress} />}

      {/* MODAL OSTRZEŻENIA O UTRACIE DANYCH */}
      <Modal
        title="Ostrzeżenie"
        message="Czy chcesz wczytać nowe dane? Wszystkie obliczenia w metodach stochastycznych zostaną utracone."
        isOpen={showWarningModal}
        onConfirm={handleConfirmDataReplace}
        onCancel={handleCancelDataReplace}
      />
    </div>
  );
}
