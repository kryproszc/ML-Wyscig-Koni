// stores/useTriangleType.ts
import { create } from "zustand";

export type TriangleType = "paid" | "incurred";

type State = {
  triangleType: TriangleType;
  setTriangleType: (t: TriangleType) => void;
};

export const useTriangleType = create<State>((set) => {
  let initial: TriangleType = "paid";
  if (typeof window !== "undefined") {
    try {
      initial = (sessionStorage.getItem("ca_triangle_type") as TriangleType) || "paid";
    } catch {}
  }

  return {
    triangleType: initial,
    setTriangleType: (t) => {
      try { sessionStorage.setItem("ca_triangle_type", t); } catch {}
      set({ triangleType: t });
    },
  };
});
