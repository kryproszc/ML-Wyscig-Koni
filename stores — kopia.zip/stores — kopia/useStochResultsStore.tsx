import { create } from 'zustand';

type StochResultsStore = {
  dev: number[];
  sd: number[];
  sigma: number[];
  decimalPlaces: number;

  setDev: (dev: number[]) => void;
  setSd: (sd: number[]) => void;
  setSigma: (sigma: number[]) => void;
  setDecimalPlaces: (decimalPlaces: number) => void;

  reset: () => void; // ✅ nowa funkcja
};

export const useStochResultsStore = create<StochResultsStore>((set) => ({
  dev: [],
  sd: [],
  sigma: [],
  decimalPlaces: 6,

  setDev: (dev) => set({ dev }),
  setSd: (sd) => set({ sd }),
  setSigma: (sigma) => set({ sigma }),
  setDecimalPlaces: (decimalPlaces) => set({ decimalPlaces }),

  reset: () => set({ dev: [], sd: [], sigma: [], decimalPlaces: 6 }), // ✅ czyści wszystko
}));
