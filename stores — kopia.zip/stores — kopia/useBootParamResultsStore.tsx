import { create } from 'zustand';

interface BootParamResultStore {
  dev: number[];
  sd: number[];
  sigma: number[];
  decimalPlaces: number;
  setDev: (dev: number[]) => void;
  setSd: (sd: number[]) => void;
  setSigma: (sigma: number[]) => void;
  setDecimalPlaces: (decimalPlaces: number) => void;
  reset: () => void; // ✅ dodane
}

export const useBootParamResultsStore = create<BootParamResultStore>((set) => ({
  dev: [],
  sd: [],
  sigma: [],
  decimalPlaces: 6,
  setDev: (dev) => set({ dev }),
  setSd: (sd) => set({ sd }),
  setSigma: (sigma) => set({ sigma }),
  setDecimalPlaces: (decimalPlaces) => set({ decimalPlaces }),
  reset: () => set({ dev: [], sd: [], sigma: [], decimalPlaces: 6 }), // ✅ implementacja resetu
}));
