from fastapi import APIRouter
import numpy as np
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from .models import SimulationClPaidRequest, StatisticClPaidRequest, SimulationClPaidResult, SimulationClIncurredRequest, SimulationClIncurredResult, StatisticClIncurredRequest, AllTestDataRequest, SimulationClIncurredIndependentRequest, StatisticClIncurredIndependentRequest, SimulationClIncurredIndependentResult
from cl_simulator import YearHorizont2
from clinc_simulator import ClincSimulator
from cladd_hybrid import CLADDHybrid
import pandas as pd
router = APIRouter()
yh2 = YearHorizont2()
clinc_simulator = ClincSimulator()
yh3 = CLADDHybrid()

@router.post("/calc/simulationClpaid")
async def simulation_cl_paid(request: SimulationClPaidRequest):
    payload = request.model_dump() if hasattr(request, "model_dump") else request.dict()

    user_id = payload['user_id']
    ilosc_symulacji = payload['ilosc_symulacji']
    ziarno = payload['ziarno']
    podzial_ziarna = payload['podzial_ziarna']
    skalowanie = payload['skalowanie']
    left_count_cl = payload['left_count_cl']
    calculation_options = payload['calculation_options']
    paid_triangle = np.array(payload['paid_triangle'])
    sigma_indexes = np.array(payload['sigma_indexes'])
    selected_value_cl = np.array(payload['selected_value_cl'])
    selected_value_sigma = np.array(payload['selected_value_sigma'])
    tail_count_cl = payload.get('tail_count_cl')  # może być None

    if payload.get('discount_rates') and len(payload['discount_rates']) > 0:
        first_inner = next(iter(payload['discount_rates'].values()))
        discount_rates = np.array(list(first_inner.values()), dtype=float)
    else:
        discount_rates = np.array([], dtype=float)

    if payload.get('netto_brutto') and len(payload['netto_brutto']) > 0:
        first_inner = next(iter(payload['netto_brutto'].values()))
        netto_brutto = np.array(list(first_inner.values()), dtype=float)
    else:
        netto_brutto = np.array([], dtype=float)
    weights = np.array(payload['weights'])
    paid_triangle = np.asarray(paid_triangle, dtype=np.float64)
    cl_indexes = np.asarray([x + 1 for x in payload['cl_indexes']], dtype=np.int32)
 
    sim_results = yh2.run_simulation_cl(
            data_paid = paid_triangle,
            sigma_j = selected_value_sigma,
            dev = selected_value_cl,
            sd =  payload['combined_sd_summary'],
            wagi_trimmed = weights,
            wykluczenia = cl_indexes,
            Poz_CL = left_count_cl,
            il_ogon = tail_count_cl if tail_count_cl is not None else 0,
            discount_factors = discount_rates,
            net_to_gross = netto_brutto,
            latest = 1,
            sim_total=ilosc_symulacji,
            batch_sim=podzial_ziarna,
            main_seed=ziarno
        )

    SimulationClPaidResult(user_id, sim_results)

    return {
            "status": "ok",
            "message": "Dane odebrane i wyświetlone w logach backendu jako numpy arrays."
        }


@router.post("/calc/statisticClpaid")
async def statistic_cl_paid(request: StatisticClPaidRequest):
    payload = request.model_dump() if hasattr(request, "model_dump") else request.dict()
    user_id = payload['user_id']
    skalowanie1 = payload['skalowanie']
    skalowanie2 = payload['skalowanie2']
    result_obj = SimulationClPaidResult.get_for_user(user_id)
    data_deterministic = payload.get('deterministic_results')
    keys = ['last_col','cum_trian', 'ult_net_disc']
    data_deterministic_sum = [sum(data_deterministic[k]) for k in keys]
    modified_data = result_obj.data.copy()  
    if data_deterministic_sum is not None:
        for i in range(len(data_deterministic_sum)):
            if i == 0:
                modified_data[:, i] = skalowanie1*(modified_data[:, i] - data_deterministic_sum[i])
            else:
                modified_data[:, i] = skalowanie1*skalowanie2*(modified_data[:, i] - data_deterministic_sum[i])
    kwantyle = payload['kwantyle']
    stats = []
    column_names = ["Brutto", "Brutto One dyskontowany", "Netto One dyskontowany"]

    for i in range(modified_data.shape[1]):
        col = modified_data[:, i]
        if not np.isnan(col).any():
            mean = np.mean(col)
            std = np.std(col)
            quantiles = np.quantile(col, kwantyle)
            stats.append({
                "column": column_names[i] if i < len(column_names) else f"Kolumna {i}",
                "mean": float(mean),
                "quantiles": [float(q) for q in quantiles],
                "std": float(std),
               "SCR": float(np.quantile(col, 0.995)) - float(mean)
            })

    return {
        "status": "ok",
        "message": "Dane statystyk odebrane pomyślnie.",
        "user_id": user_id,
        "stats": stats,
    }


##### dla incurred
@router.post("/calc/simulationClIncurred")
async def simulation_cl_incurred(request: SimulationClIncurredRequest):
    user_id = request.user_id_incurred

    dev_inc = np.array(request.selected_value_cl_incurred, dtype=np.float64)
    sigma_inc = np.array(request.selected_value_sigma_incurred, dtype=np.float64)
    sd_inc = np.array(request.selected_value_sd_incurred, dtype=np.float64)    
    rj = np.array(request.selected_values_rj_paid_to_incurred, dtype=np.float64)
    varj = np.array(request.selected_values_varj_paid_to_incurred, dtype=np.float64)
    r_i_j = np.array(request.train_paidtoincurred, dtype=np.float64)
    
    lambda_cor = np.array([request.lambda_value], dtype=np.float64)  # Konwersja na tablicę numpy
    traingle_paid_inf = np.array(request.paid_triangle_incurred, dtype=np.float64)
    traingle_incurred_inf = np.array(request.incurred_triangle_incurred, dtype=np.float64)
    data_wagi_cl = np.array(request.weights_incurred, dtype=np.float64)
    data_wagi_pi = np.array(request.weights_rj_incurred, dtype=np.float64)
 
    wykluczenia = np.array([i+1 for i in request.selected_dev_j_indexes_incurred], dtype=np.int32)
    Poz_CL = request.left_count_cl_incurred
    dop_ogo_p_i = False
    il_ogon = request.tail_count_cl_incurred
    wykluczenia_p_i = np.array([i+1 for i in request.selected_rj_paid_to_incurred_indexes_incurred ], dtype=np.int32)
    Poz_CL_p_i = request.tail_count_rj_paid_to_incurred
    
    # Konwersja discount_rates do numpy array
    if request.discount_rates_incurred and len(request.discount_rates_incurred) > 0:
        if isinstance(request.discount_rates_incurred, dict):
            first_inner = next(iter(request.discount_rates_incurred.values()))
            discount_rates = np.array(list(first_inner.values()), dtype=float)
        else:
            discount_rates = np.array(request.discount_rates_incurred, dtype=float)
    else:
        discount_rates = np.array([], dtype=float)
    
    # Konwersja netto_brutto do numpy array
    if request.netto_brutto_incurred and len(request.netto_brutto_incurred) > 0:
        if isinstance(request.netto_brutto_incurred, dict):
            first_inner = next(iter(request.netto_brutto_incurred.values()))
            netto_brutto = np.array(list(first_inner.values()), dtype=float)
        else:
            netto_brutto = np.array(request.netto_brutto_incurred, dtype=float)
    else:
        netto_brutto = np.array([], dtype=float)
        
    sim_total = request.ilosc_symulacji_incurred
    batch_sim = request.ziarno_incurred
    main_seed = 202260011

    #sd_inc[14:] = sd_inc[14:] ** 2

    sim_results = clinc_simulator.run_simulation_clinc(
        dev_inc = dev_inc, sigma_inc = sigma_inc, sd_inc = sd_inc,
        rj = rj, varj = varj, r_i_j = r_i_j, lambda_cor = lambda_cor,
        data_paid_np = traingle_paid_inf, data_inc_np = traingle_incurred_inf,
        weights_np = data_wagi_cl, wykluczenia = wykluczenia,
        Poz_CL = Poz_CL, data_wagi_pi = data_wagi_pi, wykluczenia_p_i = wykluczenia_p_i,
        Poz_CL_p_i = Poz_CL_p_i, dop_ogo_p_i = dop_ogo_p_i,
        il_ogon = il_ogon, discount_factors = discount_rates, net_to_gross = netto_brutto,
        sim_total = sim_total, batch_sim = batch_sim, main_seed = main_seed
    )
    
    SimulationClIncurredResult(user_id, sim_results)
    
    return {"status": "ok"}


@router.post("/calc/statisticClIncurred")
async def statistic_cl_incurred(request: StatisticClIncurredRequest):
    payload = request.model_dump() if hasattr(request, "model_dump") else request.dict()
    user_id = payload['user_id']
    skalowanie1 = payload['skalowanie']
    skalowanie2 = payload['skalowanie2']
    result_obj = SimulationClIncurredResult.get_for_user(user_id)
    data_deterministic = payload.get('deterministic_results')
    keys = ['last_col', 'cum_trian',  'ult_net_disc']
    data_deterministic_sum = [sum(data_deterministic[k]) for k in keys]
    modified_data = result_obj.data.copy()  
    if data_deterministic_sum is not None:
        for i in range(len(data_deterministic_sum)):
            if i == 0:
                modified_data[:, i] = skalowanie1*(modified_data[:, i] - data_deterministic_sum[i])
            else:
                modified_data[:, i] = skalowanie1*skalowanie2*(modified_data[:, i] - data_deterministic_sum[i])
    kwantyle = payload['kwantyle']
    stats = []
    column_names = ["Ultimate Paid", "Ultimate Gross Discounted", "Ultimate Net Discounted"]
    for i in range(modified_data.shape[1]):
        col = modified_data[:, i]
        if not np.isnan(col).any():
            mean = np.mean(col)
            std = np.std(col)
            quantiles = np.quantile(col, kwantyle)
            stats.append({
                "column": i,  # Numer kolumny jako int
                "mean": float(mean),
                "quantiles": [float(q) for q in quantiles],
                "std": float(std),
                "SCR": float(np.quantile(col, 0.995)) - float(mean)
            })

    return {
        "status": "ok",
        "message": "Dane statystyk incurred odebrane pomyślnie.",
        "user_id": user_id,
        "stats": stats,
    }


@router.post("/calc/simulationClIncurredV2")
async def simulation_cl_incurred_v2(request: SimulationClIncurredIndependentRequest):
    user_id = request.user_id_incurred

    dev_inc = np.array(request.selected_value_cl_incurred, dtype=np.float64)
    sigma_inc = np.array(request.selected_value_sigma_incurred, dtype=np.float64)
    sd_inc = np.array(request.selected_value_sd_incurred, dtype=np.float64)
    rj = np.array(request.selected_values_rj_paid_to_incurred, dtype=np.float64)
    varj = np.array(request.selected_values_varj_paid_to_incurred, dtype=np.float64)
    r_i_j = np.array(request.train_paidtoincurred, dtype=np.float64)

    lambda_cor = np.array([request.lambda_value], dtype=np.float64)
    traingle_paid_inf = np.array(request.paid_triangle_incurred, dtype=np.float64)
    traingle_incurred_inf = np.array(request.incurred_triangle_incurred, dtype=np.float64)
    data_wagi_cl = np.array(request.weights_incurred, dtype=np.float64)
    data_wagi_pi = np.array(request.weights_rj_incurred, dtype=np.float64)

    wykluczenia = np.array([i + 1 for i in request.selected_dev_j_indexes_incurred], dtype=np.int32)
    Poz_CL = request.left_count_cl_incurred
    dop_ogo_p_i = False
    il_ogon = request.tail_count_cl_incurred
    wykluczenia_p_i = np.array([i + 1 for i in request.selected_rj_paid_to_incurred_indexes_incurred], dtype=np.int32)
    Poz_CL_p_i = request.tail_count_rj_paid_to_incurred

    if request.discount_rates_incurred and len(request.discount_rates_incurred) > 0:
        if isinstance(request.discount_rates_incurred, dict):
            first_inner = next(iter(request.discount_rates_incurred.values()))
            discount_rates = np.array(list(first_inner.values()), dtype=float)
        else:
            discount_rates = np.array(request.discount_rates_incurred, dtype=float)
    else:
        discount_rates = np.array([], dtype=float)

    if request.netto_brutto_incurred and len(request.netto_brutto_incurred) > 0:
        if isinstance(request.netto_brutto_incurred, dict):
            first_inner = next(iter(request.netto_brutto_incurred.values()))
            netto_brutto = np.array(list(first_inner.values()), dtype=float)
        else:
            netto_brutto = np.array(request.netto_brutto_incurred, dtype=float)
    else:
        netto_brutto = np.array([], dtype=float)

    sim_total = request.ilosc_symulacji_incurred
    batch_sim = request.ziarno_incurred
    main_seed = 202260011

    sim_results = clinc_simulator.run_simulation_clinc(
        dev_inc=dev_inc, sigma_inc=sigma_inc, sd_inc=sd_inc,
        rj=rj, varj=varj, r_i_j=r_i_j, lambda_cor=lambda_cor,
        data_paid_np=traingle_paid_inf, data_inc_np=traingle_incurred_inf,
        weights_np=data_wagi_cl, wykluczenia=wykluczenia,
        Poz_CL=Poz_CL, data_wagi_pi=data_wagi_pi, wykluczenia_p_i=wykluczenia_p_i,
        Poz_CL_p_i=Poz_CL_p_i, dop_ogo_p_i=dop_ogo_p_i,
        il_ogon=il_ogon, discount_factors=discount_rates, net_to_gross=netto_brutto,
        sim_total=sim_total, batch_sim=batch_sim, main_seed=main_seed
    )

    SimulationClIncurredIndependentResult(user_id, sim_results)

    return {"status": "ok"}


@router.post("/calc/statisticClIncurredV2")
async def statistic_cl_incurred_v2(request: StatisticClIncurredIndependentRequest):
    payload = request.model_dump() if hasattr(request, "model_dump") else request.dict()
    user_id = payload['user_id']
    skalowanie1 = payload['skalowanie']
    skalowanie2 = payload['skalowanie2']
    result_obj = SimulationClIncurredIndependentResult.get_for_user(user_id)
    data_deterministic = payload.get('deterministic_results')
    keys = ['last_col', 'cum_trian', 'ult_net_disc']
    data_deterministic_sum = [sum(data_deterministic[k]) for k in keys]
    modified_data = result_obj.data.copy()
    if data_deterministic_sum is not None:
        for i in range(len(data_deterministic_sum)):
            if i == 0:
                modified_data[:, i] = skalowanie1 * (modified_data[:, i] - data_deterministic_sum[i])
            else:
                modified_data[:, i] = skalowanie1 * skalowanie2 * (modified_data[:, i] - data_deterministic_sum[i])
    kwantyle = payload['kwantyle']
    stats = []
    for i in range(modified_data.shape[1]):
        col = modified_data[:, i]
        if not np.isnan(col).any():
            mean = np.mean(col)
            std = np.std(col)
            quantiles = np.quantile(col, kwantyle)
            stats.append({
                "column": i,
                "mean": float(mean),
                "quantiles": [float(q) for q in quantiles],
                "std": float(std),
                "SCR": float(np.quantile(col, 0.995)) - float(mean)
            })

    return {
        "status": "ok",
        "message": "Dane statystyk incurred odebrane pomyślnie.",
        "user_id": user_id,
        "stats": stats,
    }
        
   
   ##############
   
@router.post("/test/all-data")
async def run_simulation_addcl(request: AllTestDataRequest):
    """Odbierz i wyświetl WSZYSTKIE dane z TestTab w jednym requescie"""
    print(f"🎯 TEST ALL DATA - User: {request.user_id}")
    print(f"=" * 80)
    
    try:
        # WSPÓLNE DANE
        print(f"📊 WSPÓLNE DANE:")
        triangle_size = f"{len(request.paid_triangle)}x{len(request.paid_triangle[0]) if request.paid_triangle else 0}"
        print(f"   Trójkąt paid: {triangle_size}")
        print(f"   Calculation options: {request.calculation_options}")
        print(f"   Discount rates: {len(request.discount_rates)} linii")
        print(f"   Netto/brutto: {len(request.netto_brutto)} linii")
        
        # ===== PRZYGOTOWANIE ZMIENNYCH DLA CL =====
        # Konwersja danych z frontu do zmiennych jak w run_simulation_cl
        id_user_cl = request.user_id
        data_paid_cl = np.array(request.paid_triangle, dtype=np.float64)
        sigma_j_cl = np.array(request.cl_selected_value_sigma)
        dev_cl = np.array(request.cl_selected_value_cl)
        sd_cl = request.cl_combined_sd_summary
        wagi_trimmed_cl = np.array(request.cl_weights)
        wykluczenia_cl = np.array([x + 1 for x in request.cl_indexes], dtype=np.int32)
        Poz_CL = request.cl_left_count
        il_ogon_cl = request.cl_tail_count if request.cl_tail_count is not None else 0
        sim_total_cl = request.cl_ilosc_symulacji
        batch_sim_cl = request.cl_podzial_ziarna
        main_seed_cl = request.cl_ziarno
        
        # Discount factors i net_to_gross dla CL
        if request.discount_rates and len(request.discount_rates) > 0:
            first_inner = next(iter(request.discount_rates.values()))
            discount_factors_cl = np.array(list(first_inner.values()), dtype=float)
        else:
            discount_factors_cl = np.array([], dtype=float)
            
        if request.netto_brutto and len(request.netto_brutto) > 0:
            first_inner = next(iter(request.netto_brutto.values()))
            net_to_gross_cl = np.array(list(first_inner.values()), dtype=float)
        else:
            net_to_gross_cl = np.array([], dtype=float)

        data_paid_lr = np.array(request.paid_triangle, dtype=np.float64)
        sigma_j_lr = np.array(request.add_selected_value_sigma)[1:]
        LR = np.array(request.add_selected_value_lr)[1:]
        sd_LR = request.add_combined_sd_summary[1:]
        e_values = np.array(request.add_e_values)[1:]
        wagi_trimmed_lr = np.array(request.add_weights)
        ilosc_dop_wsp_lr = np.array([x + 1 for x in request.add_lr_indexes], dtype=np.int32)
        Poz_LR = request.add_left_count_lr
        il_ogon_lr = request.add_tail_count_lr if request.add_tail_count_lr is not None else 0
        ultimate_param_resrisk = np.array([])
        sim_total_lr = request.add_ilosc_symulacji
        batch_sim_lr = request.add_podzial_ziarna
        main_seed_lr = request.add_ziarno
        discount_factors_lr = discount_factors_cl  # Te same co dla CL
        net_to_gross_lr = net_to_gross_cl  # Te same co dla CL
        
        yh3.run_simulation_addcl(
            data_paid = data_paid_cl,
            sigma_j = sigma_j_cl,
            dev = dev_cl,
            sd =  sd_cl,
            wagi_trimmed = wagi_trimmed_cl,
            wykluczenia = wykluczenia_cl,
            Poz_CL = Poz_CL,
            il_ogon_CL = il_ogon_cl if il_ogon_cl is not None else 0,
            sigma_j_LR=sigma_j_lr,
            dev_LR=LR,
            sd_LR=sd_LR,
            e_values=e_values,
            wagi_trimmed_LR=wagi_trimmed_lr,
            ilosc_dop_wsp_LR=ilosc_dop_wsp_lr, 
            Poz_LR=Poz_LR,
            il_ogon_LR=il_ogon_lr if il_ogon_lr is not None else 0,
            ultimate_param_resrisk = ultimate_param_resrisk,
            sim_total_lr = sim_total_lr,
            batch_sim_lr = batch_sim_lr,
            main_seed_lr = main_seed_lr,
            discount_factors_lr = discount_factors_lr,  # Te same co dla CL
            net_to_gross_lr = net_to_gross_lr)


        return {
            "status": "success"
        }
        
    except Exception as e:
        print(f"❌ BŁĄD: {str(e)}")
        return {"status": "error", "message": str(e)}


    """Odbierz i wyświetl WSZYSTKIE dane z TestTab w jednym requescie"""
    print(f"🎯 TEST ALL DATA - User: {request.user_id}")
    print(f"=" * 80)
    
    # WSPÓLNE DANE
    print(f"📊 WSPÓLNE DANE:")
    print(f"   Trójkąt paid: {len(request.paid_triangle)}x{len(request.paid_triangle[0]) if request.paid_triangle else 0}")
    print(f"   Calculation options: {request.calculation_options}")
    print(f"   Discount rates: {len(request.discount_rates)} linii")
    print(f"   Netto/brutto: {len(request.netto_brutto)} linii")
    
    # CHAIN LADDER DANE
    print(f"\n🔗 CHAIN LADDER DANE:")
    print(f"   Wagi CL: {len(request.cl_weights)}x{len(request.cl_weights[0]) if request.cl_weights else 0}")
    print(f"   CL indexes: {len(request.cl_indexes)} - {request.cl_indexes}")
    print(f"   Sigma indexes: {len(request.cl_sigma_indexes)} - {request.cl_sigma_indexes}")
    print(f"   Left count CL: {request.cl_left_count}")
    print(f"   Tail count CL: {request.cl_tail_count}")
    print(f"   Selected value CL: {len(request.cl_selected_value_cl)} wartości")
    print(f"   Selected value Sigma: {len(request.cl_selected_value_sigma)} wartości")
    print(f"   Combined SD summary: {len(request.cl_combined_sd_summary)} wartości")
    print(f"   Symulacje CL: {request.cl_ilosc_symulacji}, ziarno: {request.cl_ziarno}")
    print(f"   Skalowanie CL: {request.cl_skalowanie}")
    print(f"   Kwantyle CL: {request.cl_kwantyle}")
    
    # ADDPAID DANE
    print(f"\n💰 ADDPAID DANE:")
    print(f"   Wagi Add: {len(request.add_weights)}x{len(request.add_weights[0]) if request.add_weights else 0}")
    print(f"   LR indexes: {len(request.add_lr_indexes)} - {request.add_lr_indexes}")
    print(f"   Sigma indexes: {len(request.add_sigma_indexes)} - {request.add_sigma_indexes}")
    print(f"   Left count LR: {request.add_left_count_lr}")
    print(f"   Tail count LR: {request.add_tail_count_lr}")
    print(f"   Selected value LR: {len(request.add_selected_value_lr)} wartości")
    print(f"   Selected value Sigma: {len(request.add_selected_value_sigma)} wartości")
    print(f"   Combined SD summary: {len(request.add_combined_sd_summary)} wartości")
    print(f"   E values (exposure): {len(request.add_e_values)} wartości")
    print(f"   Symulacje Add: {request.add_ilosc_symulacji}, ziarno: {request.add_ziarno}")
    print(f"   Skalowanie Add: {request.add_skalowanie}")
    print(f"   Skalowanie2 Add: {request.add_skalowanie2}")
    print(f"   Kwantyle Add: {request.add_kwantyle}")
    
    # WYNIKI
    print(f"\n📈 WYNIKI:")
    print(f"   CL wyniki symulacji: {'TAK' if request.cl_simulation_results else 'BRAK'}")
    print(f"   Add wyniki symulacji: {'TAK' if request.add_simulation_results else 'BRAK'}")
    print(f"   CL wyniki deterministyczne: {'TAK' if request.cl_deterministic_results else 'BRAK'}")
    print(f"   Add wyniki deterministyczne: {'TAK' if request.add_deterministic_results else 'BRAK'}")
    
    print(f"=" * 80)
    
    return {
        "status": "success", 
        "message": "Wszystkie dane testowe odebrane pomyślnie", 
        "user_id": request.user_id,
        "summary": {
            "cl_triangle_size": len(request.paid_triangle),
            "cl_indexes_count": len(request.cl_indexes),
            "add_lr_indexes_count": len(request.add_lr_indexes),
            "add_exposure_count": len(request.add_e_values),
            "has_cl_results": request.cl_simulation_results is not None,
            "has_add_results": request.add_simulation_results is not None
        }
    }