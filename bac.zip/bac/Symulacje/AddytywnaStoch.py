from fastapi import APIRouter, HTTPException
import numpy as np
import sys
import os
import traceback
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from .models import SimulationLrPaidRequest, StatisticLrPaidRequest, SimulationLrPaidResult
from add_simulator import YearHorizontLR2

router = APIRouter()
yh_lr = YearHorizontLR2()


@router.post("/calc/testAddpaid")
async def test_endpoint(request: dict):
    """Endpoint testowy do sprawdzania struktury danych"""
    return {"status": "test_ok", "received_keys": list(request.keys()) if isinstance(request, dict) else []}


@router.post("/calc/simulationAddpaid")
async def simulation_lr_paid(request: SimulationLrPaidRequest):
    try:
        payload = request.model_dump() if hasattr(request, "model_dump") else request.dict()
        
        user_id = payload['user_id']
        ilosc_symulacji = payload['ilosc_symulacji']
        ziarno = payload['ziarno']
        podzial_ziarna = payload['podzial_ziarna']
        skalowanie = payload['skalowanie']
        left_count_lr = payload['left_count_lr']
        calculation_options = payload['calculation_options']
        paid_triangle = np.array(payload['paid_triangle'])
        
        # 🔥 POPRAWKA: frontend wysyła 'e_values', nie 'exposure_values'
        exposure_values = np.array(payload['e_values'])[1:]
        
        lr_indexes = np.array(payload['lr_indexes'])
        sigma_indexes = np.array(payload['sigma_indexes'])
        selected_value_lr = np.array(payload['selected_value_lr'])
        selected_value_sigma = np.array(payload['selected_value_sigma'])
        tail_count_lr = payload.get('tail_count_lr')  # może być None
        
        if payload.get('discount_rates') and len(payload['discount_rates']) > 0:
            first_inner = next(iter(payload['discount_rates'].values()))
            discount_rates = np.array(list(first_inner.values()), dtype=float)
        else:
            discount_rates = np.array([], dtype=float)

        if payload.get('netto_brutto') and len(payload['netto_brutto']) > 0:
            first_inner = next(iter(payload['netto_brutto'].values()))
            netto_brutto = np.array(list(first_inner.values()), dtype=float)
        else:
            netto_brutto = np.array([], dtype=float)
        
        # Obsługa pustych discount_rates i netto_brutto
        combined_sd_length = len(payload['combined_sd_summary'])
        target_length = combined_sd_length + 2
        
        if len(discount_rates) == 0:
            discount_rates = np.ones(target_length, dtype=float)
            
        if len(netto_brutto) == 0:
            netto_brutto = np.ones(target_length, dtype=float)
        weights = np.array(payload['weights'])
        paid_triangle = np.asarray(paid_triangle, dtype=np.float64)
        lr_indexes = np.asarray([x+1 for x in payload['lr_indexes']], dtype=np.int32)
        sim_results = yh_lr.run_simulation_lr(
            data_paid=paid_triangle,
            sigma_j_LR=selected_value_sigma[1:],
            dev_LR=selected_value_lr[1:],
            sd_LR=payload['combined_sd_summary'][1:],
            e_values=exposure_values,
            wagi_trimmed=weights,
            ilosc_dop_wsp_CL=lr_indexes,  # używamy lr_indexes zamiast cl_indexes
            Poz_LR=left_count_lr,
            il_ogon=tail_count_lr if tail_count_lr is not None else 0,
            ultimate_param_resrisk=np.array([]),  # placeholder
            discount_factors=discount_rates,
            net_to_gross=netto_brutto,
            sim_total=ilosc_symulacji,
            batch_sim=podzial_ziarna,
            main_seed=ziarno
        )
        
        # Zapisz wyniki
        SimulationLrPaidResult(user_id, sim_results)

        # 🔥 POPRAWKA: Zwróć vectors jak w ClSimulation (dla kompatybilności z frontend)
        return {
            "status": "ok",
            "message": "Symulacja AddPaid została wykonana pomyślnie.",
            "vectors": {
                "last_col": sim_results[:, 0].tolist() if sim_results.shape[1] > 0 else [],
                "cum_trian": sim_results[:, 1].tolist() if sim_results.shape[1] > 1 else [],
                "ult_net_disc": sim_results[:, 2].tolist() if sim_results.shape[1] > 2 else []
            }
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Błąd przetwarzania AddPaid: {str(e)}")


@router.post("/calc/statisticAddpaid")
async def statistic_lr_paid(request: StatisticLrPaidRequest):
    try:
        payload = request.model_dump() if hasattr(request, "model_dump") else request.dict()
        user_id = payload['user_id']
        skalowanie1 = payload['skalowanie']
        skalowanie2 = payload['skalowanie2']

        result_obj = SimulationLrPaidResult.get_for_user(user_id)
        
        if result_obj is None:
            return {
                "status": "error",
                "message": f"Brak wyników symulacji AddPaid dla użytkownika {user_id}"
            }
        
        data_deterministic = payload.get('deterministic_results')
        keys = ['last_col','cum_trian',  'ult_net_disc']
        data_deterministic_sum = [sum(data_deterministic[k]) for k in keys]
        print(data_deterministic_sum)
        #  POPRAWKA: Obsługa przypadku gdy frontend wysyła null
        if data_deterministic_sum is None:
            data_deterministic_sum = [0, 0, 0]  # Domyślne wartości dla 3 kolumn AddPaid
        modified_data = result_obj.data.copy()  
        for i in range(min(len(data_deterministic_sum), modified_data.shape[1])):
            if i == 0:
                skalowanie = skalowanie1
            else:
                skalowanie = skalowanie1 * skalowanie2
            modified_data[:, i] = skalowanie * (modified_data[:, i] - data_deterministic_sum[i])
        kwantyle = payload['kwantyle']
        stats = []
        column_names = ["AddPaid Brutto", "AddPaid Brutto Dyskont.", "AddPaid Netto Dyskont."]

        for i in range(modified_data.shape[1]):
            col = modified_data[:, i]
            if not np.isnan(col).any():
                mean = np.mean(col)
                std = np.std(col)
                quantiles = np.quantile(col, kwantyle)
                stats.append({
                    "column": column_names[i] if i < len(column_names) else f"AddPaid Kolumna {i}",
                    "mean": float(mean),
                    "quantiles": [float(q) for q in quantiles],
                    "std": float(std),
                    "SCR": float(np.quantile(col, 0.995)) - float(mean)
                })

        return {
            "status": "ok",
            "message": "Statystyki AddPaid obliczone pomyślnie.",
            "user_id": user_id,
            "stats": stats,
        }
    
    except Exception as e:
        return {
            "status": "error",
            "message": f"Błąd obliczania statystyk AddPaid: {str(e)}"
        }