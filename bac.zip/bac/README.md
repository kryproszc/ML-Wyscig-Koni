
## Installation

```bash
pip install -r requirements.txt
```

## Development

```bash
uvicorn main:app --reload
```

## Production

```bash
uvicorn main:app
```
