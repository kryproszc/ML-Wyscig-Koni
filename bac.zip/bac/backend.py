from Obliczenia_stochastyczne import hybrid_paid_router as stoch_paid_router
from Obliczenia_stochastyczne import hybrid_incurred_router as stoch_incurred_router
from Obliczenia_deterministyczne import paid_router as det_paid_router
from Obliczenia_deterministyczne import incurred_router as det_incurred_router
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# Import routerów z poszczególnych modułów
from Trojkat.inflacja import router as trojkat_router
from Multiplikatywna.wspolczynniki_cl import router as mult_wspolczynniki_router
from Multiplikatywna.dopasowanie_krzywej_cl import router as mult_krzywe_router
from Multiplikatywna.wyniki import router as mult_wyniki_router
from Addytywna.wspolczynniki_add import router as add_router
from Addytywna.dopasowanie_krzywej_add import router as add_krzywe_router
from Addytywna.wyniki_lr import router as add_wyniki_lr_router
from Symulacje.MultiplikatywneStoch import router as symulacje_router
from Symulacje.AddytywnaStoch import router as symulacje_add_router

# Import pozostałych klas, które są jeszcze potrzebne w głównym pliku
from pydantic import BaseModel
from typing import List, Union, Optional, Dict

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Dodanie routerów
app.include_router(trojkat_router, tags=["Trójkąt"])
app.include_router(mult_wspolczynniki_router, tags=["Multiplikatywna - Współczynniki CL"])
app.include_router(mult_krzywe_router, tags=["Multiplikatywna - Dopasowanie krzywej CL"])
app.include_router(mult_wyniki_router, tags=["Multiplikatywna - Wyniki"])
app.include_router(add_router, tags=["Addytywna - Współczynniki"])
app.include_router(add_krzywe_router, tags=["Addytywna - Dopasowanie krzywej LR"])
app.include_router(add_wyniki_lr_router, tags=["Addytywna - Wyniki LR"])
app.include_router(symulacje_router, tags=["Symulacje"])
app.include_router(symulacje_add_router, tags=["Symulacje - Addytywna"])

# Dodanie routera dla deterministycznych obliczeń paid
app.include_router(det_paid_router, tags=["Obliczenia deterministyczne - Paid"])
app.include_router(det_incurred_router, tags=["Obliczenia deterministyczne - Incurred"])
app.include_router(stoch_paid_router, tags=["Obliczenia stochastyczne - Hybrid Paid"])
app.include_router(stoch_incurred_router, tags=["Obliczenia stochastyczne - Incurred"])

# Klasy, które jeszcze nie zostały przeniesione do odpowiednich modułów
class MatrixRequest(BaseModel):
    user_id: str
    paid_data: List[List[Union[str, int, float, None]]]
    paid_weights: List[List[int]]
    cl_data: List[List[Union[str, int, float, None]]]
    cl_weights: List[List[int]]
    triangle_raw: List[List[Union[str, int, float, None]]]
    cl_weights_raw: List[List[int]]
    wagi_mult: Optional[List[List[int]]] = None
    quantiles: Optional[List[float]] = None
    nbr_samples: Optional[int] = 1000


class QuantileRequest(BaseModel):
    user_id: str
    request_id: str
    quantiles: List[float]


class WspolczynnikiMultiplikatywnaStochastycznaRequest(BaseModel):
    user_id: str
    dev: List[float]
    sd: List[float]
    sigma: List[float]
    triangle: List[List[Union[str, int, float, None]]]
    sim_total: Optional[int] = 1000
    batch_sim: Optional[int] = 1000
    main_seed: Optional[int] = 202260011
    ultimate_param_resrisk: Optional[int] = 0


class SaveVectorRequest(BaseModel):
    curve_name: Optional[str] = None
    coeffs: Optional[List[float]] = None
    volume: Optional[int] = None
    values: Optional[List[float]] = None
    final_dev_vector: Optional[List[float]] = None


class SaveVectorPayload(BaseModel):
    paid_data_det: List[List[Optional[float]]]
    coeff_sets: List[SaveVectorRequest]


class SelectedDevJRequest(BaseModel):
    user_id: Optional[str] = None
    selected_dev_j: List[float]
    selected_indexes: Optional[List[int]] = None
    tail_values: Optional[List[float]] = None
    full_dev_j: List[float]


class SelectedSigmaRequest(BaseModel):
    user_id: Optional[str] = None
    selected_sigma: List[float]
    selected_indexes: Optional[List[int]] = None
    tail_values: Optional[List[float]] = None
    full_sigma: List[float]
