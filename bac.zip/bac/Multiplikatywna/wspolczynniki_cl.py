from fastapi import APIRouter
import pandas as pd
import numpy as np
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from .models import PaidTriangleRequest, PaidCLRequest, IncurredTriangleRequest, IncurredCLRequest, IncurredPaidTriangleRequest, IncurredPaidTraingleWspoRequest
from calculation_method import TriangleCalculator

router = APIRouter()


@router.post("/calc/paid/train_devide_paid")
async def calc_paid_train_devide(payload: PaidTriangleRequest):
    data = {}
    headers = [x for x in range(len(payload.paid_data_det[0]))]
    for i, col in enumerate(headers):
        data[col] = []
        for row in payload.paid_data_det:
            if i < len(row):
                value = row[i]
                try:
                    num_value = float(value)
                except (ValueError, TypeError):
                    num_value = None
            else:
                num_value = None
            data[col].append(num_value)
    
    train_devide = TriangleCalculator.elementwise_division(data)    
    train_devide_serializable = np.array(train_devide).tolist()
    return {
        "train_devide": train_devide_serializable
    }


@router.post("/calc/incurred/train_devide_incurred")
async def calc_incurred_train_devide(payload: IncurredTriangleRequest):
    data = {}
    headers = [x for x in range(len(payload.incurred_data_det[0]))]
    for i, col in enumerate(headers):
        data[col] = []
        for row in payload.incurred_data_det:
            if i < len(row):
                value = row[i]
                try:
                    num_value = float(value)
                except (ValueError, TypeError):
                    num_value = None
            else:
                num_value = None
            data[col].append(num_value)
    
    train_devide = TriangleCalculator.elementwise_division(data)    
    train_devide_serializable = np.array(train_devide).tolist()
    return {
        "train_devide": train_devide_serializable
    }


@router.post("/calc/paid/cl")
async def calc_paid_cl(payload: PaidCLRequest):
    paid_data = payload.paid_data_det
    weights = payload.weights
    data = {}
    headers = np.arange(len(paid_data[0]))

    for i, col in enumerate(headers):
        data[col] = []
        for row in paid_data:
            if i < len(row):
                value = row[i]
                try:
                    num_value = float(value)
                except (ValueError, TypeError):
                    num_value = None
            else:
                num_value = None
            data[col].append(num_value)

    l_ij = pd.DataFrame(TriangleCalculator.elementwise_division(data))
    w_ij = pd.DataFrame(payload.weights)
    p_ij = pd.DataFrame(data)
    dev_j = TriangleCalculator.Dev_prem(p_ij, w_ij)
    sigmas = TriangleCalculator.calculate_sigma(p_ij, l_ij, w_ij, dev_j)
     #sd_kwadrat = [x**2 for x in sigmas[0]]
    #sigma_kwadrat = [x**2  for x in sigmas[1]]
    print(sigmas)
    return {
        "message": "Odebrano dane i zastosowano wagi",
        "dev_j": list(dev_j),
        "sigmas": {
            "sd": sigmas[0],
            "sigma":  sigmas[1]
        }
    }


@router.post("/calc/incurred/cl")
async def calc_incurred_cl(payload: IncurredCLRequest):
    incurred_data = payload.incurred_data_det
    weights = payload.weights
    data = {}
    headers = np.arange(len(incurred_data[0]))

    for i, col in enumerate(headers):
        data[col] = []
        for row in incurred_data:
            if i < len(row):
                value = row[i]
                try:
                    num_value = float(value)
                except (ValueError, TypeError):
                    num_value = None
            else:
                num_value = None
            data[col].append(num_value)

    l_ij = pd.DataFrame(TriangleCalculator.elementwise_division(data))

    w_ij = pd.DataFrame(payload.weights)
    print(pd.DataFrame(w_ij))
    p_ij = pd.DataFrame(data)
    dev_j = TriangleCalculator.Dev_prem(p_ij, w_ij)
    sigmas = TriangleCalculator.calculate_sigma(p_ij, l_ij, w_ij, dev_j)
    #sd_kwadrat = [x**2 for x in sigmas[0]]
    #sigma_kwadrat = [x**2  for x in sigmas[1]]

    return {
        "message": "Odebrano dane incurred i zastosowano wagi",
        "dev_j": list(dev_j),
        "sigmas": {
            "sd": sigmas[0],
            "sigma":  sigmas[1]
        }
    }


# paid to icurred

# Endpoint
@router.post("/calc/paid_incurred/triangles")
async def calc_paid_incurred_triangles(payload: IncurredPaidTriangleRequest):
    user_id = payload.user_id
    paid_data = payload.paid_data_det
    incurred_data = payload.incurred_data_det
    
  
    # Konwersja do numpy arrays (opcjonalnie)
    try:
        paid_array = np.array(paid_data, dtype=float)
        incurred_array = np.array(incurred_data, dtype=float)
 
    except Exception as e:
        print(f"Błąd konwersji do numpy: {e}")
    
    train_paidtoincurred = paid_array/incurred_array
    print(train_paidtoincurred)
    
    # Obsługa wartości NaN, inf, -inf przed serializacją
    train_paidtoincurred = np.where(np.isfinite(train_paidtoincurred), train_paidtoincurred, None)
    train_paidtoincurred_serializable = train_paidtoincurred.tolist()
    
    return {
        "train_paidtoincurred": train_paidtoincurred_serializable
    }


@router.post("/calc/paid_incurred/calculate")
async def calc_paid_incurred_calculate(payload: IncurredPaidTraingleWspoRequest):
    user_id = payload.user_id
    paid_data = payload.paid_data_det
    incurred_data = payload.incurred_data_det
    weights = payload.weights
    try:
        paid_array = np.array(paid_data, dtype=float)
        incurred_array = np.array(incurred_data, dtype=float)
        weights_array = np.array(weights, dtype=float)
        r_j = TriangleCalculator.wspolczynnik_r(paid_array, incurred_array, weights_array)
        r_j_serializable = np.array(r_j).tolist() if hasattr(r_j, '__iter__') else r_j
        var_j = TriangleCalculator.wspolczynnik_var_j(paid_array, incurred_array, r_j,weights_array)
        var_j_serializable = np.array(var_j).tolist() if hasattr(var_j, '__iter__') else var_j
        res_i_j = TriangleCalculator.wspolczynnik_res_i_j(paid_array, incurred_array, r_j, var_j, weights_array)
        res_i_j_serializable = np.array(res_i_j).tolist() if hasattr(res_i_j, '__iter__') else res_i_j
        lambda_j = TriangleCalculator.lambda_correlation(res_i_j)
        print(weights_array)
    except Exception as e:
        r_j_serializable = None

    return {
        "r_j": r_j_serializable,
        "var_j": var_j_serializable,
        "res_i_j":res_i_j_serializable,
        "lambda_j": lambda_j
    }