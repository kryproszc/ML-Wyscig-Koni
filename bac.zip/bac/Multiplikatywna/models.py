from pydantic import BaseModel
from typing import List, Union, Optional, Dict


class PaidTriangleRequest(BaseModel):
    user_id: str
    paid_data_det: List[List[Union[str, int, float, None]]]
    weights: Optional[List[List[int]]] = None


class PaidCLRequest(BaseModel):
    user_id: str
    paid_data_det: List[List[Union[str, int, float, None]]]
    weights: List[List[Union[int, float, None]]]  # int (0,1), float (NaN), None (null)


class IncurredTriangleRequest(BaseModel):
    user_id: str
    incurred_data_det: List[List[Union[str, int, float, None]]]
    weights: Optional[List[List[int]]] = None


class IncurredCLRequest(BaseModel):
    user_id: str
    incurred_data_det: List[List[Union[str, int, float, None]]]
    weights: List[List[Union[int, float, None]]]  # int (0,1), float (NaN), None (null)


class IncurredPaidTriangleRequest(BaseModel):
    user_id: str
    paid_data_det: List[List[Union[str, int, float, None]]]
    incurred_data_det: List[List[Union[str, int, float, None]]]


class IncurredPaidTraingleWspoRequest(BaseModel):
    user_id: str
    paid_data_det: List[List[Union[str, int, float, None]]]
    incurred_data_det: List[List[Union[str, int, float, None]]]
    weights: List[List[Union[int, float, None]]]  # int (0,1), float (NaN), None (null)


class SelectedDevJWithTableRequest(BaseModel):
    user_id: Optional[str] = None
    selected_dev_j: List[float]
    selected_indexes: Optional[List[int]] = None
    tail_values: Optional[List[float]] = None
    full_dev_j: List[float]
    
    full_sigma: Optional[List[float]] = None
    full_sd: Optional[List[float]] = None
    selected_sigma: Optional[List[float]] = None
    selected_sd: Optional[List[float]] = None


class SelectedSigmaWithTableRequest(BaseModel):
    user_id: Optional[str] = None
    selected_sigma: List[float]
    selected_indexes: Optional[List[int]] = None
    tail_values: Optional[List[float]] = None
    full_sigma: List[float]
    full_sd: Optional[List[float]] = None
    selected_sd: Optional[List[float]] = None
    full_dev_j: Optional[List[float]] = None
    selected_dev_j: Optional[List[float]] = None


class CalculationOptions(BaseModel):
    brutto: bool
    brutto_dysk: bool
    netto_dysk: bool


class IncurredSelectedDevJWithTableRequest(BaseModel):
    user_id: Optional[str] = None
    selected_dev_j: List[float]
    selected_indexes: Optional[List[int]] = None
    tail_values: Optional[List[float]] = None
    full_dev_j: List[float]
    
    full_sigma: Optional[List[float]] = None
    full_sd: Optional[List[float]] = None
    selected_sigma: Optional[List[float]] = None
    selected_sd: Optional[List[float]] = None


class IncurredSelectedSigmaWithTableRequest(BaseModel):
    user_id: Optional[str] = None
    selected_sigma: List[float]
    selected_indexes: Optional[List[int]] = None
    tail_values: Optional[List[float]] = None
    full_sigma: List[float]
    full_sd: Optional[List[float]] = None
    selected_sd: Optional[List[float]] = None
    full_dev_j: Optional[List[float]] = None
    selected_dev_j: Optional[List[float]] = None


class SelectedRjWithTableRequest(BaseModel):
    user_id: Optional[str] = None
    r_j: List[float]  # rj_selected
    selected_indexes: Optional[List[int]] = None
    tail_values: Optional[List[float]] = None
    full_r_j: List[float]
    full_var_r_j_paid_to_incurred: Optional[List[float]] = None
    selected_var_r_j_paid_to_incurred: Optional[List[float]] = None


class SelectedVarWithTableRequest(BaseModel):
    user_id: Optional[str] = None
    var_j: List[float]  # var_j values
    selected_indexes: Optional[List[int]] = None
    tail_values: Optional[List[float]] = None
    full_r_j_paid_to_incurred: Optional[List[float]] = None
    full_selected_r_j_paid_to_incurred: Optional[List[float]] = None
    selected_var_r_j_paid_to_incurred: Optional[List[float]] = None


class ExecuteCalculationsRequest(BaseModel):
    # ZAWSZE wysyłane
    user_id: str
    paid_triangle: List[List[Optional[float]]]  # Może zawierać null
    cl_indexes: List[int]             
    sigma_indexes: List[int]          
    left_count_cl: int               
    selected_value_cl: List[float]    # Teraz konwertujemy na float
    selected_value_sigma: List[float] # Teraz konwertujemy na float
    calculation_options: CalculationOptions  
    
    # WARUNKOWO wysyłane (może być pusty dict {})
    discount_rates: Dict[str, Dict[str, Optional[float]]]  # Może być {}
    netto_brutto: Dict[str, Dict[str, Optional[float]]]    # Może być {}


class ExecuteCalculationsRequestIncurred(BaseModel):
    user_id: str
    paid_triangle: List[List[Optional[float]]]  # Może zawierać null
    incurred_triangle: List[List[Optional[float]]]  # Może zawierać null
    selected_dev_j_indexes: List[int]
    dev_j_current: List[float]
    rj_paid_to_incurred_current: List[float]
    selected_values_rj_paid_to_incurred: List[float]
    last_col_incurred: List[float]
    ult_disc_incurred: List[float]
    discount_rates: Dict[str, Dict[str, Optional[float]]]  # Może być {} lub zawierać null/-1
    netto_brutto: Dict[str, Dict[str, Optional[float]]]    # Może być {} lub zawierać null/-1