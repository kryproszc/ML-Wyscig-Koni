from calculation_method import TriangleCalculator
import pandas as pd
import numpy as np
import time

data = {
    1: [5012, 106, 3410, 5655, 1092, 1513, 557, 1351, 3133, 2063],
    2: [8269, 4285, 8992, 11555, 9565, 6445, 4020, 6947, 5395, 0],
    3: [10907, 5396, 13873, 15766, 15836, 11702, 10946, 13112, 0, 0],
    4: [11805, 10666, 16141, 21266, 22169, 12935, 12314, 0, 0, 0],
    5: [13539, 13782, 18735, 23425, 25955, 15852, 0, 0, 0, 0],
    6: [16181, 15599, 22214, 26083, 26180, 0, 0, 0, 0, 0],
    7: [18009, 15496, 22863, 27067, 0, 0, 0, 0, 0, 0],
    8: [18608, 16169, 23466, 0, 0, 0, 0, 0, 0, 0],
    9: [18662, 16704, 0, 0, 0, 0, 0, 0, 0, 0],
    10: [18834, 0, 0, 0, 0, 0, 0, 0, 0, 0]
}
index = [1981, 1982, 1983, 1984, 1985, 1986, 1987, 1988, 1989, 1990]

triangle_df = pd.DataFrame(data, index=index)
triangle_np = triangle_df.to_numpy(dtype=np.float64)
#df_np = np.array(list(data.values()), dtype=float).T  # shape (10, 10)
#mask_np = ~np.isnan(df_np)
#a2a_np = TriangleCalculator.get_a2a_factors_np(df_np, mask_np)
import numpy as np
import pandas as pd

def divide(x, y):
    result = np.zeros_like(x)
    for i in range(len(x)):
        result[i] = 0 if y[i] == 0 else x[i] / y[i]
    return result

def run_bootstrap_monte_carlo(triangle, weight, number_of_simulations=1000, is_sigma_reestimated=True, sigma_tail=1.65):
    triangle = np.nan_to_num(triangle)
    weight = np.nan_to_num(weight)
    a = triangle.shape[0]

    indiv_factors = np.zeros((a-1, a-1))
    for k in range(a-1):
        indiv_factors[:, k] = divide(triangle[:a-1, k+1], triangle[:a-1, k])

    indiv_factors_weighted = indiv_factors * weight[:a-1, :a-1]

    ldf = np.zeros(a-1)
    for k in range(a-1):
        num = np.sum(triangle[:a-1, k] * indiv_factors_weighted[:, k])
        den = np.sum(triangle[:a-1, k] * weight[:a-1, k])
        ldf[k] = 1 if den == 0 else num / den

    sigma = np.zeros(a-1)
    for k in range(a-1):
        w = weight[:a-1, k]
        diff = indiv_factors_weighted[:, k] - ldf[k]
        num = np.sum(triangle[:a-1, k] * w * diff ** 2)
        den = np.sum(w) - 1
        sigma[k] = 0 if den <= 0 else np.sqrt(num / den)

    if a >= 4:
        sigma[a-2] = np.sqrt(min((sigma[a-3]**2 / sigma[a-4])**2, min(sigma[a-3]**2, sigma[a-4]**2)))

    for k in range(a-1):
        if np.sum(weight[:a-1, k]) == 1:
            sigma[k] = sigma[max(0, k-1)]
        if np.sum(weight[:a-1, k]) == 0:
            sigma[k] = sigma_tail

    ln_mu_bootstrap = np.zeros((a, a-1))
    ln_sd_bootstrap = np.zeros((a, a-1))
    for k in range(a):
        for i in range(a-1):
            if triangle[k, i] == 0:
                ln_mu_bootstrap[k, i] = -np.inf
                ln_sd_bootstrap[k, i] = 0
            else:
                mean_val = ldf[i] * triangle[k, i]
                variance_ratio = (triangle[k, i] * sigma[i]**2) / (mean_val**2)
                ln_mu_bootstrap[k, i] = np.log(mean_val) - 0.5 * np.log(variance_ratio + 1)
                ln_sd_bootstrap[k, i] = np.sqrt(np.log(variance_ratio + 1))

    ult = np.zeros(number_of_simulations)

    for n in range(number_of_simulations):
        triangle_boot = np.zeros((a, a))
        triangle_boot[:, 0] = triangle[:, 0]

        for k in range(a):
            for i in range(1, a):
                if triangle_boot[k, i-1] != 0:
                    triangle_boot[k, i] = np.random.lognormal(ln_mu_bootstrap[k, i-1], ln_sd_bootstrap[k, i-1])

        indiv_f_boot = np.zeros((a-1, a-1))
        for k in range(a-1):
            indiv_f_boot[:, k] = divide(triangle_boot[:a-1, k+1], triangle[:a-1, k])
        indiv_f_boot_weighted = indiv_f_boot * weight[:a-1, :a-1]

        ldf_boot = np.zeros(a-1)
        for k in range(a-1):
            num = np.sum(triangle[:a-1, k] * indiv_f_boot_weighted[:, k])
            den = np.sum(triangle[:a-1, k] * weight[:a-1, k])
            ldf_boot[k] = 1 if den == 0 else num / den

        sigma_boot = sigma.copy()
        if is_sigma_reestimated:
            for k in range(a-1):
                w = weight[:a-1, k]
                diff = indiv_f_boot_weighted[:, k] - ldf_boot[k]
                num = np.sum(triangle[:a-1, k] * w * diff**2)
                den = np.sum(w) - 1
                sigma_boot[k] = 0 if den <= 0 else np.sqrt(num / den)
                if k == a-2 and a >= 3:
                    sigma_boot[k] = np.sqrt(min((sigma_boot[k-1]**2 / sigma_boot[k-2])**2,
                                                min(sigma_boot[k-1]**2, sigma_boot[k-2]**2)))
                if np.sum(w) == 1:
                    sigma_boot[k] = sigma_boot[max(0, k-1)]
                if np.sum(w) == 0:
                    sigma_boot[k] = sigma_tail

        triangle_simu = triangle.copy()
        for k in range(a):
            for i in range(1, a):
                if k + i >= a and triangle_simu[k, i-1] != 0:
                    prev = triangle_simu[k, i-1]
                    mu = np.log(ldf_boot[i-1] * prev) - 0.5 * np.log((prev * sigma_boot[i-1]**2) / (ldf_boot[i-1]**2 * prev**2) + 1)
                    sigma_ln = np.sqrt(np.log((prev * sigma_boot[i-1]**2) / (ldf_boot[i-1]**2 * prev**2) + 1))
                    triangle_simu[k, i] = np.random.lognormal(mu, sigma_ln)

        ult[n] = np.sum(triangle_simu[:, a-1])

    return ult

 
index = [0,1,2,3,4,5,6,7,8,9]
# TRIANGLE (10x10)
triangle_df = pd.DataFrame(data, index=index)
triangle_np = triangle_df.to_numpy(dtype=np.float64)
index = [0,1,2,3,4,5,6,7,8]
# WEIGHT (9x9)
weight_matrix = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 0],
    [1, 1, 1, 1, 1, 1, 1, 0, 0],
    [1, 1, 1, 1, 1, 1, 0, 0, 0],
    [1, 1, 1, 1, 1, 0, 0, 0, 0],
    [1, 1, 1, 1, 0, 0, 0, 0, 0],
    [1, 1, 1, 0, 0, 0, 0, 0, 0],
    [1, 1, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0]
]
weight_df = pd.DataFrame(weight_matrix, index= [0,1,2,3,4,5,6,7,8], columns= [0,1,2,3,4,5,6,7,8])
weight_np = weight_df.to_numpy(dtype=np.float64)

print(triangle_np)
print(weight_np)
#3results = run_bootstrap_monte_carlo(triangle_np, weight_np,number_of_simulations=10000,is_sigma_reestimated=False)
results = TriangleCalculator.run_bootstrap_monte_carlo_init(triangle_np, weight_np,number_of_simulations=10000,is_sigma_reestimated=False)
end = time.time()


results_cale = 1 * (results - 0)
print(f"📊 Median: {np.median(results_cale):,.2f}")
for q in [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,0.995, 0.996, 0.997, 0.998, 0.999]:
    print(f"Quantile {q}: {np.quantile(results_cale, q):,.2f}")
print(f"Mean: {np.mean(results_cale):,.2f}")
print(f"Difference (Quantile - Mean): {np.quantile(results_cale, 0.995) - np.mean(results_cale):,.2f}")

