from pydantic import BaseModel, Field, ConfigDict
from typing import List, Union, Optional, Dict


class CalculationOptions(BaseModel):
    brutto: bool
    brutto_dysk: bool
    netto_dysk: bool


class ExecuteCalculationsRequestLR(BaseModel):
    # ZAWSZE wysyłane
    user_id: str
    paid_triangle: List[List[Optional[float]]]  # Może zawierać null
    ekspozycja: List[float]                     # Ekspozycja dla LR
    lr_indexes: List[int]                       # Indeksy wybrane LR
    sigma_lr_indexes: List[int]                 # Indeksy wybrane sigma LR
    left_count_lr: int                          # Liczba współczynników LR
    selected_value_lr: List[float]              # Wybrane wartości LR
    selected_value_sigma_lr: List[float]        # Wybrane wartości sigma LR
    calculation_options: CalculationOptions
    
    # WARUNKOWO wysyłane (może być pusty dict {})
    discount_rates: Dict[str, Dict[str, Optional[float]]]  # Może być {}
    netto_brutto: Dict[str, Dict[str, Optional[float]]]    # Może być {}


class AddTriangleRequest(BaseModel):
    user_id: str
    add_data_det: List[List[Union[str, int, float, None]]]
    ekspozycja: List[Union[str, int, float, None]]
    weights: Optional[List[List[int]]] = None


class AddTriangleRequestIncurred(BaseModel):
    user_id: str
    add_data_incurred : List[List[Union[str, int, float, None]]]
    ekspozycja: List[Union[str, int, float, None]]
 


class AddCLRequest(BaseModel):
    user_id: str
    add_data_det: List[List[Union[str, int, float, None]]]
    ekspozycja: List[Union[str, int, float, None]]
    weights: List[List[int]]

class AddCLRequestIncurred(BaseModel):
    user_id: str
    add_data_incurred: List[List[Union[str, int, float, None]]]
    ekspozycja: List[Union[str, int, float, None]]
    weights: List[List[int]]

class SelectedAddJWithTableRequest(BaseModel):
    user_id: Optional[str] = None
    selected_add_j: List[float]
    selected_indexes: Optional[List[int]] = None
    tail_values: Optional[List[float]] = None
    full_add_j: List[float]
    
    # Related wektory (identyczne jak MultPaid):
    full_sigma_l_r: Optional[List[float]] = None
    selected_sigma_l_r: Optional[List[float]] = None
    full_sd_l_r: Optional[List[float]] = None
    selected_sd_l_r: Optional[List[float]] = None



class SelectedAddJWithTableRequestIncurred(BaseModel):
    model_config = ConfigDict(extra="forbid")

    user_id: Optional[str] = None

    selected_add_j: List[float] = Field(min_length=1)
    selected_indexes: Optional[List[int]] = None
    tail_values: Optional[List[float]] = None

    full_add_j: List[float] = Field(min_length=1)

    # Related wektory (identyczne jak MultPaid)
    full_sigma_l_r: Optional[List[float]] = None
    selected_sigma_l_r: Optional[List[float]] = None
    full_sd_l_r: Optional[List[float]] = None
    selected_sd_l_r: Optional[List[float]] = None


class SelectedSigmaLRWithTableRequest(BaseModel):
    user_id: Optional[str] = None
    selected_sigma_l_r: List[float]
    selected_indexes: Optional[List[int]] = None
    tail_values: Optional[List[float]] = None
    full_sigma_l_r: List[float]
    
    # Related wektory:
    full_add_j: Optional[List[float]] = None
    selected_add_j: Optional[List[float]] = None
    full_sd_l_r: Optional[List[float]] = None
    selected_sd_l_r: Optional[List[float]] = None

class SelectedSigmaLRWithTableRequestIncurred(BaseModel):
    user_id: Optional[str] = None
    selected_sigma_l_r: List[float]
    selected_indexes: Optional[List[int]] = None
    tail_values: Optional[List[float]] = None
    full_sigma_l_r: List[float]
    
    # Related wektory:
    full_add_j: Optional[List[float]] = None
    selected_add_j: Optional[List[float]] = None
    full_sd_l_r: Optional[List[float]] = None
    selected_sd_l_r: Optional[List[float]] = None