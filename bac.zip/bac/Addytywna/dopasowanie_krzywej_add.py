from fastapi import APIRouter, HTTPException
import pandas as pd
import numpy as np
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from .models import SelectedAddJWithTableRequest, SelectedSigmaLRWithTableRequest, SelectedAddJWithTableRequestIncurred, SelectedSigmaLRWithTableRequestIncurred
from triangle_utils import TriangleCalculator_det

router = APIRouter()
calculator_det = TriangleCalculator_det()


@router.post("/calc/add/selected_add_j")
async def calc_add_selected_add_j(payload: SelectedAddJWithTableRequest):
    import numpy as np
    import pandas as pd

    # --- wejście ---
    full_ys = np.array(payload.full_add_j, dtype=float)
    xs_all  = np.array(payload.selected_indexes, dtype=float) + 1
    ys_all  = np.array(payload.selected_add_j, dtype=float)

    # --- krzywe (odkomentowane / uzupełnione, bo dalej są używane) ---
    curve_list = []

    # --- tail i siatka do symulacji ---
    tail = int(payload.tail_values[0]) if payload.tail_values and len(payload.tail_values) > 0 else 0
    xs_sim = np.array([i + 1 for i in range(len(full_ys.tolist()) + tail)], dtype=float)

    # --- selected_sd_l_r -> indeksy gdzie > 0, potem filtrujemy xs/ys/sd_l_r ---
    sd_all = np.array(payload.selected_sd_l_r, dtype=float) if payload.selected_sd_l_r and len(payload.selected_sd_l_r) > 0 else None

    if sd_all is not None:
        if not (len(sd_all) == len(xs_all) == len(ys_all)):
            raise HTTPException(
                status_code=400,
                detail=f"Length mismatch: sd={len(sd_all)}, xs={len(xs_all)}, ys={len(ys_all)}"
            )

        indices = [i for i, v in enumerate(sd_all.tolist()) if v > 0]

        xs = xs_all[indices]
        ys = ys_all[indices]
        sd_selected = sd_all[indices]
    else:
        indices = []
        xs = xs_all
        ys = ys_all
        sd_selected = None

    # --- dopasowanie krzywej ważonej (Twoja funkcja) ---
    a_wazony, b_wazony = calculator_det.fit_curve(ys, sd_selected, xs, "factor_LR", -0.5)

    # --- predykcje/regresja ---
    f_wazony    = calculator_det.wspolczynnik_reg(a_wazony, b_wazony, xs_sim, "factor_LR")  # pełny zakres
    f_wazony_r2 = calculator_det.wspolczynnik_reg(a_wazony, b_wazony, xs,     "factor_LR")  # tylko na xs

    # --- SE / wariancje ---
    w_k_sqr = calculator_det.wsp_w_k_sqr(ys, sd_selected, "factor_LR", 4)

    se_obs, sigma2_hat, Var_a, Cov_ab, Var_b = calculator_det.oblicz_se_factor_LR(
        ys, f_wazony_r2, w_k_sqr, a_wazony, b_wazony, xs, len(full_ys.tolist()) + 1
    )

    k_pred = np.arange(1, len(full_ys.tolist()) + tail + 1)

    # UWAGA: argumenty w odpowiedniej kolejności (a, b, Var_a, Cov_ab, Var_b, k_vec)
    f_pred, se_pred = calculator_det.se_for_LR_future_k(
        a_wazony, b_wazony, Var_a, Cov_ab, Var_b, k_pred
    )

    # --- reszta: symulacje krzywych + R2 (jak u Ciebie) ---
    parameters_curve = calculator_det.parameters_curve_reservoir(
        xs=xs, ys=ys, lista_krzywych=curve_list
    )

    simulation_results = calculator_det.sim_data_curve_rezerwy(xs_sim, curve_list, parameters_curve)

    f_curves_graph_real_choose = calculator_det.sim_data_curve_rezerwy(xs, curve_list, parameters_curve)
    r2_curves_df = calculator_det.r2_curves(f_curves_graph_real_choose, ys)

    # --- DataFrame-y / dopięcie weighted ---
    if not isinstance(simulation_results, pd.DataFrame):
        simulation_results = pd.DataFrame(simulation_results)

    f_wazony_list = [float(v) for v in f_wazony]
    if len(f_wazony_list) != simulation_results.shape[1]:
        raise HTTPException(
            status_code=500,
            detail=f"Mismatch: len(f_wazony)={len(f_wazony_list)} vs cols={simulation_results.shape[1]}"
        )
    simulation_results.loc["Exponential_weighted"] = f_wazony_list

    y_hat = np.array([float(v) for v in f_wazony_r2], dtype=float)
    if y_hat.shape[0] != ys.shape[0]:
        raise HTTPException(
            status_code=500,
            detail=f"Mismatch: len(f_wazony_r2)={y_hat.shape[0]} vs len(ys)={ys.shape[0]}"
        )
    ss_res = float(np.sum((ys - y_hat) ** 2))
    ss_tot = float(np.sum((ys - np.mean(ys)) ** 2))
    r2_wazony = float("nan") if ss_tot == 0 else 1.0 - ss_res / ss_tot

    if not isinstance(r2_curves_df, pd.DataFrame):
        r2_curves_df = pd.DataFrame(r2_curves_df)
    r2_curves_df["Exponential_weighted"] = r2_wazony
    print("se_pred")
    print(se_pred)
    return {
        "indices_sd_gt_0": indices,  # <- żebyś widział, co zostało wybrane
        "simulation_results": simulation_results.to_dict(),
        "r2_scores": r2_curves_df.to_dict(),
        "se_pred": se_pred.tolist() if isinstance(se_pred, np.ndarray) else se_pred
    }


@router.post("/calc/add/selected_add_j_incurred")
async def calc_add_selected_add_j_incurred(payload: SelectedAddJWithTableRequestIncurred):
    import numpy as np
    import pandas as pd

    # --- wejście ---
    full_ys = np.array(payload.full_add_j, dtype=float)
    xs_all  = np.array(payload.selected_indexes, dtype=float) + 1
    ys_all  = np.array(payload.selected_add_j, dtype=float)

    # --- krzywe (odkomentowane / uzupełnione, bo dalej są używane) ---
    curve_list = []

    # --- tail i siatka do symulacji ---
    tail = int(payload.tail_values[0]) if payload.tail_values and len(payload.tail_values) > 0 else 0
    xs_sim = np.array([i + 1 for i in range(len(full_ys.tolist()) + tail)], dtype=float)

    # --- selected_sd_l_r -> indeksy gdzie > 0, potem filtrujemy xs/ys/sd_l_r ---
    sd_all = np.array(payload.selected_sd_l_r, dtype=float) if payload.selected_sd_l_r and len(payload.selected_sd_l_r) > 0 else None

    if sd_all is not None:
        if not (len(sd_all) == len(xs_all) == len(ys_all)):
            raise HTTPException(
                status_code=400,
                detail=f"Length mismatch: sd={len(sd_all)}, xs={len(xs_all)}, ys={len(ys_all)}"
            )

        indices = [i for i, v in enumerate(sd_all.tolist()) if v > 0]

        xs = xs_all[indices]
        ys = ys_all[indices]
        sd_selected = sd_all[indices]
    else:
        indices = []
        xs = xs_all
        ys = ys_all
        sd_selected = None

    # --- dopasowanie krzywej ważonej (Twoja funkcja) ---
    a_wazony, b_wazony = calculator_det.fit_curve(ys, sd_selected, xs, "factor_LR", -0.5)

    # --- predykcje/regresja ---
    f_wazony    = calculator_det.wspolczynnik_reg(a_wazony, b_wazony, xs_sim, "factor_LR")  # pełny zakres
    f_wazony_r2 = calculator_det.wspolczynnik_reg(a_wazony, b_wazony, xs,     "factor_LR")  # tylko na xs

    # --- SE / wariancje ---
    w_k_sqr = calculator_det.wsp_w_k_sqr(ys, sd_selected, "factor_LR", 4)

    se_obs, sigma2_hat, Var_a, Cov_ab, Var_b = calculator_det.oblicz_se_factor_LR(
        ys, f_wazony_r2, w_k_sqr, a_wazony, b_wazony, xs, len(full_ys.tolist()) + 1
    )

    k_pred = np.arange(1, len(full_ys.tolist()) + tail + 1)

    # UWAGA: argumenty w odpowiedniej kolejności (a, b, Var_a, Cov_ab, Var_b, k_vec)
    f_pred, se_pred = calculator_det.se_for_LR_future_k(
        a_wazony, b_wazony, Var_a, Cov_ab, Var_b, k_pred
    )

    # --- reszta: symulacje krzywych + R2 (jak u Ciebie) ---
    parameters_curve = calculator_det.parameters_curve_reservoir(
        xs=xs, ys=ys, lista_krzywych=curve_list
    )

    simulation_results = calculator_det.sim_data_curve_rezerwy(xs_sim, curve_list, parameters_curve)

    f_curves_graph_real_choose = calculator_det.sim_data_curve_rezerwy(xs, curve_list, parameters_curve)
    r2_curves_df = calculator_det.r2_curves(f_curves_graph_real_choose, ys)

    # --- DataFrame-y / dopięcie weighted ---
    if not isinstance(simulation_results, pd.DataFrame):
        simulation_results = pd.DataFrame(simulation_results)

    f_wazony_list = [float(v) for v in f_wazony]
    if len(f_wazony_list) != simulation_results.shape[1]:
        raise HTTPException(
            status_code=500,
            detail=f"Mismatch: len(f_wazony)={len(f_wazony_list)} vs cols={simulation_results.shape[1]}"
        )
    simulation_results.loc["Exponential_weighted"] = f_wazony_list

    y_hat = np.array([float(v) for v in f_wazony_r2], dtype=float)
    if y_hat.shape[0] != ys.shape[0]:
        raise HTTPException(
            status_code=500,
            detail=f"Mismatch: len(f_wazony_r2)={y_hat.shape[0]} vs len(ys)={ys.shape[0]}"
        )
    ss_res = float(np.sum((ys - y_hat) ** 2))
    ss_tot = float(np.sum((ys - np.mean(ys)) ** 2))
    r2_wazony = float("nan") if ss_tot == 0 else 1.0 - ss_res / ss_tot

    if not isinstance(r2_curves_df, pd.DataFrame):
        r2_curves_df = pd.DataFrame(r2_curves_df)
    r2_curves_df["Exponential_weighted"] = r2_wazony
    print("se_pred")
    print(se_pred)
    return {
        "indices_sd_gt_0": indices,  # <- żebyś widział, co zostało wybrane
        "simulation_results": simulation_results.to_dict(),
        "r2_scores": r2_curves_df.to_dict(),
        "se_pred": se_pred.tolist() if isinstance(se_pred, np.ndarray) else se_pred
    }


@router.post("/calc/add/selected_sigma_LR")
async def calc_add_selected_sigma_LR(payload: SelectedSigmaLRWithTableRequest):
    import numpy as np
    import pandas as pd


    full_sigmas = np.array(payload.full_sigma_l_r, dtype=float)

    if payload.selected_indexes is not None and len(payload.selected_indexes) > 0:
        xs = np.array(payload.selected_indexes, dtype=float) + 1
    else:
        xs = np.arange(1, len(payload.selected_sigma_lr) + 1, dtype=float)

    sigmas = np.array(payload.selected_sigma_l_r, dtype=float)

    sd_selected = (np.array(payload.selected_sd_l_r, dtype=float)
                   if payload.selected_sd_l_r and len(payload.selected_sd_l_r) > 0 else None)
    add_j_selected = (np.array(payload.selected_add_j, dtype=float)
                      if payload.selected_add_j and len(payload.selected_add_j) > 0 else None)

    curve_list = []
    #curve_list = ["Exponential", "Weibull", "Power", "Inverse Power"]

    parameters_curve = calculator_det.parameters_curve_sigma(
        xs=xs, sigmas=sigmas, lista_krzywych=curve_list
    )

    tail = int(payload.tail_values[0]) if payload.tail_values and len(payload.tail_values) > 0 else 0
    xs_sim = np.array([i + 1 for i in range(len(full_sigmas.tolist()) + tail)], dtype=float)

    simulation_results = calculator_det.sim_data_curve_sigma(xs_sim, curve_list, parameters_curve)

    if sd_selected is not None and len(sd_selected) > 0:
        try:
            sigma_wazony, sigma_wazony_r2 = calculator_det.fit_curve(
                sigmas, sd_selected, xs, "variance_LR", len(full_sigmas)
            )

            sigma_wazony_pred = calculator_det.wspolczynnik_reg(
                sigma_wazony, sigma_wazony_r2, xs_sim, "variance_LR"
            )

            if not isinstance(simulation_results, pd.DataFrame):
                simulation_results = pd.DataFrame(simulation_results)

            sigma_wazony_list = [float(v) for v in sigma_wazony_pred]
            if len(sigma_wazony_list) == simulation_results.shape[1]:
                simulation_results.loc["Sigma_weighted"] = sigma_wazony_list

            y_hat_selected = calculator_det.wspolczynnik_reg(
                sigma_wazony, sigma_wazony_r2, xs, "variance_LR"
            )

        except Exception as e:
            print(f"❌ Error in weighted fitting for sigma LR: {e}")
            y_hat_selected = None
    else:
        y_hat_selected = None

    sigma_curves_real_choose = calculator_det.sim_data_curve_sigma(xs, curve_list, parameters_curve)
    r2_curves_df = calculator_det.r2_curves_sigma(sigma_curves_real_choose, sigmas)

    # --- R² dla krzywej ważonej (tu zostawiam w skali oryginalnej, jak w Twoim kodzie) ---
    if y_hat_selected is not None:
        try:
            y_hat = np.array([float(v) for v in y_hat_selected], dtype=float)
            if y_hat.shape[0] == sigmas.shape[0]:
                ss_res = float(np.sum((sigmas - y_hat) ** 2))
                ss_tot = float(np.sum((sigmas - np.mean(sigmas)) ** 2))
                r2_wazony = float('nan') if ss_tot == 0 else 1.0 - ss_res / ss_tot

                if not isinstance(r2_curves_df, pd.DataFrame):
                    r2_curves_df = pd.DataFrame(r2_curves_df)
                r2_curves_df["Sigma_weighted"] = r2_wazony
        except Exception as e:
            print(f"❌ Error calculating R² for weighted sigma LR: {e}")

    return {
        "simulation_results": simulation_results.to_dict() if hasattr(simulation_results, 'to_dict') else simulation_results,
        "r2_scores": r2_curves_df.to_dict() if hasattr(r2_curves_df, 'to_dict') else r2_curves_df,
        "processed_data": {
            "sigma_count": len(full_sigmas),
            "selected_count": len(sigmas),
            "sd_available": sd_selected is not None,
            "add_j_available": add_j_selected is not None,
            "tail_count": tail
        }
    }


@router.post("/calc/add/selected_sigma_LR_incurred")
async def calc_add_selected_sigma_LR_incurred(payload: SelectedSigmaLRWithTableRequestIncurred):
    import numpy as np
    import pandas as pd


    full_sigmas = np.array(payload.full_sigma_l_r, dtype=float)

    if payload.selected_indexes is not None and len(payload.selected_indexes) > 0:
        xs = np.array(payload.selected_indexes, dtype=float) + 1
    else:
        xs = np.arange(1, len(payload.selected_sigma_l_r) + 1, dtype=float)

    sigmas = np.array(payload.selected_sigma_l_r, dtype=float)

    sd_selected = (np.array(payload.selected_sd_l_r, dtype=float)
                   if payload.selected_sd_l_r and len(payload.selected_sd_l_r) > 0 else None)
    add_j_selected = (np.array(payload.selected_add_j, dtype=float)
                      if payload.selected_add_j and len(payload.selected_add_j) > 0 else None)

    curve_list = []
    #curve_list = ["Exponential", "Weibull", "Power", "Inverse Power"]

    parameters_curve = calculator_det.parameters_curve_sigma(
        xs=xs, sigmas=sigmas, lista_krzywych=curve_list
    )

    tail = int(payload.tail_values[0]) if payload.tail_values and len(payload.tail_values) > 0 else 0
    xs_sim = np.array([i + 1 for i in range(len(full_sigmas.tolist()) + tail)], dtype=float)

    simulation_results = calculator_det.sim_data_curve_sigma(xs_sim, curve_list, parameters_curve)

    if sd_selected is not None and len(sd_selected) > 0:
        try:
            sigma_wazony, sigma_wazony_r2 = calculator_det.fit_curve(
                sigmas, sd_selected, xs, "variance_LR", len(full_sigmas)
            )

            sigma_wazony_pred = calculator_det.wspolczynnik_reg(
                sigma_wazony, sigma_wazony_r2, xs_sim, "variance_LR"
            )

            if not isinstance(simulation_results, pd.DataFrame):
                simulation_results = pd.DataFrame(simulation_results)

            sigma_wazony_list = [float(v) for v in sigma_wazony_pred]
            if len(sigma_wazony_list) == simulation_results.shape[1]:
                simulation_results.loc["Sigma_weighted"] = sigma_wazony_list

            y_hat_selected = calculator_det.wspolczynnik_reg(
                sigma_wazony, sigma_wazony_r2, xs, "variance_LR"
            )

        except Exception as e:
            print(f"❌ Error in weighted fitting for sigma LR: {e}")
            y_hat_selected = None
    else:
        y_hat_selected = None

    sigma_curves_real_choose = calculator_det.sim_data_curve_sigma(xs, curve_list, parameters_curve)
    r2_curves_df = calculator_det.r2_curves_sigma(sigma_curves_real_choose, sigmas)

    # --- R² dla krzywej ważonej (tu zostawiam w skali oryginalnej, jak w Twoim kodzie) ---
    if y_hat_selected is not None:
        try:
            y_hat = np.array([float(v) for v in y_hat_selected], dtype=float)
            if y_hat.shape[0] == sigmas.shape[0]:
                ss_res = float(np.sum((sigmas - y_hat) ** 2))
                ss_tot = float(np.sum((sigmas - np.mean(sigmas)) ** 2))
                r2_wazony = float('nan') if ss_tot == 0 else 1.0 - ss_res / ss_tot

                if not isinstance(r2_curves_df, pd.DataFrame):
                    r2_curves_df = pd.DataFrame(r2_curves_df)
                r2_curves_df["Sigma_weighted"] = r2_wazony
        except Exception as e:
            print(f"❌ Error calculating R² for weighted sigma LR: {e}")

    return {
        "simulation_results": simulation_results.to_dict() if hasattr(simulation_results, 'to_dict') else simulation_results,
        "r2_scores": r2_curves_df.to_dict() if hasattr(r2_curves_df, 'to_dict') else r2_curves_df,
        "processed_data": {
            "sigma_count": len(full_sigmas),
            "selected_count": len(sigmas),
            "sd_available": sd_selected is not None,
            "add_j_available": add_j_selected is not None,
            "tail_count": tail
        }
    }