import pandas as pd
import numpy as np
from numpy.random import gamma
from numba import njit, prange


from numba import njit
import numpy as np
from numba import njit
import numpy as np




class TriangleCalculator:

 

    @staticmethod
    def elementwise_division(data_dict):
        # Konwersja do macierzy
        columns = data_dict.keys()
        data_matrix = np.array([
            [val for val in data_dict[col]]
            for col in columns
        ]).T  # shape: (n_rows, n_cols)

        n_rows, n_cols = data_matrix.shape
        result = [[None for _ in range(n_cols - 1)] for _ in range(n_rows)]

        for i in range(n_rows):
            for j in range(1, n_cols):
                prev = data_matrix[i][j - 1]
                curr = data_matrix[i][j]
                if prev is None or curr is None:
                    result[i][j - 1] = None
                elif prev == 0:
                    result[i][j - 1] = 1
                else:
                    result[i][j - 1] = curr / prev

        return result  # shape: (n_rows, n_cols - 1)
   
    @staticmethod
    def Dev_prem(data_paid, w):
        nn = data_paid.shape[1]
        Dev_j = []
        for j in range(nn - 1):
            mianownik = np.sum([data_paid.iloc[i, j] * w.iloc[i, j] for i in range(nn-j-1)])
            licznik = np.sum([data_paid.iloc[i, j+1] * w.iloc[i, j] for i in range(nn-j-1)])
            if(mianownik==0):
                Dev_j.append(1)
            else:
                Dev_j.append(licznik / mianownik)
        return (Dev_j)
    
    @staticmethod
    def calculate_sigma(p_ij: pd.DataFrame, l_ij: pd.DataFrame, w_ij: pd.DataFrame, dev_j: list[float]) -> list[float]:
        max_col = l_ij.shape[1]
        sigmas = []
        sd = []

        for j in range(0, max_col):  # zaczynamy od j=1, bo potrzebujemy j-1
            numerator = 0.0
            denominator = 0.0
            denominator_sd = 0.0

            for i in range(len(l_ij)):
                try:
                    w = w_ij.iloc[i, j]
                    p = p_ij.iloc[i, j]
                    l = l_ij.iloc[i, j]
                    dev = dev_j[j]

                    if not np.isnan(w) and not np.isnan(p) and not np.isnan(l):
                        numerator += w * p * (l - dev) ** 2
                        denominator += w
                        denominator_sd+=w * p 
                except IndexError:
                    continue
            if denominator > 1:
                sigma = numerator / (denominator-1)
                sd.append(sigma/denominator_sd)
            elif j ==(max_col-1) and sigmas[j - 2]!=0 and denominator_sd!=0:
                sigma = min(sigmas[j - 1]**4/sigmas[j - 2]**2, min(sigmas[j - 2]**2, sigmas[j - 1]**2) )
                sd.append(sigma/denominator_sd)
            else:
                sigma = 0
                sd.append(0)
            sigmas.append(sigma)

        return [sigmas,sd]


   ##########

    @staticmethod
    def calculate_train_devide(add_data_det, ekspozycja):
        data = {}
        headers = [x for x in range(len(add_data_det[0]))]

        for i, col in enumerate(headers):
            data[col] = []
            for row in add_data_det:
                value = row[i]
                try:
                    num_value = float(value)
                except (ValueError, TypeError):
                    num_value = None
                data[col].append(num_value)

        # Ekspozycja na float
        ekspozycja_values = []
        for exp_val in ekspozycja:
            try:
                ekspozycja_values.append(float(exp_val))
            except (ValueError, TypeError):
                ekspozycja_values.append(None)

        # Obliczenia train_devide
        train_devide = {}

        for col_idx, col in enumerate(headers):
            train_devide[col] = []
            col_data = data[col]

            if col_idx == 0:
                # Pierwsza kolumna
                for row_idx, value in enumerate(col_data):
                    if (value is not None and
                        row_idx < len(ekspozycja_values) and
                        ekspozycja_values[row_idx] not in (None, 0)):
                        result = value / ekspozycja_values[row_idx]
                        train_devide[col].append(result)
                    else:
                        train_devide[col].append(None)
            else:
                # Kolejne kolumny: różnica / ekspozycja
                prev_col_data = data[col_idx - 1]
                for row_idx, value in enumerate(col_data):
                    if (value is not None and
                        prev_col_data[row_idx] is not None and
                        row_idx < len(ekspozycja_values) and
                        ekspozycja_values[row_idx] not in (None, 0)):
                        difference = value - prev_col_data[row_idx]
                        result = difference / ekspozycja_values[row_idx]
                        train_devide[col].append(result)
                    else:
                        train_devide[col].append(None)

        # Serializacja do listy list
        train_devide_serializable = []
        num_rows = len(list(train_devide.values())[0]) if train_devide else 0

        for row_idx in range(num_rows):
            row = [train_devide[col][row_idx] for col in headers]
            train_devide_serializable.append(row)

        return {
            "train_devide": train_devide_serializable,
            "ekspozycja": ekspozycja
        }

    @staticmethod
    def wspolczynnik_LR(data_LR, w, exposure):
        # --- helper: rzutowanie wejść do np.ndarray ---
        def to_array(x):
            if isinstance(x, dict):  # słownik kolumn -> listy
                cols = [x[k] for k in sorted(x.keys())]
                arr = np.column_stack(cols)
            else:
                arr = np.array(x, dtype=object)

            # zamień None/"" na NaN i rzutuj do float
            arr = np.vectorize(lambda v: np.nan if (v is None or v == "") else float(v))(arr)
            return arr.astype(float)

        data_arr = to_array(data_LR)          # kształt (n, m)
        w_arr    = to_array(w)                # kształt (n, m)
        exp_arr  = np.array(
            [np.nan if (e is None or e == "") else float(e) for e in exposure],
            dtype=float
        )                                     # kształt (n,)

        n, m = data_arr.shape
        print(n, m)
        print(exp_arr )
        if w_arr.shape != (n, m):
            raise ValueError("Wymiary 'w' muszą być takie same jak 'data_LR'.")
        if exp_arr.shape[0] != n:
            raise ValueError("Długość 'exposure' musi równać się liczbie wierszy 'data_LR'.")

        wsp_LR = np.empty(m, dtype=float)

        for j in range(m):
            lr_col = data_arr[:, j]
            w_col  = w_arr[:, j]

            mask = (~np.isnan(lr_col)) & (~np.isnan(w_col)) & (~np.isnan(exp_arr))

            if not np.any(mask):
                wsp_LR[j] = 0.0  # lub np.nan, jeśli tak wolisz
                continue

            numerator   = np.sum(lr_col[mask] * w_col[mask] * exp_arr[mask])
            denominator = np.sum(w_col[mask]    * exp_arr[mask])

            wsp_LR[j] = (numerator / denominator) if denominator != 0 else 0.0

        return wsp_LR
    
    @staticmethod
    def sigma_LR(data_LR, w, exposure, wsp_LR):
        # --- helper: rzutowanie wejść do np.ndarray ---
        def to_array(x):
            if isinstance(x, dict):  # słownik kolumn -> listy
                cols = [x[k] for k in sorted(x.keys())]
                arr = np.column_stack(cols)
            else:
                arr = np.array(x, dtype=object)
            arr = np.vectorize(lambda v: np.nan if (v is None or v == "") else float(v))(arr)
            return arr.astype(float)

        data_arr = to_array(data_LR)           # (n, m)
        w_arr    = to_array(w)                 # (n, m)
        exp_arr  = np.array(
            [np.nan if (e is None or e == "") else float(e) for e in exposure],
            dtype=float
        )                                      # (n,)

        # wsp_LR może być listą/ndarray; rzutujemy do float
        wsp_LR   = np.array(wsp_LR, dtype=float)

        n, m = data_arr.shape
        if w_arr.shape != (n, m):
            raise ValueError("Wymiary 'w' muszą być takie same jak 'data_LR'.")
        if exp_arr.shape[0] != n:
            raise ValueError("Długość 'exposure' musi równać się liczbie wierszy 'data_LR'.")
        if wsp_LR.shape[0] != m:
            raise ValueError("Długość 'wsp_LR' musi równać się liczbie kolumn 'data_LR'.")

        sigma_j = np.empty(m, dtype=float)

        for j in range(m):
            lr_col = data_arr[:, j]
            w_col  = w_arr[:, j]
            mean_j = wsp_LR[j]

            # w oryginale licznik używał w*exp*(lr-mean)^2, a mianownik sumował tylko w
            mask = (~np.isnan(w_col)) & (~np.isnan(exp_arr)) & (~np.isnan(lr_col)) & (~np.isnan(mean_j))

            if not np.any(mask):
                sigma_j[j] = 0
                continue

            sum_num   = np.sum(w_col[mask] * exp_arr[mask] * (lr_col[mask] - mean_j) ** 2)
            sum_denom = np.sum(w_col[mask])

            if (sum_denom > 1) and (sum_num != 0):
                sigma_j[j] = sum_num / (sum_denom - 1.0)
            else:
                sigma_j[j] = 0

        return sigma_j

    @staticmethod
    def wspolczynnik_sd(wsp_sigma, w, exposure):
        import numpy as np

        # --- helper: rzutowanie wejść do np.ndarray ---
        def to_array(x):
            if isinstance(x, dict):  # słownik kolumn -> listy
                cols = [x[k] for k in sorted(x.keys())]
                arr = np.column_stack(cols)
            else:
                arr = np.array(x, dtype=object)

            arr = np.vectorize(lambda v: np.nan if (v is None or v == "") else float(v))(arr)
            return arr.astype(float)

        w_arr = to_array(w)  # (n, m)
        exp_arr = np.array(
            [np.nan if (e is None or e == "") else float(e) for e in exposure],
            dtype=float
        )  # (n,)
        wsp_sigma = np.array(wsp_sigma, dtype=float)  # (m,)

        n, m = w_arr.shape
        if exp_arr.shape[0] != n:
            raise ValueError("Długość 'exposure' musi równać się liczbie wierszy wag 'w'.")
        if wsp_sigma.shape[0] != m:
            raise ValueError("Długość 'wsp_sigma' musi równać się liczbie kolumn (m).")

        sd_j = np.empty(m, dtype=float)
        for j in range(m):
            denominator = 0.0
            for i in range(n):
                wij = w_arr[i, j]
                ei = exp_arr[i]
                if not np.isnan(wij):
                    denominator += wij * ei  # uwaga: jeśli ei jest NaN, denominator stanie się NaN (jak w njit)

            if denominator == 0.0 or wsp_sigma[j] == 0.0:
                sd_j[j] = 0.0
            else:
                sd_j[j] = np.sqrt(wsp_sigma[j] / denominator)

        return sd_j


    #### paid to incurred
    @staticmethod
    def wspolczynnik_r(d_paid, d_claim, weights):
        mm, nn = d_paid.shape
        wspol = np.ones(nn, dtype=float)
        for j in range(nn):
            licznik = np.nansum(
                d_paid[:(mm-j), j] * weights[:(mm-j), j]
            )
            mianownik = np.nansum(
                d_claim[:(mm-j), j] * weights[:(mm-j), j]
            )

            if mianownik > 0:
                wspol[j] = licznik / mianownik
            else:
                wspol[j] = 1.0

        return wspol


    import numpy as np

    @staticmethod
    def wspolczynnik_var_j(data_paid, data_incurred, r_j, weights):
        mm, nn = data_paid.shape
        var_j = []

        for j in range(nn):
            # trójkąt
            paid_col = data_paid[:mm - j, j]
            inc_col = data_incurred[:mm - j, j]
            w_col = weights[:mm - j, j]

            # r_i_j = paid / incurred
            r_ij = np.where(
                inc_col != 0,
                paid_col / inc_col,
                1
            )

            # (r_i_j - r_j)^2
            diff2 = (r_ij - r_j[j]) ** 2

            # składniki wariancji
            var_j_pom = inc_col * diff2 * w_col

            # przypadek ostatniej kolumny
            if (nn - j) == 1:
                if var_j[j - 1] > 0:
                    mianownik_pom = var_j[j - 1]
                else:
                    mianownik_pom = 1

                s_min = np.min([
                    var_j[j - 1],
                    var_j[j - 2],
                    (var_j[j - 1] ** 2) / mianownik_pom
                ])
                var_j.append(s_min)

            # standardowy przypadek
            else:
                denom = np.nansum(weights[:, j]) - 1
                if denom > 0:
                    var_j.append(np.nansum(var_j_pom) / denom)
                else:
                    var_j.append(np.nansum(var_j_pom) / 1)

        return np.array(var_j)


    @staticmethod
    def wspolczynnik_res_i_j(paid, incurred, r_j, var_j, weights):
        mm, nn = incurred.shape
        res = np.zeros_like(incurred, dtype=float)

        for j in range(nn):
            # trójkąt
            paid_col = paid[:mm - j, j]
            inc_col = incurred[:mm - j, j]
            w_col = weights[:mm - j, j]

            # r_i_j = paid / incurred
            r_ij = np.where(
                inc_col != 0,
                paid_col / inc_col,
                0.0
            )

            # licznik
            licznik = (r_ij - r_j[j]) * w_col

            # mianownik
            mianownik = np.sqrt(var_j[j] / inc_col)

            # bez mask / valid – dzielenie tylko tam gdzie ma sens
            res[:mm - j, j] = np.where(
                mianownik > 0,
                licznik / mianownik,
                0.0
            )

        return res

    @staticmethod
    def lambda_correlation(triangle_res):
        mm, nn = triangle_res.shape
        num = 0.0
        den = 0.0

        for i in range(mm - 1):
            for j in range(nn - 1 - i):
                num += triangle_res[i, j] * triangle_res[i, j + 1]
                den += triangle_res[i, j] ** 2

        return num / den if den > 0 else 0.0
    
    @staticmethod
    def vector_reverse_diagonal(data: np.ndarray):
        """Zwraca wektor elementów odwrotnej przekątnej (ostatniej pełnej diagonali)."""
        rows, cols = data.shape
        result = []
        for i in range(rows):
            j = cols - 1 - i
            if 0 <= j < cols:
                v = data[i, j]
                if not np.isnan(v):
                    result.append(v)
        return np.array(result)



    @staticmethod
    def triangle_forward_np_p_i(triangle_data: np.ndarray,triangle_paid_infl: np.ndarray, f: np.ndarray,rj: np.ndarray, discount_factors,net_to_gross) -> np.ndarray:
        mm, nn = triangle_data.shape
        n_steps = len(f)
        required_cols = n_steps + 1

        base_col = triangle_paid_infl[:, 0].copy()
        if nn < required_cols:
            extra_cols = required_cols - nn
            triangle_extended = np.full((mm, required_cols), np.nan)
            triangle_extended[:, :nn] = triangle_data
            triangle_extended_paid = np.full((mm, required_cols), np.nan)
            triangle_extended_paid[:, :nn] = triangle_paid_infl
        else:
            triangle_extended = triangle_data.copy()
            triangle_extended_paid = triangle_paid_infl.copy()
        for j in range(n_steps):
            max_ind_row = max(0, mm - j - 1)
            for i in range(max_ind_row, mm):
                if np.isnan(triangle_extended[i, j]):
                    continue
                triangle_extended[i, j + 1] = triangle_extended[i, j] * f[j]
                triangle_extended_paid[i, j + 1] = triangle_extended[i, j + 1]*rj[j+1]
        cols_tmp = triangle_extended_paid.shape[1]
        tri_proj = np.full((mm, cols_tmp + 1), np.nan)
        tri_proj[:, 0] = base_col
        tri_proj[:, 1:] = triangle_extended_paid
        inc_proj = tri_proj[:, 1:] - tri_proj[:, :-1]
        inc_proj[:, 0] = base_col
        for rr in range(mm - 1, -1, -1):
            offset = mm - 1 - rr
            for cc in range(offset + 1, inc_proj.shape[1]):
                idx = cc - (offset + 1)
                if idx < len(discount_factors) and not np.isnan(inc_proj[rr, cc]):
                    inc_proj[rr, cc] /= discount_factors[idx]
        total_disc =  np.nansum(inc_proj, axis=1)

        cum_trian = np.nansum(inc_proj, axis=1)
 
        latest = TriangleCalculator.vector_reverse_diagonal(triangle_data)
        #ult_net_disc = total_disc*0.8841
  
        ult_net_disc = [
            latest[i] + (cum_trian[i] - latest[i]) * net_to_gross[i]
            for i in range(len(latest))
        ]

        last_col = triangle_extended_paid[:,-1].tolist()
        ult_net_disc_vec = ult_net_disc

        return {
            "last_col": last_col,
            "cum_trian": cum_trian,
            "ult_net_disc": ult_net_disc_vec,
        }
    
 