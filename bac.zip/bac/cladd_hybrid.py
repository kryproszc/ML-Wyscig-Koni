
from typing import Iterable, Sequence
import time

import numpy as np
import pandas as pd
from numba import njit, prange

### do CL

# ---------------------------------------------------------------------------
# Helper functions (Numba‑accelerated)
# ---------------------------------------------------------------------------
@njit
def vector_reverse_diagonal(data: np.ndarray):
    """Zwraca wektor elementów odwrotnej przekątnej (ostatniej pełnej diagonali)."""
    rows, cols = data.shape
    result = []
    for i in range(rows):
        j = cols - 1 - i
        if 0 <= j < cols:
            v = data[i, j]
            if not np.isnan(v):
                result.append(v)
    return np.array(result)

@njit
def sum_reverse_diagonal(data: np.ndarray) -> float:
    """Suma odwrotnej przekątnej (ostatniej pełnej diagonali)."""
    tot = 0.0
    rows, cols = data.shape
    for i in range(rows):
        j = cols - 1 - i
        if 0 <= j < cols:
            v = data[i, j]
            if not np.isnan(v):
                tot += v
    return tot


@njit
def Dev_prem(data_paid: np.ndarray, wagi: np.ndarray) -> np.ndarray:
    n_row, n_col = data_paid.shape
    dev = np.empty(n_col - 1)
    for j in range(n_col - 1):
        num = den = 0.0
        for i in range(n_row):
            val_curr = data_paid[i, j]
            val_next = data_paid[i, j + 1]
            w = wagi[i, j]
            if not (np.isnan(val_next)):
                num += val_next * w
                den += val_curr * w
        dev[j] = num / den if den != 0.0 else 1.0
    return dev


@njit
def elementwise_division(data_paid: np.ndarray) -> np.ndarray:

    n_rows, n_cols = data_paid.shape
    out = np.empty((n_rows, n_cols - 1))
    for i in range(n_rows):
        for j in range(n_cols - 1):
            a = data_paid[i, j]
            b = data_paid[i, j + 1]
            if a != 0.0 and not np.isnan(b):
                val = b / a
                out[i, j] = val if np.isfinite(val) else 1.0
            else:
                out[i, j] = 1.0
    return out

@njit
def calculate_sigma(p_ij, l_ij, w_ij, dev_j):
    n_rows, n_cols = l_ij.shape
    sigmas = []
    sds = []
    
    for j in range(n_cols):
        dev = dev_j[j]
        num = den = den_sd = 0.0
        
        for i in range(n_rows):
            w = w_ij[i, j]
            p = p_ij[i, j]
            l = l_ij[i, j]
            
            # Sprawdź czy wszystkie wartości są prawidłowe (nie NaN)
            if not (np.isnan(w) or np.isnan(p) or np.isnan(l)):
                diff = l - dev
                num += w * p * diff * diff
                den += w
                den_sd += w * p
        
        # Oblicz sigma zgodnie z oryginalną logiką
        if den > 1:
            sigma = num / (den - 1.0)
            sd_val = sigma / den_sd if den_sd > 0 else 0.0
        elif j == (n_cols - 1) and len(sigmas) >= 2 and sigmas[j-2] != 0 and den_sd != 0:
            # Specjalna logika dla ostatniej kolumny
            sigma = min(sigmas[j-1]**4 / sigmas[j-2]**2, min(sigmas[j-2]**2, sigmas[j-1]**2))
            sd_val = sigma / den_sd
        else:
            sigma = 0.0
            sd_val = 0.0
        
        sigmas.append(sigma)
        sds.append(sd_val)
    
    return sigmas, sds



@njit
def choose_value_list(vec_input, vec_wykluczenia, a, b):
    count = 0
    for k in range(len(vec_wykluczenia)):
        idx = vec_wykluczenia[k] - 1
        val = vec_input[idx]
        if a < val < b:
            count += 1

    out_vals = np.empty(count)
    out_inds = np.empty(count, dtype=np.int64)

    pos = 0
    for k in range(len(vec_wykluczenia)):
        idx = vec_wykluczenia[k] - 1
        val = vec_input[idx]
        if a < val < b:
            out_vals[pos] = val
            out_inds[pos] = idx
            pos += 1

    return out_vals, out_inds

@njit
def fit_curve_factor_cl(data_input, sd_input, x_k):
    n = len(data_input)
    se2 = sd_input 
    w = np.empty(n)
    for i in range(n):
        denom = (data_input[i] - 1) ** 2
        w[i] = 1.0 / np.sqrt(np.log(1.0 + se2[i] / denom)) if denom > 0.0 else 0
    y = np.log(data_input - 1.0)
    A = A_x = A_xx = A_y = A_xy = 0.0
    for i in range(n):
        wi = w[i]
        xi = x_k[i]
        yi = y[i]
        A += wi
        A_x += wi * xi
        A_xx += wi * xi * xi
        A_y += wi * yi
        A_xy += wi * xi * yi
    Delta = A * A_xx - A_x * A_x
    if Delta == 0.0:
        return 0.0, 0.0
    a_coef = (A * A_xy - A_x * A_y) / Delta
    b_coef = (A_xx * A_y - A_x * A_xy) / Delta
    return a_coef, b_coef

@njit
def wspolczynnik_reg_factor_cl(a_coef, b_coef, k_start, k_stop):
    n = k_stop - k_start + 1
    out = np.empty(n)
    for i in range(n):
        k = k_start + i
        out[i] = 1.0 + np.exp(a_coef * k + b_coef)
    return out


@njit
def triangle_forward_one_np(triangle_input, f, k_forward_start):
    mm, nn = triangle_input.shape
    req_cols = len(f) + 1
    tri = np.zeros((mm, req_cols))
    # kopiuj istniejące dane
    for i in range(mm):
        for j in range(nn):
            tri[i, j] = triangle_input[i, j]
    # projekcja
    for j in range(k_forward_start - 1, len(f)):
        if j + 1 >= req_cols:
            continue
        max_row = max(0, mm - j - 1)
        for i in range(max_row, mm):
            tri[i, j + 1] = tri[i, j] * f[j]
    return tri





####

@njit
def vector_reverse_diagonal(data: np.ndarray):
    """Zwraca wektor elementów odwrotnej przekątnej (ostatniej pełnej diagonali)."""
    rows, cols = data.shape
    result = []
    for i in range(rows):
        j = cols - 1 - i
        if 0 <= j < cols:
            v = data[i, j]
            if not np.isnan(v):
                result.append(v)
    return np.array(result)


@njit
def _build_base_triangle_cladd(data_paid, n_dev):
    """
    Buduje bazę trójkąta o wymiarze (mm, n_dev+1) kopiując dane
    i dopełniając NaN.
    """
    mm, n_cols_orig = data_paid.shape
    total_cols = n_dev + 1
    base = np.empty((mm, total_cols), dtype=np.float64)

    for i in range(mm):
        for j in range(total_cols):
            if j < n_cols_orig:
                base[i, j] = data_paid[i, j]
            else:
                base[i, j] = np.nan
    return base


@njit
def transform_data_cladd(data_input, exposure):
    """
    Transformacja do LR-inkrementów:
    col0: C_{i,0} / exposure[i]
    colj: (C_{i,j}-C_{i,j-1}) / exposure[i]
    """
    n, m = data_input.shape
    data_input = data_input[:, :(n + 1)]

    output = np.empty((n, m))

    for i in range(n):
        output[i, 0] = data_input[i, 0] / exposure[i]

    for j in range(1, m):
        for i in range(n):
            if not np.isnan(data_input[i, j]):
                output[i, j] = (data_input[i, j] - data_input[i, j - 1]) / exposure[i]

    return output

#######################

@njit
def choose_value_list(vec_input, vec_wykluczenia, a, b):
    """
    Wybiera wartości z vec_input wg indeksów w vec_wykluczenia (1-based),
    filtrując do przedziału (a, b). Zwraca (wartosci, indeksy_0based).
    """
    count = 0
    for k in range(len(vec_wykluczenia)):
        idx = vec_wykluczenia[k] - 1
        val = vec_input[idx]
        if a < val < b:
            count += 1

    out_vals = np.empty(count)
    out_inds = np.empty(count, dtype=np.int64)

    pos = 0
    for k in range(len(vec_wykluczenia)):
        idx = vec_wykluczenia[k] - 1
        val = vec_input[idx]
        if a < val < b:
            out_vals[pos] = val
            out_inds[pos] = idx
            pos += 1

    return out_vals, out_inds


@njit(fastmath=False)
def fit_curve_factor_lr(data_input, sd_input, x_k):
    """
    Dopasowanie krzywej: log(y)=a*k+b, gdzie y=data_input.
    Wagi zależą od błędu (sd_input).
    Zwraca (a_coef, b_coef).
    """
    n = len(data_input)
    se2 = sd_input ** 2
    w = np.empty(n)

    for i in range(n):
        denom = data_input[i] ** 2
        w_mian = np.sqrt(np.log(1.0 + se2[i] / denom)) if denom != 0.0 else 0.0
        if w_mian != 0.0:
            w[i] = 1.0 / w_mian
        else:
            w[i] = 0.0

    y = np.empty(n)
    for i in range(n):
        if data_input[i] > 0.0:
            y[i] = np.log(data_input[i])
        else:
            y[i] = 0.0

    A = A_x = A_xx = A_y = A_xy = 0.0
    for i in range(n):
        wi = w[i]
        xi = x_k[i]
        yi = y[i]
        A += wi
        A_x += wi * xi
        A_xx += wi * xi * xi
        A_y += wi * yi
        A_xy += wi * xi * yi

    Delta = A * A_xx - A_x * A_x
    if Delta == 0.0:
        return 0.0, 0.0

    a_coef = (A * A_xy - A_x * A_y) / Delta
    b_coef = (A_xx * A_y - A_x * A_xy) / Delta
    return a_coef, b_coef


@njit
def wspolczynnik_reg_factor_lr(a_coef, b_coef, k_start, k_stop):
    """
    Ogon: exp(a*k+b) dla k=k_start..k_stop (włącznie).
    """
    n = k_stop - k_start + 1
    out = np.empty(n)
    for i in range(n):
        k = k_start + i
        out[i] = np.exp(a_coef * k + b_coef)
    return out


@njit
def _build_base_triangle(data_paid, n_dev):
    """
    Buduje bazę trójkąta o wymiarze (mm, n_dev+1) kopiując dane
    i dopełniając NaN.
    """
    mm, n_cols_orig = data_paid.shape
    total_cols = n_dev + 1
    base = np.empty((mm, total_cols), dtype=np.float64)

    for i in range(mm):
        for j in range(total_cols):
            if j < n_cols_orig:
                base[i, j] = data_paid[i, j]
            else:
                base[i, j] = np.nan
    return base


@njit
def triangle_forward_loss_ratio_numba(tri_in, LR_j, exposure, k_forward):
    """
    Projekcja LR: C_{i,j+1} = C_{i,j} + exposure[i] * LR_j[j]
    """
    mm, n_cols_orig = tri_in.shape
    n_cols_out = max(n_cols_orig, len(LR_j) + 1)

    tri = np.empty((mm, n_cols_out), dtype=np.float64)
    tri[:] = np.nan

    for i in range(mm):
        for j in range(n_cols_orig):
            tri[i, j] = tri_in[i, j]

    for j in range(k_forward):
        max_ind_row = 1 if (mm - j) < 1 else (mm - j)
        start_row = max_ind_row - 1
        for i in range(start_row, mm):
            base_val = tri[i, j]
            tri[i, j + 1] = base_val + exposure[i] * LR_j[j]

    return tri


@njit
def sum_reverse_diagonal(data):
    """
    Suma elementów odwrotnej przekątnej (ostatniej pełnej diagonali).
    """
    tot = 0.0
    rows, cols = data.shape
    for i in range(rows):
        j = cols - 1 - i
        if 0 <= j < cols:
            v = data[i, j]
            if not np.isnan(v):
                tot += v
    return tot


@njit
def vector_reverse_diagonal(data):
    """
    Zwraca wektor elementów odwrotnej przekątnej (ostatniej pełnej diagonali).
    """
    rows, cols = data.shape
    result = []
    for i in range(rows):
        j = cols - 1 - i
        if 0 <= j < cols:
            v = data[i, j]
            if not np.isnan(v):
                result.append(v)
    return np.array(result)


@njit
def transform_data(data_input, exposure):
    """
    Transformacja do LR-inkrementów:
    col0: C_{i,0} / exposure[i]
    colj: (C_{i,j}-C_{i,j-1}) / exposure[i]
    """
    n, m = data_input.shape
    data_input = data_input[:, :(n + 1)]

    output = np.empty((n, m))

    for i in range(n):
        output[i, 0] = data_input[i, 0] / exposure[i]

    for j in range(1, m):
        for i in range(n):
            if not np.isnan(data_input[i, j]):
                output[i, j] = (data_input[i, j] - data_input[i, j - 1]) / exposure[i]

    return output


@njit
def wspolczynnik_LR(data_LR, w, exposure):
    """
    LR_j = sum_i(lr_ij * w_ij * e_i) / sum_i(w_ij * e_i)
    """
    n, m = data_LR.shape
    wsp_LR = np.empty(m)

    for j in range(m):
        numerator = 0.0
        denominator = 0.0

        for i in range(n):
            lr_ij = data_LR[i, j]
            w_ij = w[i, j]
            e_i = exposure[i]

            if not np.isnan(lr_ij) and not np.isnan(w_ij) and not np.isnan(e_i) and w_ij > 0.0:
                numerator += lr_ij * w_ij * e_i
                denominator += w_ij * e_i

        if denominator == 0.0:
            wsp_LR[j] = 0.0
        else:
            wsp_LR[j] = numerator / denominator

    return wsp_LR


@njit
def sigma_LR(data_LR, w, exposure, wsp_LR):
    """
    Sigma dla LR (wariancja ważona): sum(w*e*(lr-mean)^2)/(sum(w)-1)
    """
    n, m = data_LR.shape
    sigma_j = np.empty(m)
    for j in range(m):
        sum_num = 0.0
        sum_denom = 0.0
        mean_j = wsp_LR[j]
        for i in range(n):
            lr = data_LR[i, j]
            wij = w[i, j]
            ei = exposure[i]
            if not np.isnan(wij) and wij>0.0  :
                sum_num += wij * ei * (lr - mean_j) ** 2
                sum_denom += wij
        if sum_denom > 1.0:
            sigma_j[j] = sum_num / (sum_denom - 1.0)
        else:
            sigma_j[j] = 0.0
    return sigma_j


@njit
def wspolczynnik_sd(wsp_sigma, w, exposure):
    """
    sd_j = sqrt( sigma_j / sum_i(w_ij * e_i) )
    """
    n, m = w.shape
    sd_j = np.empty(m)

    for j in range(m):
        denominator = 0.0
        for i in range(n):
            wij = w[i, j]
            ei = exposure[i]
            if not np.isnan(wij):
                denominator += wij * ei

        if denominator == 0.0 or wsp_sigma[j] == 0.0:
            sd_j[j] = 0.0
        else:
            sd_j[j] = np.sqrt(wsp_sigma[j] / denominator)

    return sd_j





########################

@njit
def run_simulation_addcl_numba_batched(data_paid,
                            sigma_j, 
                            dev,
                            sd,
                            wagi_trimmed,
                            wykluczenia,
                            Poz_CL,
                            il_ogon_CL,
                            sigma_j_LR,
                            dev_LR,
                            sd_LR,
                            e_values,
                            wagi_trimmed_LR,
                            ilosc_dop_wsp_LR,
                            Poz_LR,
                            il_ogon_LR,
                            ultimate_param_resrisk,
                            sim_total_lr,
                            batch_sim_lr,
                            main_seed_lr,
                            discount_factors,
                            net_to_gross,
                            k_zmiana):

    print(k_zmiana)
    latest = vector_reverse_diagonal(data_paid)
    mm, n_cols_orig   = data_paid.shape
    n_dev   = len(dev)
    base    = _build_base_triangle_cladd(data_paid, n_dev)
    results = np.zeros((sim_total_lr, 3))
    n_batches = (sim_total_lr + batch_sim_lr - 1) // batch_sim_lr
    index_el = 0
    discount_factors_safe = discount_factors
    disc_len = n_dev  
    if len(discount_factors) == 0:
        discount_factors_safe = np.ones(disc_len)
    else:
        discount_factors_safe = np.ones(disc_len)
        up_to = disc_len if len(discount_factors) > disc_len else len(discount_factors)
        for i in range(up_to):
            discount_factors_safe[i] = discount_factors[i]
    if len(net_to_gross) == 0:
        net_to_gross_safe = np.ones(mm)
    else:
        net_to_gross_safe = np.ones(mm)
        up_to = mm if len(net_to_gross) > mm else len(net_to_gross)
        for i in range(up_to):
            net_to_gross_safe[i] = net_to_gross[i]

    for batch_idx in range(n_batches):
        start   = batch_idx * batch_sim_lr
        end     = min(start + batch_sim_lr, sim_total_lr)
        cur_bs  = end - start

        mu_part_lr    = np.empty((cur_bs, n_dev), dtype=np.float64)
        sigma_part_lr = np.empty((cur_bs, n_dev), dtype=np.float64)

        mu_part_cl    = np.empty((cur_bs, n_dev), dtype=np.float64)
        sigma_part_cl = np.empty((cur_bs, n_dev), dtype=np.float64)

        np.random.seed(main_seed_lr + batch_idx)
        for jj in range(n_dev):
            mu_part_lr[:, jj] = np.random.normal(dev_LR[jj], sd_LR[jj], cur_bs)
            df_lr  = max(1, mm - jj)
            chi_lr = np.random.chisquare(df_lr, cur_bs)
            for ss in range(cur_bs):
                sigma_part_lr[ss, jj] = (chi_lr[ss] * sigma_j_LR[jj]) / df_lr

        for jj in range(n_dev):
            mu_part_cl[:, jj] = np.random.normal(dev[jj], sd[jj], cur_bs)
            df_cl  = max(1, mm - jj-2)
            chi_cl = np.random.chisquare(df_cl, cur_bs)
            for ss in range(cur_bs):
                sigma_part_cl[ss, jj] = (chi_cl[ss] * sigma_j[jj]) / df_cl

        for s in range(cur_bs):

            paid = base.copy()
            n_cols_target = n_dev + 1
            data_paid_to_one = data_paid.copy()

            new_tri = np.concatenate((data_paid_to_one, np.zeros((mm,1))), axis=1)
            empty_column = np.full((wagi_trimmed_LR.shape[0], 1), np.nan)
            wagi_modified_lr = np.hstack((wagi_trimmed_LR, empty_column))
            empty_row = np.full((1, wagi_trimmed.shape[1]), np.nan)
            wagi_modified_row = np.vstack((wagi_trimmed, empty_row))
            empty_column = np.full((wagi_modified_row.shape[0], 1), np.nan)
            wagi_modified = np.hstack((wagi_modified_row, empty_column))
 
            for j in range(n_dev):
                max_ind_row = mm - j
                if max_ind_row < 1:
                    max_ind_row = 1
                
                for i in range(max_ind_row - 1, mm):
                    var_ij_lr = sigma_part_lr[s, j] / e_values[i]
                    
                    if mu_part_lr[s, j] > 0.0:
                        lmean_lr  = np.log(mu_part_lr[s, j]**2 /
                                        np.sqrt(mu_part_lr[s, j]**2 + var_ij_lr))
                        lstdev_lr = np.sqrt(np.log(1.0 + var_ij_lr /
                                                (mu_part_lr[s, j]**2)))
                        sto_lr = np.random.lognormal(lmean_lr, lstdev_lr)
                    else:
                        adj_mu_lr = (mu_part_lr[s, j] + paid[i, j] / e_values[i])
                        lmean_lr  = np.log(adj_mu_lr**2 /
                                        np.sqrt(adj_mu_lr**2 + var_ij_lr))
                        lstdev_lr = np.sqrt(np.log(1.0 + var_ij_lr / (adj_mu_lr**2)))
                        sto_lr = np.random.lognormal(lmean_lr, lstdev_lr)
                    
                    base_cl = paid[i, j]
                    if base_cl > 0.0:
                        var_ij_cl = sigma_part_cl[s, j] / base_cl
                        m2_cl = mu_part_cl[s, j] * mu_part_cl[s, j]
                        denom_cl = np.sqrt(m2_cl + var_ij_cl)
                        ln_mean_cl = np.log(m2_cl / denom_cl)
                        ln_sd_cl = np.sqrt(np.log(1.0 + (var_ij_cl / m2_cl)))
                        cl_factor = np.random.lognormal(ln_mean_cl, ln_sd_cl)
                    else:
                        cl_factor = 1.0
                    if i == mm - j - 1 and (j < (mm)):
                        dev_con_lr = dev_LR[j]
                        std_con_lr = sd_LR[j]
                        
                        if dev_con_lr - 2 * std_con_lr <= sto_lr <= dev_con_lr + 2 * std_con_lr:
                            wagi_modified_lr[i , j + 1] = 1
                        elif (dev_con_lr - 3 * std_con_lr <= sto_lr <= dev_con_lr - 2 * std_con_lr) or (
                                dev_con_lr + 2 * std_con_lr <= sto_lr <= dev_con_lr + 3 * std_con_lr):
                            wagi_modified_lr[i, j + 1] = 0.5
                        else:
                            wagi_modified_lr[i , j + 1] = 0
                    
                    if i == mm - j - 1 and (j < (mm)) and base_cl > 0.0:
                        dev_con_cl = mu_part_cl[s, j]
                        var_ij_cl_for_std = sigma_part_cl[s, j] / base_cl
                        std_con_cl = np.sqrt(var_ij_cl_for_std)
                        
                        if dev_con_cl - 2.0 * std_con_cl <= cl_factor <= dev_con_cl + 2.0 * std_con_cl:
                            wagi_modified[i, j] = 1.0
                        elif ((dev_con_cl - 3.0 * std_con_cl) <= cl_factor < (dev_con_cl - 2.0 * std_con_cl)) or \
                             ((dev_con_cl + 2.0 * std_con_cl) < cl_factor <= (dev_con_cl + 3.0 * std_con_cl)):
                            wagi_modified[i, j] = 0.5
                        else:
                            wagi_modified[i, j] = 0.0
                    elif i == mm - j - 1 and (j < (mm)) and base_cl <= 0.0:
                        wagi_modified[i, j] = 0.0
                    
                    if j < k_zmiana:
                        if mu_part_lr[s, j] > 0.0:
                            paid[i, j + 1] = e_values[i] * sto_lr + paid[i, j]
                            if j == mm - i - 1:
                                new_tri[i, j + 1] = e_values[i] * sto_lr + paid[i, j]
                        else:
                            paid[i, j + 1] = (e_values[i] *
                                              (sto_lr - paid[i, j] / e_values[i]) +
                                              paid[i, j])
                            
                            if j == mm - i - 1:
                                new_tri[i, j + 1] = (e_values[i] *
                                              (sto_lr - paid[i, j] / e_values[i]) +
                                              paid[i, j])
                                    
                    else:
                        base_cl = paid[i, j]
                        if base_cl > 0.0:
                            paid[i, j + 1] = base_cl * cl_factor
                            if i == mm - j - 1:
                                new_tri[i, j + 1] = paid[i, j + 1]
                        else:
                            paid[i, j + 1] = 0.0
                            if i == mm - j - 1:
                                new_tri[i, j + 1] = 0.0
            ult_gross = np.sum(paid[:,-1])
            results[index_el, 0] = ult_gross

            new_tri[1:,new_tri.shape[1]-1] = np.nan

            # CL wspolczynniki
            tri_sim = new_tri[:, 1:(n_cols_orig+1)]
            dev_j = Dev_prem(new_tri[:, :(n_cols_orig+1)], wagi_modified)
            l_ij = elementwise_division(new_tri[:, :(n_cols_orig+1)])
            sigma_all = calculate_sigma(new_tri[:, :(n_cols_orig+1)], l_ij, wagi_modified, dev_j)
            sd_sim = np.array(sigma_all[1]) # konwertuj listę na tablicę numpy
            dev_sel, ind_choode = choose_value_list(dev_j, wykluczenia, 1, 10)
            sd_sel = [np.sqrt(sd_sim[x]) for x in ind_choode]

            x_k = ind_choode + 1
            a_coef, b_coef = fit_curve_factor_cl(dev_sel, sd_sel, x_k)

            total_f_len = len(dev_j) + il_ogon_CL
            if (Poz_CL - 1) > 0:
                vec_f = np.empty(total_f_len - 1)
                # zachowanie jak w oryginale
                for k in range(Poz_CL - 1):
                    vec_f[k] = dev_j[k + 1]
                tail_from = Poz_CL + 1
                tail_to = total_f_len
                tail = wspolczynnik_reg_factor_cl(a_coef, b_coef, tail_from, tail_to)
                tlen = len(tail)
 
                for k in range(tlen):
                    vec_f[(Poz_CL - 1) + k] = tail[k]
            else:
                tail = wspolczynnik_reg_factor_cl(a_coef, b_coef, 2, total_f_len)
                vec_f = tail

            # CL koniec wspolczynniki


            # LR wspolczynniki
            LR_i_j_stoch = transform_data(new_tri, e_values)
            LR_j_wyzn = wspolczynnik_LR(LR_i_j_stoch, wagi_modified_lr, e_values)
            sigma_j_pred = sigma_LR(LR_i_j_stoch, wagi_modified_lr, e_values, LR_j_wyzn)

            sd_j = wspolczynnik_sd(sigma_j_pred, wagi_modified_lr, e_values)
            vector_value, x_k_ind = choose_value_list(LR_j_wyzn, ilosc_dop_wsp_LR, 0, 10)
            sd_input = sd_j[x_k_ind]
            x_k_ind = x_k_ind
            a, b = fit_curve_factor_lr(vector_value, sd_input, x_k_ind)
            total_f_len = len(LR_j_wyzn) + il_ogon_LR + 1
            vec_lr = np.empty(total_f_len - 2)
            vec_lr[:(Poz_LR - 2)] = LR_j_wyzn[2:(Poz_LR)]
            tail_factors = wspolczynnik_reg_factor_lr(
                float(a), float(b),
                Poz_LR,
                total_f_len - 1,
            )
            vec_lr[(Poz_LR - 2):] = tail_factors[:(total_f_len - 2)]
           
            # LR wspolczynniki koniec



            # Wyliczenia dla CL i LR
            if len(vec_f) > mm:
                pad_width = len(vec_f) + 1 - n_cols_orig
            if pad_width > 0:
                tri_proj_tmp = np.hstack((tri_sim, np.full((mm, pad_width), np.nan)))
            for j in range(0, len(vec_f)):
                max_ind_row = max(0, mm - j - 1)
                for i in range(max_ind_row, mm):
                    if j < k_zmiana:
                        tri_proj_tmp[i, j + 1] = tri_proj_tmp[i, j] + e_values[i] * vec_lr[j]
                    else:
                        tri_proj_tmp[i, j + 1] = tri_proj_tmp[i, j] * vec_f[j]

            
           # print(pd.DataFrame(tri_proj_tmp))
            # dyskontowanie i netto-gross


            cols_tmp = tri_proj_tmp.shape[1]
            tri_proj = np.empty((mm, cols_tmp + 1))
            tri_proj[:, 0] = data_paid[:, 0]

            for r in range(mm):
                for c in range(cols_tmp):
                    tri_proj[r, c + 1] = tri_proj_tmp[r, c]
            inc_proj = tri_proj[:, 1:] - tri_proj[:, :-1]
            inc_disc = np.empty_like(tri_proj)
            inc_disc[:, 0] = tri_proj[:, 0]
            for r in range(mm):
                for c in range(1, tri_proj.shape[1]):
                    inc_disc[r, c] = inc_proj[r, c - 1]

            for rr in range(mm - 1, -1, -1):
                offset = mm - 1 - rr
                for cc in range(offset + 1, tri_proj.shape[1]):
                    idx = cc - (offset + 1)
                    if idx < len(discount_factors_safe):
                        inc_disc[rr, cc] /= discount_factors_safe[idx]

            cum_disc = inc_disc.copy()
            for r in range(mm):
                for c in range(1, tri_proj.shape[1]):
                    cum_disc[r, c] += cum_disc[r, c - 1]

            ult_gross = np.sum(paid[:,-1])

            #ult_gross_disc = np.sum(cum_disc[:, n_cols_target - 1])
            #ult_net_disc = latest + (ult_gross_disc - latest) * net_to_gross[

            ult_gross_disc = cum_disc[:, n_cols_target - 1]
           # total_disc = np.sum(np.nansum(inc_proj, axis=1))
           # ult_net_disc = latest + (total_disc - latest) * net_to_gross
            ult_gross_disc_sum = np.sum(ult_gross_disc)
            latest = vector_reverse_diagonal(data_paid)
            ult_net_disc = 0
            for iii in range(len(latest)):
                ult_net_disc += latest[iii] + (ult_gross_disc[iii] - latest[iii]) * net_to_gross_safe[iii]

            results[index_el, 0] = ult_gross
            results[index_el, 1] = ult_gross_disc_sum
            results[index_el, 2] = ult_net_disc
            index_el = index_el+1

    return results


class CLADDHybrid:
   
    def vector_reverse_diagonal_to_script(self,data):
        return vector_reverse_diagonal(data)

    def run_simulation_addcl(self,
                            data_paid,
                            sigma_j, 
                            dev,
                            sd,
                            wagi_trimmed,
                            wykluczenia,
                            Poz_CL,
                            il_ogon_CL,
                            sigma_j_LR,
                            dev_LR,
                            sd_LR,
                            e_values,
                            wagi_trimmed_LR,
                            ilosc_dop_wsp_LR,
                            Poz_LR,
                            il_ogon_LR,
                            ultimate_param_resrisk,
                            sim_total_lr,
                            batch_sim_lr,
                            main_seed_lr,
                            discount_factors_lr,
                            net_to_gross_lr,
                            k_zmiana,
                            ):
        latest = self.vector_reverse_diagonal_to_script(data_paid)

        return run_simulation_addcl_numba_batched(    
                            data_paid,
                            sigma_j, 
                            dev,
                            sd,
                            wagi_trimmed,
                            wykluczenia,
                            Poz_CL,
                            il_ogon_CL,
                            sigma_j_LR,
                            dev_LR,
                            sd_LR,
                            e_values,
                            wagi_trimmed_LR,
                            ilosc_dop_wsp_LR,
                            Poz_LR,
                            il_ogon_LR,
                            ultimate_param_resrisk,
                            sim_total_lr,
                            batch_sim_lr,
                            main_seed_lr,
                            discount_factors_lr,
                            net_to_gross_lr,
                            k_zmiana,)