from datetime import datetime
from typing import Dict, List, Optional
from pydantic import AliasChoices, BaseModel, Field, ConfigDict, field_validator, model_validator


# ---------- Request ----------

class CalculationOptions(BaseModel):
    brutto: bool
    brutto_dysk: bool
    netto_dysk: bool


class ExecuteChangeMethodRequest(BaseModel):
    """
    Payload z frontu dla:
    POST /calc_change_method/execute_calculations
    """
    model_config = ConfigDict(extra='forbid')

    user_id: str = Field(..., min_length=1)
    paid_triangle: List[List[Optional[float]]]
    selected_value_cl: List[float] = Field(..., min_length=1)
    selected_value_lr: List[float] = Field(..., min_length=1)
    ekspozycja: List[Optional[float]]
    k_change: float
    discount_rates: Dict[str, Dict[str, float]]
    netto_dysk: Dict[str, Dict[str, float]]
    calculation_options: CalculationOptions

    @field_validator('paid_triangle')
    @classmethod
    def validate_paid_triangle(cls, value: List[List[Optional[float]]]):
        if len(value) == 0:
            raise ValueError('paid_triangle nie może być pusty')
        if not all(isinstance(row, list) for row in value):
            raise ValueError('paid_triangle musi być listą list')
        return value



class CalculationOptions(BaseModel):
    brutto: bool
    brutto_dysk: bool
    netto_dysk: bool


class ExecutePaidToIncurredRequest(BaseModel):
    # lekkie podejście: bez custom validatorów
    model_config = ConfigDict(extra='forbid', populate_by_name=True)

    user_id: str = Field(..., min_length=1)

    paid_triangle: Optional[List[List[Optional[float]]]] = None
    incurred_triangle: Optional[List[List[Optional[float]]]] = None
    incurred_triangle_bez_inf: Optional[List[List[Optional[float]]]] = None

    selected_value_cl: List[float] = Field(..., min_length=1)
    selected_value_lr: List[float] = Field(..., min_length=1)

    r_i_calculated: List[Optional[float]] = Field(
        ...,
        validation_alias=AliasChoices('r_i_calculated', 'rJPaidToIncurred')
    )
    var_j_calculated: List[Optional[float]] = Field(
        ...,
        validation_alias=AliasChoices('var_j_calculated', 'varJPaidToIncurred')
    )

    r_i_final: List[Optional[float]] = Field(
        ...,
        validation_alias=AliasChoices(
            'r_i_final',
            'selectedValuesRJPaidToIncurred',
            'combinedRPaidToIncurredSummary'
        )
    )
    var_j_final: List[Optional[float]] = Field(
        ...,
        validation_alias=AliasChoices(
            'var_j_final',
            'selectedValuesVarJPaidToIncurred',
            'combinedVarJPaidToIncurredSummary'
        )
    )

    weights: Optional[List[Optional[float]]] = Field(
        default=None,
        validation_alias=AliasChoices('weights', 'weights_rj_incurred')
    )

    ekspozycja: List[Optional[float]]
    discount_rates: Dict[str, Dict[str, float]]
    netto_dysk: Dict[str, Dict[str, float]]
    k_change: float
    calculation_options: CalculationOptions

# ---------- Response ----------

class DeterministicResults(BaseModel):
    """
    Zwracane wyniki obliczeń deterministycznych.
    """
    model_config = ConfigDict(
        extra='forbid',
        populate_by_name=True
    )

    cum_trian: List[float]
    last_col: List[float]
    ult_net_disc: List[float]
    user_id: str = Field(..., alias='userId')   # backend używa user_id, frontend może dalej dostać userId
    calculated_at: datetime = Field(..., alias='calculatedAt')


# ---------- Opcjonalny wrapper API ----------

class ExecuteChangeMethodResponse(BaseModel):
    status: str = 'ok'
    data: DeterministicResults
    message: Optional[str] = None