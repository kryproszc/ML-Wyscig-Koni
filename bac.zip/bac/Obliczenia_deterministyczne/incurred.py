from fastapi import APIRouter, HTTPException
import numpy as np
import logging
from .models import ExecutePaidToIncurredRequest
from cl_simulator import YearHorizont2

router = APIRouter()
yh2 = YearHorizont2()
logger = logging.getLogger(__name__)


@router.post("/calc_change_method/execute_calculations_incurred")
async def execute_change_method_incurred(request: ExecutePaidToIncurredRequest):
	logger.info("[INCURRED] Otrzymany payload: %s", request.model_dump())
	data_paid = np.array(request.paid_triangle, dtype=float) if request.paid_triangle is not None else None

	if request.incurred_triangle is not None:
		data = np.array(request.incurred_triangle, dtype=float)
		triangle_source_name = "incurred_triangle"
	elif request.incurred_triangle_bez_inf is not None:
		data = np.array(request.incurred_triangle_bez_inf, dtype=float)
		triangle_source_name = "incurred_triangle_bez_inf"
	else:
		data = data_paid
		triangle_source_name = "paid_triangle"

	if data is None:
		raise HTTPException(status_code=422, detail="Brak danych trójkąta: przekaż incurred_triangle, incurred_triangle_bez_inf albo paid_triangle")

	f = np.array(request.selected_value_cl, dtype=float)
	lr = np.array(request.selected_value_lr, dtype=float)
	r_j = np.array(request.r_i_final, dtype=float)
	exposure = np.array(request.ekspozycja, dtype=float)
	k_change = int(request.k_change)

	if not request.discount_rates or not any(request.discount_rates.values()):
		discount_factors = np.ones(len(f), dtype=float)
	else:
		discount_values = [
			v for k, v in request.discount_rates[next(iter(request.discount_rates))].items()
			if k != "0" and v is not None
		]
		if not discount_values:
			discount_factors = np.ones(len(f), dtype=float)
		else:
			discount_factors = np.array(discount_values, dtype=float)

	if not request.netto_dysk or not any(request.netto_dysk.values()):
		net_to_gross = np.ones(data.shape[0], dtype=float)
	else:
		netto_dysk_values = [
			v for k, v in request.netto_dysk[next(iter(request.netto_dysk))].items()
			if k != "0" and v is not None
		]
		if not netto_dysk_values:
			net_to_gross = np.ones(data.shape[0], dtype=float)
		else:
			net_to_gross = np.array(netto_dysk_values, dtype=float)


	ult_det = yh2.triangle_forward_incurred_change(
		data,
		data_paid,
		f,
		lr,
		r_j,
		exposure,
		k_change,
		discount_factors,
		net_to_gross
	)

	return {
		"status": "ok",
		"vectors": {
			"last_col": np.array(ult_det["last_col"]).tolist(),
			"cum_trian": np.array(ult_det["cum_trian"]).tolist(),
			"ult_net_disc": np.array(ult_det["ult_net_disc"]).tolist(),
		},
	}
