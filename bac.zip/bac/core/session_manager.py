from typing import Dict


class UserSession:
    def __init__(self, user_id: str):
        self.user_id = user_id
        self.simulations: Dict[str, Dict] = {}

    def save_simulation(self, request_id: str, sim, diff, latest, quantiles_result=None):
        self.simulations[request_id] = {
            "sim": sim,
            "diff": diff,
            "latest": latest,
            "quantiles": quantiles_result
        }

    def get_simulation(self, request_id: str):
        return self.simulations.get(request_id)


class SessionManager:
    def __init__(self):
        self.sessions: Dict[str, UserSession] = {}

    def get_session(self, user_id: str) -> UserSession:
        if user_id not in self.sessions:
            self.sessions[user_id] = UserSession(user_id)
        return self.sessions[user_id]


# Globalna instancja
SESSIONS = SessionManager()