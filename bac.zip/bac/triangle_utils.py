import pandas as pd
import numpy as np

class TriangleCalculator_det:
    def __init__(self):
        pass  # nie trzymamy danych na starcie, tylko czekamy na dane wejściowe
     
    def get_r2_numpy_manual(self, x, y):
        zx = (x - np.mean(x)) / np.std(x, ddof=1)
        zy = (y - np.mean(y)) / np.std(y, ddof=1)
        r = np.sum(zx * zy) / (len(x) - 1)
        return r ** 2

    def r2_curves(self, f_curves, y_input):
        r2_value = pd.DataFrame(np.nan, index=['Wartość'], columns=f_curves.index)

        k = 0
        for row in f_curves.index:

            if (row == "Exponential"):
                r2 = self.get_r2_numpy_manual(np.log(y_input - 1), np.log(f_curves.loc[row] - 1))
                r2_value.iloc[0, k] = r2

            elif (row == "Weibull"):
                r2 = self.get_r2_numpy_manual(
                    np.log(np.log(y_input / (y_input - 1))),
                    np.log(np.log(f_curves.loc[row] / (f_curves.loc[row] - 1)))
                )
                r2_value.iloc[0, k] = r2

            elif (row == "Power"):
                r2 = self.get_r2_numpy_manual(
                    np.log(np.log(y_input)),
                    np.log(np.log(f_curves.loc[row]))
                )
                r2_value.iloc[0, k] = r2

            elif (row == "Inverse Power"):
                r2 = self.get_r2_numpy_manual(
                    np.log(y_input - 1),
                    np.log(f_curves.loc[row] - 1)
                )
                r2_value.iloc[0, k] = r2

            k = k + 1

        return (r2_value)

    def curve_predict(self, x, a, b, c, curve):
        if curve == 'Exponential':
            y_fit = 1 + a * np.exp(b * x)
        elif curve == 'Weibull':
            y_fit = 1 / (1 - np.exp(-a * x ** b))
            # y_fit = 1 + a * x ** (a - 1) * np.exp(-(x ** a))  # alternatywna wersja zakomentowana
        elif curve == 'Power':
            y_fit = a ** (b ** x)
        elif curve == 'Inverse Power':
            y_fit = 1 + a * (c + x) ** b
        return y_fit

    def parameters_curve_reservoir(self, xs, ys, lista_krzywych):
        # Inicjalizacja DataFrame na wyniki
        parametry = pd.DataFrame(np.nan, index=lista_krzywych, columns=['a', 'b', 'c'])

        for krzywa in lista_krzywych:
            if krzywa == 'Exponential':
                param = np.polyfit(xs, np.log(ys - 1), deg=1)
                parametry.loc['Exponential', ['a', 'b']] = param

            elif krzywa == 'Weibull':
                param = np.polyfit(np.log(xs), np.log(np.log(ys / (ys - 1))), deg=1)
                parametry.loc['Weibull', ['a', 'b']] = param

            elif krzywa == 'Power':
                param = np.polyfit(xs, np.log(np.log(ys)), deg=1)
                parametry.loc['Power', ['a', 'b']] = param

            elif krzywa == 'Inverse Power':
                best_r2 = -np.inf
                best_param = None

                for c in [-0.5, 1, 3, 5]:
                    param = np.polyfit(np.log(xs + c), np.log(ys - 1), deg=1)
                    y_pred = self.curve_predict(xs, np.exp(param[1]), param[0], c, curve='Inverse Power')
                    r2 = self.get_r2_numpy_manual(np.log(ys - 1), np.log(y_pred))

                    if r2 > best_r2:
                        best_r2 = r2
                        best_param = list(param) + [c]

                parametry.loc['Inverse Power'] = best_param

        return parametry

    def sim_data_curve_rezerwy(self, x, lista_krzywych, parameters_curve_num):
        factor_value = pd.DataFrame(np.nan, index=lista_krzywych,
                                    columns=['dp: ' + str(j) for j in range(1, len(x) + 1)])

        for l_curve in lista_krzywych:
            if l_curve == 'Exponential':
                param = parameters_curve_num.loc['Exponential'][0:2]
                y = self.curve_predict(x, np.exp(param.iloc[1]), param.iloc[0], c=0, curve='Exponential')
                factor_value.loc['Exponential'] = y

            elif l_curve == 'Weibull':
                param = parameters_curve_num.loc['Weibull'][0:2]
                y = self.curve_predict(x, np.exp(param.iloc[1]), param.iloc[0], c=0, curve='Weibull')
                factor_value.loc['Weibull'] = y

            elif l_curve == 'Power':
                param = parameters_curve_num.loc['Power'][0:2]
                y = self.curve_predict(x, np.exp(np.exp(param.iloc[1])), np.exp(param.iloc[0]), c=0, curve='Power')
                factor_value.loc['Power'] = y

            elif l_curve == 'Inverse Power':
                param = parameters_curve_num.loc['Inverse Power']
                y = self.curve_predict(x, np.exp(param.iloc[1]), param.iloc[0], param.iloc[2], curve='Inverse Power')
                factor_value.loc['Inverse Power'] = y

        return factor_value
    
    
    def get_r2_numpy_manual(self, x, y):
        zx = (x - np.mean(x)) / np.std(x, ddof=1)
        zy = (y - np.mean(y)) / np.std(y, ddof=1)
        r = np.sum(zx * zy) / (len(x) - 1)
        return r ** 2

    def r2_curves(self, f_curves, y_input):
        r2_value = pd.DataFrame(np.nan, index=['Wartość'], columns=f_curves.index)

        k = 0
        for row in f_curves.index:

            if (row == "Exponential"):
                r2 = self.get_r2_numpy_manual(np.log(y_input - 1), np.log(f_curves.loc[row] - 1))
                r2_value.iloc[0, k] = r2

            elif (row == "Weibull"):
                r2 = self.get_r2_numpy_manual(
                    np.log(np.log(y_input / (y_input - 1))),
                    np.log(np.log(f_curves.loc[row] / (f_curves.loc[row] - 1)))
                )
                r2_value.iloc[0, k] = r2

            elif (row == "Power"):
                r2 = self.get_r2_numpy_manual(
                    np.log(np.log(y_input)),
                    np.log(np.log(f_curves.loc[row]))
                )
                r2_value.iloc[0, k] = r2

            elif (row == "Inverse Power"):
                r2 = self.get_r2_numpy_manual(
                    np.log(y_input - 1),
                    np.log(f_curves.loc[row] - 1)
                )
                r2_value.iloc[0, k] = r2

            k = k + 1

        return (r2_value)

    def triangle_forward(self, df_data, f, k_forward_start):
        df_t = df_data.copy()
        data = df_t.values  # numpy array for speed
        m, n = data.shape

        max_len = len(f) + 1
        if max_len > n:
            # dodaj nowe kolumny jeśli trzeba
            extra_cols = max_len - n
            data = np.hstack((data, np.full((m, extra_cols), np.nan)))

        for j in range(k_forward_start - 1, len(f)):
            col_from = data[:, j]
            col_to = data[:, j + 1]
            start_row = max(0, m - j - 1)
            data[start_row:, j + 1] = col_from[start_row:] * f[j]

        col_names = list(df_data.columns) + [f'proj_{i}' for i in range(n, data.shape[1])]
        return pd.DataFrame(data, columns=col_names)
    
    def triangle_forward_np(self, data, f, k_forward_start, discount_factors, net_to_gross):
        data = data.copy()
        mm, nn = data.shape

        latest = self.vector_reverse_diagonal_to_script(data)
        base_col = data[:, 0].copy()

        # dopaduj kolumny, jeśli trójkąt jest za krótki względem długości f
        if len(f) > mm:
            pad_width = len(f) + 1 - nn
            if pad_width > 0:
                data = np.hstack((data, np.full((mm, pad_width), np.nan)))

        # projekcja do przodu: wypełnianie kolejnych kolumn czynnikiem f
        for j in range(k_forward_start - 1, len(f)):
            max_ind_row = max(0, mm - j - 1)
            for i in range(max_ind_row, mm):
                data[i, j + 1] = data[i, j] * f[j]

        cols_tmp = data.shape[1]

        # budowa macierzy projekcji i przyrostów
        tri_proj = np.full((mm, cols_tmp + 1), np.nan)
        tri_proj[:, 0] = base_col
        tri_proj[:, 1:] = data

        inc_proj = tri_proj[:, 1:] - tri_proj[:, :-1]
        inc_proj[:, 0] = base_col

        for rr in range(mm - 1, -1, -1):
            offset = mm - 1 - rr
            for cc in range(offset + 1, inc_proj.shape[1]):
                idx = cc - (offset + 1)
                if idx < len(discount_factors) and not np.isnan(inc_proj[rr, cc]):
                    inc_proj[rr, cc] /= discount_factors[idx]

        cum_trian = np.nansum(inc_proj, axis=1)
        total_disc = np.sum(cum_trian)

        ult_net_disc = 0.0
        for i in range(len(latest)):
            ult_net_disc += latest[i] + (cum_trian[i] - latest[i]) * net_to_gross[i]

        return [np.sum(data[:, -1]), total_disc, ult_net_disc]


    ############## krzywe wazone

    def wsp_w_k_sqr(self, f_input, se_factor, dopasowanie, n):
        if dopasowanie == 'factor_CL':
            w_k_sqr = [
                1 / np.sqrt(np.log(1 + ((se_f_k) / (f_k - 1) ** 2)))
                for f_k, se_f_k in zip(f_input, se_factor)
            ]
        elif dopasowanie == 'variance_CL':
            w_k_sqr = [n - k for k in range(1, len(f_input) + 1)]
        elif dopasowanie == 'factor_P_to_I':
            w_k_sqr = [1] * (len(f_input) + 1)
        elif dopasowanie == 'variance_P_to_I':
            w_k_sqr = [1] * (len(f_input))
        elif dopasowanie == 'factor_LR':
            w_k_sqr = [
                1 / np.sqrt(np.log(1 + ((se_f_k) / (f_k) ** 2)))
                for f_k, se_f_k in zip(f_input, se_factor)
            ]
        elif dopasowanie == 'variance_LR':
            w_k_sqr = [n - k for k in range(1, len(f_input) + 1)]
        else:
            w_k_sqr = []
        return w_k_sqr

    def fit_curve(self, data_input, sd_input, x_k, dopasowanie, n):
        se_factor = [x for x in sd_input[:len(data_input)]]
        w_k_sqr = self.wsp_w_k_sqr(data_input, se_factor, dopasowanie, n)
        if dopasowanie == 'factor_CL':
            factor_input = [np.log(f - 1) for f in data_input]
        elif dopasowanie == 'variance_CL':
            factor_input = [np.log(sigma) for sigma in data_input]
        elif dopasowanie == 'factor_P_to_I':
            factor_input = [np.log(1 - r_j) for r_j in data_input]
        elif dopasowanie == 'variance_P_to_I':
            factor_input = [np.log(var_j) for var_j in data_input]
        elif dopasowanie == 'factor_LR':
            factor_input = [np.log(f) for f in data_input]
        elif dopasowanie == 'variance_LR':
            factor_input = [np.log(f) for f in data_input]
        else:
            raise ValueError(f"Nieznane dopasowanie: {dopasowanie}")
        A = np.sum(w_k_sqr)
        A_x = np.sum([x * y for x, y in zip(w_k_sqr, x_k)])
        A_x_x = np.sum([x * (y ** 2) for x, y in zip(w_k_sqr, x_k)])
        A_y = np.sum([x * y for x, y in zip(w_k_sqr, factor_input)])
        A_x_y = np.sum([x * y * z for x, y, z in zip(w_k_sqr, x_k, factor_input)])
        Delta = A * A_x_x - (A_x ** 2)
        a = (A * A_x_y - A_x * A_y) / Delta
        b = (A_x_x * A_y - A_x * A_x_y) / Delta
        return [a, b]

    def wspolczynnik_reg(self, a, b, zakres_zmiennych_x, dopasowanie):
        if dopasowanie == 'factor_CL':
            wartosci_reg = [1 + np.exp(a * k + b) for k in zakres_zmiennych_x]
        elif dopasowanie == 'variance_CL':
            wartosci_reg = [np.exp(a * k + b) for k in zakres_zmiennych_x]
        elif dopasowanie == 'factor_P_to_I':
            wartosci_reg = [1 - np.exp(a * k + b) for k in zakres_zmiennych_x]
        elif dopasowanie == 'variance_P_to_I':
            wartosci_reg = [np.exp(a * k + b) for k in zakres_zmiennych_x]
        elif dopasowanie == 'factor_LR':
            wartosci_reg = [np.exp(a * k + b) for k in zakres_zmiennych_x]
        elif dopasowanie == 'variance_LR':
            wartosci_reg = [np.exp(a * k + b) for k in zakres_zmiennych_x]
        else:
            raise ValueError(f"Nieznane dopasowanie: {dopasowanie}")
        return wartosci_reg
    

    def oblicz_se_factor_CL(self,f_input, f_reg, w_k_sqr, a, b, x_k,m):

        sigma2_hat = (
            np.sum([
                w * (np.log(f - 1) - np.log(f_r - 1))**2
                for f, f_r, w in zip(f_input, f_reg, w_k_sqr)
            ]) / (m - 2-2)   # <- kluczowa zmiana: m-2, nie n-4
        )

        # 2. Obliczenie sum pomocniczych
        A = np.sum(w_k_sqr)
        A_x = np.sum([w * x for w, x in zip(w_k_sqr, x_k)])
        A_xx = np.sum([w * x**2 for w, x in zip(w_k_sqr, x_k)])
        Delta = A * A_xx - (A_x ** 2)

        # 3. Wariancje i kowariancje parametrów
        Var_a = sigma2_hat * A / Delta
        Cov_ab = -sigma2_hat * A_x / Delta
        Var_b = sigma2_hat * A_xx / Delta

        # 4. Standard error dla każdego f_k^reg
        se_values = []
        for k, f_r in zip(x_k, f_reg):
            se = (f_r - 1) * np.sqrt(
                np.exp(k**2 * Var_a + 2 * k * Cov_ab + Var_b) - 1
            )
            se_values.append(se)

        return se_values, sigma2_hat, Var_a, Cov_ab, Var_b

    def se_for_future_k(self,a, b, Var_a, Cov_ab, Var_b, k_vec):
        k = np.asarray(k_vec, dtype=float)

        f_reg = 1.0 + np.exp(a * k + b)

        # wariancja liniowej kombinacji (stabilnie numerycznie)
        tau = k**2 * Var_a + 2.0 * k * Cov_ab + Var_b
        tau = np.maximum(tau, 0.0)         # obcięcie na wypadek -1e-12
        g = np.expm1(tau)                  # exp(tau) - 1 (dokładniejsze)
        g = np.maximum(g, 0.0)

        se_param = (f_reg - 1.0) * np.sqrt(g)
        return f_reg, se_param


    def oblicz_se_factor_LR(self, l_input, l_reg, w_k_sqr, a, b, x_k, m):

        # 1. Estymacja wariancji reszt na skali log
        sigma2_hat = (
            np.sum([
                w * (np.log(l) - np.log(l_r))**2
                for l, l_r, w in zip(l_input, l_reg, w_k_sqr)
            ]) / (m - 4)   # df = liczba obserwacji - 2
        )

        # 2. Sumy pomocnicze
        A = np.sum(w_k_sqr)
        A_x = np.sum([w * x for w, x in zip(w_k_sqr, x_k)])
        A_xx = np.sum([w * x**2 for w, x in zip(w_k_sqr, x_k)])
        Delta = A * A_xx - (A_x ** 2)

        # 3. Wariancje i kowariancja parametrów
        Var_a = sigma2_hat * A / Delta
        Cov_ab = -sigma2_hat * A_x / Delta
        Var_b = sigma2_hat * A_xx / Delta

        # 4. SE dla l_k^reg
        se_values = []
        for k, l_r in zip(x_k, l_reg):
            tau = k**2 * Var_a + 2 * k * Cov_ab + Var_b
            se = l_r * np.sqrt(np.exp(tau) - 1)
            se_values.append(se)

        return se_values, sigma2_hat, Var_a, Cov_ab, Var_b


    def se_for_LR_future_k(self, a, b, Var_a, Cov_ab, Var_b, k_vec):

        k = np.asarray(k_vec, dtype=float)

        # LR z regresji
        l_reg = np.exp(a * k + b)

        # wariancja kombinacji liniowej
        tau = k**2 * Var_a + 2.0 * k * Cov_ab + Var_b
        tau = np.maximum(tau, 0.0)      # zabezpieczenie numeryczne

        g = np.expm1(tau)               # exp(tau) - 1 (stabilniej)
        g = np.maximum(g, 0.0)

        se_param = l_reg * np.sqrt(g)
        print(l_reg)
        return l_reg, se_param


    def se_total_for_future_k(self,a, b, Var_a, Cov_ab, Var_b, k_vec,
                            a_sig=None, b_sig=None, D_last=None):
        import numpy as np
        k = np.asarray(k_vec, dtype=float)

        f_reg, se_param = self.se_for_future_k(a, b, Var_a, Cov_ab, Var_b, k)

        if (a_sig is None) or (b_sig is None) or (D_last is None):
            # tylko komponent parametryczny
            return f_reg, se_param

        sigma_reg = np.exp(a_sig * k + b_sig)   # z regresji wariancji
        var_proc = sigma_reg / float(D_last)    # przyjęte założenie
        var_param = se_param**2

        se_total = np.sqrt(var_param + var_proc)
        return f_reg, se_total



# ==== DLA SIGMA (malejąca >0) ====

    def curve_predict_sigma(self, x, A, B=None, C=None, K=None, curve='Exponential'):
        """
        Predykcja σ(x) > 0, malejącej do 0.
        """
        x = np.asarray(x, dtype=float)

        if curve == 'Exponential':
            # sigma(x) = A * exp(B*x), B<0
            return A * np.exp(B * x)

        elif curve == 'Weibull':
            # sigma(x) = A * exp(-(x/C)^K), C>0, K>0
            if C is None or K is None:
                raise ValueError("Weibull wymaga parametrów C>0 i K>0.")
            return A * np.exp(- (x / C) ** K)

        elif curve == 'Power':
            # sigma(x) = A * x^B, B<0, x>0
            if np.any(x <= 0):
                raise ValueError("Power dla sigma wymaga x > 0.")
            return A * (x ** B)

        elif curve == 'Inverse Power':
            # sigma(x) = A * (x + C)^B, B<0, x+C>0
            if C is None:
                raise ValueError("Inverse Power wymaga parametru C.")
            if np.any(x + C <= 0):
                raise ValueError("Inverse Power wymaga x + C > 0 dla wszystkich x.")
            return A * (x + C) ** B

        else:
            raise ValueError(f"Nieznana krzywa: {curve}")

    def parameters_curve_sigma(self, xs, sigmas, lista_krzywych,
                            K_grid=None, C_grid=None, eps=1e-12):
        """
        Estymacja parametrów dla σ>0 metodą liniaryzacji w log-skali.
        Zwraca DataFrame z kolumnami ['a','b','c','k'] (nieużywane = NaN).
        """
        xs = np.asarray(xs, dtype=float)
        sigmas = np.asarray(sigmas, dtype=float)
        if np.any(sigmas <= 0):
            raise ValueError("Wszystkie sigma muszą być > 0.")

        if K_grid is None:
            K_grid = np.array([0.7, 1.0, 1.3, 1.6, 2.0], dtype=float)

        if C_grid is None:
            xmin = np.min(xs)
            C_min = -xmin + 1e-6  # zapewnia xs + C > 0
            C_grid = np.array([C_min, 0.0, 0.5, 1.0, 3.0, 5.0], dtype=float)

        Y = np.log(np.maximum(sigmas, eps))
        parametry = pd.DataFrame(np.nan, index=lista_krzywych, columns=['a', 'b', 'c', 'k'])

        for krzywa in lista_krzywych:
            if krzywa == 'Exponential':
                # log(sigma) = log A + B * x
                b, a0 = np.polyfit(xs, Y, deg=1)   # slope, intercept
                A = np.exp(a0); B = b
                parametry.loc['Exponential', ['a', 'b']] = [A, B]

            elif krzywa == 'Power':
                # log(sigma) = log A + B * log x  (x>0)
                if np.any(xs <= 0):
                    raise ValueError("Power dla sigma wymaga xs > 0.")
                X = np.log(xs)
                b, a0 = np.polyfit(X, Y, deg=1)
                A = np.exp(a0); B = b
                parametry.loc['Power', ['a', 'b']] = [A, B]

            elif krzywa == 'Inverse Power':
                # log(sigma) = log A + B * log(x + C)  (grid po C)
                best = None
                for C in C_grid:
                    if np.any(xs + C <= 0):
                        continue
                    Xc = np.log(xs + C)
                    b, a0 = np.polyfit(Xc, Y, deg=1)
                    A = np.exp(a0); B = b
                    y_hat = self.curve_predict_sigma(xs, A, B=B, C=C, curve='Inverse Power')
                    r2 = self.get_r2_numpy_manual(np.log(sigmas), np.log(np.maximum(y_hat, eps)))
                    if (best is None) or (r2 > best['r2']):
                        best = dict(A=A, B=B, C=C, r2=r2)
                if best is not None:
                    parametry.loc['Inverse Power', ['a', 'b', 'c']] = [best['A'], best['B'], best['C']]

            elif krzywa == 'Weibull':
                # log(sigma) = log A + beta * x^K,  beta=-(1/C^K) < 0
                best = None
                for K in K_grid:
                    Xk = xs ** K
                    beta, a0 = np.polyfit(Xk, Y, deg=1)   # Y = a0 + beta * Xk
                    if beta >= 0:
                        continue  # chcemy spadek
                    A = np.exp(a0)
                    C = (-1.0 / beta) ** (1.0 / K)
                    y_hat = self.curve_predict_sigma(xs, A, C=C, K=K, curve='Weibull')
                    r2 = self.get_r2_numpy_manual(np.log(sigmas), np.log(np.maximum(y_hat, eps)))
                    if (best is None) or (r2 > best['r2']):
                        best = dict(A=A, C=C, K=K, r2=r2)
                if best is not None:
                    parametry.loc['Weibull', ['a', 'c', 'k']] = [best['A'], best['C'], best['K']]

            else:
                raise ValueError(f"Nieznana krzywa: {krzywa}")

        return parametry

    def sim_data_curve_sigma(self, x, lista_krzywych, parameters_curve_sigma, eps=1e-12):
        """
        Generuje wartości σ(x) dla dopasowanych parametrów.
        Zwraca DataFrame: wiersze = krzywe, kolumny = 'dp: i'.
        """
        x = np.asarray(x, dtype=float)
        sigma_value = pd.DataFrame(np.nan, index=lista_krzywych,
                                columns=[f'dp: {j}' for j in range(1, len(x) + 1)])

        for l_curve in lista_krzywych:
            p = parameters_curve_sigma.loc[l_curve]
            if l_curve == 'Exponential':
                y = self.curve_predict_sigma(x, A=p['a'], B=p['b'], curve='Exponential')
            elif l_curve == 'Power':
                y = self.curve_predict_sigma(x, A=p['a'], B=p['b'], curve='Power')
            elif l_curve == 'Inverse Power':
                y = self.curve_predict_sigma(x, A=p['a'], B=p['b'], C=p['c'], curve='Inverse Power')
            elif l_curve == 'Weibull':
                y = self.curve_predict_sigma(x, A=p['a'], C=p['c'], K=p['k'], curve='Weibull')
            else:
                raise ValueError(f"Nieznana krzywa: {l_curve}")

            sigma_value.loc[l_curve] = np.maximum(y, eps)

        return sigma_value

    def r2_curves_sigma(self, sigma_pred_df, sigma_obs, eps=1e-12):
        """
        R^2 (tu: ρ^2) w log-skali między obserwowaną σ a predykcjami.
        sigma_pred_df: wiersze = krzywe, kolumny = dp: ...
        sigma_obs: wektor σ_observed dla tych samych x.
        """
        sigma_obs = np.asarray(sigma_obs, dtype=float)
        if np.any(sigma_obs <= 0):
            raise ValueError("Wszystkie sigma_obs muszą być > 0.")
        log_obs = np.log(np.maximum(sigma_obs, eps))

        r2_value = pd.DataFrame(np.nan, index=['Wartość'], columns=sigma_pred_df.index)

        for i, row in enumerate(sigma_pred_df.index):
            pred = np.asarray(sigma_pred_df.loc[row].values, dtype=float)
            log_pred = np.log(np.maximum(pred, eps))
            r2 = self.get_r2_numpy_manual(log_obs, log_pred)
            r2_value.iloc[0, i] = r2

        return r2_value
