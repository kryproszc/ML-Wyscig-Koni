from fastapi import APIRouter
import pandas as pd
import numpy as np
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from .models import InflationRequest, InflationRequestIncurred, InflationRequestExposure
from ad_function import YearHorizont

router = APIRouter()
yh = YearHorizont()


@router.post("/calc/paid/inflation")
async def apply_inflation(request: InflationRequest):
    reserv_dat = pd.DataFrame(request.triangle)
    print(reserv_dat)
    incremental_paid = yh.incremental_triangle(reserv_dat)
    inflation = request.inflationVector
    print(inflation)
    past_inf = inflation[:-2]
    future_inf = inflation[-1]
    # inflacja na trojkat (inflation on triangle)
    inflation_adjustment = yh.calculate_inflation_adjustment(past_inf, future_inf)
    inc_inf = yh.incrementa_with_inflation(incremental_paid, inflation_adjustment)
    reserv_data = inc_inf.cumsum(axis=1)
    reserv_data = reserv_data.to_numpy(dtype=np.float64)
    
    # Convert numpy array to list with proper null handling
    result_list = reserv_data.tolist()
    
    # Replace NaN and infinity with None (which becomes null in JSON)
    def clean_value(val):
        if isinstance(val, list):
            return [clean_value(v) for v in val]
        if pd.isna(val) or np.isinf(val):
            return None
        return val
    
    cleaned_result = clean_value(result_list)
    
    print(reserv_data)
    return {
        "success": True,
        "adjustedTriangle": cleaned_result
    }



@router.post("/calc/incurred/inflation")
async def apply_inflationincurred(request: InflationRequestIncurred):
    # Odbieranie danych z requesta
    user_id = request.user_id
    triangle_paid = pd.DataFrame(request.triangle_paid)
    triangle_reserved = pd.DataFrame(request.triangle_reserved)

    inflation = request.inflationVector
    past_inf = inflation[:-2]
    future_inf = inflation[-1]

    incremental_paid = yh.incremental_triangle(triangle_paid)
     
    # inflacja na trojkat (inflation on triangle)
    inflation_adjustment = yh.calculate_inflation_adjustment(past_inf, future_inf)  
    print(inflation_adjustment)
    inc_inf_paid = yh.incrementa_with_inflation(incremental_paid, inflation_adjustment)
    inc_inf_reserved = yh.incrementa_with_inflation(triangle_reserved, inflation_adjustment)

    padi_inf = inc_inf_paid.cumsum(axis=1)
    incurred_trian = padi_inf.add(inc_inf_reserved)
    incurred_input = incurred_trian.to_numpy(dtype=np.float64)
    
    # Convert numpy array to list with proper null handling
    result_list = incurred_input.tolist()
 
    # Replace NaN and infinity with None (which becomes null in JSON)
    def clean_value(val):
        if isinstance(val, list):
            return [clean_value(v) for v in val]
        if pd.isna(val) or np.isinf(val):
            return None
        return val
    
    cleaned_result = clean_value(result_list)
    #print(pd.DataFrame(cleaned_result))
    return {
        "success": True,
        "adjustedTriangle": cleaned_result
    }


@router.post("/calc/exposure/inflation")
async def apply_inflation_exposure(request: InflationRequestExposure):
    """
    Endpoint to apply inflation adjustment with exposure vector
    """
    # Odbieranie danych z requesta
    user_id = request.user_id
    inflation = request.inflationVector

    past_inf = inflation[:-2]
    future_inf = inflation[-1]
    inflation_adjustment = yh.calculate_inflation_adjustment(past_inf, future_inf) 
    exposure = request.exposureVector 
    print(exposure)
    print(inflation_adjustment)
    exposure_inf = [x*y for x,y in zip(exposure, inflation_adjustment)]
    print(exposure_inf)
    return {
        "success": True,
        "adjustedExposure": exposure_inf,
        "user_id": user_id
    }



